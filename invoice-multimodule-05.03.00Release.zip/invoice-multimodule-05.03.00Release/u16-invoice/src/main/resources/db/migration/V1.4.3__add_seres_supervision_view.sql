create index idx_seres_replay_invoice_number on seres_replay (invoice_number);
create index idx_seres_replay_error_date on seres_replay (error_date);
create index idx_seres_replay_error_code on seres_replay (error_code);
CREATE OR REPLACE VIEW `seres_replay_supervision` AS
SELECT
    `sr`.`id` AS `id`,
    `sr`.`invoice_number` AS `invoice_number`,
    `sr`.`error_date` AS `error_date`,
    `sr`.`error_code` AS `error_code`,
    `sr`.`error_message` AS `error_message`,
    `sr`.`invoice_url` AS `invoice_url`,
    CASE WHEN (JSON_EXTRACT(`inv_mes`.`message`, "$.invoiceHeader.printFlag")=true)
             THEN 1
         ELSE 0
        END AS `print_flag`
FROM
    `seres_replay` `sr` LEFT JOIN `invoice` `inv` ON `sr`.`invoice_number` = `inv`.`invoice_number`
                        LEFT JOIN `invoice_message` `inv_mes` ON `inv`.`id_invoice` = `inv_mes`.`id_invoice`