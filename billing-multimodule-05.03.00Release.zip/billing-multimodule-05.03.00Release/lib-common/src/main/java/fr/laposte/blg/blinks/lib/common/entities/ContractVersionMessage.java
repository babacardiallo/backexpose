package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("contract_version_message")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ContractVersionMessage {
    @Id
    @Column("id_contract_version_message")
    private Long idContractVersionMessage;

    @Column("id_contract_version")
    private Long idContractVersion;

    @Column("contract_version_information")
    private String contractVersionInformation;

    @Column("contract_consolidated")
    private String contractConsolidated;

    @Column("contract_odc")
    private String odcContract;


}
