package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionDetailsEntity;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ContractSupervisionDetailsRepository extends ReactiveCrudRepository<ContractSupervisionDetailsEntity, String> {

    Flux<ContractSupervisionDetailsEntity> findAllByContractNumberAndAmendmentNumber(@Param("contractNumber") String contractNumber, @Param("amendmentNumber") Integer amendmentNumber);
    Mono<ContractSupervisionDetailsEntity> findFirstByContractNumberAndAmendmentNumber(@Param("contractNumber") String contractNumber, @Param("amendmentNumber") Integer amendmentNumber);
}
