package fr.laposte.blg.blinks.u12.apim;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApimErrorDto implements Serializable {
    String error_description;
    String error;
}
