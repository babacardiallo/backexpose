# 🧭 Git Workflow – Projet Blinks Collector

## 🔀 Branches principales

| Branche | Rôle |
|---------|------|
| `develop` | Base de développement |
| `test` | Environnement de test (préprod) |
| `main` *(optionnelle)* | Historique des versions stables (production) |

---

## 🌱 Branches de travail

| Type | Nom conventionnel | Base |
|------|-------------------|------|
| Feature | `feat-xxxx` | `develop` |
| Fix / Hotfix | `fix-xxxx` ou `hotfix-xxxx` | `develop` ou `main` |

---

## 🧑‍💻 Développement d’une feature

```bash
git checkout develop
git pull origin develop
git checkout -b feat-1234-nouvelle-fonction
# ... développement ...
git add .
git commit -m "feat: ajout de la fonctionnalité 1234"
git push origin feat-1234-nouvelle-fonction
```

---

## 🧪 Tester une feature ou un fix

```bash
git checkout test
git pull origin test
git merge origin/feat-1234-nouvelle-fonction
git push origin test
```

> ✅ Cela déclenche un déploiement avec un tag `test`.

---

## 🚀 Déploiement d’une release

### 1. Rebase la branche sur `develop`

```bash
git checkout feat-1234-nouvelle-fonction
git pull origin develop --rebase
```

### 2. Merge vers `develop`

```bash
git checkout develop
git pull origin develop
git merge feat-1234-nouvelle-fonction
git push origin develop
```

> ✅ Cela déclenche un déploiement avec un tag `develop`.

---

## 🏷️ Création d’un tag de release

```bash
git checkout develop
git pull origin develop
git tag -a x.y.z -m "Release x.y.z"
git push origin x.y.z
```

> ✅ Cela déclenche un build et un déploiement avec une image Docker taguée `x.y.z`.

---

## 🐛 Hotfix en production

```bash
git checkout main
git pull origin main
git checkout -b hotfix-5678-correction-urgence
# ... correction ...
git add .
git commit -m "hotfix: correction critique"
git push origin hotfix-5678-correction-urgence
```

### Merge vers `develop` et `main`

```bash
git checkout develop
git pull origin develop
git merge hotfix-5678-correction-urgence
git push origin develop

git checkout main
git pull origin main
git merge hotfix-5678-correction-urgence
git push origin main
```

### Tag si nécessaire

```bash
git checkout main
git tag -a x.y.z -m "Hotfix x.y.z"
git push origin x.y.z
```

---

## ✅ Résumé visuel

```text
develop ──────┬───────────────▶ [tag develop]
              │
              ├─ feat-xxxx ──▶ test ──▶ [tag test]
              │                │
              │                └──────▶ merge vers develop
              │
              └───────────────▶ tag x.y.z
```

---