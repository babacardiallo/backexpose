package fr.laposte.blg.blinks.lib.common;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class BasicLibCommonTest {

    @Test
    void basicSanity() {
        assertTrue(true);
    }
}

