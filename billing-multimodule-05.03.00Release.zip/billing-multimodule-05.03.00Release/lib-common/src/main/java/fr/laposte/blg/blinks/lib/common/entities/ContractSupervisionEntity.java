package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;

import java.time.Instant;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ContractSupervisionEntity {

    @Id
    protected String id;

    @Column("contract_number")
    @NotBlank
    protected String contractNumber;

    @Column("id_contract")
    protected Long contractId;

    @Column ("amendment_number")
    protected Integer amendmentNumber;

    @Column ("revision_number")
    protected Integer revisionNumber;

    @Column("status")
    protected String status;

    @Column("substatus")
    protected String substatus;

    @Column("id_contract_version")
    protected Long idContractVersion;

    @Column("type")
    protected String type;

    @Column("subtype")
    protected String subtype;

    @Column("ops_code")
    protected String opsCode;

    @Column("ops_id")
    protected Long opsId;

    @Column("ops_label")
    protected String opsLabel;

    @Column("is_synchronized")
    protected Boolean isSynchronized;

    @Column("last_date_synchronization")
    protected Instant lastDateSynchronization;

    @Column("date_error")
    protected Instant dateError;

    @Column("first_error_date")
    protected Instant firstErrorDate;

    @Column("cust_acc_number")
    protected Integer custAccNumber;

    @Column("cust_acc_number_before_synchronisation")
    protected Integer custAccNumberBeforeSynchronisation;


}
