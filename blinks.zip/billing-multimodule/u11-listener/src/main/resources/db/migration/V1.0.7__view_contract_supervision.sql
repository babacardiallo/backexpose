CREATE OR REPLACE VIEW `contract_supervision` AS
    SELECT
        `co`.`contract_number` AS `contract_number`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `co`.`subtype` AS `subtype`,
        `vo`.`ops_code` AS `ops_code`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        `cv`.`date_synchronization` AS `date_synchronization`,
        MIN(`el`.`date_error`) AS `first_error_date`
    FROM
        (((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`el`.`workflow_step` LIKE '%SYNCHRONIZATION%'))))
    GROUP BY `co`.`contract_number` , `cv`.`amendment_number`;
