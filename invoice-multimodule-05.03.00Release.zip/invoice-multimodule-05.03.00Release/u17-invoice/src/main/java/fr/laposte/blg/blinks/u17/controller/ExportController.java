package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.service.DocaposteService;
import fr.laposte.blg.blinks.u17.service.CoeurfinanceService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import fr.laposte.blg.blinks.u17.service.RefcomRestService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@RestController
@RequestMapping("/export")
@OpenAPIDefinition(tags = {@Tag(name = "Export Runner")}, info = @Info(description = "permet de déclencher les exports de facture"))
@CrossOrigin
@Data
public class ExportController {

    private final CoeurfinanceService coeurfinanceService;

    private final DocaposteService docaposteService;

    private final InfocaInvoiceExportService infocaService;
    private final InvoiceRepository invoiceRepository;

    private final RefcomRestService refcomRestService;

    private AtomicBoolean isRunning = new AtomicBoolean(false);

    @PostMapping(value = "/coeurfinance/run")
    @Operation(
            summary = "Export Coeurfinance",
            description = "Service d'export des factures vers Coeurfinance")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> runCoeurfinanceExport(
            @RequestParam(required = false) Long minId,
            @RequestParam(required = false) Long maxId,
            @RequestParam(required = false) String exportPath
    ) {
        Long finalMinId = minId !=null ? minId : 1L;
        Long finalMaxId = maxId != null ? maxId : Long.MAX_VALUE;
        ExportProcess e = new ExportProcess();
        e.setMinId(finalMinId);
        e.setMaxId(finalMaxId);
        if (!isRunning.get()) {
            isRunning.set(true);
            Mono.fromRunnable(() -> coeurfinanceService.process(e, exportPath))
                    .subscribeOn(Schedulers.boundedElastic())
                    .doOnTerminate(() -> isRunning.set(false))
                    .subscribe();
            return ResponseEntity.accepted().body("Coeurfinance export started !");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("An coeurfinance export is already running. Please Wait ... ");
        }
    }


    @PostMapping(value = "/docaposte/run")
    @Operation(
            summary = "Export Docaposte",
            description = "Service d'export des factures vers Docaposte")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> runDocaposteExport(
            @RequestParam(required = false) Long minId,
            @RequestParam(required = false) Long maxId,
            @RequestParam(required = false) String exportPath
    ) {
        Long finalMinId = minId !=null ? minId : 1L;
        Long finalMaxId = maxId != null ? maxId : Long.MAX_VALUE;
        ExportProcess e = new ExportProcess();
        e.setMinId(finalMinId);
        e.setMaxId(finalMaxId);
        if (!isRunning.get()) {
            isRunning.set(true);
            Mono.fromRunnable(() -> docaposteService.process(e, exportPath))
                    .subscribeOn(Schedulers.boundedElastic())
                    .doOnTerminate(() -> isRunning.set(false))
                    .subscribe();
            return ResponseEntity.accepted().body("Docaposte export started !");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("A docaposte export is already running. Please Wait ... ");


        }

    }

    @PostMapping(value = "/infoca/run")
    @Operation(
            summary = "Export InfoCA",
            description = "Service d'export des factures vers InfoCA")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> runInfocaExport(
            @RequestParam(required = false) Long minId,
            @RequestParam(required = false) Long maxId,
            @RequestParam(required = false) String exportPath
    ) {
        Long finalMinId = minId !=null ? minId : 1L;
        Long finalMaxId = maxId != null ? maxId : Long.MAX_VALUE;
        ExportProcess e = new ExportProcess();
        e.setMinId(finalMinId);
        e.setMaxId(finalMaxId);
        if (!isRunning.get()) {
            isRunning.set(true);
            Mono.fromRunnable(() -> infocaService.process(e, exportPath))
                    .subscribeOn(Schedulers.boundedElastic())
                    .doOnTerminate(() -> isRunning.set(false))
                    .subscribe();
            return ResponseEntity.accepted().body("Infoca export started !");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("An Infoca export is already running. Please Wait ... ");
        }
    }

    @PostMapping("/refcom/run")
    @Operation(
            summary = "Export Refcom",
            description = "Service d'export des codes Regates refcom")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> runRefcomExport(@RequestBody List<Long> coclicos,
                                                  @RequestParam @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate consultationDate) {
        if (!isRunning.get()) {
            isRunning.set(true);
            Mono.fromRunnable(() -> refcomRestService.process(consultationDate, coclicos))
                    .subscribeOn(Schedulers.boundedElastic())
                    .doOnTerminate(() -> isRunning.set(false))
                    .subscribe();
            return ResponseEntity.accepted().body("Refcom export started !");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("An Refcom export is already running. Please Wait ... ");
        }
    }
}
