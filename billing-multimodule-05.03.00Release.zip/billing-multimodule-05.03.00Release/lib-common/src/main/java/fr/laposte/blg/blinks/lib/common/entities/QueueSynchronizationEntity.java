package fr.laposte.blg.blinks.lib.common.entities;


import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;

@Table("queue_synchronization_after_error")
@Data
@Accessors(chain = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QueueSynchronizationEntity {

    @Id
    @Column("id_queue")
    private Long idQueue;
    @Column("id_contract")
    private Long idContract;
    @Column("id_legal_person")
    private Long idLegalPerson;
    @Column("date_synchronization_expected")
    private Instant dateSynchronizationExpected;
    @Column("action")
    private ActionEnum action;
    @Column("refcom_replay")
    private Boolean refcomReplay;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QueueSynchronizationEntity that = (QueueSynchronizationEntity) o;
        return Objects.equals(idQueue, that.idQueue) &&
            Objects.equals(idContract, that.idContract) &&
            Objects.equals(dateSynchronizationExpected, that.dateSynchronizationExpected);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idQueue, idContract, dateSynchronizationExpected);
    }
}
