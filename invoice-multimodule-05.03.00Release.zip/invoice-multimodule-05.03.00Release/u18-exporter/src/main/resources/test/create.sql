

CREATE TABLE customer_account_message (
  id CHAR(36) NOT NULL PRIMARY KEY, -- UUID stocké en texte
  contractNumber VARCHAR(255) NOT NULL,
  offerCode VARCHAR(255) NOT NULL,
  message_key VARCHAR(255),
  message_value JSON,
  topic_name VARCHAR(255),
  topic_offset BIGINT,
  topic_partition INT,
  comment TEXT,
  status VARCHAR(50) NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_contract_number (contractNumber),
  INDEX idx_status (status),
  INDEX idx_created (created)
);
