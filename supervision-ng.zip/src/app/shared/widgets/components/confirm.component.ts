import { Component } from '@angular/core';
import { ModalService } from 'ngx-modal-ease';

export interface ConfirmModel {
  title: string;
  message: string;
}

@Component({
    selector: 'confirm',
    template: `
    <div class="modal-content">
      <div class="modal-header">
        <h4>{{title || 'Confirmation'}}</h4>
      </div>
      <div class="modal-body">
        <p>{{message || 'Vous êtes sûr?'}}</p>
      </div>
      <mat-divider></mat-divider>
      <div class="modal-footer">
        <button mat-raised-button class="btn btn-secondary" color="accent" style="margin-left: 10px"  (click)="cancel()">Annuler</button>
        <button mat-raised-button class="btn btn-primary btn-ok" color="warn"  (click)="confirm()">Confirmer</button>
      </div>
    </div>
  `,
    styleUrls: ['./confirm.component.scss'],
    standalone: false
})
export class ConfirmComponent  implements ConfirmModel {
  title: string='';
  message: string='';
  name = 'ConfirmComponent';
  constructor(private modalService: ModalService) {
  }
  confirm() {
    this.close(true);
  }
  cancel() {
    this.close(false);
  }

  close(result: boolean){
    this.modalService.close(result);
  }
}
