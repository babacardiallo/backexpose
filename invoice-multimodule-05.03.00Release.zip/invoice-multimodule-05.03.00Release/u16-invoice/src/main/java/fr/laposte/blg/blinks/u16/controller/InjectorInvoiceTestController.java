package fr.laposte.blg.blinks.u16.controller;

import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.u16.service.KafkaTestInvoiceProducer;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import reactor.core.publisher.Mono;

@Controller
@Profile("mar-sdev|mar-srec|sloc")
@RequestMapping("/api-test/inject")
public class InjectorInvoiceTestController {
    private final KafkaTestInvoiceProducer producer;

    public InjectorInvoiceTestController(KafkaTestInvoiceProducer producer) {
        this.producer = producer;
    }

    @PostMapping("/invoice")
    @ResponseStatus(HttpStatus.OK)
    public void pushToTopic(@RequestBody Invoice invoice) {
        producer.sendInvoiceToTopic(invoice);
    }

    }
