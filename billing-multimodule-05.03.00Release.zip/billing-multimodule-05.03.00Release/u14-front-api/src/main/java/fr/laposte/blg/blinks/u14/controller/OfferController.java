package fr.laposte.blg.blinks.u14.controller;

import fr.laposte.blg.blinks.lib.common.entities.OfferFilterEntity;
import fr.laposte.blg.blinks.u14.controller.dto.ContractErrorDTO;
import fr.laposte.blg.blinks.u14.controller.dto.OfferSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.RefopsDto;
import fr.laposte.blg.blinks.u14.service.OfferService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Objects;

/**
 * Exemple de controller.
 */
@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/offer")
@Validated
@OpenAPIDefinition(tags = {@Tag(name = "OfferController")})
public class OfferController {

    private final OfferService service;

    @PostMapping(value = "/enable-offer")
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Activation d'offre",
            description = "Service d'activation d'offre")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ResponseEntity<String>> enableOffer(
            @RequestParam("offer-ops-code") @Pattern(regexp = "[\\d]{4}", message = "offerCodeOps must be a string representing an integer of 4 digits") String offerOpsCode
            , @RequestParam(value = "date-migration-expected", required = false)
            //Si nulle, permet de désactiver la migration pour une offre donnée
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateMigrationExpected) {
        Instant dateMigrationInstant = null;
        if (Objects.nonNull(dateMigrationExpected)) {
            dateMigrationInstant = dateMigrationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateMigrationExpected));
        }
        return service.enableOffer(offerOpsCode, dateMigrationInstant)
                .map(s -> new ResponseEntity<>(s, HttpStatus.OK));
    }

    @GetMapping("/list-offer")
    @Operation(
            summary = "Liste des offres éligibles",
            description = "Service permettant de retourner la liste des offres éligibles")
    Flux<OfferFilterEntity> listOfferEnabled() {
        return service.listOfferEnabled();
    }

    @GetMapping("/offer-errors")
    @Operation(
            summary = "Liste des erreurs liée à une offre",
            description = "Service permettant de retourner toutes les erreurs de synchro, intégration")
    Flux<ContractErrorDTO> getAllContractErrors(@RequestParam String opsCode, @RequestParam String workflowStep) {
        return service.getListcontractErrors(opsCode, workflowStep);
    }

    @GetMapping("/list-offer-supervision")
    @Operation(
            summary = "Liste des offres éligibles, les contrats et leurs erreurs")
    Object listOfferContractsAndErrors(@RequestParam(defaultValue = "0") int page,
                                                     @RequestParam(defaultValue = "10") int size,
                                                     @RequestParam(defaultValue = "opsCode") String sort,
                                                     @RequestParam(defaultValue = "asc") String order,
                                                     @RequestParam(defaultValue = "noValue") String filter) {

        if(sort.equals("offerActivationDatetime")){
            return service.getAll(filter, sort, order, page, size);
        } else {
            return service.getAllCaseNoPagination(filter, sort, order, page, size);

        }
    }

    @GetMapping("/list-active-offer-supervision")
    @Operation(
            summary = "Liste des offres actives, contrats et erreurs"
    )
    Object listOfferActivesContractsAndErrors(@RequestParam(defaultValue = "0") int page,
                                                                 @RequestParam(defaultValue = "10") int size,
                                                                 @RequestParam(defaultValue = "opsCode") String sort,
                                                                 @RequestParam(defaultValue = "asc") String order,
                                                                 @RequestParam(defaultValue = "noValue") String filter) {
        if(sort.equals("offerActivationDatetime")){
            return service.getAllActives(filter, sort, order, page, size);
        } else {
            return service.getAllActivesCaseNoPagination(filter, sort, order, page, size);
        }

    }
    @GetMapping("/list-refops")
    @Operation(
            summary = "Liste toutes les offres OPS")
    Flux<RefopsDto> listOffersRefops() {
        return service.listOffersRefops();
    }

    @GetMapping("/list-all-errors")
    @Operation(
            summary = "Liste des erreurs lié aux contrats")
    Flux<ContractErrorDTO> listAllErrors() {
        return service.listAllErrors();
    }


    @PostMapping("/delete-offer")
    @Operation(
            summary = "Supprimer une offre",
            description = "Service permettant supprimer une offre des offres ouvertes à la synchronisation")
    Mono<Void> deleteOffer(@RequestParam String opsCode) {
        return service.deleteOffer(opsCode);
    }


    @GetMapping("/export-active-offer")
    @Operation(
            summary = "export liste des offres actives, contrats et erreurs"
    )
    Flux<OfferSupervisionDto> exportAllActives(@RequestParam(defaultValue = "noValue") String filter) {
        return service.exportAllActives(filter);
    }

    @GetMapping("/export-all-offer")
    @Operation(
            summary = "export liste des offres, les contrats et leurs erreurs")
    Flux<OfferSupervisionDto> exportAll(@RequestParam(defaultValue = "noValue") String filter) {
        return service.exportAll(filter);
    }

}
