import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { LancementExportComponent } from './lancement-export.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: LancementExportComponent }
        ])],
    exports: [RouterModule]
})
export class LancementRoutingExportModule { }