package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.ContractSuperiorRevError;
import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionActivesEntity;
import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionAllEntity;
import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractSupervisionActivesRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractSupervisionAllRepository;
import fr.laposte.blg.blinks.u14.controller.dto.ContractSupervisionDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ContractRestServiceTest {

    @Mock
    private ContractSupervisionActivesRepository contractSupervisionActivesRepository;
    @Mock
    private ContractSupervisionAllRepository contractSupervisionAllRepository;


    @InjectMocks
    private ContractRestService contractRestService;
    private ContractSupervisionActivesEntity contractSupervisionActivesEntity;
    private ContractSupervisionAllEntity contractSupervisionAllEntity;

    private ContractSuperiorRevError contractSuperiorRevErrorEntity;

    @BeforeEach
    void setUp() {
        contractSupervisionActivesEntity = new ContractSupervisionActivesEntity("id","D-1646497-1", 12L, 0, 4, "status",
                "substatus", 1L, "type", "subtype", "PROXI TEST", 2L, "COREM", true,
                Instant.parse("2022-12-05T10:15:30.00Z"), Instant.parse("2022-12-05T10:15:30.00Z"), Instant.parse("2022-12-05T10:15:30.00Z"),
                1, 1);
        contractSupervisionAllEntity = new ContractSupervisionAllEntity("id","D-1646497-1", 1L, 0, 4, "status",
                "substatus", 1L, "type", "subtype", "PROXI TEST", 2L, "COREM", true,
                Instant.parse("2022-12-05T10:15:30.00Z"), Instant.parse("2022-12-05T10:15:30.00Z"),Instant.parse("2022-12-05T10:15:30.00Z"),
                1, 1);
        contractSuperiorRevErrorEntity = new ContractSuperiorRevError("id", 1L,"D-1646497-1", 0, 5, 6, "0", "10", "errror testing message", "ODC message", "t", "t", "t", "t","t", true,Instant.now(), Instant.now(), Instant.now(), 1, 1);
    }

    @Test
    void getContractsActiveOffersTest() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        Mockito.when(contractSupervisionActivesRepository.findAllByFirstErrorDateIsNotNull(Mockito.any(PageRequest.class))).thenReturn(Flux.just(contractSupervisionActivesEntity));
        Mockito.when(contractSupervisionActivesRepository.findAllBy(Mockito.any(PageRequest.class))).thenReturn(Flux.just(contractSupervisionActivesEntity));
        Mockito.when(contractSupervisionActivesRepository.countAllByFirstErrorDateIsNotNull()).thenReturn(Mono.just(1L));
        Mockito.when(contractSupervisionActivesRepository.count()).thenReturn(Mono.just(1L));
        StepVerifier.create(contractRestService.getContractsActiveOffers(false, false,  PageRequest.of(0, 1, sortOrder)))
                .assertNext(contractResult -> assertContract(contractSupervisionActivesEntity, contractResult.getContent().get(0)))
                .verifyComplete();
    }


   /* @Test
    void getAllContractsTest() {
        Mockito.when(contractSupervisionAllRepository.findAllBy()).thenReturn(Flux.just(contractSupervisionAllEntity));
        StepVerifier.create(contractRestService.getAllContracts())
                .assertNext(contractResult -> assertContract(contractSupervisionAllEntity, contractResult))
                .verifyComplete();
    }*/


    @Test
    void getSuperiorRevErrors() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        Mockito.when(contractSupervisionActivesRepository.contractSuperiorRevError( Mockito.any(String.class), Mockito.any(String.class),  Mockito.anyList(), Mockito.any(PageRequest.class))).thenReturn(Flux.just(contractSuperiorRevErrorEntity));
        Mockito.when(contractSupervisionActivesRepository.countContractSuperiorRevError(Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(Mono.just(1L));
        StepVerifier.create(contractRestService.getSuperiorRevErrors(PageRequest.of(0, 1, sortOrder),"","",List.of(""), true))
                .assertNext(contractErrorsResult -> {
                    assertNotNull(contractErrorsResult);
                    assertEquals(contractSuperiorRevErrorEntity.getContractNumber(), contractErrorsResult.getContent().get(0).getContractNumber());
                    assertEquals(contractSuperiorRevErrorEntity.getAmendmentNumber(), contractErrorsResult.getContent().get(0).getAmendmentNumber());
                    assertEquals(contractSuperiorRevErrorEntity.getRevisionNumber(), contractErrorsResult.getContent().get(0).getRevisionNumber());
                    assertEquals(contractSuperiorRevErrorEntity.getSuperiorRevisionNumber(), contractErrorsResult.getContent().get(0).getSuperiorRevError());
                    assertEquals(contractSuperiorRevErrorEntity.getErrorMessage(), contractErrorsResult.getContent().get(0).getSuperiorRevErrMessage());
                    assertEquals(contractSuperiorRevErrorEntity.getOffsetError(), contractErrorsResult.getContent().get(0).getSupOffsetError());
                    assertEquals(contractSuperiorRevErrorEntity.getPartitionError(), contractErrorsResult.getContent().get(0).getSupPartitionError());
                })
                .verifyComplete();
    }

    private void assertContract(ContractSupervisionEntity contractSupervisionEntity, ContractSupervisionDto contractResult) {
        assertNotNull(contractResult);
        assertEquals(contractSupervisionEntity.getContractNumber(), contractResult.getContractNumber());
        assertEquals(contractSupervisionEntity.getAmendmentNumber(), contractResult.getAmendmentNumber());
        assertEquals(contractSupervisionEntity.getRevisionNumber(), contractResult.getRevisionNumber());
        assertEquals(contractSupervisionEntity.getStatus(), contractResult.getStatus());
        assertEquals(contractSupervisionEntity.getSubstatus(), contractResult.getSubStatus());
        assertEquals(contractSupervisionEntity.getType(), contractResult.getType());
        assertEquals(contractSupervisionEntity.getSubtype(), contractResult.getSubtype());
        assertEquals(contractSupervisionEntity.getOpsCode(), contractResult.getOpsCode());
        assertEquals(contractSupervisionEntity.getOpsLabel(), contractResult.getOpsLabel());
        assertEquals(contractSupervisionEntity.getIsSynchronized(), contractResult.getIsSynchronized());
        assertEquals(contractSupervisionEntity.getLastDateSynchronization(), contractResult.getLastDateSynchronization());
        assertEquals(contractSupervisionEntity.getDateError(), contractResult.getDateError());
        assertEquals(contractSupervisionEntity.getFirstErrorDate(), contractResult.getFirstErrorDate());
    }

}

