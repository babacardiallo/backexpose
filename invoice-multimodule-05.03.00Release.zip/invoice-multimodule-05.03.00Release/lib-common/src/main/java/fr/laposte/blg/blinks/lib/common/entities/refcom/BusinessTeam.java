package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_team")
@Data
@Accessors(chain = true)

public class BusinessTeam implements Disposable, Persistable<Integer> {
    @Id
    @Column("business_team_id")
    private int businessTeamId;
    @Column("business_team_type_id")
    private Integer businessTeamTypeId;
    @Column("business_team_start_date")
    private Instant businessTeamStartDate;
    @Column("business_team_end_date")
    private Instant businessTeamEndDate;
    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessTeamStartDate) &&
                        businessTeamStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessTeamEndDate)
                                || businessTeamEndDate.isAfter(Instant.now())
                );
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Integer getId() {
        return businessTeamId;
    }


    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
