package fr.laposte.blg.blinks.u13.scheduler;

import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.QueueMigrationService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@ComponentScan(basePackages = "fr.laposte.blg.blinks.lib")
@EnableScheduling
@RequiredArgsConstructor
public class SynchronizationScheduler {

    private final QueueService queueSynchronizationService;
    private final QueueMigrationService queueMigrationService;
    private final SynchronizationSender synchronizationSender;
    private final SchedulerService schedulerService;
    private final ErrorLogService errorLogService;

    @Scheduled(fixedDelayString = "${fr.laposte.schedulers.synchronization-after-error.delay-in-minutes}", timeUnit = TimeUnit.MINUTES)
    /**
     * Dedicated to error handling
     */
    public void synchronizeContracts() {
        log.info("Scheduled execution of synchronizeContracts after error");
        this.queueSynchronizationService.findEntitiesToSynchronizeImmediately()
            .doOnNext(queueSynchronizationEntity -> log.debug("QueueSync : {}", queueSynchronizationEntity))
            .flatMap(queueSynchronizationEntity -> {
                if (Objects.nonNull(queueSynchronizationEntity.getIdContract())) {
                    return Mono.just(queueSynchronizationEntity)
                        .filterWhen(schedulerService::isOfferOfContractEligibleForSynchronization)
                        .switchIfEmpty(Mono.defer(() ->
                            {
                                log.warn("Contract (id_contract: {}) awaiting for synchronization are linked " +
                                    "to an offer which is not eligible to be synchronized ! The queue row is removed", queueSynchronizationEntity.getIdContract());
                                return queueSynchronizationService.deleteQueueSynchronizationById(queueSynchronizationEntity.getIdQueue())
                                    .then(errorLogService.purgeErrorOfSchedulerForOneContract(queueSynchronizationEntity.getIdContract()))
                                    .then(Mono.empty());
                            }
                            )
                        )
                        .doOnNext(queueSynchronizationEntity1 -> log.debug("Contract {} is ready to be published", queueSynchronizationEntity1.getIdContract()))
                        ;
                }
                return Mono.just(queueSynchronizationEntity)
                    .doOnNext(queueSynchronizationEntity1 ->
                        log.debug("LegalPerson {} is ready to be published, refcom call : {}", queueSynchronizationEntity1.getIdLegalPerson(), queueSynchronizationEntity1.getRefcomReplay()));
            })
            .flatMap(queueSynchronizationEntity -> queueSynchronizationService.deleteQueueSynchronizationById(queueSynchronizationEntity.getIdQueue()).thenReturn(queueSynchronizationEntity))
            .flatMap(this.synchronizationSender::sendQueuedItem)
            .flatMap(queueSynchronizationEntity -> errorLogService.purgeErrorOfSchedulerForOneContract(queueSynchronizationEntity.getIdContract())
                .thenReturn(queueSynchronizationEntity))
            .count()
            .doOnSuccess(nbQueueMigration ->
                log.info("{} contracts synchronized after error", nbQueueMigration))
            .subscribe();
    }


    /**
     * allows to migrate contrats with an offer eligible
     */
    @Scheduled(fixedDelayString = "${fr.laposte.schedulers.migration-by-offer.delay-in-minutes}", timeUnit = TimeUnit.MINUTES)
    //For test purposes
    public void migrateContracts() {
        log.info("Scheduled execution of migrationContracts");
        //1 Récupération de la liste des offres éligibles
        queueMigrationService.findQueueMigrationToMigrateByOffer()
            .flatMap(this.synchronizationSender::sendQueuedMigrationItem)
            .flatMap(queueMigrationEntity -> queueMigrationService.deleteQueueMigrationById(queueMigrationEntity.getIdQueue())
                .thenReturn(queueMigrationEntity))
            .flatMap(queueMigrationEntity -> errorLogService.purgeErrorOfSchedulerForOneContract(queueMigrationEntity.getIdContract())
                .thenReturn(queueMigrationEntity))
            .count()
            .doOnSuccess(nbQueueMigration ->
                log.info("{} contracts migrated", nbQueueMigration))
            .subscribe();
    }
}
