ALTER TABLE export_history
ADD transfer_status ENUM('NO_FILE','NEW','TRANSFERED','FAILED') not null default 'NEW',
ADD transfer_error_message TEXT DEFAULT NULL,
ADD transfer_error_code VARCHAR(32) DEFAULT NULL;

ALTER TABLE export_history ADD start_date datetime;

set sql_safe_updates=0;
update export_history set transfer_status='TRANSFERED' where id is not null;