set sql_safe_updates=0;

ALTER TABLE invoice
    RENAME COLUMN `equinox_error_code` to `coeurfinance_error_code`,
    RENAME COLUMN `equinox_error_message` to `coeurfinance_error_message`,
    RENAME COLUMN `equinox_export_id` to `coeurfinance_export_id`,
    RENAME COLUMN `equinox_export_status` to `coeurfinance_export_status`;

ALTER TABLE `export_history`
    MODIFY COLUMN `file_type` ENUM(
    'DOCAPOSTE',
    'INFOCA',
    'EQUINOX',
    'COEURFINANCE',
    'REFCOM_BATCH',
    'DOCAPOSTE_AVIS_PAIEMENT'
    ) DEFAULT NULL;

ALTER TABLE `export_process`
    MODIFY COLUMN `file_type` ENUM(
    'DOCAPOSTE',
    'INFOCA',
    'EQUINOX',
    'COEURFINANCE',
    'REFCOM_BATCH',
    'DOCAPOSTE_AVIS_PAIEMENT'
    ) DEFAULT NULL;

ALTER TABLE file_sequence
MODIFY COLUMN sequence_name ENUM('DOCAPOST', 'INFOCA', 'EQUINOX', 'COPILOTMD', 'COEURFINANCE') NOT NULL;
UPDATE file_sequence set sequence_name = 'COEURFINANCE' where sequence_name = 'EQUINOX';

UPDATE scheduler_params
SET `custom_params` = REPLACE(`custom_params`, 'equinox', 'coeurfinance')
WHERE `scheduler_name` IN ('scheduler_export', 'scheduler_notification')
  AND `custom_params` LIKE '%equinox%';

CREATE OR REPLACE
VIEW `invoice_supervision` AS
SELECT
    `inv`.`id_invoice` AS `id_invoice`,
    `inv`.`invoice_number` AS `invoice_number`,
    `inv`.`created` AS `created`,
    `inv`.`client` AS `client`,
    `inv`.`billrun_id` AS `billrun_id`,
    `inv`.`docaposte_export_status` AS `docaposte_export_status`,
    `inv`.`infoca_export_status` AS `infoca_export_status`,
    `inv`.`coeurfinance_export_status` AS `coeurfinance_export_status`,
    `export1`.`file_date` AS `docaposte_export_date`,
    `export1`.`id` AS `docaposte_export_id`,
    `export2`.`file_date` AS `infoca_export_date`,
    `export2`.`id` AS `infoca_export_id`,
    `export3`.`file_date` AS `coeurfinance_export_date`,
    `export3`.`id` AS `coeurfinance_export_id`
FROM
    (((`invoice` `inv`
        LEFT JOIN `export_history` `export1` ON ((`inv`.`docaposte_export_id` = `export1`.`id`)))
        LEFT JOIN `export_history` `export2` ON ((`inv`.`infoca_export_id` = `export2`.`id`)))
        LEFT JOIN `export_history` `export3` ON ((`inv`.`coeurfinance_export_id` = `export3`.`id`)));

set sql_safe_updates=1;
