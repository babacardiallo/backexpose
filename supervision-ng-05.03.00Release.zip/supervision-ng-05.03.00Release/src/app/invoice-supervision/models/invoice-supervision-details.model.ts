export class InvoiceSupervisionDetailsModel {
    isCredit?: boolean;
    isRefundable?: boolean;
    isDownpayment?: boolean;
    isStatement?: boolean;
    isOpencellPdf?: boolean;
    isDedicated?: boolean;
    support?: string;
    printFlag?: boolean;
    htAmount?: number;
    amount?: number;
    coeurfinanceFileName?: string;
    docaposteFileName?: string;
    infocaFileName?: string;
    coeurfinanceTransferDate?: string;
    docaposteTransferDate?: string;
    infocaTransferDate?: string;
    coeurfinanceTransferStatus?: string;
    docaposteTransferStatus?: string;
    infocaTransferStatus?: string;
    invoiceJson?: JSON;
    mappingError?: string | null;
    type?: string;
}
