package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.OfferFilterEntity;
import fr.laposte.blg.blinks.lib.common.entities.OfferSupervisionEntity;
import fr.laposte.blg.blinks.lib.common.entities.RefopsOfferFilter;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractErrorRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferSupervisionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.RefopsRepository;
import fr.laposte.blg.blinks.lib.common.service.QueueMigrationService;
import fr.laposte.blg.blinks.u14.controller.dto.ContractErrorDTO;
import fr.laposte.blg.blinks.u14.controller.dto.OfferSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.OfferSupervisionDtoNoPagination;
import fr.laposte.blg.blinks.u14.controller.dto.RefopsDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.reactivestreams.Publisher;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Function;

@Service
@RequiredArgsConstructor
@Data
public class OfferService {
    private final QueueMigrationService queueMigrationService;
    private final OfferFilterRepository offerFilterRepository;
    private final OfferSupervisionRepository offerSupervisionRepository;
    private final ContractErrorRepository contractErrorRepository;
    private final RefopsRepository refopsRepository;


    @Transactional
    public Mono<String> enableOffer(String offerOpsCode, Instant dateMigrationExpected) {

        Mono<OfferFilterEntity> monoToAddOfferFilterEntity = Mono.just(offerOpsCode)
                .map(s -> OfferFilterEntity.builder().opsCode(offerOpsCode)
                        .offerOpsId(Long.parseLong(offerOpsCode)).build()
                )
                .flatMap(offerFilterRepository::save);
        // save dans refops

        return offerFilterRepository.findFirstByOpsCode(offerOpsCode)
                .switchIfEmpty(Mono.defer(() -> monoToAddOfferFilterEntity))
                .zipWith(queueMigrationService.enableMigrationForOffer(dateMigrationExpected, offerOpsCode)

                )
                .map(offerAndNbContractsModified ->
                        offerAndNbContractsModified.getT2() + " contracts set for the offerCodeOps "
                                + offerAndNbContractsModified.getT1().getOpsCode()
                )
                .zipWith(refopsRepository.setActivationDate(offerOpsCode, dateMigrationExpected))
                .map(refopsEntity -> "Date d'activation ajoutée à la table Refops: "
                        + refopsEntity.getT2().getOfferActivationDatetime().toString());
    }

    public Flux<OfferFilterEntity> listOfferEnabled() {
        return offerFilterRepository.findAll();
    }

    public Flux<ContractErrorDTO> getListcontractErrors(String opsCode, String workflowStep) {
        return contractErrorRepository.getListcontractErrors(opsCode, workflowStep)
                .map(contractError ->
                        new ContractErrorDTO(
                                contractError.getContractNumber(),
                                contractError.getVersionNumber(),
                                contractError.getAmendmentNumber(),
                                contractError.getDateError(),
                                contractError.getFirstErrorDate(),
                                contractError.getIsSynchronized(),
                                contractError.getPreviousDateSynchronization(),
                                contractError.getWorkflowStep(),
                                contractError.getErrorMessage(),
                                contractError.getOpsCode()
                        ));
    }

    public Flux<OfferSupervisionDto> listOfferContractsAndErrors() {
        ArrayList<String> opsCodes = new ArrayList<>();
        return offerSupervisionRepository.countOfferContractsErrors()
                .flatMap(getOfferSupervisionBeforeFirstInteg(opsCodes))
                .concatWith(getOfferWithoutContracts(opsCodes))
                .concatWith(refopsRepository.findAll()
                        .filter(offerOps -> !opsCodes.contains(offerOps.getOpsCode()))
                        .map(offerRefOps ->
                                new OfferSupervisionDto(
                                        offerRefOps.getOpsCode(),
                                        offerRefOps.getOpsLabel(),
                                        offerRefOps.getOfferActivationDatetime(),
                                        "0",
                                        "0",
                                        "0",
                                        "0",
                                        "0",
                                        "0",
                                        false
                                )));
    }


    public Flux<RefopsDto> listOffersRefops() {
        return refopsRepository.findAll()
                .map(refopsOffer ->
                        new RefopsDto(
                                refopsOffer.getOpsCode(),
                                refopsOffer.getOpsLabel(),
                                refopsOffer.getOfferActivationDatetime()));
    }

    public Flux<ContractErrorDTO> listAllErrors() {
        return contractErrorRepository.getAllErrorsRepository().map(contractError ->
                new ContractErrorDTO(
                        contractError.getContractNumber(),
                        contractError.getVersionNumber(),
                        contractError.getAmendmentNumber(),
                        contractError.getDateError(),
                        contractError.getFirstErrorDate(),
                        contractError.getIsSynchronized(),
                        contractError.getPreviousDateSynchronization(),
                        contractError.getWorkflowStep(),
                        contractError.getErrorMessage(),
                        contractError.getOpsCode()
                ));
    }

    public Mono<Void> deleteOffer(String opsCode) {
        return refopsRepository.setActivationDateToNull(opsCode)
                .zipWith(offerFilterRepository.deleteByOpsCode(opsCode))
                .map(Tuple2::getT2);
    }

    public Flux<OfferSupervisionDto> listActiveOfferContractsAndErrors() {
        ArrayList<String> opsCodes = new ArrayList<>();
        return offerSupervisionRepository.countActiveOfferContractsErrors()
                .flatMap(getOfferSupervisionBeforeFirstInteg(opsCodes))
                .concatWith(getOfferWithoutContracts(opsCodes));
    }

    private Function<OfferSupervisionEntity, Publisher<? extends OfferSupervisionDto>> getOfferSupervisionBeforeFirstInteg(ArrayList<String> opsCodes) {
        return offer -> {
            String opsCode = offer.getOpsCode();
            opsCodes.add(opsCode);
            return offerSupervisionRepository.getErrorsBeforeFirstInteg()
                    .filter(offer1 -> opsCode.equals(offer1.getOpsCode()))
                    .map(offer1 -> {
                        int totalErrorListening = Integer.parseInt(offer.getErrorListening())
                                + Integer.parseInt(offer1.getErrorListening());
                        return new OfferSupervisionDto(
                                offer.getOpsCode(),
                                offer.getOpsLabel(),
                                offer.getOfferActivationDate(),
                                offer.getContractSynch(),
                                offer.getContractVersionSynch().toString(),
                                "0",
                                "0",
                                String.valueOf(totalErrorListening),
                                offer.getErrorSynchronization(),
                                offer.getOfferActivationDate() != null
                        );
                    })
                    .defaultIfEmpty(new OfferSupervisionDto(
                            offer.getOpsCode(),
                            offer.getOpsLabel(),
                            offer.getOfferActivationDate(),
                            offer.getContractSynch(),
                            offer.getContractVersionSynch().toString(),
                            "0",
                            "0",
                            offer.getErrorListening(),
                            offer.getErrorSynchronization(),
                            offer.getOfferActivationDate() != null));
        };
    }


    private Flux<OfferSupervisionDto> getOfferWithoutContracts(ArrayList<String> opsCodes) {
        return offerSupervisionRepository.getOffersWithoutContracts()
                .map(offer2 -> {
                    opsCodes.add(offer2.getOpsCode());
                    return new OfferSupervisionDto(
                            offer2.getOpsCode(),
                            offer2.getOpsLabel(),
                            offer2.getOfferActivationDate(),
                            offer2.getContractSynch(),
                            offer2.getContractVersionSynch().toString(),
                            "0",
                            "0",
                            offer2.getErrorListening(),
                            offer2.getErrorSynchronization(), true);
                });
    }


    public Flux<RefopsOfferFilter> getOfferFilter(String order) {
        if(order.equals("asc")){
            return refopsRepository.getAllOfferFilterWithOrderAsc();
        } else {
            return refopsRepository.getAllOfferFilterWithOrderDesc();
        }
    }

    public Flux<RefopsOfferFilter> getOfferFilterWithFilter(String filter, String order) {
        if(order.equals("asc")){
            return refopsRepository.getAllOfferFilterWhithOrderAscAndFilter(filter);
        } else {
            return refopsRepository.getAllOfferFilterWhithOrderDescAndFilter(filter);
        }
    }

    public Mono<Page<OfferSupervisionDto>> getAllActives(String filter, String sort, String order, int page, int size) {
        int offset = page*size;
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if (filter.equals("noValue")) {
            return getOfferFilter(order)
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel() != null ? offerRefOps.getOpsLabel() : "",
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    true
                            )).concatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }))
                    .collectList()
                    .map(offerSupervisionDtos -> new PageImpl<>(offerSupervisionDtos.subList(offset, Math.min(offset + size, offerSupervisionDtos.size())), pageable, offerSupervisionDtos.size()));
        } else {
            filter = "%" + filter + "%";
            return getOfferFilterWithFilter(filter, order)
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel() != null ? offerRefOps.getOpsLabel() : "",
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    true
                            )).concatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }))
                    .collectList()
                    .map(offerSupervisionDtos -> new PageImpl<>(offerSupervisionDtos.subList(offset, Math.min(offset + size, offerSupervisionDtos.size())), pageable, offerSupervisionDtos.size()));
        }

    }

    public Flux<RefopsOfferFilter> getAllRefops(String order) {
        if(order.equals("asc")){
            return refopsRepository.getAllRefopsWithOrderAsc();
        } else {
            return refopsRepository.getAllRefopsWithOrderDesc();
        }
    }

    public Flux<RefopsOfferFilter> getAllRefopsWithFilter(String filter, String order) {
        if(order.equals("asc")){
            return refopsRepository.getAllRefopsWithFilterAndOrderAsc(filter);
        } else {
            return refopsRepository.getAllRefopsWithFilterAndOrderdesc(filter);
        }
    }

    public Mono<Page<OfferSupervisionDto>> getAll(String filter, String sort, String order, int page, int size) {
        int offset = page*size;
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if (filter.equals("noValue")) {
            return getAllRefops(order)
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel(),
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    offerRefOps.getOfferActivationDatetime() != null
                            )).concatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }))
                    .collectList()
                    .map(offerSupervisionDtos -> new PageImpl<>(offerSupervisionDtos.subList(offset, Math.min(offset + size, offerSupervisionDtos.size())), pageable, offerSupervisionDtos.size()));
        } else {
            filter = "%" + filter + "%";
            return getAllRefopsWithFilter(filter, order)
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel(),
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    offerRefOps.getOfferActivationDatetime() != null
                            )).concatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }))
                    .collectList()
                    .map(offerSupervisionDtos -> new PageImpl<>(offerSupervisionDtos.subList(offset, Math.min(offset + size, offerSupervisionDtos.size())), pageable, offerSupervisionDtos.size()));
        }

    }


    public Flux<OfferSupervisionDto> exportAllActives(String filter) {
        if (filter.equals("noValue")) {
            return offerFilterRepository.getAllActivesOpsCode()
                    .collectList()
                    .flatMapMany(refopsRepository::findAllByOpsCodeIn)
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel(),
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    true
                            )).flatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }));
        } else {
            filter = "%" + filter + "%";
            String finalFilter = filter;
            return offerFilterRepository.getAllActivesOpsCode()
                    .collectList()
                    .flatMapMany(opsCodeList -> refopsRepository.findAllByOpsCodeInAndOpsCodeLike(opsCodeList, finalFilter))
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel(),
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    true
                            )).flatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }));
        }

    }

    public Flux<OfferSupervisionDto> exportAll(String filter) {
        if (filter.equals("noValue")) {
            return refopsRepository.findAll()
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel(),
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    offerRefOps.getOfferActivationDatetime() != null
                            )).flatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }));
        } else {
            filter = "%" + filter + "%";
            return refopsRepository.findAllByOpsCodeLikeOrOpsLabelLike(filter, filter)
                    .map(offerRefOps ->
                            new OfferSupervisionDto(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel(),
                                    offerRefOps.getOfferActivationDatetime(),
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    "0",
                                    offerRefOps.getOfferActivationDatetime() != null
                            )).flatMap(offerSupervisionDto ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDto.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDto.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDto.setErrorListening(tuple5.getT1().getErrorListening());
                                        offerSupervisionDto.setErrorSynch(tuple5.getT1().getErrorSynch());
                                        offerSupervisionDto.setContractSynch(tuple5.getT2().toString());
                                        offerSupervisionDto.setContractVersionSynch(tuple5.getT3().toString());
                                        offerSupervisionDto.setContractIntegrated(tuple5.getT4().toString());
                                        offerSupervisionDto.setContractVersionIntegrated(tuple5.getT5().toString());
                                        return offerSupervisionDto;
                                    }));
        }

    }


    public Flux<OfferSupervisionDtoNoPagination> getAllActivesBeforeSort(String filter) {
        if (filter.equals("noValue")) {
            return refopsRepository.getAllOfferFilter()
                    .map(offerRefOps ->
                            new OfferSupervisionDtoNoPagination(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel() != null ? offerRefOps.getOpsLabel() : "",
                                    offerRefOps.getOfferActivationDatetime(),
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    true
                            )).concatMap(offerSupervisionDtoNoPagination ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDtoNoPagination.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDtoNoPagination.setErrorListening(Integer.parseInt(tuple5.getT1().getErrorListening()));
                                        offerSupervisionDtoNoPagination.setErrorSynch(Integer.parseInt(tuple5.getT1().getErrorSynch()));
                                        offerSupervisionDtoNoPagination.setContractSynch(Math.toIntExact(tuple5.getT2()));
                                        offerSupervisionDtoNoPagination.setContractVersionSynch(Math.toIntExact(tuple5.getT3()));
                                        offerSupervisionDtoNoPagination.setContractIntegrated(Math.toIntExact(tuple5.getT4()));
                                        offerSupervisionDtoNoPagination.setContractVersionIntegrated(Math.toIntExact(tuple5.getT5()));
                                        return offerSupervisionDtoNoPagination;
                                    }));
        } else {
            filter = "%" + filter + "%";
            return refopsRepository.getAllOfferFilterWhithFilter(filter)
                    .map(offerRefOps ->
                            new OfferSupervisionDtoNoPagination(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel() != null ? offerRefOps.getOpsLabel() : "",
                                    offerRefOps.getOfferActivationDatetime(),
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    true
                            )).concatMap(offerSupervisionDtoNoPagination ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDtoNoPagination.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDtoNoPagination.setErrorListening(Integer.parseInt(tuple5.getT1().getErrorListening()));
                                        offerSupervisionDtoNoPagination.setErrorSynch(Integer.parseInt(tuple5.getT1().getErrorSynch()));
                                        offerSupervisionDtoNoPagination.setContractSynch(Math.toIntExact(tuple5.getT2()));
                                        offerSupervisionDtoNoPagination.setContractVersionSynch(Math.toIntExact(tuple5.getT3()));
                                        offerSupervisionDtoNoPagination.setContractIntegrated(Math.toIntExact(tuple5.getT4()));
                                        offerSupervisionDtoNoPagination.setContractVersionIntegrated(Math.toIntExact(tuple5.getT5()));
                                        return offerSupervisionDtoNoPagination;
                                    }));
        }

    }


    public Mono<Page<OfferSupervisionDtoNoPagination>> getAllActivesCaseNoPagination(String filter, String sort, String order, int page, int size) {
        int offset = page*size;
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if (sort.equals("opsCode")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsCode))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));

            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsCode, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }
        if (sort.equals("opsLabel")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsLabel))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));

            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsLabel, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }
        if (sort.equals("contractIntegrated")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractIntegrated))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));

            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractIntegrated, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }
        if (sort.equals("contractVersionIntegrated")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionIntegrated))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionIntegrated, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("errorListening")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorListening))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorListening, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("contractSynch")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractSynch))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractSynch, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("contractVersionSynch")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionSynch))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionSynch, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("errorSynch")) {
            if (order.equals("asc")) {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorSynch))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllActivesBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorSynch, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        return null;
    }

    public Flux<OfferSupervisionDtoNoPagination> getAllBeforeSort(String filter) {
        if (filter.equals("noValue")) {
            return refopsRepository.getAllRefops()
                    .map(offerRefOps ->
                            new OfferSupervisionDtoNoPagination(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel() != null ? offerRefOps.getOpsLabel():"",
                                    offerRefOps.getOfferActivationDatetime(),
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    offerRefOps.getOfferActivationDatetime() != null
                            )).concatMap(offerSupervisionDtoNoPagination ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDtoNoPagination.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDtoNoPagination.setErrorListening(Integer.parseInt(tuple5.getT1().getErrorListening()));
                                        offerSupervisionDtoNoPagination.setErrorSynch(Integer.parseInt(tuple5.getT1().getErrorSynch()));
                                        offerSupervisionDtoNoPagination.setContractSynch(Math.toIntExact(tuple5.getT2()));
                                        offerSupervisionDtoNoPagination.setContractVersionSynch(Math.toIntExact(tuple5.getT3()));
                                        offerSupervisionDtoNoPagination.setContractIntegrated(Math.toIntExact(tuple5.getT4()));
                                        offerSupervisionDtoNoPagination.setContractVersionIntegrated(Math.toIntExact(tuple5.getT5()));
                                        return offerSupervisionDtoNoPagination;
                                    }));
        } else {
            filter = "%" + filter + "%";
            return refopsRepository.getAllRefopsWithFilter(filter)
                    .map(offerRefOps ->
                            new OfferSupervisionDtoNoPagination(
                                    offerRefOps.getOpsCode(),
                                    offerRefOps.getOpsLabel() != null ? offerRefOps.getOpsLabel():"",
                                    offerRefOps.getOfferActivationDatetime(),
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    offerRefOps.getOfferActivationDatetime() != null
                            )).concatMap(offerSupervisionDtoNoPagination ->
                            Mono.zip(refopsRepository.countOfferErrorListeningAndSynchro(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countOfferErrorNbContractVersionSynchronized(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractIntegrated(offerSupervisionDtoNoPagination.getOpsCode()),
                                            refopsRepository.countNbContractVersionIntegrated(offerSupervisionDtoNoPagination.getOpsCode()))
                                    .map(tuple5 -> {
                                        offerSupervisionDtoNoPagination.setErrorListening(Integer.parseInt(tuple5.getT1().getErrorListening()));
                                        offerSupervisionDtoNoPagination.setErrorSynch(Integer.parseInt(tuple5.getT1().getErrorSynch()));
                                        offerSupervisionDtoNoPagination.setContractSynch(Math.toIntExact(tuple5.getT2()));
                                        offerSupervisionDtoNoPagination.setContractVersionSynch(Math.toIntExact(tuple5.getT3()));
                                        offerSupervisionDtoNoPagination.setContractIntegrated(Math.toIntExact(tuple5.getT4()));
                                        offerSupervisionDtoNoPagination.setContractVersionIntegrated(Math.toIntExact(tuple5.getT5()));
                                        return offerSupervisionDtoNoPagination;
                                    }));
        }
    }


    public Mono<Page<OfferSupervisionDtoNoPagination>> getAllCaseNoPagination(String filter, String sort, String order, int page, int size) {
        int offset = page*size;
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if (sort.equals("opsCode")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsCode))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));

            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsCode, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }
        if (sort.equals("opsLabel")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsLabel))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));

            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getOpsLabel, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }
        if (sort.equals("contractIntegrated")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractIntegrated))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractIntegrated, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }
        if (sort.equals("contractVersionIntegrated")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionIntegrated))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionIntegrated, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("errorListening")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorListening))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorListening, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("contractSynch")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractSynch))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractSynch, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("contractVersionSynch")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionSynch))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getContractVersionSynch, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        if (sort.equals("errorSynch")) {
            if (order.equals("asc")) {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorSynch))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            } else {
                return this.getAllBeforeSort(filter)
                        .sort(Comparator.comparing(OfferSupervisionDtoNoPagination::getErrorSynch, Comparator.reverseOrder()))
                        .collectList()
                        .map(offerSupervisionDtoNoPaginations
                                -> new PageImpl<>(offerSupervisionDtoNoPaginations.subList(offset, Math.min(offset + size, offerSupervisionDtoNoPaginations.size())), pageable, offerSupervisionDtoNoPaginations.size()));
            }
        }

        return null;
    }
}