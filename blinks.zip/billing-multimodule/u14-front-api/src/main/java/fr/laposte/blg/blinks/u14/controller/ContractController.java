package fr.laposte.blg.blinks.u14.controller;

import fr.laposte.blg.blinks.lib.common.entities.ReplayDto;
import fr.laposte.blg.blinks.u14.controller.dto.ContractSupervisionDetailsDto;
import fr.laposte.blg.blinks.u14.controller.dto.ContractSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.ErrorLogSupRevDto;
import fr.laposte.blg.blinks.u14.controller.dto.SuperiorRevErrorDto;
import fr.laposte.blg.blinks.u14.service.ContractRestService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;


@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/contract")
@Validated
@OpenAPIDefinition(tags = {@Tag(name = "ContractController")})
public class ContractController {

    private final ContractRestService contractRestService;

    @GetMapping("/active-offers-contracts")
    @Operation(
            summary = "Liste les contrats des offres actives",
            description = "Permet de récupérer tous les contrats, synchronisés ou non, des offres actives pour supervision")
    Mono<Page<ContractSupervisionDto>> getContractsActiveOffers(
            @RequestParam(defaultValue = "0") boolean errors,
            @RequestParam(defaultValue = "0") boolean isNotSynchronized,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "desc") String order
    ) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idContractVersion"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return contractRestService.getContractsActiveOffers(errors, isNotSynchronized, pageable);
    }

    @GetMapping("/all-contracts")
    @Operation(
            summary = "Liste les contrats de toutes les offres",
            description = "Permet de récupérer tous les contrats, synchronisés ou non, de toutes les offres pour supervision")
    Mono<Page<ContractSupervisionDto>> getAllContracts(
            @RequestParam(defaultValue = "0") boolean errors,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "desc") String order
    ) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idContractVersion"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return contractRestService.getAllContracts(errors, pageable);
    }

    @GetMapping("/superior-rev-errors")
    @Operation(
            summary = "Liste des erreurs sur révision supérieure",
            description = "Retourne toutes les révision de contrats en erreurs d'intégration pour lesquelles une révision inférieure" +
                    "du même contrat est déjà synchronisée")
    Mono<Page<SuperiorRevErrorDto>> getSuperiorRevErrors(@RequestParam(defaultValue = "0") int page,
                                                         @RequestParam(defaultValue = "10") int size,
                                                         @RequestParam(defaultValue = "id") String sort,
                                                         @RequestParam(defaultValue = "desc") String order,
                                                         @RequestParam(defaultValue = "0") boolean showAll,
                                                         @RequestParam(required = false) String contractNumber,
                                                         @RequestParam(required = false) String custAccNumber,
                                                         @RequestParam(required = false) List<String> offers) {

        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idContractVersion"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return contractRestService.getSuperiorRevErrors(pageable, contractNumber, custAccNumber, offers, showAll);
    }

    @GetMapping("/superior-rev-error-contract")
    @Operation(
            summary = "Vérifie si le contrat a une erreur d'intégration sur révision supérieur",
            description = "Pour une version de contrat donnée sur une révision, check error_log pour vérifier si une révision supérieure est en erreur"
    )
    Mono<ErrorLogSupRevDto> getSuperiorRevErrorContract(@RequestParam String contractNumber,
                                                        @RequestParam Integer amendmentNumber,
                                                        @RequestParam Integer revisionNumber) {
        return contractRestService.getSuperiorRevErrorContract(contractNumber, amendmentNumber, revisionNumber);
    }

    @GetMapping("/details-contract")
    @Operation(
            summary = "Récupère les détails d'un contrat selon son ID",
            description = "Permet de récupérer les détails d'un contrat selon son ID en prenant la date la plus récente pour les informations d'erreur")
    Mono<ContractSupervisionDetailsDto> getContractDetails(@RequestParam String contractNumber,
                                                           @RequestParam Integer amendementNumber) {
        return contractRestService.getContractDetails(contractNumber, amendementNumber);
    }


    @GetMapping("/filter-contracts")
    @Operation(
            summary = "Liste les contrats des offres actives ou non selon des critères de recherche",
            description = "Permet de récupérer tous les contrats, synchronisés ou non, des offres actives ou non selon un boolean")
    Mono<Page<ContractSupervisionDto>> getFilteredContracts(
            @RequestParam(defaultValue = "0") boolean errors,
            @RequestParam(defaultValue = "0") boolean isNotSynchronized,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "desc") String order,
            @RequestParam(defaultValue = "0") boolean showAll,
            @RequestParam(required = false) String contractNumber,
            @RequestParam(required = false) String custAccNumber,
            @RequestParam(required = false) List<String> offers) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idContractVersion"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return contractRestService.getFilteredContracts(errors, isNotSynchronized, showAll, contractNumber, custAccNumber, offers, pageable);
    }


    @GetMapping("/active-offers-contracts-for-replay")
    @Operation(
            summary = "Liste les contrats pour le rejeu",
            description = "Permet de récupérer tous les contrats disponibles pour le rejeu")
    Flux<ReplayDto> getContractsActiveOffersForReplay() {
        return contractRestService.getAllContractsForReplay();
    }

    @GetMapping("/extract-contracts-synchronized")
    @Operation(
            summary = "Permet de récupérer tous les contrats synchros",
            description = "Récupération des contrats synchro pour export excel"
    )
    Flux<ContractSupervisionDto> getSynchedContractsExport() {
        return contractRestService.getSynchedContractsExport();
    }

}
