package fr.laposte.blg.blinks.u14.service.producer;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import MD.LatestValue.Address;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;

import java.util.*;

@Slf4j
@Service
@Profile("mar-srec|mar-sdev|sloc")
public class KafkaLegalPersonAddressInjectorProducer {

    @Value("${fr.laposte.topic.legal_person_address_injector}")
    String topic;

    @Resource(name = "kafkaConfig")
    Properties kafkaConfig;

    private KafkaSender<String, Address> legalPersonAddressKafkaSender;

    public KafkaLegalPersonAddressInjectorProducer(KafkaSender<String, Address> legalPersonAddressKafkaSender) {
        this.legalPersonAddressKafkaSender = legalPersonAddressKafkaSender;
    }

    @PostConstruct
    void init() {
        SenderOptions<String, Address> senderOptions = SenderOptions.create(kafkaConfig);
        legalPersonAddressKafkaSender = KafkaSender.create(senderOptions);
    }

    public Mono<Void> sendLegalPersonAddressToTopic(Address address) {
        return legalPersonAddressKafkaSender.send(Mono.just(address)
                        .map(message -> SenderRecord.create(new ProducerRecord<>(topic, message.getCustAccNumber().toString(), message), message)))
                .doOnTerminate(() -> log.info("address legalperson {} published on topic {}", address.getCustAccNumber().toString(), topic))
                .then();
    }
}
