export class ClientTableDetail {
  siret?: string;
  legalNatureCode?: string;
  legalNatureName?: string;
  implantationCode?: string;
  vatNumber?: string;
  message?: string;
  errorMessage?: string;
}
