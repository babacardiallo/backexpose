package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractErrorEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;

public interface ContractErrorRepository extends ReactiveCrudRepository<ContractErrorEntity, Long> {

    @Query("""
            select             
            contract_number,
            revision_number,
            amendment_number,
            date_error,
            first_error_date,
            is_synchronized,
            previous_date_synchronization,
            workflow_step,
            error_message,
            ops_code
            from offer_errors_view
            where ops_code = :codeOps and workflow_step like :workflowStep""")
    Flux<ContractErrorEntity> getListcontractErrors(String codeOps, String workflowStep);

    @Query("""
            select
            contract_number,
            revision_number,
            amendment_number,
            date_error,
            first_error_date,
            is_synchronized,
            previous_date_synchronization,
            workflow_step,
            error_message,
            ops_code
            from offer_errors_view
            order by ops_code, contract_number, amendment_number, revision_number""")
    Flux<ContractErrorEntity> getAllErrorsRepository();
}
