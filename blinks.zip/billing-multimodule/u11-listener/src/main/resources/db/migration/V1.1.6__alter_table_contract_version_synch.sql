alter table blg_contract_importer.contract_version add column offset_num_consolidated int;
alter table blg_contract_importer.contract_version add column partition_num_consolidated int;
