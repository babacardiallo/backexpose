package fr.laposte.blg.blinks.u17.dto;

import fr.laposte.blg.blinks.lib.common.entities.ExportStatus;
import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MorningCheckDto {

    private Long idExport;
    private String type;
    private String fileName;
    private String startDate;
    private String endDate;
    private Integer nbTreatedInvoices;
    private Integer nbInvoiceExportedInFile;
    private Integer nbNormalInvoices;
    private Integer nbAcomptes;
    private Integer nbAvoirs;
    private Integer nbReleves;
    private Double caHtHorsRelevesAndAcomptes;
    private Double caTtcHorsRelevesAndAcomptes;
    private String comment;
    private Boolean isFileEmpty;
    private Boolean isFileSent;
    private ExportStatus status;
    private String fileSendDate;
    private Integer nbExcludedInvoices;
    private Integer nbFailedInvoices;
    private TransferStatus transferStatus;
    private String errorMessage;
    private String errorCode;

}
