CREATE OR REPLACE
VIEW `contract_supervision_actives` AS
    SELECT
        CONCAT(`co`.`contract_number`,
                `cv`.`amendment_number`,
                `cv`.`revision_number`) AS `id`,
        `co`.`contract_number` AS `contract_number`,
        `co`.`id_contract` AS `id_contract`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `cv`.`status` AS `status`,
        `cv`.`substatus` AS `substatus`,
        `cv`.`id_contract_version` AS `id_contract_version`,
        `co`.`type` AS `type`,
        `co`.`subtype` AS `subtype`,
        `vo`.`ops_code` AS `ops_code`,
        `vo`.`ops_id` AS `ops_id`,
        `ro`.`ops_label` AS `ops_label`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        COALESCE(GREATEST(`cv`.`date_synchronization`,
                        `cv`.`previous_date_synchronization`),
                `cv`.`date_synchronization`,
                `cv`.`previous_date_synchronization`) AS `last_date_synchronization`,
        `el`.`date_error` AS `date_error`,
        `el`.`first_error_date` AS `first_error_date`,
        `lp`.`cust_acc_number` AS `cust_acc_number`,
        `co`.`cust_acc_number` AS `cust_acc_number_before_synchronisation`
    FROM
        (((((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        LEFT JOIN `legal_person` `lp` ON ((`lp`.`cust_acc_number` = `co`.`cust_acc_number`)))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`cv`.`amendment_number` = `el`.`amendment_number`)
            AND (`el`.`workflow_step` = 'SYNCHRONIZATION_CONTRACT')
            AND (`el`.`date_error` IS NOT NULL))))
    WHERE
        `vo`.`ops_code` IN (SELECT
                `offer_filter`.`ops_code`
            FROM
                `offer_filter`);

CREATE OR REPLACE
VIEW `contract_supervision_all` AS
    SELECT
        CONCAT(`co`.`contract_number`,
                `cv`.`amendment_number`,
                `cv`.`revision_number`) AS `id`,
        `co`.`contract_number` AS `contract_number`,
        `co`.`id_contract` AS `id_contract`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `cv`.`status` AS `status`,
        `cv`.`substatus` AS `substatus`,
        `cv`.`id_contract_version` AS `id_contract_version`,
        `co`.`type` AS `type`,
        `co`.`subtype` AS `subtype`,
        `vo`.`ops_code` AS `ops_code`,
        `vo`.`ops_id` AS `ops_id`,
        `ro`.`ops_label` AS `ops_label`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        COALESCE(GREATEST(`cv`.`date_synchronization`,
                        `cv`.`previous_date_synchronization`),
                `cv`.`date_synchronization`,
                `cv`.`previous_date_synchronization`) AS `last_date_synchronization`,
        `el`.`date_error` AS `date_error`,
        `el`.`first_error_date` AS `first_error_date`,
        `lp`.`cust_acc_number` AS `cust_acc_number`,
        `co`.`cust_acc_number` AS `cust_acc_number_before_synchronisation`
    FROM
        (((((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        LEFT JOIN `legal_person` `lp` ON ((`lp`.`cust_acc_number` = `co`.`cust_acc_number`)))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`cv`.`amendment_number` = `el`.`amendment_number`)
            AND (`el`.`workflow_step` LIKE '%SYNCHRONIZATION%'))));

CREATE OR REPLACE
VIEW `contract_supervision_details` AS
    SELECT
        CONCAT(`co`.`contract_number`,
                `cv`.`amendment_number`,
                `cv`.`revision_number`) AS `id`,
        `co`.`contract_number` AS `contract_number`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `el`.`date_error` AS `date_error`,
        `el`.`first_error_date` AS `first_error_date`,
        `el`.`error_message` AS `error_message`,
        `ii`.`invoice_address_number` AS `invoice_address_number`,
        `ii`.`dedicated_invoice_flag` AS `dedicated_invoice_flag`,
        `ii`.`invoice_periodicity_label` AS `invoice_periodicity_label`,
        `ii`.`sending_support_label` AS `sending_support_label`,
        `ii`.`payment_means` AS `payment_means`,
        `ii`.`rum` AS `rum`,
        `ii`.`cust_purchase_order_number` AS `cust_purchase_order_number`,
        `ii`.`contracting_cust_ref1` AS `contracting_cust_ref1`,
        `ii`.`market_number` AS `market_number`,
        `cv`.`contract_consolidated` AS `contract_consolidated`,
        `cv`.`offset_num_consolidated` AS `offset_num_consolidated`,
        `cv`.`partition_num_consolidated` AS `partition_num_consolidated`,
        `cv`.`contract_odc_json` AS `contract_odc_json`,
        `cv`.`offset_num` AS `offset`,
        `cv`.`partition_num` AS `partition`,
        `cv`.`category` AS `category`
    FROM
        ((((((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `invoice_information` `ii` ON ((`cv`.`id_invoice_information` = `ii`.`id_invoice_information`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        LEFT JOIN `legal_person` `lp` ON ((`lp`.`cust_acc_number` = `co`.`cust_acc_number`)))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`cv`.`amendment_number` = `el`.`amendment_number`))))
    WHERE
        `vo`.`ops_code` IN (SELECT
                `offer_filter`.`ops_code`
            FROM
                `offer_filter`);

CREATE OR REPLACE
VIEW `offer_errors_view` AS
    SELECT
        `er`.`contract_number` AS `contract_number`,
        `er`.`revision_number` AS `revision_number`,
        `er`.`amendment_number` AS `amendment_number`,
        `er`.`date_error` AS `date_error`,
        `er`.`first_error_date` AS `first_error_date`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        `cv`.`date_synchronization` AS `previous_date_synchronization`,
        `er`.`workflow_step` AS `workflow_step`,
        `er`.`error_message` AS `error_message`,
        `er`.`ops_code` AS `ops_code`
    FROM
        ((`error_log` `er`
        LEFT JOIN `contract` `c` ON ((`er`.`contract_number` = `c`.`contract_number`)))
        LEFT JOIN `contract_version` `cv` ON (((`c`.`id_contract` = `cv`.`id_contract`)
            AND (`er`.`amendment_number` = `cv`.`amendment_number`))))
    WHERE
        ((`er`.`ops_code` IS NOT NULL)
            AND (((`er`.`workflow_step` LIKE 'CONTRACT%')
            AND ((`cv`.`revision_number` IS NULL)
            OR (`er`.`revision_number` > `cv`.`revision_number`)))
            OR ((`er`.`workflow_step` LIKE '%SYNCH%')
            AND ((`c`.`contract_number` IS NULL)
            OR (`er`.`amendment_number` <> `cv`.`amendment_number`)
            OR (`er`.`revision_number` >= `cv`.`revision_number`)))));