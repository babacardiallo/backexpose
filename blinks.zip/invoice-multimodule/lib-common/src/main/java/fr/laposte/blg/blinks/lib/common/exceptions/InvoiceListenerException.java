package fr.laposte.blg.blinks.lib.common.exceptions;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class InvoiceListenerException extends RuntimeException {
    private WorkFlowStep workFlowStep;
    private CodeError code;
    public InvoiceListenerException(String message, Throwable cause, WorkFlowStep workFlowStep, CodeError code){
        super(message, cause);
        this.workFlowStep = workFlowStep;
        this.code = code;
    }
}
