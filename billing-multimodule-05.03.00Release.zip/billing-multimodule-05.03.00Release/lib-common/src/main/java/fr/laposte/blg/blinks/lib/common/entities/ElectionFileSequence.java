package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Table("file_sequence_election")
public class ElectionFileSequence {

    @Id
    @Column("id")
    private Long id;

    @Column("file_sequence")
    private Integer fileSequence;

}
