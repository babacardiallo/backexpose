package fr.laposte.blg.blinks.lib.common.entities;

public enum InvoiceStatusEnum {
    NEW,
    SUCCESS,
    FAILED,
    EXCLUDED

}

