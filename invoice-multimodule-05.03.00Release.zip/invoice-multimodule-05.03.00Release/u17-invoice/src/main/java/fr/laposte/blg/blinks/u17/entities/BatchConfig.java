package fr.laposte.blg.blinks.u17.entities;

import fr.laposte.blg.blinks.lib.common.entities.FileType;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;


@Table("batch_config")
@Data
@Accessors(chain = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BatchConfig {
    @Id
    @Column("id")
    int id;

    @Column("code")
    @NotBlank
    FileType code;

    @Column("exec_order")
    int order;

    @Column("is_enable")
    boolean isEnabled;

    @Column("updated" )
    LocalDateTime lastUpdated;
}
