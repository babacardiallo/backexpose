package fr.laposte.blg.blinks.u17.dto.invoice;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import fr.laposte.blg.blinks.lib.common.dto.BillingAddressDto;
import fr.laposte.blg.blinks.lib.common.dto.UniqueMandateReferenceDto;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "custAccNumber",
        "extension",
        "categoryCode",
        "categoryLabel",
        "inactivationDate",
        "custInvoiceTermId",
        "sectorCode",
        "periodicityCode",
        "periodicityLabel",
        "paymentMeanCode",
        "paymentMeanLabel",
        "repaymentTypeCode",
        "repaymentTypeLabel",
        "paymentPeriodCode",
        "paymentPeriodLabel",
        "VATliabilityFlag",
        "invoiceModeCode",
        "invoiceModeLabel",
        "sendingSupportCode",
        "sendingSupportLabel",
        "SECode",
        "EJCode",
        "marketNumber",
        "uniqueMandateReference",
        "billingAddress",
})
public class BillingAccountInfoCaDto {
    String custAccNumber;
    Integer extension;
    Instant inactivationDate;
    String periodicityCode;
    String categoryCode;
    String periodicityLabel;
    String paymentMeanCode;
    String paymentMeanLabel;
    String paymentPeriodCode;
    String paymentPeriodLabel;
    String sendingSupportCode;
    String sendingSupportLabel;
    @JsonProperty("SECode")
    String seCode;
    @JsonProperty("EJCode")
    String ejCode;
    String marketNumber;

    UniqueMandateReferenceDto uniqueMandateReference;
    BillingAddressDto billingAddress;
}
