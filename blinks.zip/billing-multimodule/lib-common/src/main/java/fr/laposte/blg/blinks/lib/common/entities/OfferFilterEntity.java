package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table("offer_filter")
@Data
@Builder
@AllArgsConstructor
public class OfferFilterEntity implements Persistable<Long> {
    @Id
    @Column("offer_ops_id")
    private Long offerOpsId;
    @Column("ops_code")
    private String opsCode;
    @Column("filter")
    private String filter;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OfferFilterEntity that = (OfferFilterEntity) o;
        return Objects.equals(offerOpsId, that.offerOpsId) &&
            Objects.equals(opsCode, that.opsCode) &&
            Objects.equals(filter, that.filter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(offerOpsId, opsCode, filter);
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return offerOpsId;
    }

    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        //in order to force an insert even if we set the id.
        return true;
    }
}
