import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgxPermissionsModule } from 'ngx-permissions';
import { SharedModule } from '../shared/shared.module';
import { ClientsRoutingModule } from './clients-routing.module';
import { ClientsComponent } from './clients.component';
import { ClientsDetailsPopUpComponent } from './components/clients-details-pop-up/clients-details-pop-up.component';
import { ClientsReplayerPopUpComponent } from './components/clients-replayer-pop-up/clients-replayer-pop-up.component';
import { ClientsTableComponent } from './components/clients-table.component';
import { ModalService } from 'ngx-modal-ease';


@NgModule({
    imports: [
        SharedModule,
        ClientsRoutingModule,
        NgxDatatableModule,
        MatSnackBarModule,
        NgxPermissionsModule.forChild()
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [ClientsComponent, ClientsTableComponent, ClientsDetailsPopUpComponent, ClientsReplayerPopUpComponent],
    exports: [ClientsComponent]
})
export class ClientsModule { }