
# Shell script for docker

We have two scripts init.sh and docker-before.sh:
- **Init.sh:** 👉 It is used for the initialization of environment before running pipeline 
- **Docker-before.sh:** 👉 It is used for creating a docker-context folder where whe can copy all we need for docker build
