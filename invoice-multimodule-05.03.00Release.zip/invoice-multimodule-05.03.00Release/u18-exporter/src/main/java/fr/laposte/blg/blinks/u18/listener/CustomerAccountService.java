package fr.laposte.blg.blinks.u18.listener;

import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import fr.laposte.blg.blinks.u18.repository.CustomerAccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerAccountService {

    private final CustomerAccountRepository customerAccountRepository;

    //
    // Utilisation d'un bean different du listener pour pouvoir appliquer l'annotation @Transactional
    // uniquement à cet endroit.
    //
    @Transactional
    public void save(CustomerAccountMessage message) {
        log.info("Received record");
        customerAccountRepository.save(message);
        log.info("Saved record");
    }
}
