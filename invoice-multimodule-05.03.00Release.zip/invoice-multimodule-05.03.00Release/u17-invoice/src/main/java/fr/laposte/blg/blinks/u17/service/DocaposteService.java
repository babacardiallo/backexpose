package fr.laposte.blg.blinks.u17.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializationFeature;
import fr.laposte.blg.blinks.lib.common.dto.DocaposteDto;
import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.utils.TrackExecutionTime;
import fr.laposte.blg.blinks.u17.dto.InvoiceExportDto;
import fr.laposte.blg.blinks.u17.util.ObjectMapperWithModules;
import fr.laposte.blg.blinks.u17.util.XmlMapperWithJavaTimeModule;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.File;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocaposteService implements ExportBaseService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceMessageRepository invoiceMessageRepository;
    private final ObjectMapperWithModules objectMapper;
    private final XmlMapperWithJavaTimeModule xmlMapper;
    private final ExportService exportService;
    private final ExportProcessRepository exportProcessRepository;
    @Value("${fr.laposte.docaposte.file.name}")
    private String baseName;
    @Value("${fr.laposte.docaposte.file.location}")
    private String location;
    private String fileName;

    @TrackExecutionTime
    public Mono<ExportHistoryEntity> process(ExportProcess exportProcess, String exportPath) {
        if(exportProcess.getFileType().equals(FileType.DOCAPOSTE)){
            log.info("Début du traitement Docaposte avec les avis de paiement exclus, avisPaiement = false");
        } else {
            log.info("Début du traitement Docaposte avec les avis, avisPaiement = true");
        }
        if (exportProcess.getMaxId().equals(Long.MAX_VALUE)){
            exportProcess.setMaxId(invoiceRepository.getMaxIdForProcess().block());
        }
        String finalLocation = exportPath != null ? exportPath:location;
        xmlMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        var startTime = Instant.now();
        List<InvoiceExportDto> excludedInvoices = new ArrayList<>();
        List<InvoiceExportDto> failedInvoices = new ArrayList<>();
        List<InvoiceExportDto> validInvoices = new ArrayList<>();
        List<InvoiceDTO> validInvoicesDto = new ArrayList<>();
        try {
            Flux<InvoiceEntity> invoiceEntityFlux = exportProcess.getFileType().equals(FileType.DOCAPOSTE) ?
                    this.invoiceRepository.findByDocaposteExportIdIsNullAndIdBetweenOrderByReferenceAsc(exportProcess.getMinId(), exportProcess.getMaxId()):
                    this.invoiceRepository.findByDocaposteAvispaiementExportIdIsNullAndIdBetweenOrderByReferenceAsc(exportProcess.getMinId(), exportProcess.getMaxId());
            List<Pair<InvoiceEntity, InvoiceDTO>> validInvoicePairs =
                    invoiceEntityFlux
                            .flatMap(invoiceEntity -> this.invoiceMessageRepository.getMessage(invoiceEntity.getIdInvoice())
                                    .flatMap(message -> {
                                        try {
                                            InvoiceDTO invoiceDTO = this.objectMapper.readValue(message, InvoiceDTO.class);
                                            return Mono.just(Pair.of(invoiceEntity, invoiceDTO));
                                        } catch (JsonProcessingException e) {
                                            log.info("Failure for invoice {} : error when parsing invoice JSON : {}",
                                                    invoiceEntity.getInvoiceNumber(), e.getMessage());
                                            failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Error when parsing invoice JSON: " + e.getMessage(), "U170001"));
                                            return Mono.empty();
                                        }
                                    })
                            )
                            .concatMap(pair -> {
                                InvoiceEntity invoiceEntity = pair.getFirst();
                                InvoiceDTO invoiceDTO = pair.getSecond();
                                Boolean avisPaiementFlag = invoiceDTO.getInvoiceHeader().getAvisPaiementFlag();
                                if(FileType.DOCAPOSTE.equals(exportProcess.getFileType())){
                                    if (invoiceDTO.getInvoiceHeader() == null || invoiceDTO.getInvoiceHeader().getPrintFlag() == null) {
                                        log.info("Failure for invoice {} : missing header or printFlag",
                                                invoiceEntity.getInvoiceNumber());
                                        failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Missing header or printFlag value", "U170002"));
                                        return Mono.empty();
                                    }
                                    if (Boolean.FALSE.equals(invoiceDTO.getInvoiceHeader().getPrintFlag())) {
                                        log.info("Skipping invoice {} : printFlag from invoice is false",
                                                invoiceEntity.getInvoiceNumber());
                                        excludedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Skipping invoice : printFlag from invoice is false", null));
                                        return Mono.empty();
                                    }
                                    if (Boolean.TRUE.equals(invoiceDTO.getInvoiceHeader().getPdfGeneratedByOpencell())) {
                                        log.info("Skipping invoice {} : pdfGeneratedByOpencell from invoice is true",
                                                invoiceEntity.getInvoiceNumber());
                                        excludedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Skipping invoice : pdfGeneratedByOpencell from invoice is true", null));
                                        return Mono.empty();
                                    }
                                    if (Boolean.TRUE.equals(invoiceDTO.getBillingAccount().getEfact())) {
                                        log.info("Skipping invoice {} : efact from invoice is true",
                                                invoiceEntity.getInvoiceNumber());
                                        excludedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Skipping invoice : efact from invoice is true", null));
                                        return Mono.empty();
                                    }
                                    if (Boolean.TRUE.equals(avisPaiementFlag)) {
                                        log.info(
                                                "Skipping invoice {} : avisPaiementFlag is true",
                                                invoiceEntity.getInvoiceNumber());

                                        excludedInvoices.add(new InvoiceExportDto(
                                                invoiceEntity.getIdInvoice(),
                                                invoiceEntity.getInvoiceNumber(),
                                                "Skipping invoice : avisPaiementFlag = true",
                                                null
                                        ));

                                        return Mono.empty();
                                    }
                                } else {
                                    if (invoiceDTO.getInvoiceHeader() == null ) {
                                        log.info("Failure for invoice {} : missing header",
                                                invoiceEntity.getInvoiceNumber());
                                        failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Missing header value", "U170002"));
                                        return Mono.empty();
                                    }
                                    if (Boolean.FALSE.equals(avisPaiementFlag)) {
                                        log.info(
                                                "Skipping invoice {} : avisPaiementFlag is false",
                                                invoiceEntity.getInvoiceNumber());

                                        excludedInvoices.add(new InvoiceExportDto(
                                                invoiceEntity.getIdInvoice(),
                                                invoiceEntity.getInvoiceNumber(),
                                                "Skipping invoice : avisPaiementFlag = false",
                                                null
                                        ));

                                        return Mono.empty();
                                    }
                                }

                                log.info("Treating invoice {}", invoiceEntity.getInvoiceNumber());
                                validInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), null, null));
                                validInvoicesDto.add(invoiceDTO);
                                return Mono.just(pair);
                            })
                            .collectList()
                            .block();

            this.fileName = "NO_INVOICES";
            if (!ObjectUtils.isEmpty(validInvoicePairs)) {
                List<InvoiceDTO> invoicesToWrite = validInvoicePairs.stream()
                        .map(Pair::getSecond)
                        .toList();
                DocaposteDto docaposteDto = new DocaposteDto();
                docaposteDto.setInvoices(invoicesToWrite);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
                this.fileName = baseName + "_" + LocalDateTime.now().format(formatter) + ".ws";
                this.xmlMapper.writeValue(new File(finalLocation + this.fileName), docaposteDto);
            }
        } catch (Exception e) {
            log.error("Couldn't export Docaposte file : {}", e.getMessage(), e);
        }
        return this.exportService.generateHistory(startTime, validInvoicesDto, validInvoices, failedInvoices, excludedInvoices, exportProcess.getFileType(), this.fileName);

    }

}
