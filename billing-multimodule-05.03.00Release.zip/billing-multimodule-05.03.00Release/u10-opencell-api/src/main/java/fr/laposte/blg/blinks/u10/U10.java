package fr.laposte.blg.blinks.u10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
public class U10 {

	public static void main(String[] args) {
		SpringApplication.run(U10.class, args);
	}

}
