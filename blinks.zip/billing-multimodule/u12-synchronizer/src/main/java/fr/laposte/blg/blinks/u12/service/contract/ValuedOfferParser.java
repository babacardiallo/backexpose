package fr.laposte.blg.blinks.u12.service.contract;

import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferEntity;
import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferMessage;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationMappingException;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.JsonDecoder;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ValuedOfferParser {

    private static final String ADR_PREST_KEY = "ADR_PREST";
    private static final String ETB_PREST_KEY = "ETB_PREST";

    public Map<String, List<String>> fetchAllDeliveryAddressIdsInOffer(ValuedOfferEntity valuedOfferEntity, ValuedOfferMessage valuedOfferMessage) {


        Offer valuedOfferDeserialized;
        try {
            JsonDecoder decoder = DecoderFactory.get().jsonDecoder(Offer.getClassSchema(), valuedOfferMessage.getMessage());
            SpecificDatumReader<Offer> reader = new SpecificDatumReader<>(Offer.getClassSchema());
            valuedOfferDeserialized = reader.read(null, decoder);
        } catch (Exception e) {
            throw new SynchronizationMappingException(
                    "Error during criteria and product/service mapping: " + e.getMessage()
            );
        }

        var offerCriteriaListOpt = Optional.ofNullable(valuedOfferDeserialized.getOfferCriteria());
        var offerProductListOpt = Optional.ofNullable(valuedOfferDeserialized.getProducts());

        HashSet<String> deliveryAddressIds = new HashSet<>();
        HashSet<String> establishmentIds = new HashSet<>();
        //Parsing des critères d'offre
        offerCriteriaListOpt
                .ifPresentOrElse(offerCriteriaList -> {
                    offerCriteriaList.forEach(offerCriteria -> fetchDeliveryAddressIdsFromOfferCriterion(offerCriteria, deliveryAddressIds, establishmentIds));
                }, () -> log.warn(Markers.append("idValuedOffer"
                                , valuedOfferEntity.getIdValuedOffer())
                        , "No offerCriteria block in valuedOffer; idValuedOffer : {}"
                        , valuedOfferEntity.getIdValuedOffer()));
        //Parsing des products/services
        offerProductListOpt.ifPresentOrElse(offerProductList -> {
            offerProductList
                    .forEach(offerProduct -> fetchDeliveryAddressFromProduct(offerProduct, deliveryAddressIds, establishmentIds));
        }, () -> log.warn(Markers.append("idValuedOffer"
                        , valuedOfferEntity.getIdValuedOffer())
                , "No products block in valuedOffer; idValuedOffer : {}"
                , valuedOfferEntity.getIdValuedOffer()));

        Map<String, List<String>> response = new HashMap<>();
        response.put(ADR_PREST_KEY, new ArrayList<>(deliveryAddressIds));
        response.put(ETB_PREST_KEY, new ArrayList<>(establishmentIds));
        return response;

    }

    private void fetchDeliveryAddressIdsFromOfferCriterion(OfferCriteria offerCriterion, HashSet<String> deliveryAddressIds, HashSet<String> etablishmentIds) {
        if (ObjectUtils.isNotEmpty(offerCriterion.getOfferCriterionKey()) && ObjectUtils.isNotEmpty(offerCriterion.getOfferCriterionValueId())) {
            if (offerCriterion.getOfferCriterionKey().toString().equals(ADR_PREST_KEY)) {
                deliveryAddressIds.add(offerCriterion.getOfferCriterionValueId().toString());
            }
            if (offerCriterion.getOfferCriterionKey().toString().equals(ETB_PREST_KEY)) {
                etablishmentIds.add(offerCriterion.getOfferCriterionValueId().toString());
            }
        }
        if (ObjectUtils.isNotEmpty(offerCriterion.getOfferCriterionCriteria())) {
            offerCriterion.getOfferCriterionCriteria()
                    .forEach(o -> {
                        if (o instanceof OfferCriteria) {
                            fetchDeliveryAddressIdsFromOfferCriterion((OfferCriteria) o, deliveryAddressIds, etablishmentIds);
                        } else if (o instanceof List) {
                            ((List<OfferCriteria>) o).forEach(offerCriteria -> fetchDeliveryAddressIdsFromOfferCriterion(offerCriteria, deliveryAddressIds, etablishmentIds));
                        }
                    });
        }

    }

    private void fetchDeliveryAddressFromProduct(OfferProduct offerProduct, HashSet<String> deliveryAddressIds, HashSet<String> etablishmentIds) {
        List<ProductCriteria> offerProductCriteria = offerProduct.getProductCriteria();
        if (ObjectUtils.isNotEmpty(offerProductCriteria)) {
            offerProductCriteria
                    .forEach(productCriteria -> fetchDeliveryAddressIdsFromProductCriterion(productCriteria, deliveryAddressIds, etablishmentIds));
        }
        if (ObjectUtils.isNotEmpty(offerProduct.getProductService())) {
            offerProduct.getProductService()
                    .forEach(productService -> fetchDeliveryAddressFromService(productService, deliveryAddressIds, etablishmentIds));
        }

    }

    private void fetchDeliveryAddressIdsFromProductCriterion(ProductCriteria productCriterion, HashSet<String> deliveryAddressIds, HashSet<String> etablishmentIds) {
        if (ObjectUtils.isNotEmpty(productCriterion.getProductCriterionKey()) && ObjectUtils.isNotEmpty(productCriterion.getProductCriterionValueId())) {
            if (productCriterion.getProductCriterionKey().toString().equals(ADR_PREST_KEY)) {
                deliveryAddressIds.add(productCriterion.getProductCriterionValueId().toString());
            }
            if (productCriterion.getProductCriterionKey().toString().equals(ETB_PREST_KEY)) {
                etablishmentIds.add(productCriterion.getProductCriterionValueId().toString());
            }
        }
        if (ObjectUtils.isNotEmpty(productCriterion.getProductCriterionCriteria())) {
            productCriterion.getProductCriterionCriteria()
                    .forEach(o -> {
                        if (o instanceof ProductCriteria) {
                            fetchDeliveryAddressIdsFromProductCriterion((ProductCriteria) o, deliveryAddressIds, etablishmentIds);
                        } else if (o instanceof List) {
                            ((List<ProductCriteria>) o).forEach(productCriteria -> fetchDeliveryAddressIdsFromProductCriterion(productCriteria, deliveryAddressIds, etablishmentIds));
                        }
                    });
        }
    }

    private void fetchDeliveryAddressFromService(ProductService productService, HashSet<String> deliveryAddressIds, HashSet<String> etablishmentIds) {
        List<ServiceCriteria> serviceCriteria = productService.getServiceCriteria();

        if (ObjectUtils.isNotEmpty(serviceCriteria)) {
            serviceCriteria
                    .forEach(serviceCriterion -> fetchDeliveryAddressIdsFromServiceCriterion(serviceCriterion, deliveryAddressIds, etablishmentIds));
        }
    }

    private void fetchDeliveryAddressIdsFromServiceCriterion(ServiceCriteria serviceCriterion, HashSet<String> deliveryAddressIds, HashSet<String> etablishmentIds) {
        if (ObjectUtils.isNotEmpty(serviceCriterion.getServiceCriterionKey()) && ObjectUtils.isNotEmpty(serviceCriterion.getServiceCriterionValueId())) {
            if (serviceCriterion.getServiceCriterionKey().toString().equals(ADR_PREST_KEY)) {
                deliveryAddressIds.add(serviceCriterion.getServiceCriterionValueId().toString());
            }
            if (serviceCriterion.getServiceCriterionKey().toString().equals(ETB_PREST_KEY)) {
                etablishmentIds.add(serviceCriterion.getServiceCriterionValueId().toString());
            }
        }
        if (ObjectUtils.isNotEmpty(serviceCriterion.getServiceCriterionCriteria())) {
            serviceCriterion.getServiceCriterionCriteria()
                .forEach(o -> {
                    if (o instanceof ServiceCriteria serviceCriteria) {
                        fetchDeliveryAddressIdsFromServiceCriterion(serviceCriteria, deliveryAddressIds, etablishmentIds);
                    } else if (o instanceof List) {
                        ((List<ServiceCriteria>) o).forEach(serviceCriteria -> fetchDeliveryAddressIdsFromServiceCriterion(serviceCriteria, deliveryAddressIds, etablishmentIds));
                    }
                });
        }
    }

}
