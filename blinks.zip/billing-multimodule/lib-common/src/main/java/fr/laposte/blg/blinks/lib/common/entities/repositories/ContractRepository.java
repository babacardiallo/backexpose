package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractEntity;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Repository("contractEntityRepository") //To prevent conficts with Opencell library contract-module
public interface ContractRepository extends ReactiveCrudRepository<ContractEntity, Long> {

    Mono<ContractEntity> findFirstByContractNumber(String contractNumber);

    @Query("""
            select * from contract_version cv
            inner join valued_offer vo on cv.id_valued_offer = vo.id_valued_offer
            inner join contract c on cv.id_contract = c.id_contract
            where vo.ops_code = :opsCode""")
    Flux<ContractVersionEntity> getContractVersionByOpsCode(String opsCode);

    @Transactional(readOnly = true)
    @Query("select count(distinct id_contract) from contract_version where is_synchronized=1")
    Mono<Long> countContractsSynchronized();

    @Transactional(readOnly = true)
    @Query("select count(id_contract) from contract")
    Mono<Long> countContractsIntegrated();

    Mono<Void> deleteByContractNumber(String contractNumber);

}
