ALTER TABLE legal_person
ADD COLUMN billing_typology VARCHAR(2) DEFAULT NULL;