package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_portfolio_team_link")
@Data
@Accessors(chain = true)
public class BusinessPortfolioTeamLink implements Disposable, Persistable<Long> {
    @Id
    @Column("business_portfolio_link_team_id")
    private Long businessPortfolioLinkTeamId;
    @Column("business_portfolio_id")
    private int businessPortfolioId;
    @Column("business_team_id")
    private Long businessTeamId;
    @Column("business_portfolio_link_type_id")
    private Integer businessPortfolioLinkTypeId;
    @Column("business_portfolio_link_team_start_date")
    private Instant businessPortfolioLinkTeamStartDate;
    @Column("business_portfolio_link_team_end_date")
    private Instant businessPortfolioLinkTeamEndDate;
    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessPortfolioLinkTeamStartDate) &&
                        businessPortfolioLinkTeamStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessPortfolioLinkTeamEndDate)
                                || businessPortfolioLinkTeamEndDate.isAfter(Instant.now())
                )
                        &&
                        businessPortfolioLinkTypeId == 1;//On ne prend que les liens de portefeuille PILOTE soit d'id 1 ;
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessPortfolioLinkTeamId;
    }


    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
