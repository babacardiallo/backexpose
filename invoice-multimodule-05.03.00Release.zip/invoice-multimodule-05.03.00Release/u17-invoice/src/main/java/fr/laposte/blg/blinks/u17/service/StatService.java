package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.dto.StatDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class StatService {
    private final InvoiceRepository invoiceRepository;
    private static final String  INVOICE_SUPERVISION_LABEL="Nombre de factures";
    private static final String  AVOIR_SUPERVISION_LABEL="Nombre d'avoirs";
    private static final String  RELEVE_SUPERVISION_LABEL="Nombre de relevés";
    private static final String  INVOICE_EXPORTED_TO_DOCAPOSTE_SUPERVISION_LABEL="Nombre de factures exportées vers Docaposte";
    private static final String  INVOICE_EXPORTED_TO_INFOCA_SUPERVISION_LABEL="Nombre de factures exportées vers Infoca";
    private static final String  INVOICE_EXPORTED_TO_COEURFINANCE_SUPERVISION_LABEL="Nombre de factures exportées vers Coeurfinance";

    public Mono<StatDto[]> getTotaux(){
        return Mono.zip(
                invoiceRepository.getNbInvoices(),
                invoiceRepository.getNbAvoirs(),
                invoiceRepository.getNbReleves(),
                invoiceRepository.countExportedInvoicesToDocaposte(),
                invoiceRepository.countExportedInvoicesToInfoca(),
                invoiceRepository.countExportedInvoicesToCoeurfinance()
        ).flatMap(tuple5 -> Mono.just(
                new StatDto[]{
                        new StatDto(0,INVOICE_SUPERVISION_LABEL, tuple5.getT1()),
                        new StatDto(1,AVOIR_SUPERVISION_LABEL, tuple5.getT2()),
                        new StatDto(2,RELEVE_SUPERVISION_LABEL, tuple5.getT3()),
                        new StatDto(3,INVOICE_EXPORTED_TO_DOCAPOSTE_SUPERVISION_LABEL, tuple5.getT4()),
                        new StatDto(4,INVOICE_EXPORTED_TO_INFOCA_SUPERVISION_LABEL, tuple5.getT5()),
                        new StatDto(5,INVOICE_EXPORTED_TO_COEURFINANCE_SUPERVISION_LABEL, tuple5.getT6())

                }
        ));
    }
}
