package fr.laposte.blg.blinks.lib.security;

import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.web.server.authentication.AuthenticationWebFilter;

public class ByPassJwtAuthFilter extends AuthenticationWebFilter {
    /**
     * Creates an instance
     *
     * @param authenticationManager the authentication manager to use
     */
    public ByPassJwtAuthFilter(ReactiveAuthenticationManager authenticationManager) {
        super(authenticationManager);
        setServerAuthenticationConverter(new ServerBodyAuthenticationConverter());
        setAuthenticationSuccessHandler(new StatusCodeAuthSuccessHandler());
    }

}