package fr.laposte.blg.blinks.u17.dto.coeurfinance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class InvoiceCoeurfinanceDto {

    String[] header;
    double amount;
    List<String[]> invoiceContent;
    String invoiceNo;
    String error;
    boolean isExport;

}
