package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class ContractSupervisionDetailsDto {

    private Instant dateError;
    private Instant firstErrorDate;
    private String errorMessage;
    private String invoiceAddressNumber;
    private Boolean dedicatedInvoiceFlag;
    private String invoicePeriodicityLabel;
    private String sendingSupportLabel;
    private String paymentMeans;
    private String rum;
    private String custPurchaseOrderNumber;
    private String contractingCustRef;
    private String marketNumber;
    private String contractConsolidatedJson;
    private String offsetConsolidated;
    private String partitionConsolidated;
    private String contractOdcJson;
    private String offsetOdc;
    private String partitionOdc;
    private String category;
}
