package fr.laposte.blg.blinks.u14.controller.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OfferSupervisionDto {
    private String opsCode;
    private String opsLabel;
    private Instant offerActivationDate;
    private String contractSynch;
    private String contractVersionSynch;
    private String contractIntegrated;
    private String contractVersionIntegrated;
    private String errorListening;
    private String errorSynch;
    private Boolean isActiveOffer;
}
