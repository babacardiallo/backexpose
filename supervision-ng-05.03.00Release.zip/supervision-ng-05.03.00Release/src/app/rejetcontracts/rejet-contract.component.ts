
import { Component } from "@angular/core";
import { Title } from "@angular/platform-browser";
import { Router, NavigationEnd } from "@angular/router";
import { filter } from "rxjs";
import { environment } from "../../environments/environment";

@Component({
    selector: 'rejet-contract',
    templateUrl: './rejet-contract.component.html',
    styleUrls: ['./rejet-contract.component.scss'],
    standalone: false
})

export class RejetContractComponent {
  appName = environment.appName;
  constructor(
    private router: Router,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.updateTitle();

    this.router.events
      .pipe(filter((event: any) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateTitle();
      });
  }

  private updateTitle() {
    this.titleService.setTitle("Factura : Rejets Contrats U3");

  }

}