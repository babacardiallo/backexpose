package fr.laposte.blg.blinks.u12.config.secret;

import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.stereotype.Service;
import reactor.core.Exceptions;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
@Slf4j
public class SecretService {

    /**
     * Chargement d'un secret textuel
     *
     * @param secretPath Chemin du secret
     * @return Valeur textuelle du secret
     */
    /* Charge un secret textuel */
    public Mono<String> loadSecret(String secretPath) {
        return Mono.just(secretPath)
                .doOnNext(path -> log.debug(Markers.append("secretPath", path), "Chargement d'un secret: {}", secretPath))
                /* Création d'un chemin sur le fichier */
                .map(this::getPath)
                /* Lecture du fichier */
                .map(path -> {
                    try {
                        return readFile(path);
                    } catch (IOException e) {
                        throw Exceptions.propagate(e);
                    }
                })
//                .map(base64Secret-> Base64.getDecoder().decode(base64Secret))
                /* Formattage en chaine de caractère */
                .map(base64Secret -> {
                    try {
                        return new String(base64Secret, StandardCharsets.UTF_8.name());
                    } catch (UnsupportedEncodingException e) {
                        throw Exceptions.propagate(e);
                    }
                })
                /* Si une erreur se produit, enregistrement d'un trace pour l'analyse du problème */
                .doOnError(e -> log.debug(Markers.append("secretPath", secretPath) + "Impossible de charger le secret"));
    }

    byte[] readFile(Path path) throws IOException {
        return Files.readAllBytes(path);
    }

    Path getPath(String secretPath) {
        return Paths.get(secretPath);
    }
}
