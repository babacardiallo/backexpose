package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractErrorRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferSupervisionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.RefopsRepository;
import fr.laposte.blg.blinks.u14.controller.dto.OfferSupervisionDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class OfferServiceTest {

    @Mock
    private OfferSupervisionRepository offerSupervisionRepository;
    @Mock
    private ContractErrorRepository contractErrorRepository;
    @Mock
    private RefopsRepository refopsRepository;
    @Mock
    private OfferFilterRepository offerFilterRepository;

    @InjectMocks
    private OfferService offerService;
    private ContractErrorEntity contractErrorEntity;
    private OfferSupervisionEntity offerSupervisionEntity;
    private OfferSupervisionEntity offerSupervisionEntity2;
    private OfferSupervisionEntity offerSupervisionEntity3;
    private RefopsEntity refopsEntity;
    private OfferSupervisionEntity offerSupervisionEntity4;
    private ErrorEntity errorEntity;
    private OfferFilterEntity offerFilterEntity;


    @BeforeEach
    void setUp() {
        offerSupervisionEntity = new OfferSupervisionEntity("2454", "Libellé offre test", Instant.parse("2022-12-05T10:15:30.00Z"), "D-2489248", 420L, "3", "1");
        contractErrorEntity = new ContractErrorEntity("D-2364266-1", "4", "4", Instant.parse("2022-09-09T15:30:45.123Z"), Instant.parse("2022-12-05T10:15:30.00Z"),false, Instant.parse("2022-12-05T10:15:30.00Z"),  "CONTRACT_LISTENING_ORDER", "Error in the order of the versions", "0002");
        refopsEntity = new RefopsEntity(1L, "0275", "libellé offre test", "1.0.0", "1.2.1", Instant.parse("2022-12-05T10:15:30.00Z"), Instant.parse("2022-12-05T10:15:30.00Z"),"data json");
        offerSupervisionEntity2 = new OfferSupervisionEntity("2454", "Libellé offre test", Instant.parse("2023-02-15T10:15:30.00Z"), "D-2489249", 440L, "5", "2");
        offerSupervisionEntity3 = new OfferSupervisionEntity("9999", null, null, "0", 0L, "1", null);
        offerSupervisionEntity4 = new OfferSupervisionEntity("9991", null, null, "0", 0L, "1", null);
        refopsEntity = new RefopsEntity(1L, "9991", "libellé offre test", "1.0.0", "1.2.1", Instant.parse("2022-12-05T10:15:30.00Z"), Instant.parse("2022-12-05T10:15:30.00Z"),"data json");
        errorEntity = new ErrorEntity("10", "11");
        offerFilterEntity = new OfferFilterEntity(1L, "0275", "");
    }

    @Test
    void getErrorsByCodeOpsTest() {
        Mockito.when(contractErrorRepository.getListcontractErrors(Mockito.anyString(), Mockito.anyString())).thenReturn(Flux.just(contractErrorEntity));
        StepVerifier.create(offerService.getListcontractErrors("0002", "CONTRACT_LISTENING_ORDER")).
                assertNext(contractResult -> {
                    assertNotNull(contractResult);
                    assertEquals(contractErrorEntity.getContractNumber(), contractResult.getContractNumber());
                    assertEquals(contractErrorEntity.getVersionNumber(),contractResult.getRevisionNumber());
                    assertEquals(contractErrorEntity.getAmendmentNumber(), contractResult.getAmendmentNumber());
                    assertEquals(contractErrorEntity.getDateError(), contractResult.getDateError());
                    assertEquals(contractErrorEntity.getIsSynchronized(), contractResult.getIsSynchronized());
                    assertEquals(contractErrorEntity.getPreviousDateSynchronization(), contractResult.getPreviousDateSynchronization());
                    assertEquals(contractErrorEntity.getWorkflowStep(), contractResult.getWorkflowStep());
                    assertEquals(contractErrorEntity.getErrorMessage(), contractResult.getErrorMessage());
                    assertEquals(contractErrorEntity.getOpsCode(), contractResult.getCodeOps());
            })
            .verifyComplete();
    }

    @Test
    void listOfferContractsAndErrorsTest() {
        Mockito.when(offerSupervisionRepository.countOfferContractsErrors())
            .thenReturn(Flux.just(offerSupervisionEntity));
        Mockito.when(offerSupervisionRepository.getErrorsBeforeFirstInteg())
            .thenReturn(Flux.just(offerSupervisionEntity2));
        Mockito.when(offerSupervisionRepository.getOffersWithoutContracts())
            .thenReturn(Flux.just(offerSupervisionEntity3));

        Mockito.when(refopsRepository.findAll())
            .thenReturn(Flux.just(refopsEntity));

            StepVerifier.create(offerService.listOfferContractsAndErrors())
                .assertNext(offerSupervisionResult -> {
                    assertNotNull(offerSupervisionResult);
                    assertEquals(offerSupervisionEntity.getOpsCode(), offerSupervisionResult.getOpsCode());
                    assertEquals(offerSupervisionEntity.getOpsLabel(), offerSupervisionResult.getOpsLabel());
                    assertEquals(offerSupervisionEntity.getOfferActivationDate(), offerSupervisionResult.getOfferActivationDate());
                    assertEquals(offerSupervisionEntity.getContractSynch(), offerSupervisionResult.getContractSynch());
                    assertEquals(offerSupervisionEntity.getContractVersionSynch().toString(), offerSupervisionResult.getContractVersionSynch());
                    assertEquals(String.valueOf(Integer.parseInt(offerSupervisionEntity.getErrorListening()) +
                        Integer.parseInt(offerSupervisionEntity2.getErrorListening())), offerSupervisionResult.getErrorListening());
                    assertEquals(offerSupervisionEntity.getErrorSynchronization(), offerSupervisionResult.getErrorSynch());
                })
                .assertNext(offerSupervisionResult2 -> {
                    assertNotNull(offerSupervisionResult2);
                    assertEquals(offerSupervisionEntity3.getOpsCode(), offerSupervisionResult2.getOpsCode());
                    assertNull(offerSupervisionResult2.getOpsLabel());
                    assertNull(offerSupervisionResult2.getOfferActivationDate());
                    assertEquals(offerSupervisionEntity3.getContractSynch(), offerSupervisionResult2.getContractSynch());
                    assertEquals(offerSupervisionEntity3.getContractVersionSynch().toString(), offerSupervisionResult2.getContractVersionSynch());
                    assertEquals(offerSupervisionEntity3.getErrorListening(), offerSupervisionResult2.getErrorListening());
                    assertEquals(offerSupervisionEntity3.getErrorSynchronization(), offerSupervisionResult2.getErrorSynch());
                })
                .assertNext(offerSupervisionResult3 -> {
                    assertNotNull(offerSupervisionResult3);
                    assertEquals(offerSupervisionEntity4.getOpsCode(), offerSupervisionResult3.getOpsCode());
                })
                .verifyComplete();
        }
    @Test
    void listOffersRefopsTest() {
        Mockito.when(refopsRepository.findAll()).thenReturn(Flux.just(refopsEntity));
        StepVerifier.create(offerService.listOffersRefops())
            .assertNext(offersRefopsResult -> {
                assertNotNull(offersRefopsResult);
                assertEquals(refopsEntity.getOpsCode(), offersRefopsResult.getOpsCode());
                assertEquals(refopsEntity.getOpsLabel(), offersRefopsResult.getOpsLabel());
                assertEquals(refopsEntity.getOfferActivationDatetime(), offersRefopsResult.getOfferActivationDatetime());
            })
            .verifyComplete();
    }

    @Test
    void listAllErrorsTest() {
        Mockito.when(contractErrorRepository.getAllErrorsRepository()).thenReturn(Flux.just(contractErrorEntity));
        StepVerifier.create(offerService.listAllErrors()).
            assertNext(contractResult -> {
                assertNotNull(contractResult);
                assertEquals(contractErrorEntity.getContractNumber(), contractResult.getContractNumber());
                assertEquals(contractErrorEntity.getVersionNumber(),contractResult.getRevisionNumber());
                assertEquals(contractErrorEntity.getAmendmentNumber(), contractResult.getAmendmentNumber());
                assertEquals(contractErrorEntity.getDateError(), contractResult.getDateError());
                assertEquals(contractErrorEntity.getIsSynchronized(), contractResult.getIsSynchronized());
                assertEquals(contractErrorEntity.getPreviousDateSynchronization(), contractResult.getPreviousDateSynchronization());
                assertEquals(contractErrorEntity.getWorkflowStep(), contractResult.getWorkflowStep());
                assertEquals(contractErrorEntity.getErrorMessage(), contractResult.getErrorMessage());
                assertEquals(contractErrorEntity.getOpsCode(), contractResult.getCodeOps());
            })
            .verifyComplete();
    }



   /* @Test
    void getAllTest(){
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "opsCode");
        Mockito.when(refopsRepository.findAllByOpsCodeLikeOrOpsLabelLike(Mockito.anyString(), Mockito.anyString(), Mockito.any(PageRequest.class))).thenReturn(Flux.just(refopsEntity));
        Mockito.when(refopsRepository.countAllByOpsCodeLikeOrOpsLabelLike(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(1L));
        Mockito.when(refopsRepository.countOfferErrorListeningAndSynchro(Mockito.any(String.class))).thenReturn(Mono.just(errorEntity));
        Mockito.when(refopsRepository.countOfferErrorNbContractSynchronized(Mockito.any(String.class))).thenReturn(Mono.just(1L));
        Mockito.when(refopsRepository.countOfferErrorNbContractVersionSynchronized(Mockito.any(String.class))).thenReturn(Mono.just(2L));
        Mockito.when(refopsRepository.countNbContractIntegrated(Mockito.any(String.class))).thenReturn(Mono.just(1L));
        Mockito.when(refopsRepository.countNbContractVersionIntegrated(Mockito.any(String.class))).thenReturn(Mono.just(2L));
        StepVerifier.create(offerService.getAll("filter", PageRequest.of(0, 1, sortOrder))).
                assertNext(offerSupervisionPage -> assertOffer(refopsEntity, offerSupervisionPage.getContent().get(0)))
                .verifyComplete();
    }*/


    private void assertOffer(RefopsEntity refopsEntity, OfferSupervisionDto offerSupervisionDto) {
        assertNotNull(refopsEntity);
        assertEquals(refopsEntity.getOpsCode(), offerSupervisionDto.getOpsCode());
        assertEquals(refopsEntity.getOpsLabel(), offerSupervisionDto.getOpsLabel());

    }
}
