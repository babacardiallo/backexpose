import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { AuthGuard } from '../auth/auth-guard.service';
import { RejetContractComponent } from './rejet-contract.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: 'rejetcontrat', component: RejetContractComponent, canActivate: [AuthGuard], data: { permissions: { only: ['ADMIN', 'CONS', 'ADV'], } } }
        ])],
    exports: [RouterModule]
})
export class RejetContractRoutingModule { }
