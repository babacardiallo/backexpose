export class OffresAjoutParameters {
    codeOps: string;
    date: Date;
}