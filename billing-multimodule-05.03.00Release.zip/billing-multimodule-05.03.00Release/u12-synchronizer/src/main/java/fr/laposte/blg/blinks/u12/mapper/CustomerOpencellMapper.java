package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import org.mapstruct.Builder;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(builder = @Builder(disableBuilder = true))
@DecoratedWith(CustomerOpencellMapperDecorator.class)
public interface CustomerOpencellMapper {

    @Mapping(source = "custAccNumber", target = "customerInformation.custAccNumber")
    @Mapping(source = "compName", target = "customerInformation.name")
    @Mapping(source = "brandName", target = "customerInformation.brandName")
    @Mapping(source = "typeCode", target = "customerInformation.typeCode")
    @Mapping(source = "typeLabel", target = "customerInformation.typeLabel")
    @Mapping(source = "status", target = "customerInformation.active")
    @Mapping(source = "siretCode", target = "customerInformation.siretCode")
    @Mapping(source = "vatNumber", target = "customerInformation.CVATNO")
    @Mapping(source = "email", target = "customerInformation.email")
    @Mapping(source = "legalNatureCode", target = "customerInformation.legalNatureCode")
    @Mapping(source = "legalNatureName", target = "customerInformation.legalNatureName")
    @Mapping(source = "marketingTypeCode", target = "customerInformation.marketingTypeCode")
    @Mapping(source = "establishZoneCode", target = "customerInformation.establishZoneCode")
    @Mapping(source = "billingTypology", target = "customerInformation.billingTypology")
    @Mapping(target = "customerInformation.businessTeamId", ignore = true)
    @Mapping(target = "customerInformation.businessTeamLongname", ignore = true)
    fr.laposte.bscc.billing.avro.billing.CustomerOpencell legalPersonEntityToCustomerOpencell(LegalPersonEntity legalPersonEntity);

    default CharSequence asCharSquence(Integer value) {
        return value != null ? Integer.toString(value) : null;
    }

}
