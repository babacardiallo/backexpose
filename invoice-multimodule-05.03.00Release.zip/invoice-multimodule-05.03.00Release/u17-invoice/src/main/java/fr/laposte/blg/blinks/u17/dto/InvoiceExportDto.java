package fr.laposte.blg.blinks.u17.dto;


import lombok.*;

@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceExportDto {
    private Long invoiceId;
    private String invoiceNumber;
    private String errorMessage;
    private String errorCode;

}
