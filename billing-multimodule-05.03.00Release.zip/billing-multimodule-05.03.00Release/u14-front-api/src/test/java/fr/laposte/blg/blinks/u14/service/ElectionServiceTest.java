package fr.laposte.blg.blinks.u14.service;


import fr.laposte.blg.blinks.lib.common.entities.ContractEntity;
import fr.laposte.blg.blinks.lib.common.entities.LinkContractCoclicoMarket;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractSequenceElectionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ElectionFileSequenceRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LinkContractCoclicoMarketRepository;
import fr.laposte.blg.blinks.u14.controller.dto.ElectionReportDto;
import fr.laposte.blg.blinks.u14.controller.dto.ExcelAdvDto;
import fr.laposte.blg.blinks.u14.service.producer.KafkaElectionContractProducer;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import java.io.FileInputStream;
import java.io.IOException;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@ExtendWith(MockitoExtension.class)
class ElectionServiceTest {

    @Mock
    private  ElectionFileSequenceRepository electionFileSequenceRepository;

    @Mock
    private  LinkContractCoclicoMarketRepository linkContractCoclicoMarketRepository;

    @Mock
    private  ContractSequenceElectionRepository contractSequenceElectionRepository;

    @Mock
    private  ContractRepository contractRepository;

    @Mock
    private  KafkaElectionContractProducer electionContractProducer;

    @InjectMocks
    private ElectionService electionService;

    @BeforeEach
    void setUp() throws IOException {
      ReflectionTestUtils.setField(electionService, "advSource", "src/test/resources/");
    }

    @Test
    void processTest(){

        electionService.process("InjectionContratFichierADV.xlsx");

    }


    @Test
    void readAdvDataTest(){
        try(FileInputStream excelFile= new FileInputStream("src/test/resources/InjectionContratFichierADV.xlsx");
            Workbook workbook = new XSSFWorkbook(excelFile)) {
            Sheet datatypeSheetAdv = workbook.getSheetAt(0);
            electionService.readAdvData("2", datatypeSheetAdv);
            verify(electionService, times(1)).readAdvData("2", datatypeSheetAdv);

        } catch (Exception ignored) {
        }
    }

    @Test
    void generateOdcMessageAndSendToTopicTestCaseNewContract(){
        ExcelAdvDto excelAdvDto = new ExcelAdvDto("1", "2", "comment", "9000", "Virement", "10 jour", "MCGG662", "BICIS", "", "");
        Mockito.when(electionContractProducer.sendContractToTopic(Mockito.any())).thenReturn(Mono.empty());
        Mockito.when(linkContractCoclicoMarketRepository.getContractNumberBuyCoclicoAndMarketNumber(Mockito.anyInt(), Mockito.anyString())).thenReturn(Mono.empty());
        Mockito.when(contractSequenceElectionRepository.incrementSequenceContract()).thenReturn(Mono.just(1));
        Mockito.when(contractSequenceElectionRepository.getCurrentSequenceContract()).thenReturn(Mono.just(1L));
        Mockito.when(linkContractCoclicoMarketRepository.save(Mockito.any(LinkContractCoclicoMarket.class)))
                .thenReturn(Mono.just(new LinkContractCoclicoMarket()));
        electionService.generateOdcMessageAndSendToTopic(excelAdvDto, new ElectionReportDto());
    }

    @Test
    void generateOdcMessageAndSendToTopicTestOldContract(){
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setContractNumber("CONTRACT-1");
        ExcelAdvDto excelAdvDto = new ExcelAdvDto("1", "2", "comment", "9000", "Virement", "10 jour", "MCGG662", "BICIS", "", "");
        Mockito.when(electionContractProducer.sendContractToTopic(Mockito.any())).thenReturn(Mono.empty());
        Mockito.when(linkContractCoclicoMarketRepository.getContractNumberBuyCoclicoAndMarketNumber(Mockito.anyInt(), Mockito.anyString())).thenReturn(Mono.just("CONTRACT-1"));
        electionService.generateOdcMessageAndSendToTopic(excelAdvDto, new ElectionReportDto());
    }
    
}
