package fr.laposte.blg.blinks.u17.dto.invoice;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import fr.laposte.blg.blinks.lib.common.dto.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "header",
        "invoiceHeader",
        "billingAccount",
        "customer",
        "contracts",
        "accountDetails"
})
@JacksonXmlRootElement(localName = "invoice")
public class InvoiceInfoCaDTO {
    HeaderDTO header;
    InvoiceHeaderDTO invoiceHeader;
    BillingAccountInfoCaDto billingAccount;
    CustomerDTO customer;
    @JacksonXmlElementWrapper(localName = "contracts")
    @JacksonXmlProperty(localName = "contract")
    List<ContractDTO> contracts;
    @JacksonXmlElementWrapper(localName = "accountDetails")
    @JacksonXmlProperty(localName = "accountDetail")
    List<AccountDetailsDTO> accountDetails;
}
