package fr.laposte.blg.blinks.u12.listener.exception;

import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SynchronizationContractException extends SynchronizationException {

    private Long idContract;
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionNumber;
    private String rum;
    private String regate;
    private ContractVersionEntity contractVersionEntity;
    private String opsCode;

    /**
     * Constructs a new runtime exception with the specified detail message.
     * The cause is not initialized, and may subsequently be initialized by a
     * call to {@link #initCause}.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the {@link #getMessage()} method.
     */
    public SynchronizationContractException(String message) {
        super(message);
    }

    /**
     * Constructs a new runtime exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this runtime exception's detail message.
     *
     * @param message          the detail message (which is saved for later retrieval
     *                         by the {@link #getMessage()} method).
     * @param cause            the cause (which is saved for later retrieval by the
     *                         {@link #getCause()} method).  (A {@code null} value is
     *                         permitted, and indicates that the cause is nonexistent or
     *                         unknown.)
     * @param workflowStepEnum step at which the exception was thrown
     * @since 1.4
     */
    public SynchronizationContractException(String message, Throwable cause, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, Long idContract, String contractNumber, Integer amendmentNumber, Integer revisionNumber, ContractVersionEntity contractVersionEntity, String opsCode, CodeErrorEnum codeError) {
        super(message, cause, workflowStepEnum, codeError);
        this.idContract = idContract;
        this.contractNumber = contractNumber;
        this.amendmentNumber = amendmentNumber;
        this.revisionNumber = revisionNumber;
        this.contractVersionEntity = contractVersionEntity;
        this.opsCode = opsCode;
    }

    public SynchronizationContractException(String message, Throwable cause, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, Long idContract, String contractNumber, Integer amendmentNumber, Integer revisionNumber, ContractVersionEntity contractVersionEntity, String opsCode, String rum, CodeErrorEnum codeError) {
        this(message, cause, workflowStepEnum, idContract, contractNumber, amendmentNumber, revisionNumber, contractVersionEntity, opsCode, codeError);
        this.rum = rum;
    }

    public SynchronizationContractException(String message, Throwable cause, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, Long idContract, String contractNumber, Integer amendmentNumber, Integer revisionNumber, ContractVersionEntity contractVersionEntity, String opsCode, String rum, String regate, CodeErrorEnum codeError) {
        this(message, cause, workflowStepEnum, idContract, contractNumber, amendmentNumber, revisionNumber, contractVersionEntity, opsCode, rum, codeError);
        this.regate = regate;
    }

}
