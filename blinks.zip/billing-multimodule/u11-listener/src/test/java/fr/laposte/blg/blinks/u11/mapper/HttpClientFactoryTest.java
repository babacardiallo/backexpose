package fr.laposte.blg.blinks.u11.mapper;

import fr.laposte.blg.blinks.u11.scheduler.HttpClientFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.net.http.HttpClient;

@SpringBootTest(classes = HttpClientFactory.class)
class HttpClientFactoryTest {
    @Autowired
    HttpClientFactory httpClientFactory;

    @Test
    void createTest(){
        HttpClient httpClient = httpClientFactory.create();
        Assertions.assertNotNull(httpClient);
    }
}

