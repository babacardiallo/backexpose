package fr.laposte.blg.blinks.lib.common.sender;



import fr.laposte.blg.blinks.lib.common.entities.QueueMigrationEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.Synchronization;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.kafka.sender.KafkaSender;
import reactor.test.StepVerifier;

import java.time.Instant;


@ExtendWith(MockitoExtension.class)
class SynchronizationSenderTest {
    @InjectMocks
    private SynchronizationSender synchronizationSender;
    @Mock
    private KafkaSender<String, Synchronization> synchronizationKafkaSender;
    @Mock
    private ErrorLogService errorLogService;


    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void sendTest(){
        Mockito.when(synchronizationKafkaSender.send(Mockito.any())).thenReturn(Flux.empty());
        StepVerifier.create(this.synchronizationSender.send(new Synchronization()))
                .verifyComplete();
    }

    @Test
    void sendQueueItemTest(){
        Mockito.when(synchronizationKafkaSender.send(Mockito.any())).thenReturn(Flux.empty());
        StepVerifier.create(this.synchronizationSender.sendQueuedItem(QueueSynchronizationEntity.builder().idQueue(1L).idContract(1L).dateSynchronizationExpected(Instant.now()).action(ActionEnum.create).build()))
                .expectNextMatches(queueSynchronizationEntity -> queueSynchronizationEntity.getIdQueue() == 1L
                        && queueSynchronizationEntity.getIdContract()==1L
                        && queueSynchronizationEntity.getAction().equals(ActionEnum.create)
                )
                .verifyComplete();
    }

    @Test
    void sendQueueItemCustomerTest(){
        Mockito.when(synchronizationKafkaSender.send(Mockito.any())).thenReturn(Flux.empty());
        StepVerifier.create(this.synchronizationSender.sendQueuedItem(QueueSynchronizationEntity.builder().idQueue(1L).idLegalPerson(1L).refcomReplay(true).dateSynchronizationExpected(Instant.now()).action(ActionEnum.create).build()))
                .expectNextMatches(queueSynchronizationEntity -> queueSynchronizationEntity.getIdQueue() == 1L
                        && queueSynchronizationEntity.getIdLegalPerson()==1L
                        && queueSynchronizationEntity.getAction().equals(ActionEnum.create)
                )
                .verifyComplete();
    }

    @Test
    void sendQueueItemMigrationTest(){
        Mockito.when(synchronizationKafkaSender.send(Mockito.any())).thenReturn(Flux.empty());
        StepVerifier.create(this.synchronizationSender.sendQueuedMigrationItem(QueueMigrationEntity.builder().idQueue(1L).idContract(1L).dateSynchronizationExpected(Instant.now()).action(ActionEnum.create).build()))
                .expectNextMatches(queueMigrationEntity -> queueMigrationEntity.getIdQueue() == 1L
                        && queueMigrationEntity.getIdContract()==1L
                        && queueMigrationEntity.getAction().equals(ActionEnum.create)
                )
                .verifyComplete();
    }
}
