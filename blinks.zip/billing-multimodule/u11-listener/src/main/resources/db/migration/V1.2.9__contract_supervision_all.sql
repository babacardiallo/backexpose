CREATE OR REPLACE VIEW `contract_supervision_all` AS
    SELECT `co`.`contract_number` || `cv`.`amendment_number` || `cv`.`revision_number` AS `id`,
        `co`.`contract_number` AS `contract_number`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `cv`.`status` AS `status`,
        `cv`.`substatus` AS `substatus`,
        `co`.`type` AS `type`,
        `co`.`subtype` AS `subtype`,
        `vo`.`ops_code` AS `ops_code`,
        `ro`.`ops_label` AS `ops_label`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        COALESCE(GREATEST(`cv`.`date_synchronization`,
                        `cv`.`previous_date_synchronization`),
                `cv`.`date_synchronization`,
                `cv`.`previous_date_synchronization`) AS `last_date_synchronization`,
        MAX(`el`.`date_error`) AS `first_error_date`,
        `lp`.`cust_acc_number` AS `cust_acc_number`,
        `co`.`cust_acc_number` AS `cust_acc_number_before_synchronisation`
    FROM
        (((((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        LEFT JOIN `legal_person` `lp` ON ((`lp`.`cust_acc_number` = `co`.`cust_acc_number`)))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`cv`.`amendment_number` = `el`.`amendment_number`)
            AND (`el`.`workflow_step` LIKE '%SYNCHRONIZATION%'))))
    GROUP BY `co`.`contract_number` , `cv`.`amendment_number`