package fr.laposte.blg.blinks.u17.mapper;

import fr.laposte.blg.blinks.u17.dto.MoulinetteRefcomDto;
import fr.laposte.blg.blinks.u17.dto.RefcomDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface RefcomMapper {

    @Mapping(source = "coclico", target = "coclico")
    @Mapping(source = "entityCode", target = "entityCode")
    MoulinetteRefcomDto RefcomDtoToMoulinetteRefcomDto(RefcomDto refcomDto);

}
