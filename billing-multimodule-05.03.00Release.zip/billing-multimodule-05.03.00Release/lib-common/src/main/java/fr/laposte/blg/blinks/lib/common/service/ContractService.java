package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.*;
import fr.laposte.bscc.billing.avro.billing.ContractOpencell;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.time.Instant;
import java.util.Objects;

@Service
@Data
@Slf4j
@RequiredArgsConstructor // Génère le constructeur avec les injections de service
public class ContractService {

    private final ContractRepository contractRepository;

    private final ContractVersionRepository contractVersionRepository;

    private final InvoiceInformationRepository invoiceInformationRepository;

    private final ValuedOfferRepository valuedOfferRepository;

    private final AddressRepository addressRepository;

    private final ContractLinkedRepository contractLinkedRepository;

    private final ContractVersionMessageRepository contractVersionMessageRepository;

    private final ContractMessageRepository contractMessageRepository;

    private final ValuedOfferMessageRepository valuedOfferMessageRepository;

    private final InvoiceInformationMessageRepository invoiceInformationMessageRepository;

    /**
     * Fetch the contract and its contract_versions (without invoice_information and so on) from the contract number
     *
     * @param contractNumber       contract Number from Odyssée
     * @param loadContractVersions if we want to load the versions of the contract
     * @return the contract and its versions without information_entity and so on
     */
    public Mono<ContractEntity> findContractByContractNumberWithVersions(String contractNumber, boolean loadContractVersions) {

        Mono<ContractEntity> contractEntityMono = contractRepository.findFirstByContractNumber(contractNumber);

        if (loadContractVersions) {
            contractEntityMono = contractEntityMono.flatMap(this::loadContractVersions);
        }
        return contractEntityMono;

    }

    public Mono<ContractEntity> loadContractVersions(ContractEntity contractEntity) {
        return this.contractVersionRepository.findByIdContractOrderByAmendmentNumberAsc(contractEntity.getIdContract())
                .map(contractVersionEntity -> contractVersionEntity.setContract(contractEntity))
                .collectList()
                .map(contractEntity::setContractVersionEntities);
    }

    public Mono<ContractVersionEntity> findContractVersionByAmendmentNumberAndIdContract(int amendmentNumber, Long idContract, boolean loadRelations) {
        return contractVersionRepository.findByAmendmentNumberAndIdContract(amendmentNumber, idContract)
                .flatMap(contractVersionEntity -> {
                    if (loadRelations) {
                        return this.loadContractRelations(contractVersionEntity);
                    } else {
                        return Mono.just(contractVersionEntity);
                    }
                });
    }

    public Mono<ContractVersionEntity> findContractVersionById(long id, boolean loadRelations) {
        return contractVersionRepository.findById(id)
                .flatMap(contractVersionEntity -> {
                    if (loadRelations) {
                        return this.loadContractRelations(contractVersionEntity);
                    } else {
                        return Mono.just(contractVersionEntity);
                    }
                });
    }

    public Flux<ContractVersionEntity> findContractVersionsToSynchronizeByContractId(long idContract) {
        return this.contractVersionRepository.findByIdContractOrderByAmendmentNumberAsc(idContract)
                .flatMap(this::loadContractRelations)
                .flatMap(contractVersionEntity -> this.contractRepository.findById(idContract)
                        .map(contractVersionEntity::setContract));
    }

    public Mono<ContractVersionEntity> loadContractRelations(ContractVersionEntity contractVersionEntity) {
        Scheduler parallelScheduler = Schedulers.parallel();
        Mono<InvoiceInformationEntity> informationEntityMono =
                Mono.justOrEmpty(contractVersionEntity.getIdInvoiceInformation())
                        .subscribeOn(parallelScheduler)
                        .flatMap(idInvoiceInformation ->
                                invoiceInformationRepository.findById(idInvoiceInformation)
                                        .flatMap(invoiceInformationEntity -> Mono.justOrEmpty(invoiceInformationEntity.getIdAddressInvoice())
                                                .flatMap(this.addressRepository::findById)
                                                .map(invoiceInformationEntity::setAddressFacturation)
                                                .defaultIfEmpty(invoiceInformationEntity)
                                        )
                        );

        Mono<ValuedOfferEntity> valuedOfferEntityMono = Mono.justOrEmpty(contractVersionEntity.getIdValuedOffer())
                .subscribeOn(parallelScheduler)
                .flatMap(valuedOfferRepository::findById);

        return Mono.zip(informationEntityMono, valuedOfferEntityMono)
                .map(tupleInfoValue -> contractVersionEntity.setInvoiceInformationEntity(tupleInfoValue.getT1())
                        .setValuedOffer(tupleInfoValue.getT2()));
    }

    public Flux<ContractLinkedEntity> findContractLinked(long idContract) {
        return this.contractLinkedRepository.findAllByIdContract(idContract);
    }

    public Mono<ContractVersionEntity> loadValuedOffer(ContractVersionEntity contractVersionEntity) {

        Mono<ValuedOfferEntity> valuedOfferEntityMono = Mono.justOrEmpty(contractVersionEntity.getIdValuedOffer())
                .flatMap(valuedOfferRepository::findById);

        return valuedOfferEntityMono.map(
                contractVersionEntity::setValuedOffer
        );
    }

    public Mono<Tuple2<ContractEntity, Boolean>> checkIfContractIsNew(ContractVersionEntity contractVersionEntity) {
        return this.contractRepository.findFirstByContractNumber(contractVersionEntity.getContract().getContractNumber())
                .flatMap(contractEntity -> this.contractVersionRepository.findFirstByIdContractAndIsSynchronized(contractEntity.getIdContract(), true)
                        .map(contractVersionEntity1 -> Tuples.of(contractEntity, false))
                        .defaultIfEmpty(Tuples.of(contractEntity , true)))
                .switchIfEmpty( //Si le contract n'existe pas
                        Mono.just(Tuples.of(contractVersionEntity.getContract(), true))
                );
    }

    public Mono<Boolean> isContractVersionAmendmentSuperior(ContractVersionEntity contractVersionEntity) {
        return this.contractRepository.findFirstByContractNumber(contractVersionEntity.getContract().getContractNumber())
                .flatMap(contractEntity -> {
                    return this.contractVersionRepository.findByAmendmentNumberAndIdContract(contractVersionEntity.getAmendmentNumber(), contractEntity.getIdContract())
                            .map(existingVersion -> {
                                return contractVersionEntity.getRevisionNumber() >= existingVersion.getRevisionNumber();
                            });
                })
                .defaultIfEmpty(true); // Si le contrat n'existe pas, on considère que la révision est supérieure
    }


    /**
     * Méthode permettant de créer ou de modifier toute la chaine de liaison autour d'une version de contrat provenant du topic contract
     *
     * @param contractVersionEntityFromAvro
     * @return La version de contrat persistée
     */
    @Transactional
    public Mono<ContractVersionEntity> createOrUpdateContractVersionChain(ContractVersionEntity contractVersionEntityFromAvro, ContractEntity contractEntity, ContractVersionMessage contractVersionMessage, ValuedOfferMessage valuedOfferMessage, InvoiceInformationEntityMessage invoiceInformationEntityMessage) {

        assert (Objects.nonNull(contractVersionEntityFromAvro.getContract()));
        assert (Objects.nonNull(contractVersionEntityFromAvro.getInvoiceInformationEntity()));
        assert (Objects.nonNull(contractVersionEntityFromAvro.getValuedOffer()));

        var invoiceInformationEntityFromAvro = contractVersionEntityFromAvro.getInvoiceInformationEntity();
        var valuedOfferEntityFromAvro = contractVersionEntityFromAvro.getValuedOffer();
        var contractEntityFromAvro = contractVersionEntityFromAvro.getContract();

        //2 Je recherche la version de contrat
        return this.findContractVersionByAmendmentNumberAndIdContract(contractVersionEntityFromAvro.getAmendmentNumber(), contractEntity.getIdContract(), false)
                .flatMap(contractVersionEntity -> {
                    contractVersionEntityFromAvro
                            .setContract(contractEntity)
                            .setIdContractVersion(contractVersionEntity.getIdContractVersion())
                            .setIdInvoiceInformation(contractVersionEntity.getIdInvoiceInformation())
                            .setIdValuedOffer(contractVersionEntity.getIdValuedOffer())
                            .setIdContract(contractEntity.getIdContract());

                    // Si la version trouvée est déjà synchronisée :
                    // on sauvegarde la date de synchronisation, contrat consolidé, offset consolidé et partition consolidée
                    // on enregistre les json du version de contrat dans la table contractVersionMessage
                    return contractVersionMessageRepository.findByIdContractVersion(contractVersionEntity.getIdContractVersion())
                            .flatMap(contractVersionMessage1 -> {
                                contractVersionMessage.setIdContractVersionMessage(contractVersionMessage1.getIdContractVersionMessage());
                                contractVersionMessage.setIdContractVersion(contractVersionMessage1.getIdContractVersion());
                                if (contractVersionEntity.isSynchronized()
                                        && contractVersionEntity.getDateSynchronization() != null
                                        && contractVersionMessage1.getContractConsolidated() != null
                                        && contractVersionEntity.getOffsetNumConsolidated() != null
                                        && contractVersionEntity.getPartitionNumConsolidated() != null
                                ) {
                                    contractVersionEntityFromAvro.setPreviousDateSynchronization(contractVersionEntity.getDateSynchronization());
                                    contractVersionEntityFromAvro.setOffsetNumConsolidated(contractVersionEntity.getOffsetNumConsolidated());
                                    contractVersionEntityFromAvro.setPartitionNumConsolidated(contractVersionEntity.getPartitionNumConsolidated());
                                    contractVersionMessage.setContractConsolidated(contractVersionMessage1.getContractConsolidated());
                                }
                                return Mono.zip(Mono.just(contractVersionEntityFromAvro), Mono.just(contractVersionMessage));
                            });
                })
                //Si la version de contract n'existe pas
                .switchIfEmpty(Mono.defer(() -> Mono.zip(contractVersionRepository.save(contractVersionEntityFromAvro
                        .setIdContract(contractEntity.getIdContract())
                        .setContract(contractEntity)), Mono.just(contractVersionMessage))))
                .flatMap(tuple2 -> {
                    //We save invoiceInformation & ValuedOffer
                    Mono<InvoiceInformationEntity> invoiceInformationEntityMono =
                            Mono.justOrEmpty(tuple2.getT1().getIdInvoiceInformation())
                                    .map(invoiceInformationEntityFromAvro::setIdInvoiceInformation)
                                    .defaultIfEmpty(invoiceInformationEntityFromAvro)
                                    .flatMap(invoiceInformationEntity -> this.addressRepository.findByAddressIdRefPM(invoiceInformationEntityFromAvro.getInvoiceAddressNumber())
                                            .map(addressEntity -> invoiceInformationEntity.setIdAddressInvoice(addressEntity.getIdAddress()))
                                            .defaultIfEmpty(invoiceInformationEntity)
                                    )
                                    .flatMap(invoiceInformationRepository::save)
                                    .flatMap(invoiceInformationEntity ->
                                            Mono.zip(
                                                    Mono.just(invoiceInformationEntity),
                                                    invoiceInformationMessageRepository.findByIdInvoiceInformation(invoiceInformationEntity.getIdInvoiceInformation())
                                                            .switchIfEmpty(Mono.defer(() -> Mono.just(invoiceInformationEntityMessage)))
                                            )
                                    )
                                    .map(tuple ->  {
                                        invoiceInformationEntityMessage.setIdInvoiceInformation(tuple.getT1().getIdInvoiceInformation());
                                        invoiceInformationEntityMessage.setIdInvoiceInformationMessage(tuple.getT2().getIdInvoiceInformationMessage());
                                        return Tuples.of(tuple.getT1(), invoiceInformationEntityMessage);
                                    }).flatMap(tuple -> invoiceInformationMessageRepository.save(tuple.getT2()).thenReturn(tuple.getT1()));

                    Mono<ValuedOfferEntity> valuedOfferEntityMono =
                            Mono.justOrEmpty(tuple2.getT1().getIdValuedOffer())
                                    .map(valuedOfferEntityFromAvro::setIdValuedOffer)
                                    .flatMap(valuedOfferRepository::save)
                                    .switchIfEmpty(Mono.defer(() -> valuedOfferRepository //Si l'offre valorisé n'existe pas
                                            .save(valuedOfferEntityFromAvro)))
                                    .flatMap(valuedOfferEntity ->
                                            Mono.zip(Mono.just(valuedOfferEntity), valuedOfferMessageRepository.findByIdValuedOffer(valuedOfferEntity.getIdValuedOffer()).switchIfEmpty(Mono.defer(() -> Mono.just(valuedOfferMessage)))))
                                    .flatMap(tupleValuedOfferValuedMessage -> {
                                        ValuedOfferMessage valuedOfferMessage1 = tupleValuedOfferValuedMessage.getT2();
                                        valuedOfferMessage.setIdValuedOfferMessage(valuedOfferMessage1.getIdValuedOfferMessage());
                                        valuedOfferMessage.setIdValuedOffer(tupleValuedOfferValuedMessage.getT1().getIdValuedOffer());
                                        return valuedOfferMessageRepository.save(valuedOfferMessage).thenReturn(tupleValuedOfferValuedMessage.getT1());
                                    });


                    Mono<ContractEntity> contractEntityMono =
                            Mono.justOrEmpty(tuple2.getT1().getIdContract())
                                    .map(contractEntityFromAvro::setIdContract)
                                    .flatMap(contractRepository::save)
                                    .switchIfEmpty(Mono.defer(() -> contractRepository
                                            .save(contractEntityFromAvro)));

                    Mono<ContractVersionMessage> contractVersionMessageMono =
                            contractVersionMessageRepository.save(contractVersionMessage.setIdContractVersion(tuple2.getT1().getIdContractVersion()));

                    //Attention, si l'un des deux mono est empty, le mono résultant du zip sera nulle.
                    //cette contrainte ne nous posera pas de soucis

                    return Mono.zip(invoiceInformationEntityMono, valuedOfferEntityMono, contractEntityMono, contractVersionMessageMono)
                            .map(tupleInvoiceOfferContract ->
                                    tuple2.getT1()
                                            .setInvoiceInformationEntity(tupleInvoiceOfferContract.getT1())
                                            .setIdInvoiceInformation(tupleInvoiceOfferContract.getT1().getIdInvoiceInformation()) //Dans le cas d'une création
                                            .setValuedOffer(tupleInvoiceOfferContract.getT2())
                                            .setIdValuedOffer(tupleInvoiceOfferContract.getT2().getIdValuedOffer())//Dans le cas d'une création;
                                            .setContract(tupleInvoiceOfferContract.getT3())
                                            .setIdContract(tupleInvoiceOfferContract.getT3().getIdContract()));

                })
                ///////VERY IMPORTANT////////////
                .map(contractVersionEntity -> contractVersionEntity.setSynchronized(false))
                ////////////////////////////////
                .flatMap(contractVersionRepository::save);

    }

    public Mono<ContractVersionEntity> findByContractNumberAndAmendmentNumber(String contractNumber, int amendmentNumber) {
        return contractRepository.findFirstByContractNumber(contractNumber)
                .flatMap(contractEntity -> contractVersionRepository.findByAmendmentNumberAndIdContract(amendmentNumber, contractEntity.getIdContract()));
    }

    /**
     * Allows to persist a ContractVersion entity
     *
     * @param contractVersionEntity
     * @return
     */
    public Mono<ContractVersionEntity> save(ContractVersionEntity contractVersionEntity) {
        if (contractVersionEntity.getDateSynchronization() != null) {
            contractVersionEntity.setPreviousDateSynchronization(contractVersionEntity.getDateSynchronization());
        }
        return contractVersionRepository.save(contractVersionEntity);
    }

    public Mono<InvoiceInformationEntity> saveInvoiceInformation(InvoiceInformationEntity invoiceInformationEntity) {
        return this.invoiceInformationRepository.save(invoiceInformationEntity);
    }

    public Mono<ContractVersionEntity> markVersionSynchronized(ContractOpencell contractOpencell, RecordMetadata recordMetadata) {
        return this.contractVersionRepository.findByContractNumberAndByAmendmentNumber(contractOpencell.getContractInformation().getContractNumber().toString(), contractOpencell.getContractVersionInformation().getAmendmentNumber())
                .map(contractVersionEntity -> {
                    contractVersionEntity.setSynchronized(true);
                    contractVersionEntity.setDateSynchronization(Instant.now());
                    contractVersionEntity.setOffsetNumConsolidated(recordMetadata.offset());
                    contractVersionEntity.setPartitionNumConsolidated(recordMetadata.partition());
                    return contractVersionEntity;
                })
                .flatMap(contractVersionEntity -> Mono.zip(Mono.just(contractVersionEntity), contractVersionMessageRepository.findByIdContractVersion(contractVersionEntity.getIdContractVersion())))
                .flatMap(tuple2 -> contractVersionMessageRepository.save(tuple2.getT2().setContractConsolidated(contractOpencell.toString())).thenReturn(tuple2.getT1()))
                .flatMap(this.contractVersionRepository::save);
    }

    public Mono<ContractVersionEntity> findAnyVersionOfTheContract(Long contractId) {
        return contractVersionRepository.findFirstByIdContract(contractId);
    }

    public Mono<ContractEntity> save(ContractEntity contractEntity, ContractMessage contractMessage) {
        return contractRepository.save(contractEntity)
                .flatMap(contractEntity1 ->
                        Mono.zip(
                                Mono.just(contractEntity1),
                                contractMessageRepository.findByIdContract(contractEntity1.getIdContract())
                                        .switchIfEmpty(Mono.defer(() -> Mono.just(contractMessage)))
                        )
                )
                .flatMap(tuple2 -> {
                    contractMessage.setIdContractMessage(tuple2.getT2().getIdContractMessage());
                    contractMessage.setIdContract(tuple2.getT1().getIdContract());
                    return contractMessageRepository.save(contractMessage).thenReturn(tuple2.getT1());
                });
    }

    public Flux<ContractVersionEntity> findAllContractVersionsAlreadySynced() {
        return contractVersionRepository.findAllByIsSynchronizedTrue();
    }

    public Mono<ContractEntity> findContractByIdContract(long idContract) {
        return contractRepository.findById(idContract);
    }
}
