import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { OffresTableService } from '../service/offres-table.service';
import { OffresTable } from '../models/offres-table.model';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { OffreErrorDetailPopUpComponent } from './offre-error-detail-pop-up/offre-error-detail-pop-up.component';
import { UitPopupService } from '@cddng/ui-theme';
import { OffresAjoutPopUpComponent } from './offres-ajout-pop-up/offres-ajout-pop-up.component';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';
import { ErrorOfferBean } from '../models/error-offer.model';
import { ConfirmComponent } from '../../shared/widgets/components/confirm.component';
import { OfferPage } from '../models/offer.page';
import { ModalService } from 'ngx-modal-ease';
import { LoaderService } from '../../shared/errors/service/loader.service';

@Component({
    selector: 'offres-table-component',
    templateUrl: './offres-table.component.html',
    styleUrls: ['./offres-table.component.scss'],
    standalone: false
})
export class OffresTableComponent implements OnInit, OnDestroy {
  @ViewChild(DatatableComponent) offerTable: DatatableComponent;
  filtered: OffresTable[];
  isActiveOffers: boolean = true;
  listAllOffers: OffresTable[];
  offerPage: OfferPage = new OfferPage();
  searchText = '';

  M1_MODAL_PROPERTIES = {
    animation: 'enter-going-down',
    duration: '0.1s',
    easing: 'ease-out',
    padding: '1rem',
    width: '1800px',
    height: '100%'
  };

  M2_MODAL_PROPERTIES = {
    animation: 'enter-going-down',
    duration: '0.1s',
    easing: 'ease-out',
    padding: '1rem',
    width: '500px',
    height: '70%'
  };

  constructor(private offreTableService: OffresTableService, private popupService: UitPopupService,
    private datePipe: DatePipe, private modalService: ModalService, private loadingService: LoaderService) {
  }

  ngOnInit(): void {
    this.getListeOffresActives(0, 10, 'opsCode', 'asc', '');
  }

  ngOnDestroy(): void {
    // permet de tout unsubscribe, voir service
    this.offreTableService.ngUnsubscribe$.next();
    this.offreTableService.ngUnsubscribe$.complete();
  }

  getListeOffres(page: number, itemPerPage: number, sort: string, order: string, filter: string): void {
    this.offreTableService.getOffres(page, itemPerPage, sort, order, filter).subscribe({
      next: (response: any) => {
        this.listAllOffers = response.content.map((data: any) => {
          return <OffresTable>{
            codeOps: data.opsCode,
            labelOps: data.opsLabel,
            offerActivationDate: data.offerActivationDate ? new Date(data.offerActivationDate * 1000) : null,
            contractsSynch: data.contractSynch,
            versionsSynch: data.contractVersionSynch,
            contractIntegrated: data.contractIntegrated,
            contractVersionIntegrated: data.contractVersionIntegrated,
            errorsListening: data.errorListening,
            errorsSynch: data.errorSynch,
            isActiveOffer: data.isActiveOffer
          };
        })
        this.offerPage = {
          currentPage: response.pageable.pageNumber,
          itemsOnPage: response.pageable.pageSize,
          currentOffset: response.pageable.offset,
          totalPages: response.totalPages,
          totalItems: response.totalElements
        };
      },
      complete: () => {

      },
    });
  }

  getListeOffresActives(page: number, itemPerPage: number, sort: string, order: string, filter: string) {
    this.offreTableService.getActivesOffres(page, itemPerPage, sort, order, filter).subscribe({
      next: (response: any) => {
        this.listAllOffers = response.content.map((data: any) => {
          return <OffresTable>{
            codeOps: data.opsCode,
            labelOps: data.opsLabel,
            offerActivationDate: data.offerActivationDate ? new Date(data.offerActivationDate * 1000) : null,
            contractsSynch: data.contractSynch,
            versionsSynch: data.contractVersionSynch,
            contractIntegrated: data.contractIntegrated,
            contractVersionIntegrated: data.contractVersionIntegrated,
            errorsListening: data.errorListening,
            errorsSynch: data.errorSynch,
            isActiveOffer: data.isActiveOffer
          };
        })
        this.offerPage = {
          currentPage: response.pageable.pageNumber,
          itemsOnPage: response.pageable.pageSize,
          currentOffset: response.pageable.offset,
          totalPages: response.totalPages,
          totalItems: response.totalElements
        };
      },
      complete: () => {

      },
    });
  }

  exportOffers(): void {
    if (this.isActiveOffers) {
      this.offreTableService.exportActivesOffres(this.searchText).subscribe(response => {
        const fileName = 'ExportOffres_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["Code OPS", "Libellé", "Date d'activation", "Nombre contrats synchros", "Nombre versions synchros",
          "Nombre erreurs intégration", "Nombre erreurs synchronisation", "Offre active"]];
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(response, {
          dateNF: 'dd/mm/yyyy à HH:MM:SS',
          cellDates: true
        });
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.sheet_add_aoa(ws, headers);
        XLSX.utils.book_append_sheet(wb, ws, 'Export des offres');
        ws['!cols'] = [
          { wch: 10 },
          { wch: 35 },
          { wch: 20 },
          { wch: 23 },
          { wch: 23 },
          { wch: 23 },
          { wch: 27 }
        ];
        XLSX.writeFile(wb, fileName);
        this.offerTable.selected.splice(0, this.offerTable.selected.length);
        this.offerTable.recalculate();
      });
    } else {
      this.offreTableService.exportOffres(this.searchText).subscribe(response => {
        const fileName = 'ExportOffres_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["Code OPS", "Libellé", "Date d'activation", "Nombre contrats synchros", "Nombre versions synchros",
          "Nombre erreurs intégration", "Nombre erreurs synchronisation", "Offre active"]];
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(response, {
          dateNF: 'dd/mm/yyyy à HH:MM:SS',
          cellDates: true
        });
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.sheet_add_aoa(ws, headers);
        XLSX.utils.book_append_sheet(wb, ws, 'Export des offres');
        ws['!cols'] = [
          { wch: 10 },
          { wch: 35 },
          { wch: 20 },
          { wch: 23 },
          { wch: 23 },
          { wch: 23 },
          { wch: 27 }
        ];
        XLSX.writeFile(wb, fileName);
        this.offerTable.selected.splice(0, this.offerTable.selected.length);
        this.offerTable.recalculate();
      })
    }
  }

  exportErrors() {
    let dataToExport: ErrorOfferBean[];
    this.offreTableService.getErrors().subscribe({
      next: (response: any) => {
        dataToExport = response.map((data: any) => {
          return <ErrorOfferBean>{
            contractNumber: data.contractNumber,
            amendmentNumber: data.amendmentNumber,
            revisionNumber: data.revisionNumber,
            codeOps: data.codeOps,
            libelleOps: "",
            dateError: new Date(data.dateError * 1000),
            hasBeenSyncOnce: data.previousDateSynchronization != null || (data.previousDateSynchronization == null && data.isSynchronized) ? "Oui" : "Non",
            workflowStep: data.workflowStep,
            errorMessage: data.errorMessage,
          };
        })
      },
      complete: () => {
        for (let i = 0; i < dataToExport.length; i++) {
          for (let j = 0; j < this.listAllOffers.length; j++) {
            dataToExport[i].codeOps == this.listAllOffers[j].codeOps ? dataToExport[i].libelleOps = this.listAllOffers[j].labelOps : '';
          }
        }
        const fileName = 'ExportErreursOffresOuvertes_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["N° Contrat", "N° Avenant", "N° Révision", "Code offre", "Libellé offre", "Date d'erreur", "Déjà synchronisé",
          "Code d'erreur", "Détail de l'erreur"]];
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport, {
          dateNF: 'dd/mm/yyyy à HH:MM:SS',
          cellDates: true
        });
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.sheet_add_aoa(ws, headers);
        XLSX.utils.book_append_sheet(wb, ws, 'Export des erreurs');
        ws['!cols'] = [
          { wch: 12 },
          { wch: 10 },
          { wch: 10 },
          { wch: 10 },
          { wch: 25 },
          { wch: 22 },
          { wch: 15 },
          { wch: 30 },
          { wch: 100 },
        ];
        XLSX.writeFile(wb, fileName);
      },
    });
  }


  showPopupAddOffer() {
    setTimeout(() => {
      this.modalService
        .open(OffresAjoutPopUpComponent, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
            top: '35%'
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
            height: this.M1_MODAL_PROPERTIES.height
          }
        })
        .then((response) => console.log(response));
    }
    );
  }

  showPopup(row: any, type: string, event: Event) {
    this.modalService
      .open(OffreErrorDetailPopUpComponent, {
        modal: {
          enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
        },
        overlay: {
          leave: 'fade-out 0.3s',
        },
        size: {
          padding: this.M1_MODAL_PROPERTIES.padding,
          width: this.M1_MODAL_PROPERTIES.width,
          height: this.M1_MODAL_PROPERTIES.height
        },
        data: {
          offre: row,
          typeError: type
        }
      })
      .then((response) => console.log(response));
    event.stopPropagation();
  }

  updateFilter(event: KeyboardEvent) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value;
    if (event.key === 'Enter') {
      if (this.isActiveOffers)
        this.getListeOffresActives(0, 10, 'opsCode', 'asc', val);
      else {
        this.getListeOffres(0, 10, 'opsCode', 'asc', val);
      }
    }
  }

  formatDateExport(date: number) {
    return this.datePipe.transform(date, 'yyyyMMdd_HHmmss', 'fr');
  }

  formatDateTable(date: number) {
    return date ? this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
  }

  formatDateErrors(date: number): string | null {
    return this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr');
  }

  switchIsActive() {
    if (this.isActiveOffers)
      this.getListeOffresActives(0, 10, 'opsCode', 'asc', '');
    else {
      this.getListeOffres(0, 10, 'opsCode', 'asc', '');
    }

  }

  addUnActiveOffer(codeOps: string) {
    this.modalService
      .open(OffresAjoutPopUpComponent, {
        modal: {
          enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
          top: '35%'
        },
        overlay: {
          leave: 'fade-out 0.3s',
        },
        size: {
          padding: this.M1_MODAL_PROPERTIES.padding,
          width: this.M1_MODAL_PROPERTIES.width,
          height: this.M1_MODAL_PROPERTIES.height
        },
        data: {
          codeOps: codeOps,
          disableSelection: true
        }
      })
      .then((response) => {
        if (response.data) {
          this.callDelay();
        }
      });
  }

  deleteOffer(opsCode: string) {
    this.modalService
      .open(ConfirmComponent, {
        modal: {
          enter: `${this.M2_MODAL_PROPERTIES.animation} ${this.M2_MODAL_PROPERTIES.duration} ${this.M2_MODAL_PROPERTIES.easing}`,
        },
        overlay: {
          leave: 'fade-out 0.3s',
        },
        size: {
          padding: this.M2_MODAL_PROPERTIES.padding,
          width: this.M2_MODAL_PROPERTIES.width,
          height: this.M2_MODAL_PROPERTIES.height
        },
        data: {
          title: 'Confirmation',
          message: 'Etes vous sûr de vouloir désactiver cet offre?'
        }
      })
      .then((response: any) => {
        if (response.data) {
          this.offreTableService.deleteOffer(opsCode).subscribe(response => {
            this.callDelay();
          });
        }
      });

  }

  onPageChange(event: any) {
    if (this.isActiveOffers) {
      this.getListeOffresActives(event.offset, 10, this.offerTable.sorts[0].prop, this.offerTable.sorts[0].dir, this.searchText);
    } else {
      this.getListeOffres(event.offset, 10, this.offerTable.sorts[0].prop, this.offerTable.sorts[0].dir, this.searchText);
    }
  }

  onSort(event: any) {
    if (this.isActiveOffers) {
      this.getListeOffresActives(this.offerPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.searchText);
    } else {
      this.getListeOffres(this.offerPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.searchText);
    }

    this.offerTable.offset = this.offerPage.currentPage!;
  }

  callDelay() {
    setTimeout(() => {
      this.loadingService.setLoading(true);
    }, 500);
    setTimeout(() => {
      if (this.isActiveOffers)
        this.getListeOffresActives(0, 10, 'opsCode', 'asc', this.searchText);
      else {
        this.getListeOffres(0, 10, 'opsCode', 'asc', this.searchText);
      }
    }, 2000);
  }

}
