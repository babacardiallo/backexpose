import { NgModule } from '@angular/core';
import { AuditComponent } from './audit.component';
import {AuditRoutingModule} from "./audit-routing.module";



@NgModule({
  declarations: [AuditComponent],
  imports: [
    AuditRoutingModule
  ],
  exports: [AuditComponent]
})
export class AuditModule { }
