package fr.laposte.blg.blinks.u12.service.customer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.constant.KibanaCustomField;
import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationLegalPersonException;
import fr.laposte.blg.blinks.u12.mapper.CustomerOpencellMapper;
import fr.laposte.blg.blinks.u12.service.ImportService;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.billing.ContractConsolidated;
import fr.laposte.bscc.billing.avro.billing.ContractOpencell;
import fr.laposte.bscc.billing.avro.billing.CustomerOpencell;
import fr.laposte.bscc.billing.avro.billing.OpencellActionEnum;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class CustomerSyncService {

    private final ImportService importService;

    private final LegalPersonService legalPersonService;

    private final CustomerOpencellMapper customerOpencellMapper;

    private final ErrorLogService errorLogService;

    private final QueueService queueService;

    private Long custAccNumber;

    public Mono<ContractConsolidated> synchronize(int internalId, boolean refcomReplay) {

        Mono<ContractConsolidated> fallbackAfterError = Mono.defer(
                () ->
                        queueService.enQueueCustomerByIdLegalPerson((long) internalId, Instant.now(), ActionEnum.update, refcomReplay)
                                .then(Mono.empty())
        );

        Mono<LegalPersonEntity> fallbackAfterRefcomError = Mono.defer(
                () ->
                        queueService.enQueueCustomerByIdLegalPerson((long) internalId, Instant.now(), ActionEnum.update, refcomReplay)
                                .then(Mono.empty())
        );

        return this.legalPersonService.findLegalPersonByIdLegalPerson((long) internalId, true)
                .filter(legalPersonEntity -> !legalPersonEntity.isSynchronized()) //inutile d'aller plus loin le client a déjà été synchronisé une première fois
                .switchIfEmpty(
                        Mono.defer(() -> {
                            log.warn("LegalPerson has already been synchronized idLegalPerson : {}", internalId);
                            return Mono.empty();
                        })
                )
                .flatMap(legalPersonEntity -> {
                    this.custAccNumber = (long)legalPersonEntity.getCustAccNumber();
                    if (legalPersonEntity.getBusinessTeamLongName() == null || legalPersonEntity.getBusinessTeamLongName().isBlank() || refcomReplay) {
                        return importService.fetchBusinessTeam(legalPersonEntity.getCustAccNumber(), legalPersonEntity, LocalDate.now())
                                .onErrorResume(SynchronizationLegalPersonException.class, e -> {
                                    var workflowStep = ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER;
                                    var errorLog = ErrorLogEntity.builder().workflowStep(workflowStep)
                                            .idLegalPerson((long) internalId)
                                            .custAccNumber((long) legalPersonEntity.getCustAccNumber())
                                            .errorMessage("[CLIENT: " + legalPersonEntity.getCustAccNumber() + "]" + e.getMessage() + " Error on BusinessAssignment API")
                                            .codeError(CodeErrorEnum.U12002)
                                            .build();
                                    ObjectMapper objectMapper = new ObjectMapper();
                                    objectMapper.registerModule(new JavaTimeModule());
                                    JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                    log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CUSTOMER, node), "Synchronization customer error: {}, unable to fetch BusinessAssignment API on custAccNumber: {}", node, legalPersonEntity.getCustAccNumber());
                                    return errorLogService.logError(errorLog)
                                            .then(fallbackAfterRefcomError);
                                });
                    } else {
                        return Mono.just(legalPersonEntity);
                    }
                })
                .map(this.customerOpencellMapper::legalPersonEntityToCustomerOpencell)
                .map(customerOpencell -> this.buildContractConsolidated(null, customerOpencell, OpencellActionEnum.UPDATE_CUSTOMER))
                .onErrorResume(SynchronizationLegalPersonException.class, e -> {
                    var workflowStep = e.getWorkflowStepEnum();
                    var errorLog = ErrorLogEntity.builder().workflowStep(workflowStep)
                            .idLegalPerson((long) internalId)
                            .custAccNumber(e.getCoclico())
                            .errorMessage("[CLIENT: " + e.getCoclico() + "] " + e.getMessage())
                            .codeError(CodeErrorEnum.U12002)
                            .build();
                    ObjectMapper objectMapper = new ObjectMapper();
                    objectMapper.registerModule(new JavaTimeModule());
                    JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                    log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CUSTOMER, node), "Synchronization customer error: {}", errorLog);
                    return errorLogService.logError(errorLog)
                            .then(fallbackAfterError);
                })
                .onErrorResume(e -> {
                    var workflowStep = ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER;
                    var errorLog = ErrorLogEntity.builder().workflowStep(workflowStep)
                            .idLegalPerson((long) internalId)
                            .custAccNumber(this.custAccNumber)
                            .errorMessage("[CLIENT: " + this.custAccNumber + "] Unhandled error during legal person synchronization :" + e.getMessage())
                            .codeError(CodeErrorEnum.U12002)
                            .build();
                    ObjectMapper objectMapper = new ObjectMapper();
                    objectMapper.registerModule(new JavaTimeModule());
                    JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                    log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CUSTOMER, node), "Synchronization customer error: {}", errorLog);
                    return errorLogService.logError(errorLog)
                            .then(fallbackAfterError);
                });
    }

    /**
     * Build the complete contractConsolidated avro with the contract and the customer
     *
     * @param contractOpencell The contract for opencell
     * @param customerOpencell The customer for opencell (null in case of update)
     * @param action
     * @return The complete contract consolidated
     */
    public ContractConsolidated buildContractConsolidated(ContractOpencell contractOpencell, CustomerOpencell customerOpencell, OpencellActionEnum action) {
        return ContractConsolidated.newBuilder()
                .setAction(action)
                .setContractOpencell(contractOpencell)
                .setCustomerOpencell(customerOpencell)
                .build();
    }

}
