package fr.laposte.blg.blinks.u11.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.entities.RefopsEntity;
import fr.laposte.r5.uk.kafka.avro.viewoscar.Oscar;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;



@SpringBootTest(classes = {RefopsListenerMapper.class, RefopsListenerMapperImpl.class, RefopsListenerMapperImpl_.class})
public class RefopsListenerMapperTest {

    @Autowired
    RefopsListenerMapper refopsListenerMapper;

    @Test
    void refopsToRefopsEntityTest() throws JsonProcessingException {
        var refopsAvro = "{\n" +
                "  \"offerCode\": \"3186\",\n" +
                "  \"offerName\": \"Offres Presse éditeur ou offres de la gamme Publissimo\",\n" +
                "  \"offerTechnicalVersion\": \"1.0.0\",\n" +
                "  \"offerFunctionalVersion\": \"1.0\",\n" +
                "  \"functionalViewCode\": \"oscar\",\n" +
                "  \"functionalViewVersion\": \"1\",\n" +
                "  \"shortDescription\": \"Solution d'envoi standard pour les publications de presse agréées par la Commission Paritaire et/ou la diffusion de publications périodiques non agréées.\",\n" +
                "  \"longDescription\": \"<u>Offre presse éditeur </u> : Pour les publications qui disposent de l'agrément CPPAP de la Commission Paritaire des Publications et Agences de Presse. L'offre Presse éditeur est un service standard d\\u2019envoi des publications à tarif préférentiel. Ce service permet aux clients éditeurs, d\\u2019envoyer une publication dans les conditions et les délais de distribution correspondant à la périodicité de la publication et aux attentes des abonnés (plus de détails sur la fiche OPS dédiée).\\n\\n<u>Offres Publissimo Intégral et Publissimo Esprit Libre</u> : Pour les publications périodiques, avec ou sans agrément CPPAP. Les offres Publissimo relèvent du cadre du service universel postal et permettent l'accès à un service standard d'envoi des publications à tarif compétitif. Ce service permet aux clients éditeurs, d\\u2019envoyer une publication dans les conditions et les délais de distribution correspondant à leurs attentes, avec une préparation des routages industriels pour le Publissimo Intégral et non routé pour le Publissimo Esprit Libre (plus de détails sur la fiche OPS dédiée).\\n\\n<u>Modalités de préparation et de dépôts décrites dans les spécifications techniques SP8855</u> (téléchargeable sur lastation.fr/laposte.fr)\\n\\nOffres à contractualiser avec l'appui technique du <u>Responsable Déploiement et Réalisation Offres Presse en DEX</u>.\",\n" +
                "  \"restrictedAccess\": {\n" +
                "    \"id\": \"X\",\n" +
                "    \"label\": \"Non\"\n" +
                "  },\n" +
                "  \"simulatorDirectAccess\": {\n" +
                "    \"id\": \"X\",\n" +
                "    \"label\": \"Rien\"\n" +
                "  },\n" +
                "  \"simulatorAccessByODC\": {\n" +
                "    \"id\": \"O\",\n" +
                "    \"label\": \"Configurateur OPS + offre commerciale\"\n" +
                "  },\n" +
                "  \"family\": {\n" +
                "    \"id\": 12,\n" +
                "    \"name\": \"Presse\",\n" +
                "    \"startDate\": \"2017-01-01\",\n" +
                "    \"idMarket\": {\n" +
                "      \"id\": 3,\n" +
                "      \"name\": \"Services aux entreprises\"\n" +
                "    }\n" +
                "  },\n" +
                "  \"market\": {\n" +
                "    \"id\": 3,\n" +
                "    \"name\": \"Services aux entreprises\"\n" +
                "  },\n" +
                "  \"cycle\": [\n" +
                "    {\n" +
                "      \"id\": 4,\n" +
                "      \"name\": \"Gérer (contrat)\",\n" +
                "      \"conquer\": false,\n" +
                "      \"retain\": true\n" +
                "    }\n" +
                "  ],\n" +
                "  \"conquer\": false,\n" +
                "  \"retain\": true,\n" +
                "  \"startDate\": \"2023-01-01\",\n" +
                "  \"endDate\": null,\n" +
                "  \"deleteDate\": null,\n" +
                "  \"marketingData\": {\n" +
                "    \"cabestanCode\": null,\n" +
                "    \"businessUnit\": null,\n" +
                "    \"stampingMethod\": null,\n" +
                "    \"communicationChannel\": null,\n" +
                "    \"oscarTarget\": null\n" +
                "  },\n" +
                "  \"offerCard\": {\n" +
                "    \"bacGroup\": {\n" +
                "      \"driver\": {\n" +
                "        \"id\": 1,\n" +
                "        \"label\": \"Offres standards\"\n" +
                "      },\n" +
                "      \"benefit\": \"Servez vos abonnés et vos prospections de publications au meilleur prix.\",\n" +
                "      \"advantage\": \"Des offres complètes, spécialement conçues pour les diffusions de publications, avec des options permettant de s'adapter aux besoins du client.\",\n" +
                "      \"specific\": \"Les offres presse, des solutions dédiées pour l'envoi de publications avec une préparation industrielle des dépôts (Presse, Publissimo Intégral) ou via des routages simplifiés (Publissimo Esprit Libre).\"\n" +
                "    },\n" +
                "    \"complementaryBAC\": null,\n" +
                "    \"caption\": null,\n" +
                "    \"thatIs\": null,\n" +
                "    \"thatIsCaption\": null,\n" +
                "    \"additionalInformation\": null,\n" +
                "    \"additionalInformationCaption\": null,\n" +
                "    \"nationalInternational\": null,\n" +
                "    \"forLink\": null,\n" +
                "    \"cardScope\": null,\n" +
                "    \"scopeCaption\": null,\n" +
                "    \"andAlso\": null,\n" +
                "    \"options\": null,\n" +
                "    \"optionsCaption\": null,\n" +
                "    \"captionOffer\": null\n" +
                "  },\n" +
                "  \"offerMissionplan\": {\n" +
                "    \"description\": \"XXXXXXXXXXXXXXXXXXXXXXX\",\n" +
                "    \"accessibility\": \"XXXXXXXXXXXXXXXXXXXXXXX\",\n" +
                "    \"geographicscope\": \"XXXXXXXXXXXXXXXXXXXXXXX\",\n" +
                "    \"contract\": \"XXXXXXXXXXXXXXXXXXXXXXX\",\n" +
                "    \"implement\": \"XXXXXXXXXXXXXXXXXXXXXXX\",\n" +
                "    \"thatIs\": null,\n" +
                "    \"aftersalesservice\": null,\n" +
                "    \"technicalspecfific\": null,\n" +
                "    \"priceStructure\": null,\n" +
                "    \"salesChannel\": null\n" +
                "  },\n" +
                "  \"keywords\": {\n" +
                "    \"keywords\": [\n" +
                "      {\n" +
                "        \"id\": 856,\n" +
                "        \"name\": \"presse\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"id\": 1908,\n" +
                "        \"name\": \"Publissimo\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"id\": 1909,\n" +
                "        \"name\": \"plan contractuel de dépôt\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"id\": 1910,\n" +
                "        \"name\": \"éditeur\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"id\": 898,\n" +
                "        \"name\": \"publication\"\n" +
                "      }\n" +
                "    ]\n" +
                "  },\n" +
                "  \"links\": {\n" +
                "    \"customerSpeech\": null,\n" +
                "    \"prices\": null,\n" +
                "    \"implementation\": null,\n" +
                "    \"communication\": null,\n" +
                "    \"offerKnowledge\": null,\n" +
                "    \"other\": [\n" +
                "      {\n" +
                "        \"fileName\": {\n" +
                "          \"fileCode\": \"6165\",\n" +
                "          \"fileName\": \"Logo de l'offre Offres Presse éditeur ou offres de la gamme Publissimo\",\n" +
                "          \"fileType\": {\n" +
                "            \"abbreviation\": \"LOGO\",\n" +
                "            \"type\": \"Logo\",\n" +
                "            \"grouping\": {\n" +
                "              \"id\": \"V\",\n" +
                "              \"label\": \"Divers\"\n" +
                "            },\n" +
                "            \"canvas\": [\n" +
                "              {\n" +
                "                \"id\": \"ContractDomain\",\n" +
                "                \"label\": \"Contrat\"\n" +
                "              }\n" +
                "            ]\n" +
                "          },\n" +
                "          \"format\": null,\n" +
                "          \"fileUrl\": \"https://www.oscar-ops.net-courrier.extra.laposte.fr/documents/LOGOS_OFFRES/3186.png\",\n" +
                "          \"fileValidStartDate\": \"2030-05-11\",\n" +
                "          \"fileVersion\": 1\n" +
                "        },\n" +
                "        \"oscarOfferFileOrder\": 9999\n" +
                "      }\n" +
                "    ]\n" +
                "  }\n" +
                "}";
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        Oscar refops = objectMapper.readValue(refopsAvro, Oscar.class);
        RefopsEntity refopsEntity = refopsListenerMapper.refopsToRefopsEntity(refops);
        assertEquals(refops.getOfferCode(), refopsEntity.getOpsCode());
        assertEquals(refops.getOfferName(), refopsEntity.getOpsLabel());
        assertEquals(refops.getOfferTechnicalVersion(), refopsEntity.getOfferTechnicalVersion());
        assertEquals(refops.getOfferFunctionalVersion(), refopsEntity.getOfferFunctionalVersion());

    }
}

