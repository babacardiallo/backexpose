package fr.laposte.blg.blinks.lib.common.entities;

public enum ContractStatusEnum {
    VALIDE,
    INACTIF,
    EN_COURS_DE_CREATION


}
