package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("address")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Accessors(chain = true)
@Builder
public class AddressEntity {
    @Id
    @Column("id_address")
    private Long idAddress;
    @Column("address_id_refpm")
    private String addressIdRefPM; //String car nous avons des exemples d'addressID avec "_1"
    @Column("id_legal_person")
    private Long idLegalPerson;
    @Column("cust_acc_number")
    private Integer custAccNumber;
    @Transient
    private LegalPersonEntity legalPersonEntity;
    @Column("c_datetime")
    private Instant creationDatetime;
    @Column("m_datetime")
    private Instant modificationDatetime;
    @Column("name1")
    private String name1;
    @Column("add2")
    private String add2;
    @Column("add3")
    private String add3;
    @Column("add4")
    private String add4;
    @Column("add5")
    private String add5;
    @Column("add6")
    private String add6;
    @Column("add7")
    private String add7;
    @Column("address_json")
    private String addressJson;
    @Column("address_type")
    private AddressType addressType;

}
