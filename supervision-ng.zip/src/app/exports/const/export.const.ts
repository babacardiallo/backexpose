export const CHOIX_EXPORTS: Choix[] = [
    {value: 'docaposte',label: 'Docaposte'},
    {value: 'infoca',label: 'Infoca'},
    {value: 'equinox',label: 'Equinox'}
]

export class Choix{
     value: string='';
     label: string='';
}