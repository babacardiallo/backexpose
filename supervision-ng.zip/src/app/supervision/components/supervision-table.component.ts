import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { SupervisionTable } from "../models/supervision-table.model";
import { formatDate } from "@angular/common";
import { Treatment } from "../models/supervision.enum";
import { SupervisionService } from "../service/supervision.service";
import { environment } from "../../../environments/environment";
import { CalendarEvent } from '../models/calendar.event';
import { CalendarMonthViewBeforeRenderEvent, CalendarView } from 'angular-calendar';
import { NguCarousel, NguCarouselConfig } from '@ngu/carousel';
import { Subject } from 'rxjs';

@Component({
    selector: 'supervision-table-component',
    //encapsulation: ViewEncapsulation.None,
    templateUrl: './supervision-table.component.html',
    styleUrls: ['./supervision-table.component.scss',],
    standalone: false
})
export class SupervisionTableComponent implements OnInit, AfterViewInit {

  exportList: SupervisionTable[] = [];
  selected: Date;
  treatment = Treatment;
  expandedIndex = 0;
  kibana = "#";
  events: CalendarEvent[] = [];
  view: CalendarView = CalendarView.Month;
  color = 'yellow';
  public carouselConfig: NguCarouselConfig = {
    grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
    slide: 3,
    speed: 250,
    point: {
      visible: true
    },
    touch: true,
    interval: { timing: 4000, initialDelay: 1000 },
  };

  currentEquinoxIndex = 0;
  currentInfocaIndex = 0;
  currentDocaposteindex = 0;
  equinoxList: SupervisionTable[] = [];
  infocaList: SupervisionTable[] = [];
  docaposteList: SupervisionTable[] = [];
  expandedAccordionEquinox: boolean = false;
  expandedAccordionInfoca: boolean = false;
  expandedAccordionDocaposte: boolean = false;
  exportFileList: any[] = [];
  refresh = new Subject<void>();

  @ViewChild('myCarouselEquinox') myCarouselEquinox: NguCarousel<any>;

  @ViewChild('myCarouselInfoca') myCarouselInfoca: NguCarousel<any>;

  @ViewChild('myCarouselDoca') myCarouselDoca: NguCarousel<any>;

  constructor(private supervisionService: SupervisionService, private cdr: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.selected = new Date();
    this.getDalilyListTreatment();
    this.getMonthlyTreatment();
    this.callFileTransferStatus();
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  callExportsOnDate(): void {
    this.supervisionService.getHistories(this.formatDatetoApi(this.selected))
      .pipe().subscribe(response => {
        this.exportList = response;
      });
  }

  formatDate(date: Date): string {
    const format = 'dd/MM/yyyy';
    const locale = "fr-FR";
    return formatDate(date, format, locale);
  }

  formatDatetoApi(date: Date): string {
    const format = 'yyyy-MM-dd';
    const locale = "fr-FR";
    return formatDate(date, format, locale);
  }

  buildKibanaLinks(event: any, exportId: number) {
    event.preventDefault();
    const url: string = environment.URL_KIBANA;
    const query = 'exportId%20:%20' + exportId;
    const finalUrl = url.replace('exportId%20:%201508', query);
    window.open(finalUrl, '_blank');
  }


  refreshView(): void {
    this.refresh.next();
  }

  dayClicked(event: any) {
    this.selected = event.day.date
    this.getDalilyListTreatment();
    this.callFileTransferStatus();   
  }

  beforeMonthViewRender(renderEvent: CalendarMonthViewBeforeRenderEvent): void {
    renderEvent.body.forEach((day) => {
      if(day.events.length > 0){
        let transferStatusGlobal = 'ico-transfered tooltip';
        for(let i = 0; i < day.events.length; i++){
            const exportEvent = day.events[i];
            if(exportEvent.meta == 'NEW'){
              transferStatusGlobal = 'ico-new tooltip';
              break;
            }
        }

        for(let i = 0; i < day.events.length; i++){
            const exportEvent = day.events[i];
            if(exportEvent.meta == 'FAILED'){
              transferStatusGlobal = 'ico-failed tooltip';
              break;
            }
        }
        day.cssClass = transferStatusGlobal;
      } else {
        day.cssClass = 'icov';
      }
       
    });
  }


  getMonthlyTreatment(year?: number, month?: number) {
    this.supervisionService.getMonthlyTreatment(year, month).subscribe(response => {
      this.events = response?.map((data: any) => {
        return <CalendarEvent>{
          title: data.title,
          start: new Date(data.start),
          end: new Date(data.end),
          meta: data.status,
          color: data.color == 0 ? {
            primary: 'green',
            secondary: 'white',
          } : data.color == 1 ? {
            primary: '#e3bc08',
            secondary: 'white',
          } : {
            primary: 'red',
            secondary: 'white',
          }
        };
      });
      this.refreshView();
    })
  }

  nextMonth() {
    this.events = [];
    const month = this.selected.getMonth() + 1;
    const year = this.selected.getFullYear();
    this.getMonthlyTreatment(year, month);


  }

  previousMonth() {
    this.events = [];
    const month = this.selected.getMonth() + 1;
    const year = this.selected.getFullYear();
    this.getMonthlyTreatment(year, month);
  }

  currentMonth() {
    this.events = [];
    this.getMonthlyTreatment();
    this.getDalilyListTreatment();
    this.callFileTransferStatus();
  }

  onSelectedDateChange() {
    this.events = [];
    const month = this.selected.getMonth() + 1;
    const year = this.selected.getFullYear();
    this.getDalilyListTreatment();
    this.getMonthlyTreatment(year, month);
    this.callFileTransferStatus();
  }

  moveToNextEqunoxExport() {
    if (this.currentEquinoxIndex != this.equinoxList.length - 1) {
      this.myCarouselEquinox.moveTo(this.currentEquinoxIndex + 1);
      this.currentEquinoxIndex++;
    }
  }

  moveToPreviousEqunoxExport() {
    if (this.currentEquinoxIndex != 0) {
      this.myCarouselEquinox.moveTo(this.currentEquinoxIndex - 1);
      this.currentEquinoxIndex--;
    }
  }


  moveToNextInfocaExport() {
    if (this.currentInfocaIndex != this.infocaList.length - 1) {
      this.myCarouselInfoca.moveTo(this.currentInfocaIndex + 1);
      this.currentInfocaIndex++;
    }
  }

  moveToPreviousInfocaExport() {
    if (this.currentInfocaIndex != 0) {
      this.myCarouselInfoca.moveTo(this.currentInfocaIndex - 1);
      this.currentInfocaIndex--;
    }
  }

  moveToNextDocaExport() {
    if (this.currentDocaposteindex != this.docaposteList.length - 1) {
      this.myCarouselDoca.moveTo(this.currentDocaposteindex + 1);
      this.currentDocaposteindex++;
    }
  }

  moveToPreviousDocaExport() {
    if (this.currentDocaposteindex != 0) {
      this.myCarouselDoca.moveTo(this.currentDocaposteindex - 1);
      this.currentDocaposteindex--;
    }
  }

  getDalilyListTreatment() {
    this.equinoxList = [];
    this.infocaList = [];
    this.docaposteList = [];
    this.currentEquinoxIndex = 0;
    this.currentInfocaIndex = 0;
    this.currentDocaposteindex = 0;
    this.supervisionService.getDailyListTreatment(this.formatDatetoApi(this.selected))
      .pipe().subscribe(response => {
        this.equinoxList = response.EQUINOX;
        this.infocaList = response.INFOCA;
        this.docaposteList = response.DOCAPOSTE;
      });
  }

  openEquinoxAcccordion() {
    this.expandedAccordionEquinox = true;
  }

  closeEquinoxAcccordion() {
    this.expandedAccordionEquinox = false;
  }

  openInfocaAcccordion() {
    this.expandedAccordionInfoca = true;
  }

  closeInfocaAcccordion() {
    this.expandedAccordionInfoca = false;
  }

  openDocaposteAcccordion() {
    this.expandedAccordionDocaposte = true;
  }

  closeDocaposteAcccordion() {
    this.expandedAccordionDocaposte = false;
  }

  callFileTransferStatus(): void {
    this.supervisionService.getDailyFileTransfer(this.formatDatetoApi(this.selected))
      .pipe().subscribe(response => {
        this.exportFileList = response;        
      });
  }

}
