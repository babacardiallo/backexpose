package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessAssignementNomenclature;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessAssignmentNomenclatureRepository extends ReactiveCrudRepository<BusinessAssignementNomenclature, Long> {

    Mono<BusinessAssignementNomenclature> findByBusinessAssignementId(Long businessAssignmentId);
    @Query("SELECT b.* FROM refcom_business_assignement_nomenclature b WHERE b.business_assignment_custaccnumber = :custAccNumber AND " +
            "b.business_assignment_start_date <= NOW() AND (b.business_assignment_end_date IS NULL OR b.business_assignment_end_date > NOW()) ")
    Flux<BusinessAssignementNomenclature> findActivesPortfoliosForACustomer(String custAccNumber);
}
