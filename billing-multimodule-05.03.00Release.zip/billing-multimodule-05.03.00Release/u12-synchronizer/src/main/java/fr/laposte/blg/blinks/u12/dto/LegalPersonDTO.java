package fr.laposte.blg.blinks.u12.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
public class LegalPersonDTO {

    @JsonProperty(value = "active", required = true)
    String active;

    @JsonProperty("compName")
    String compName;

    @JsonProperty("brandName")
    String brandName;

    @JsonProperty(value = "custAccNumber", required = true)
    String custAccNumber;

    @JsonProperty(value = "custTypeCode", required = true)
    String custTypeCode;

    @JsonProperty("cvatno")
    String CVATNO;

    @JsonProperty(value = "establishZoneCode", required = true)
    String establishZoneCode;

    @JsonProperty("legalNatureCode")
    String legalNatureCode;

    @JsonProperty("legalNatureName")
    String legalNatureName;

    @JsonProperty("legalPersonBillingTypology")
    String billingTypology;

    @JsonProperty("marketingTypeCode")
    String marketingTypeCode;

    @JsonProperty("siret")
    String siretCode;

    @JsonProperty("email")
    String email;
    List<AddressDTO> adresses;

    public void setAddresses(List<AddressDTO> adresses) {
        this.adresses=adresses;
    }
}
