package fr.laposte.blg.blinks.u12.service.customer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import fr.laposte.blg.blinks.u12.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u12.dto.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Data
@Slf4j
@Service
@ConfigurationProperties(prefix = "fr.laposte.apim.refcom")
@Primary
public class RefComCommunicationServiceImpl implements RefComCommunicationService {

    private String apiName;
    private final ApimServiceImpl apimService;
    private final ObjectMapper objectMapper;

    @Autowired
    public RefComCommunicationServiceImpl(ApimServiceImpl apimService, ObjectMapper objectMapper) {
        this.apimService = apimService;
        this.objectMapper = objectMapper;
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false);
    }

    @Override
    public Mono<RefEquipeCommerciale> fetchTeamCodeAndName(int coclico, LocalDate dateConsultation) {
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        String date = dateConsultation.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String stringBuilder = "((CL_COCLICO|IN|" + coclico + ")" +
                "AND" + "(CL_DATE_DEBUT|<=|" + date + ")" +
                "AND" + "((CL_DATE_FIN|>=|" + date + ")" + "OR" + "(CL_DATE_FIN|IS|NULL))" +
                "AND" + "(PRLP_DATE_DEBUT|<=|" + date + ")" +
                "AND" + "((PRLP_DATE_FIN|>=|" + date + ")" + "OR" + "(PRLP_DATE_FIN|IS|NULL))" +
                "AND" + "(PLEC_DATE_DEBUT|<=|" + date + ")" +
                "AND" + "((PLEC_DATE_FIN|>=|" + date + ")" + "OR" + "(PLEC_DATE_FIN|IS|NULL))" +
                "AND" + "(ALP_DATE_DEBUT|<=|" + date + ")" +
                "AND" + "((ALP_DATE_FIN|>=|" + date + ")" + "OR" + "(ALP_DATE_FIN|IS|NULL))" +
                "AND" + "(TLP_DATE_DEBUT|<=|" + date + ")" +
                "AND" + "((TLP_DATE_FIN|>=|" + date + ")" + "OR" + "(TLP_DATE_FIN|IS|NULL))" +
                "AND(PRLP_FK_TLPR_ID|=|3))";


        queryParams.add("filtre", stringBuilder);
        queryParams.add("join", "*portefeuille(*portefeuillerefcomlienposition(*positions(*agentlienposition,*territoirelienposition(*territoires),*positionlienequipecommerciale(*equipecommerciale))))");
        queryParams.add("_accept", "json");
        log.info("QUERY PARAMS {}", queryParams);

        return apimService.get(apiName, queryParams)
                .switchIfEmpty(Mono.defer(() -> {
                    try {
                        ObjectNode emptyNode = new ObjectMapper().createObjectNode();
                        String emptyJson = new ObjectMapper().writeValueAsString(emptyNode);
                        return Mono.just(emptyJson);
                    } catch (Exception e) {
                        return Mono.error(e);
                    }
                }))
                .flatMap(jsonResponse -> {
                    log.debug("Retour APIM BusinessTeam {}", jsonResponse);
                    RefEquipeCommerciale refComTeamDTO = new RefEquipeCommerciale();
                    try {
                        RefComResponseTeamDTO refComResponseTeamDTO = objectMapper.readValue(jsonResponse, RefComResponseTeamDTO.class);
                        log.info("result {}", refComResponseTeamDTO);
                        if(refComResponseTeamDTO!=null && refComResponseTeamDTO.getResult()!=null && !refComResponseTeamDTO.getResult().isEmpty()){
                            RefPorteFeuilleParent refPorteFeuilleParent = refComResponseTeamDTO.getResult().get(0);
                            if(refPorteFeuilleParent!=null && refPorteFeuilleParent.getPortefeuille()!=null && !refPorteFeuilleParent.getPortefeuille().isEmpty()){
                                RefPorteFeuille portFeuille = refPorteFeuilleParent.getPortefeuille().get(0);
                                if(portFeuille!=null && portFeuille.getPortefeuillerefcomlienposition()!=null && !portFeuille.getPortefeuillerefcomlienposition().isEmpty()){
                                    RefPortefeuilleRefcomLienPosition refPortefeuilleRefcomLienPosition = portFeuille.getPortefeuillerefcomlienposition().get(0);
                                    if(refPortefeuilleRefcomLienPosition!=null && refPortefeuilleRefcomLienPosition.getPositions()!=null && !refPortefeuilleRefcomLienPosition.getPositions().isEmpty()){
                                        RefPosition refPosition = refPortefeuilleRefcomLienPosition.getPositions().get(0);
                                        if(refPosition!=null && refPosition.getPositionlienequipecommerciale()!=null && !refPosition.getPositionlienequipecommerciale().isEmpty()){
                                            RefPositionLienEquipeCommerciale refPositionLienEquipeCommerciale = refPosition.getPositionlienequipecommerciale().get(0);
                                            if(refPositionLienEquipeCommerciale != null && refPositionLienEquipeCommerciale.getEquipecommerciale()!=null && !refPositionLienEquipeCommerciale.getEquipecommerciale().isEmpty()){
                                                refComTeamDTO = refPositionLienEquipeCommerciale.getEquipecommerciale().get(0);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (JsonProcessingException e) {
                        return Mono.error(new LegalPersonCommunicationException("Response from BusinessTeam api cannot be parsed", e));
                    }
                    return Mono.just(refComTeamDTO);
                })
                .onErrorResume(err -> Mono.just(new RefEquipeCommerciale()));

    }
}
