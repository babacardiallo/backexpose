package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface AddressRepository extends ReactiveCrudRepository<AddressEntity, Long> {

    Flux<AddressEntity> findByIdLegalPerson(Long idLegalPerson);
    Mono<AddressEntity> findByAddressIdRefPM(String addressIdRefPM);
    Mono<Long> countByIdLegalPerson(Long idLegalPerson);
}
