package fr.laposte.blg.blinks.u17.service;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceSupervisionRepository;
import fr.laposte.blg.blinks.u17.dto.InvoiceDetailsDto;
import fr.laposte.blg.blinks.u17.dto.InvoiceSupervsionDto;
import fr.laposte.blg.blinks.u17.util.Constant;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@Data
public class InvoiceSupervisionService {
    private final InvoiceSupervisionRepository invoiceSupervisionRepository;
    private final ExportHistoryRepository exportHistoryRepository;
    private final InvoiceMessageRepository invoiceMessageRepository;
    private static final ObjectMapper mapper = new ObjectMapper();
    private final DatabaseClient databaseClient;


    public Mono<Page<InvoiceSupervsionDto>> getAllByOnInvoiceNumber(Pageable pageable, String invoiceNumber) {
        return invoiceSupervisionRepository.findAllByInvoiceNumber(pageable, invoiceNumber)
                .map(this::mapEntityToDto)
                .collectList()
                .zipWith(invoiceSupervisionRepository.countAllByInvoiceNumber(invoiceNumber))
                .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));

    }

    public Mono<Page<InvoiceSupervsionDto>> getAllByListOfInvoiceNumber(Pageable pageable, List<String> invoiceNumbers) {
        return invoiceSupervisionRepository.findAllByInvoiceNumberIn(pageable, invoiceNumbers)
                .map(this::mapEntityToDto)
                .collectList()
                .zipWith(invoiceSupervisionRepository.countAllByInvoiceNumberIn(invoiceNumbers))
                .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));

    }

    public Mono<InvoiceDetailsDto> getInvoiceDetails(Long invoiceId, List<Long> idsExport) {
        return invoiceMessageRepository.getMessage(invoiceId)
                .flatMap(message -> {
                    try {
                        InvoiceDetailsDto dto = invoiceMessageToInvoiceDetails(message);
                        return exportHistoryToInvoiceDetails(idsExport, dto);
                    } catch (JacksonException e) {
                        return Mono.just(InvoiceDetailsDto.builder()
                                .mappingError(e.getMessage())
                                .build());
                    }
                });
    }

    private InvoiceSupervsionDto mapEntityToDto(InvoiceSupervision invoiceSupervision) {
        return new InvoiceSupervsionDto(
                invoiceSupervision.getIdInvoice(),
                invoiceSupervision.getInvoiceNumber(),
                invoiceSupervision.getCreated(),
                invoiceSupervision.getClient(),
                invoiceSupervision.getBillrunId(),
                invoiceSupervision.getDocaposteExportStatus().toString(),
                invoiceSupervision.getInfocaExportStatus().toString(),
                invoiceSupervision.getCoeurfinanceExportStatus().toString(),
                invoiceSupervision.getDocaposteExportDate(),
                invoiceSupervision.getInfocaExportDate(),
                invoiceSupervision.getCoeurfinanceExportDate(),
                invoiceSupervision.getDocaposteExportId(),
                invoiceSupervision.getInfocaExportId(),
                invoiceSupervision.getCoeurfinanceExportId(),
                1,
                true
        );
    }

    private Mono<InvoiceDetailsDto> exportHistoryToInvoiceDetails(List<Long> idsExport, InvoiceDetailsDto invoiceDetails) {
        return exportHistoryRepository.findAllByIdExportIn(idsExport)
                .collectList()
                .map(exportHistoryEntities -> {
                    for (ExportHistoryEntity exportHistory : exportHistoryEntities) {
                        FileType fileType = exportHistory.getFileType();
                        String fileName = exportHistory.getFileName();
                        TransferStatus transferStatus = exportHistory.getTransferStatus();
                        Instant transferDate = exportHistory.getFileSendDate();

                        if (fileType.equals(FileType.COEURFINANCE)) {
                            invoiceDetails.setCoeurfinanceFileName(fileName);
                            invoiceDetails.setCoeurfinanceTransferStatus(transferStatus);
                            invoiceDetails.setCoeurfinanceTransfertDate(transferDate);
                        } else if (fileType.equals(FileType.DOCAPOSTE)) {
                            invoiceDetails.setDocaposteFileName(fileName);
                            invoiceDetails.setDocaposteTransferStatus(transferStatus);
                            invoiceDetails.setDocaposteTransfertDate(transferDate);
                        } else if (fileType.equals(FileType.INFOCA)) {
                            invoiceDetails.setInfocaFileName(fileName);
                            invoiceDetails.setInfocaTransferStatus(transferStatus);
                            invoiceDetails.setInfocaTransfertDate(transferDate);
                        }
                    }
                    return invoiceDetails;
                });
    }

    private InvoiceDetailsDto invoiceMessageToInvoiceDetails(String message) throws JacksonException {
        int jsonSize = message.length();
        JsonNode root = mapper.readTree(message);
        JsonNode invoiceHeader = root.path("invoiceHeader");
        JsonNode billingAmount = invoiceHeader.path("billingAmount");
        boolean isCredit = invoiceHeader.path("creditFlag").asBoolean();
        boolean isRefundable = invoiceHeader.path("refundableFlag").asBoolean();
        boolean isDownpayment = invoiceHeader.path("downpaymentFlag").asBoolean();
        boolean isStatement = invoiceHeader.path("isStatementFlag").asBoolean();
        boolean isOpencellPdf = invoiceHeader.path("pdfGeneratedByOpencell").asBoolean();
        boolean isDedicated = invoiceHeader.path("dedicatedInvoiceFlag").asBoolean();
        boolean printFlag = root.path("invoiceHeader").path("printFlag").asBoolean();
        double htAmount = billingAmount.path("excludingTaxNetTotalAmount").asDouble();
        double amount = billingAmount.path("amountDue").asDouble();
        String support = root.path("billingAccount").path("sendingSupportLabel").asText();

        return InvoiceDetailsDto.builder()
                .isCredit(isCredit)
                .isRefundable(isRefundable)
                .isDownpayment(isDownpayment)
                .isStatement(isStatement)
                .isOpencellPdf(isOpencellPdf)
                .isDedicated(isDedicated)
                .printFlag(printFlag)
                .htAmount(htAmount)
                .amount(amount)
                .support(support)
                .invoiceJson(jsonSize <= 1000000 ? message : null)
                .build();
    }

    public Mono<Page<InvoiceSupervsionDto>> getAllInvoicesInAndOutOfBlinks(
            List<String> invoiceNumbers,
            Pageable pageable,
            String sortField,
            String sortDirection
    ) {
        try {

            String idsJson = mapper.writeValueAsString(invoiceNumbers);

            String safeSortField = getSafeSortField(sortField);

            String dataQuery = Constant.BASE_QUERY +
                    " SELECT * FROM combined " +
                    " ORDER BY " + safeSortField + " " + sortDirection +
                    " LIMIT :limit OFFSET :offset";

            String countQuery = Constant.BASE_QUERY + " SELECT COUNT(*) AS total FROM combined";

            Mono<List<InvoiceSupervsionDto>> data = getData(dataQuery, pageable,idsJson, false);

            Mono<Long> count = databaseClient.sql(countQuery)
                    .bind("ids", idsJson)
                    .map((row, meta) -> row.get("total", Long.class))
                    .one();

            return Mono.zip(data, count)
                    .map(tuple -> new PageImpl<>(
                            tuple.getT1(),
                            pageable,
                            tuple.getT2()
                    ));

        } catch (JsonProcessingException e) {
            return Mono.error(new RuntimeException("Erreur de sérialisation JSON", e));
        }
    }

    public Mono<Page<InvoiceSupervsionDto>> getAllInvoicesOutOfBlinks(
            List<String> invoiceNumbers,
            Pageable pageable,
            String sortField,
            String sortDirection
    ) {
        try {

            String idsJson = mapper.writeValueAsString(invoiceNumbers);

            String safeSortField = getSafeSortField(sortField);

            String dataQuery = Constant.OUT_OF_BLINKS_BASE_QUERY +
                    " SELECT * FROM combined " +
                    " ORDER BY " + safeSortField + " " + sortDirection +
                    " LIMIT :limit OFFSET :offset";

            String countQuery = Constant.OUT_OF_BLINKS_BASE_QUERY + " SELECT COUNT(*) AS total FROM combined";

            Mono<List<InvoiceSupervsionDto>> data = getData(dataQuery, pageable,idsJson, true);

            Mono<Long> count = databaseClient.sql(countQuery)
                    .bind("ids", idsJson)
                    .map((row, meta) -> row.get("total", Long.class))
                    .one();

            return Mono.zip(data, count)
                    .map(tuple -> new PageImpl<>(
                            tuple.getT1(),
                            pageable,
                            tuple.getT2()
                    ));

        } catch (JsonProcessingException e) {
            return Mono.error(new RuntimeException("Erreur de sérialisation JSON", e));
        }
    }


    private String getSafeSortField(String sortField){
        return switch (sortField) {
            case "invoiceNumber" -> "invoice_number";
            case "created" -> "created";
            case "client" -> "client";
            case "billrunId" -> "billrun_id";
            case "docaposteExportStatus" -> "docaposte_export_status";
            case "infocaExportStatus" -> "infoca_export_status";
            case "coeurfinanceExportStatus" -> "coeurfinance_export_status";
            case "docaposteExportDate" -> "docaposte_export_date";
            case "docaposteExportId" -> "docaposte_export_id";
            case "infocaExportDate" -> "infoca_export_date";
            case "infocaExportId" -> "infoca_export_id";
            case "coeurfinanceExportDate" -> "coeurfinance_export_date";
            case "coeurfinanceExportId" -> "coeurfinance_export_id";
            case "present" -> "present";
            default -> "id_invoice";
        };
    }

    private Mono<List<InvoiceSupervsionDto>> getData(String dataQuery, Pageable pageable, String idsJson, boolean fromTableOnly){
        return databaseClient.sql(dataQuery)
                .bind("ids", idsJson)
                .bind("limit", pageable.getPageSize())
                .bind("offset", (int) pageable.getOffset())
                .map((row, meta) -> new InvoiceSupervsionDto(
                        row.get("id_invoice", Long.class),
                        row.get("invoice_number", String.class),
                        row.get("created", Instant.class),
                        row.get("client", Integer.class),
                        row.get("billrun_id", String.class),
                        row.get("docaposte_export_status", String.class),
                        row.get("infoca_export_status", String.class),
                        row.get("coeurfinance_export_status", String.class),
                        row.get("docaposte_export_date", Instant.class),
                        row.get("infoca_export_date", Instant.class),
                        row.get("coeurfinance_export_date", Instant.class),
                        row.get("docaposte_export_id", Long.class),
                        row.get("infoca_export_id", Long.class),
                        row.get("coeurfinance_export_id", Long.class),
                        row.get("present", Integer.class),
                        fromTableOnly
                ))
                .all()
                .collectList();
    }

}
