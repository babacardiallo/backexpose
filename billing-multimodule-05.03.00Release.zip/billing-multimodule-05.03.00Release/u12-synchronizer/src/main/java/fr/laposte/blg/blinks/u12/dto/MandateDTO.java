package fr.laposte.blg.blinks.u12.dto;

import lombok.Data;

@Data
public class MandateDTO {

    private String rum;

    private String iban;

    private String bic;

    private String status;

    private String custAccNumber;
}
