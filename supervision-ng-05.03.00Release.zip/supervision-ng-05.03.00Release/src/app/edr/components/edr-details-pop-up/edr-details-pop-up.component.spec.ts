import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EdrDetailsPopUpComponent } from './edr-details-pop-up.component';


describe('EdrDetailsPopUpComponent', () => {
    let component: EdrDetailsPopUpComponent;
    let fixture: ComponentFixture<EdrDetailsPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [EdrDetailsPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(EdrDetailsPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
