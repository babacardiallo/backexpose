package fr.laposte.blg.blinks.u12.mapper.enumeration;

import lombok.AllArgsConstructor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
public enum SendingSupportEnum {

    SUPP_FAC_10("10", "Papier"),
    SUPP_FAC_20("20", "Dématérialisation fiscale"),
    SUPP_FAC_30("30", "Autre"),
    SUPP_FAC_40("40", "PDF Signé");

    private static final Map<String, String> BY_LABEL = new HashMap<>();

    static {
        Arrays.stream(values()).forEach(sendingSupportEnum -> BY_LABEL.put(sendingSupportEnum.label, sendingSupportEnum.code));
    }

    private String code;
    private String label;

    public static String getCode(String label) {
        return BY_LABEL.get(label);
    }

}
