import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClientsDetailsPopUpComponent } from './clients-details-pop-up.component';


describe('ClientsDetailsPopUpComponent', () => {
    let component: ClientsDetailsPopUpComponent;
    let fixture: ComponentFixture<ClientsDetailsPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ClientsDetailsPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ClientsDetailsPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
