export class EdrTable {
    id?: string;
    eventUuid?:string;
    errorDate?: Date;
    errorCode?: string;
    errorMessage?:string;
    replayStatus?:string;
    nbRetry?: number;
    contractCode?: string;
    custAccNumber?: string;
    offerCode?: string;
    productCode?: string;
 
}