package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.u17.dto.InvoiceDetailsDto;
import fr.laposte.blg.blinks.u17.dto.InvoiceSupervsionDto;
import fr.laposte.blg.blinks.u17.service.InvoiceSupervisionService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/invoice-supervision")
@OpenAPIDefinition(tags = {@Tag(name = "InvoiceSupervisionController")})
public class InvoiceSupervisionController {

    private final InvoiceSupervisionService invoiceSupervisionService;

    @GetMapping("/all")
    @Operation(
            summary = "Liste des factures en supervision",
            description = "Retourne toutes les factures en supervision")
    Mono<Page<InvoiceSupervsionDto>> getAllInvoices(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "invoiceNumber") String sort,
            @RequestParam(defaultValue = "desc") String order,
            @RequestParam List<String> invoiceNumber,
            @RequestParam(defaultValue = "1") boolean inBlinks,
            @RequestParam(defaultValue = "0") boolean isMultiSearch,
            @RequestParam(defaultValue = "1") boolean outOfBlinks

    ) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idInvoice"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if(isMultiSearch){
            if(inBlinks && outOfBlinks){
                return invoiceSupervisionService.getAllInvoicesInAndOutOfBlinks(invoiceNumber, pageable, sort, order);
            } else {
                if(!inBlinks && !outOfBlinks){
                    return Mono.just(new PageImpl<>(new ArrayList<>(), pageable, 0));
                } else {
                    if (inBlinks){
                        return invoiceSupervisionService.getAllByListOfInvoiceNumber(pageable, invoiceNumber);
                    }
                    return invoiceSupervisionService.getAllInvoicesOutOfBlinks(invoiceNumber, pageable, sort, order);
                }
            }

        } else {
            if(inBlinks && outOfBlinks){
                return invoiceSupervisionService.getAllByOnInvoiceNumber(pageable, invoiceNumber.get(0));
            } else {
                if (inBlinks) {
                    return invoiceSupervisionService.getAllByOnInvoiceNumber(pageable, invoiceNumber.get(0));
                }
                return Mono.just(new PageImpl<>(new ArrayList<>(), pageable, 0));
            }
        }
    }


    @GetMapping("/{idInvoice}/details")
    @Operation(
            summary = "Détails pour une facture",
            description = "Récupère les information d'export et de transfert et des données du json d'une facture"
    )
    Mono<InvoiceDetailsDto> getInvoiceDetails(
            @PathVariable Long idInvoice,
            @RequestParam(required = false) List<Long> idsExport
    ){
        if (idsExport == null){
            idsExport = new ArrayList<>();
        }
        return invoiceSupervisionService.getInvoiceDetails(idInvoice,idsExport);
    }
}
