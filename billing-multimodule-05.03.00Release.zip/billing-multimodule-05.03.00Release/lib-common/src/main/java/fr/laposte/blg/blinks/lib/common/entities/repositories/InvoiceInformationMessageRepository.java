package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.InvoiceInformationEntityMessage;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface InvoiceInformationMessageRepository extends ReactiveCrudRepository<InvoiceInformationEntityMessage, Long> {

    Mono<InvoiceInformationEntityMessage> findByIdInvoiceInformation(Long id);
}
