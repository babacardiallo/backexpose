package controller;

import fr.laposte.blg.blinks.u17.controller.NotificationController;
import fr.laposte.blg.blinks.u17.service.NotificationService;
import fr.laposte.blg.blinks.u17.service.NotificationService.EmailsResponse;
import fr.laposte.blg.blinks.u17.service.NotificationService.UpdateEmailsRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;

    private NotificationController notificationController;

    @BeforeEach
    void setUp() {
        notificationController = new NotificationController(notificationService);
    }

    @Test
    void getEmails_shouldReturnEmailsFromService() {
        EmailsResponse response = new EmailsResponse(Collections.singletonList("a@test.fr"));
        when(notificationService.getEmails()).thenReturn(Mono.just(response));

        StepVerifier.create(notificationController.getEmails())
                .assertNext(result -> assertThat(result.getEmails()).containsExactly("a@test.fr"))
                .verifyComplete();
    }

    @Test
    void updateEmails_shouldDelegateToService() {
        UpdateEmailsRequest request = new UpdateEmailsRequest();
        request.setAdd(Collections.singletonList("b@test.fr"));

        EmailsResponse response = new EmailsResponse(Collections.singletonList("b@test.fr"));
        when(notificationService.updateEmails(any(UpdateEmailsRequest.class))).thenReturn(Mono.just(response));

        StepVerifier.create(notificationController.updateEmails(request))
                .assertNext(result -> assertThat(result.getEmails()).containsExactly("b@test.fr"))
                .verifyComplete();
    }
}

