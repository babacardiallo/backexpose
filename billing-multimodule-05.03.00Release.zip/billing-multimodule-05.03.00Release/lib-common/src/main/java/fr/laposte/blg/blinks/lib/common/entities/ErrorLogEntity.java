package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;

@Table("error_log")
@Data
@Builder
public class ErrorLogEntity {
    @Id
    @Column("id_error_log")
    private Long idErrorLog;

    @Column("contract_number")
    private String contractNumber;

    @Column("id_contract")
    private Long idContract;

    @Column("amendment_number")
    private Integer amendmentNumber;

    @Column("revision_number")
    private Integer revisionNumber;

    @Column("id_legal_person")
    private Long idLegalPerson;

    @Column("cust_acc_number")
    private Long custAccNumber;

    @Column("id_address_refpm")
    private Long idAddressREFPM;

    @Column("status")
    private ContractStatusEnum status;

    @Column("substatus")
    private ContractSubStatusEnum substatus;

    @Column("first_error_date")
    private Instant firstErrorDate;

    @Column("date_error")
    private Instant dateError;

    @Column("error_message")
    private String errorMessage;

    @Column("workflow_step")
    private ErrorWorkflowStepEnum workflowStep;

    @Column("offset_num")
    private String offset;

    @Column("partition_num")
    private String partition;

    @Column("contract_odc_json")
    private String contractOdcJson;

    @Column("ops_code")
    private String opsCode;

    @Column("code_error")
    private CodeErrorEnum codeError;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ErrorLogEntity that = (ErrorLogEntity) o;
        return Objects.equals(idErrorLog, that.idErrorLog) &&
            Objects.equals(contractNumber, that.contractNumber) &&
            Objects.equals(amendmentNumber, that.amendmentNumber) &&
            Objects.equals(revisionNumber, that.revisionNumber) &&
            Objects.equals(status, that.status) &&
            Objects.equals(substatus, that.substatus) &&
            Objects.equals(dateError, that.dateError) &&
            Objects.equals(firstErrorDate, that.firstErrorDate) &&
            Objects.equals(errorMessage, that.errorMessage) &&
            Objects.equals(workflowStep, that.workflowStep) &&
            Objects.equals(codeError, that.codeError);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idErrorLog, contractNumber, amendmentNumber, revisionNumber, status, substatus, dateError, firstErrorDate, errorMessage, workflowStep, codeError);
    }

    public enum ErrorWorkflowStepEnum {
        /**
         * Dans le contexte du listener, erreur lors de la vérification de l'ordre d'écoute des status/sous statut des révisions pour une version de contrat donnée.
         * Ne donne pas lieu à un rattrapage
         */
        CONTRACT_LISTENING_ORDER,
        /**
         * Erreur dans le contexte du listener, se reférer au message. N'est pas éligible à un rattrapage
         */
        CONTRACT_LISTENING,
        ELECTION_CONTRACT_LISTENING,
        /**
         * Erreur dans le contexte du listener, a lieu pendant la publication, peut donner lieu à un rattrapage
         */
        CONTRACT_POST_LISTENING_PUBLISHING,
        /**
         * Erreur dans le contexte du listener de legalPerson, ne donne pas lieu à un rattrapage.
         */
        LEGALPERSON_LISTENING,
        /**
         * Erreur dans le contexte du listener d'adresse, ne donne pas lieu à un rattrapage.
         */
        ADDRESS_LISTENING,
        /**
         * Erreur dans le contexte de sychronisation du client (modification), ne donne pas lieu à un rattrapage
         */
        SYNCHRONIZATION_CUSTOMER,
        /**
         * Erreur dans le contexte de synchronisation du contrat, se référer au message d'erreur, donne lieu à un rattrapage
         */
        SYNCHRONIZATION_CONTRACT,
        /**
         * Erreur dans le contexte de synchro contrat au niveau mapping des critères/produits/service et attributs du contrat, donne lieu à un rattrapage
         */
        MAPPING_CONTRACT_OPENCELL,

        SCHEDULER,

        /**
         * Erreur dans le contexte de synchro contrat lors de la publication dans le topic consolid (create action), donne lieu à un rattrapage si contexte de synchro contrat
         */
        SYNCHRONIZATION_PUBLISHING_CREATE_CONTRACT,
        /**
         * Erreur dans le contexte de synchro contrat lors de la publication dans le topic consolidé (update action), donne lieu à un rattrapage si contexte de synchro contrat
         */
        SYNCHRONIZATION_PUBLISHING_UPDATE_CONTRACT,
        /**
         * Erreur dans le contexte de synchro client lors de la publication dans le topic consolidé, ne donne pas lieu à un rattrapage
         */
        SYNCHRONIZATION_PUBLISHING_CUSTOMER,
        /**
         * Erreur dans le contexte de synchro contrat
         */
        CALLING_REFPM_API,
        /**
         * Erreur dans le contexte de synchro contrat alors qu'on appelle Mandat
         */
        CALLING_MANDAT_SEPA_API,
        /**
         * Erreur dans le contexte de synchro contrat alors qu'on appelle Source Orga
         */
        CALLING_SOURCE_ORGA_API,
        /**
         * Erreur lors la lecture du message du topic des des messages contrats
         */
        CONTRACT_LISTENING_BEFORE_CONTRACT_CREATION,
        /**
         * Erreur après la mapping avro des messages des contrats
         */
        CONTRACT_LISTENING_AFTER_MAPPING_AVRO,
        MANDATE_INTEGRATION,
        MANDATE_UPDATE
    }

}
