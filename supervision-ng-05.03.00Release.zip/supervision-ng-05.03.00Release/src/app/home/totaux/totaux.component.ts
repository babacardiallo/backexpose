import { Component, OnInit } from '@angular/core';
import { StatModel } from './models/stat.model';
import { TotauxService } from './totaux.service';

@Component({
    selector: 'totaux-component',
    templateUrl: './totaux.component.html',
    styleUrls: ['./totaux.component.scss'],
    standalone: false
})
export class TotauxComponent implements OnInit {

  totauxBilling: StatModel[] = [];
  totauxInvoice: StatModel[] = [];
  totauxContractAndVersionIntegrated: StatModel[] = [];
 
  constructor(private totauxService: TotauxService){}

  ngOnInit(): void {
    this.getTotaux();
  }

  getTotaux(){
    this.totauxBilling = [];
    this.totauxContractAndVersionIntegrated = [];
    this.totauxService.getTotauxBilling().subscribe(totaux =>{
        totaux.forEach(statModel=>{
            if(statModel.index<5){
              this.totauxBilling.push(statModel);
            } else {
              this.totauxContractAndVersionIntegrated.push(statModel);
            }
        })
     });

     this.totauxService.getTotauxInvoice().subscribe(totaux =>{
        this.totauxInvoice  = totaux;
     }); 
  }

}