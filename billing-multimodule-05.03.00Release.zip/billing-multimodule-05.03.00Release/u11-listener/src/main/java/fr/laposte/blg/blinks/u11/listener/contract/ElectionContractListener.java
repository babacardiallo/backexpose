package fr.laposte.blg.blinks.u11.listener.contract;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.constant.KibanaCustomField;
import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Data
@Component
@ConfigurationProperties(prefix = "fr.laposte.billing.listener.election-contract.canal-suez")
@ConditionalOnProperty(value = "fr.laposte.billing.listener.election-contract.activated", havingValue = "true")
public class ElectionContractListener {
    String kafkaTopic;
    String kafkaGroupId;

    ContractFullService contractFullService;

    private final ErrorLogService errorLogService;

    public ElectionContractListener(ContractFullService contractFullService, ErrorLogService errorLogService) {
        this.contractFullService = contractFullService;
        this.errorLogService = errorLogService;
    }

    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", kafkaTopic);
        log.info("Kafka groupId: {}", kafkaGroupId);
        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", kafkaTopic, kafkaGroupId);
    }
    @KafkaListener(groupId = "${fr.laposte.billing.listener.election-contract.canal-suez.kafka-group-id}",
            topics = "${fr.laposte.billing.listener.election-contract.canal-suez.kafka-topic}", containerFactory = "specificAvroValueConsumerFactory")
    public void onMessages(List<ConsumerRecord<String, gkContractFullOutV1>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} contract(s) from topic '{}'", total, kafkaTopic);
        AtomicInteger errorCount = new AtomicInteger(0);
        try {
            Flux.fromIterable(records)
                    .concatMap(message -> {
                        log.info("Record received: key={}, topic={}, partition={}, offset={}",
                                message.key(), message.topic(), message.partition(), message.offset());
                        return contractFullService.readODCContract(message)
                                .onErrorResume(exception -> {
                                    errorCount.incrementAndGet();
                                    var errorLog = ErrorLogEntity.builder()
                                            .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING)
                                            .contractNumber(message.key())
                                            .errorMessage(exception.getMessage())
                                            .offset(String.valueOf(message.offset()))
                                            .partition(String.valueOf(message.partition()))
                                            .amendmentNumber(Integer.parseInt(message.value().getContract().getContractVersionInformation().getAmendmentNumber().toString()))
                                            .revisionNumber(Integer.parseInt(message.value().getContract().getContractVersionInformation().getContractVersionNumber().toString()))
                                            .status(null)
                                            .substatus(null)
                                            .contractOdcJson(String.valueOf(message.value()))
                                            .opsCode(String.valueOf(message.value().getContract().getOffer().getOpsCode()))
                                            .custAccNumber(Long.parseUnsignedLong(message.value().getContract().getContractInformation().getCustAccNumber().toString()))
                                            .codeError(CodeErrorEnum.U11001)
                                            .build();
                                    ObjectMapper objectMapper = new ObjectMapper();
                                    objectMapper.registerModule(new JavaTimeModule());
                                    JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                    log.error(Markers.append(KibanaCustomField.CLEFS_INTEGRATION_CONTRACT, node),
                                            "Error on Contract Listener on contract number : {}, clefs: {}",
                                            message.key(), node);
                                    return errorLogService.logError(errorLog).then(Mono.empty());
                                });
                    })
                    .then()
                    .block();
            if (errorCount.get() == 0) {
                ack.acknowledge();
                log.info("Batch processed and acknowledged successfully");
            } else {
                log.warn("Batch processing failed with {} errors — retrying individually {} records ))",
                        errorCount.get(), total);
                retryIndividually(records, ack);
            }
        } catch (Exception error) {
            log.error("Unexpected error during batch processing — retrying individually ({} record(s))", total, error);
            retryIndividually(records, ack);
        }
    }

    private void retryIndividually(List<ConsumerRecord<String, gkContractFullOutV1>> records, Acknowledgment ack) {
        Flux.fromIterable(records)
                .concatMap(message -> contractFullService.readODCContract(message)
                        .doOnSuccess(c -> {
                            log.info("Contract key: {} is acknowledged successfully", message.key());
                            ack.acknowledge();
                        })
                        .doOnError(e -> log.error("Error processing contract key={}", message.key(), e))
                        .onErrorResume(exception -> {
                            var errorLog = ErrorLogEntity.builder()
                                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING)
                                    .contractNumber(message.key())
                                    .errorMessage(exception.getMessage())
                                    .offset(String.valueOf(message.offset()))
                                    .partition(String.valueOf(message.partition()))
                                    .amendmentNumber(Integer.parseInt(message.value().getContract().getContractVersionInformation().getAmendmentNumber().toString()))
                                    .revisionNumber(Integer.parseInt(message.value().getContract().getContractVersionInformation().getContractVersionNumber().toString()))
                                    .status(null)
                                    .substatus(null)
                                    .contractOdcJson(String.valueOf(message.value()))
                                    .opsCode(String.valueOf(message.value().getContract().getOffer().getOpsCode()))
                                    .custAccNumber(Long.parseUnsignedLong(message.value().getContract().getContractInformation().getCustAccNumber().toString()))
                                    .codeError(CodeErrorEnum.U11001)
                                    .build();
                            ObjectMapper objectMapper = new ObjectMapper();
                            objectMapper.registerModule(new JavaTimeModule());
                            JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                            log.error(Markers.append(KibanaCustomField.CLEFS_INTEGRATION_CONTRACT, node), "Error on Contract Listener on contract number : {}, clefs: {}", message.key(), node);
                            return errorLogService.logError(errorLog).then(Mono.empty());
                        })
                )
                .then()
                .block();
    }

}
