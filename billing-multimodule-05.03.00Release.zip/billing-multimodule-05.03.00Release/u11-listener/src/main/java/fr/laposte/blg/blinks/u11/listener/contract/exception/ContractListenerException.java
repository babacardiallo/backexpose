package fr.laposte.blg.blinks.u11.listener.contract.exception;

import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class ContractListenerException extends RuntimeException {

    ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum;
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionNumber;
    private ContractVersionEntity contractVersionEntity;
    private String offset;
    private String partition;
    private String contractJson;

    private String opsCode;

    /**
     * Constructs a new runtime exception with the specified detail message.
     * The cause is not initialized, and may subsequently be initialized by a
     * call to {@link #initCause}.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the {@link #getMessage()} method.
     */
    public ContractListenerException(String message) {
        super(message);
    }

    /**
     * Constructs a new runtime exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this runtime exception's detail message.
     *
     * @param message the detail message (which is saved for later retrieval
     *                by the {@link #getMessage()} method).
     * @param cause   the cause (which is saved for later retrieval by the
     *                {@link #getCause()} method).  (A {@code null} value is
     *                permitted, and indicates that the cause is nonexistent or
     *                unknown.)
     * @since 1.4
     */
    public ContractListenerException(String message, Throwable cause, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, String contractNumber, Integer amendmentNumber, Integer revisionNumber, ContractVersionEntity contractVersionEntity, String opsCode) {
        super(message, cause);
        this.workflowStepEnum = workflowStepEnum;
        this.contractNumber = contractNumber;
        this.amendmentNumber = amendmentNumber;
        this.revisionNumber = revisionNumber;
        this.contractVersionEntity = contractVersionEntity;
        this.opsCode = opsCode;
    }

    public ContractListenerException(String message, Throwable cause, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, String contractNumber, Integer amendmentNumber, Integer revisionNumber, ContractVersionEntity contractVersionEntity, String offset, String partition, String contractJson, String opsCode){
        super(message, cause);
        this.workflowStepEnum = workflowStepEnum;
        this.contractNumber = contractNumber;
        this.amendmentNumber = amendmentNumber;
        this.revisionNumber = revisionNumber;
        this.contractVersionEntity = contractVersionEntity;
        this.offset = offset;
        this.partition = partition;
        this.contractJson = contractJson;
        this.opsCode = opsCode;
    }
}
