package fr.laposte.blg.blinks.u18.service;

import java.time.Instant;

public interface FilePurgeService {
    int purgeFilesOlderThan(String folderPath, Instant threshold);
}
