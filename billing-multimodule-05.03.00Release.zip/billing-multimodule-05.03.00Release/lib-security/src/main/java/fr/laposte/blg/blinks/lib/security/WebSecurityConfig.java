package fr.laposte.blg.blinks.lib.security;

import fr.laposte.bscc.shared.jwt.filter.reactive.JwtAuthorizationWebFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

@Configuration
@EnableWebFluxSecurity
@Slf4j
public class WebSecurityConfig {

    @Value("${fr.laposte.security.cors.allowed-origins}")
    List<String> allowedOrigins;

    @Bean
    @Profile("mar-srec")
    public MapReactiveUserDetailsService reactiveUserDetailsService(
            @Value("${mar.srec.basic.user}") String username,
            @Value("${mar.srec.basic.password}") String password
    ) {
        UserDetails user = User
                .withUsername(username)
                .password("{noop}" + password)
                .roles("SREC")
                .build();

        return new MapReactiveUserDetailsService(user);
    }

    @Bean
    public SecurityWebFilterChain securityWebFilterChainByPass(ServerHttpSecurity http, JwtAuthorizationWebFilter jwtAuthorizationWebFilter) {
        log.info("Configuration de la sécurité du module : JWT + Basic Auth (Basic uniquement si profil mar-srec actif)");
        return http
                .httpBasic(Customizer.withDefaults())
                .csrf(Customizer.withDefaults())
                .authorizeExchange(exchange ->
                        exchange.pathMatchers(
                                        "/health/**",
                                        "/actuator/**",
                                        "/swagger-resources/**",
                                        "/configuration/**",
                                        "/swagger-ui.html",
                                        "/swagger-ui/**",
                                        "/csrf/token").permitAll()
                                .anyExchange().authenticated()
                )
                .cors(cors -> cors.configurationSource(request -> {
                    CorsConfiguration configuration = new CorsConfiguration();
                    configuration.setAllowedOrigins(allowedOrigins);
                    configuration.setAllowedMethods(List.of("*"));
                    configuration.setAllowedHeaders(List.of("*"));
                    configuration.setAllowCredentials(true);
                    return configuration;
                }))
                .addFilterAt(jwtAuthorizationWebFilter, SecurityWebFiltersOrder.AUTHENTICATION)
                .build();
    }

}
