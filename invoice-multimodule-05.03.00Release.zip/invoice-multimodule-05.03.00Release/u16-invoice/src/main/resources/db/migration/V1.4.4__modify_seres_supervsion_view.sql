CREATE OR REPLACE VIEW `seres_replay_supervision` AS
SELECT
    `sr`.`id` AS `id`,
    `sr`.`invoice_number` AS `invoice_number`,
    `sr`.`error_date` AS `error_date`,
    `sr`.`error_code` AS `error_code`,
    `sr`.`error_message` AS `error_message`,
    `sr`.`invoice_url` AS `invoice_url`,
    CASE
        WHEN (JSON_EXTRACT(`inv_mes`.`message`, "$.invoiceHeader.printFlag")=true) THEN "Oui" COLLATE utf8mb4_general_ci
        WHEN (JSON_EXTRACT(`inv_mes`.`message`, "$.invoiceHeader.printFlag")=false) THEN "Non" COLLATE utf8mb4_general_ci
        ELSE "N/A" COLLATE utf8mb4_general_ci
        END AS `print_flag`

FROM
    `seres_replay` `sr` LEFT JOIN `invoice` `inv` ON `sr`.`invoice_number` = `inv`.`invoice_number`
                        LEFT JOIN `invoice_message` `inv_mes` ON `inv`.`id_invoice` = `inv_mes`.`id_invoice`
