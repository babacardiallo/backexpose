package fr.laposte.blg.blinks.u18.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "customer_account_message", indexes = {
        @Index(name = "idx_contract_number", columnList = "contractNumber"),
        @Index(name = "idx_status", columnList = "status"),
        @Index(name = "idx_created", columnList = "created")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerAccountMessage {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name="contract_number", nullable = false)
    private String contractNumber;

    @Column(name="offer_code", nullable = false)
    private String offerCode;

    @Column(name = "message_key")
    private String messageKey;

    @Lob
    @Column(name = "message_value", columnDefinition = "JSON")
    private String messageValue;

    @Column(name = "topic_name")
    private String topicName;

    @Column(name = "topic_offset")
    private long topicOffset;

    @Column(name = "topic_partition")
    private int topicPartition;

    @Column(name = "comment")
    private String comment;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MessageStatus status;

    @Column(name = "created", nullable = false, updatable = false)
    private Instant created;

    @Column(name = "updated", nullable = false)
    private Instant updated;

    @PrePersist
    public void prePersist() {
        Instant now = Instant.now();
        if (status == null) {
            status = MessageStatus.PENDING;
        }
        if (created == null) {
            created = now;
        }
        updated = now;
    }

    @PreUpdate
    public void preUpdate() {
        updated = Instant.now();
    }
}
