package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import fr.laposte.blg.blinks.lib.common.service.AbstractSchedulerService;
import fr.laposte.blg.blinks.u17.scheduler.ExportScheduler;
import fr.laposte.blg.blinks.u17.scheduler.NotificationScheduler;
import fr.laposte.blg.blinks.u17.scheduler.PurgeScheduler;
import fr.laposte.blg.blinks.u17.scheduler.TransferScheduler;
import fr.laposte.blg.blinks.u17.util.SchedulerUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
@Slf4j
public class SchedulerService extends AbstractSchedulerService {
    private final ExportHistoryRepository exportHistoryRepository;
    private final DocaposteService docaposteService;
    private final CoeurfinanceService coeurfinanceService;
    private final InfocaInvoiceExportService infocaInvoiceExportService;
    private final ExportProcessRepository exportProcessRepository;
    private final InvoiceRepository invoiceRepository;
    private final SchedulerUtils schedulerUtils;
    private final NotificationService notificationService;

    private final String coeurfinanceEncryptionKeyPath;

    public SchedulerService(TaskScheduler scheduler,
                            SchedulerParamsRepository schedulerParamsRepository,
                            ExportHistoryRepository exportHistoryRepository,
                            DocaposteService docaposteService,
                            CoeurfinanceService coeurfinanceService,
                            InfocaInvoiceExportService infocaInvoiceExportService,
                            ExportProcessRepository exportProcessRepository,
                            InvoiceRepository invoiceRepository,
                            SchedulerUtils schedulerUtils,
                            NotificationService notificationService,
                            @Value("${fr.laposte.coeurfinance.encryption.keypath}") String coeurfinanceEncryptionKeyPath) {
        super(scheduler, schedulerParamsRepository, "u17");
        this.exportHistoryRepository = exportHistoryRepository;
        this.docaposteService = docaposteService;
        this.coeurfinanceService = coeurfinanceService;
        this.infocaInvoiceExportService = infocaInvoiceExportService;
        this.exportProcessRepository = exportProcessRepository;
        this.invoiceRepository = invoiceRepository;
        this.schedulerUtils = schedulerUtils;
        this.notificationService = notificationService;
        this.coeurfinanceEncryptionKeyPath = coeurfinanceEncryptionKeyPath;
        initializeSchedulers();
    }

    @Override
    protected Runnable createTask(SchedulerParamsEntity schedulerParamsEntity) {
        String name = schedulerParamsEntity.getSchedulerName().toLowerCase();
        return switch (name) {
            case "scheduler_transfer" -> new TransferScheduler(schedulerParamsEntity, exportHistoryRepository, coeurfinanceEncryptionKeyPath);
            case "scheduler_export" ->
                    new ExportScheduler(docaposteService, coeurfinanceService, infocaInvoiceExportService, exportProcessRepository, invoiceRepository, schedulerParamsEntity, schedulerUtils, scheduler);
            case "scheduler_purge" -> new PurgeScheduler(schedulerParamsEntity, invoiceRepository, exportHistoryRepository);
            case "scheduler_notification" -> new NotificationScheduler(exportHistoryRepository, schedulerParamsEntity, notificationService);
            default ->
                    throw new IllegalArgumentException("Unknown scheduler type: " + schedulerParamsEntity.getSchedulerName());
        };
    }

    public Mono<Integer> organizeExistingArchives(Long id) {
        return schedulerParamsRepository.findById(id)
                .filter(params -> "scheduler_transfer".equalsIgnoreCase(params.getSchedulerName()))
                .flatMap(this::organizeArchiveFiles)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("Scheduler not found or not a transfer scheduler")));
    }

    private Mono<Integer> organizeArchiveFiles(SchedulerParamsEntity schedulerParams) {
        return Mono.fromCallable(() -> {
            Path archivePath = Paths.get(schedulerParams.getArchivePath());
            if (!Files.exists(archivePath)) {
                log.warn("Archive path does not exist: {}", archivePath);
                return 0;
            }

            int organizedCount = 0;
            try (var files = Files.list(archivePath)) {
                var fileList = files.filter(Files::isRegularFile).toList();

                for (Path file : fileList) {
                    if (organizeFileByName(file, archivePath)) {
                        organizedCount++;
                    }
                }
            } catch (IOException e) {
                throw new ArchiveOrganizationException("Error organizing archive files", e);
            }

            log.info("Organized {} files in archive", organizedCount);
            return organizedCount;
        });
    }

    private boolean organizeFileByName(Path file, Path baseArchivePath) {
        try {
            String fileName = file.getFileName().toString().toLowerCase();
            FileType fileType = determineFileTypeFromName(fileName);

            if (fileType == null) {
                log.warn("Cannot determine file type for file: {}", fileName);
                return false;
            }

            String dateFromFileName = extractDateFromFileName(fileName);
            if (dateFromFileName == null) {
                log.warn("Cannot extract date from filename: {}", fileName);
                return false;
            }

            String year = dateFromFileName.substring(0, 4);
            String month = dateFromFileName.substring(4, 6);

            Path organizedPath = baseArchivePath
                    .resolve(fileType.name())
                    .resolve(year)
                    .resolve(month);

            if (!Files.exists(organizedPath)) {
                Files.createDirectories(organizedPath);
                log.info("Created directory: {}", organizedPath);
            }

            Path targetFile = organizedPath.resolve(file.getFileName());
            if (!Files.exists(targetFile)) {
                Files.move(file, targetFile);
                log.info("Moved file {} to organized archive: {}", file, targetFile);
                return true;
            } else {
                log.warn("Target file already exists, skipping: {}", targetFile);
                return false;
            }
        } catch (IOException e) {
            log.error("Error organizing file: {}", file, e);
            return false;
        }
    }

    private FileType determineFileTypeFromName(String fileName) {
        if (fileName.contains("blg3aaaa") || fileName.endsWith(".ws")) {
            return FileType.DOCAPOSTE;
        } else if (fileName.contains("blg1aaaa") || fileName.endsWith(".ep") || fileName.endsWith(".a3p")) {
            return FileType.COEURFINANCE;
        } else if (fileName.contains("blg2aaaa") || fileName.endsWith(".is") || fileName.endsWith(".etz")) {
            return FileType.INFOCA;
        }
        return null;
    }

    private String extractDateFromFileName(String fileName) {
        var pattern = java.util.regex.Pattern.compile("(\\d{8})");
        var matcher = pattern.matcher(fileName);

        if (matcher.find()) {
            return matcher.group(1);
        }

        log.debug("Could not extract date from filename: {}", fileName);
        return null;
    }

    public static class ArchiveOrganizationException extends RuntimeException {
        public ArchiveOrganizationException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
