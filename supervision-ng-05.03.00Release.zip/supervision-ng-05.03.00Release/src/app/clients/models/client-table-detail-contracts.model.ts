export class ClientDetailContracts {
  contractNumber?: string;
  amendmentNumber?: string;
  revisionNumber?: string;
  subType?: string;
  isSynchronized?: boolean;
  synchronisationDate?: string | Date;
  fistDateError?: string | Date;
  opsCode?: string;

}
