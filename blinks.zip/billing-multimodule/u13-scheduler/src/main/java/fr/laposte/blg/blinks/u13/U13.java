package fr.laposte.blg.blinks.u13;

import fr.laposte.blg.blinks.lib.common.config.EnableBillingLibrary;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe Application du module u11.
 */
 @SpringBootApplication(scanBasePackages = "fr.laposte.blg.blinks")
@EnableBillingLibrary
public class U13 {

    public static void main(String[] args) {
        SpringApplication.run(U13.class, args);
    }

}
