package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_position_hierarchy")
@Data
@Accessors(chain = true)

public class BusinessPositionHierarchy implements Disposable, Persistable<Long> {
    @Id
    @Column("business_position_id")
    private Long businessPositionId;
    @Column("business_position_type_id")
    private Integer businessPositionTypeId;
    @Column("business_position_start_date")
    private Instant businessPositionStartDate;
    @Column("business_position_end_date")
    private Instant businessPositionEndDate;
    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessPositionStartDate) &&
                        businessPositionStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessPositionEndDate)
                                || businessPositionEndDate.isAfter(Instant.now())
                );
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessPositionId;
    }

    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
