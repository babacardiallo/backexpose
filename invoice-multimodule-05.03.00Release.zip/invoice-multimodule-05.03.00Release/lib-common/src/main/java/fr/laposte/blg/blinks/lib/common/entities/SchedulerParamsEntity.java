package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("scheduler_params")
@Data
public class SchedulerParamsEntity {

    @Id
    @Column("id")
    private Long id;

    @Column("scheduler_name")
    private String schedulerName;

    @Column("cron_expression")
    private String cronExpression;

    @Column("export_path")
    private String exportPath;

    @Column("cft_path")
    private String cftPath;

    @Column("archive_path")
    private String archivePath;

    @Column("is_enabled")
    private Boolean isEnabled;

    @Column("waiting_delay")
    private int waitingDelay;

    @Column("custom_params")
    private String customParams;

    @Column("retention_days")
    private int retentionDays;

    @Column("module")
    private String module;

}
