package fr.laposte.blg.blinks.u18.service;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import fr.laposte.blg.blinks.lib.common.service.AbstractSchedulerService;
import fr.laposte.blg.blinks.u18.scheduler.DataPurgeScheduler;
import fr.laposte.blg.blinks.u18.scheduler.ExportScheduler;
import fr.laposte.blg.blinks.u18.scheduler.FilePurgeScheduler;
import fr.laposte.blg.blinks.u18.scheduler.TransferScheduler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SchedulerService extends AbstractSchedulerService {
    private final MessagePurgeService messagePurgeService;
    private final FilePurgeService filePurgeService;
    private final FileWriterService fileWriterService;
    private final TransferService transferService;

    public SchedulerService(@Qualifier("taskScheduler") TaskScheduler scheduler,
                            SchedulerParamsRepository schedulerParamsRepository,
                            MessagePurgeService messagePurgeService,
                            FilePurgeService filePurgeService,
                            FileWriterService fileWriterService,
                            TransferService transferService) {
        super(scheduler, schedulerParamsRepository, "u18");
        this.messagePurgeService = messagePurgeService;
        this.filePurgeService = filePurgeService;
        this.fileWriterService = fileWriterService;
        this.transferService = transferService;
        initializeSchedulers();
    }

    @Override
    protected Runnable createTask(SchedulerParamsEntity schedulerParamsEntity) {
        String name = schedulerParamsEntity.getSchedulerName().toLowerCase();
        return switch (name) {
            case "scheduler_data_purge" -> new DataPurgeScheduler(messagePurgeService, schedulerParamsEntity);
            case "scheduler_export" -> new ExportScheduler(fileWriterService, schedulerParamsEntity);
            case "scheduler_file_purge" -> new FilePurgeScheduler(filePurgeService, schedulerParamsEntity);
            case "scheduler_transfer" -> new TransferScheduler(transferService, schedulerParamsEntity);
            default ->
                    throw new IllegalArgumentException("Unknown scheduler type: " + schedulerParamsEntity.getSchedulerName());
        };
    }
}
