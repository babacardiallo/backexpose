CREATE TABLE blg_contract_importer.file_sequence_election
(
    id int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    file_sequence int UNSIGNED NOT NULL
);

CREATE TABLE blg_contract_importer.contract_sequence_election
(
   sequence_name enum ('ELECTION') PRIMARY KEY,
   current_sequence bigint,
   last_updated     datetime NOT NULL DEFAULT NOW() ON UPDATE NOW()
);

CREATE TABLE blg_contract_importer.link_coclico_market_contract
(
    id int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    cust_acc_number int UNSIGNED NOT NULL,
    market_number varchar(255) NOT NULL,
    contract_number varchar(255) NOT NULL
);

INSERT INTO blg_contract_importer.contract_sequence_election(sequence_name, current_sequence)
VALUES ('ELECTION', 0);