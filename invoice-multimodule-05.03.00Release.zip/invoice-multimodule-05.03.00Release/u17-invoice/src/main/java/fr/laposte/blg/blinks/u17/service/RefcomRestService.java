package fr.laposte.blg.blinks.u17.service;

import com.opencsv.CSVWriter;
import com.opencsv.ICSVWriter;
import fr.laposte.blg.blinks.lib.common.repositories.organization.OrganizationRepository;
import fr.laposte.blg.blinks.lib.common.utils.TrackExecutionTime;
import fr.laposte.blg.blinks.u17.dto.MoulinetteRefcomDto;
import fr.laposte.blg.blinks.u17.mapper.RefcomMapper;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.FileWriter;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class RefcomRestService {

    private final OrganizationRepository organizationRepository;
    private final RefcomCommunicationService refcomCommunicationService;
    private final RefcomMapper refcomMapper;

    @Value("${fr.laposte.refcom.file.name}")
    private String name;

    @Value("${fr.laposte.refcom.file.location}")
    private String location;

    @TrackExecutionTime
    public void process(LocalDate consultationDate, List<Long> coclicos) {
        Instant startTime = Instant.now();
        log.info("Début de l'export Refcom a" + startTime);

        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(location + name)
                , ';'
                , ICSVWriter.NO_QUOTE_CHARACTER
                , ICSVWriter.NO_ESCAPE_CHARACTER
                , ICSVWriter.DEFAULT_LINE_END
        )) {
            csvWriter.writeNext(new String[]{"Coclico", "Entity", "Regate"}, false);

            Flux<MoulinetteRefcomDto> moulinetteFlux = getEntityCodes(consultationDate, coclicos);

            Flux.fromIterable(Objects.requireNonNull(moulinetteFlux.collectList().block()))
                    .doOnNext(moulinetteRefcomDto ->
                        csvWriter.writeNext(new String[]{
                                moulinetteRefcomDto.getCoclico(),
                                moulinetteRefcomDto.getEntityCode(),
                                moulinetteRefcomDto.getRegateCode()
                        }, false)
                    )
                    .blockLast();

            Instant endTime = Instant.now();
            Long durationInMs = Duration.between(startTime, endTime).toMillis();
            log.info("Fin de l'export Refcom après" + durationInMs);

        } catch (Exception e) {
            log.error("Couldn't export Refcom file : {}", e.getMessage(), e);
        }
    }

    public Flux<MoulinetteRefcomDto> getEntityCodes(LocalDate consultationDate, List<Long> coclicos) {
        return refcomCommunicationService.fetchEntityCodes(consultationDate, coclicos)
                .flatMap(refcomDto -> {
                    MoulinetteRefcomDto moulinetteRefcomDto = refcomMapper.RefcomDtoToMoulinetteRefcomDto(refcomDto);
                    return organizationRepository.findByCode(moulinetteRefcomDto.getEntityCode())
                            .map(organization -> {
                                moulinetteRefcomDto.setRegateCode(organization.getCodeRegate());
                                return moulinetteRefcomDto;
                            })
                            .switchIfEmpty(Mono.just(moulinetteRefcomDto));
                });
    }
}
