package fr.laposte.blg.blinks.u12.config.kafka.synchronization;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.*;

@Configuration
@Profile("!sloc")
@Slf4j
public class KafkaListenerConfig {
    private final KafkaProperties kafkaProperties;
    @Value("${fr.laposte.keystore-location}")
    private String keystoreLocation;
    @Value("${fr.laposte.keystore-password}")
    private String keyStorePassword;

    public KafkaListenerConfig(KafkaProperties kafkaProperties) {
        this.kafkaProperties = kafkaProperties;
    }

    private void configureSsl(Map<String, Object> props) {
        log.debug("CREATE SSL CONFIG FOR CONNECTION FROM KAFKA BROKER");
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "JKS");
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLocation);
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keyStorePassword);
        props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "JKS");
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, keystoreLocation);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, keyStorePassword);
        props.put("schema.registry.ssl.keystore.type", "JKS");
        props.put("schema.registry.ssl.keystore.location", keystoreLocation);
        props.put("schema.registry.ssl.keystore.password", keyStorePassword);
        props.put("schema.registry.ssl.truststore.type", "JKS");
        props.put("schema.registry.ssl.truststore.location", keystoreLocation);
        props.put("schema.registry.ssl.truststore.password", keyStorePassword);
    }

    @Bean
    public DefaultKafkaConsumerFactory<?, ?> consumerFactory() {
        Map<String, Object> props = kafkaProperties.buildConsumerProperties(null);
        configureSsl(props);
        return new DefaultKafkaConsumerFactory<>(props);

    }


}
