import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ContratsTable } from "../../contrats/models/contrats-table.model";
import { ReplayReport } from "../models/replay-report.model";

@Injectable({
  providedIn: 'root',
})
export class ReplayerService {
  ngUnsubscribe$ = new Subject<void>();

  constructor(private http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }

  httpOptionsTextResponse = {
    headers: new HttpHeaders({
      'Accept': 'text/plain, */*',
      'Content-Type': 'application/json'
    }),
    responseType: 'text' as 'json'
  }


  getContracts(page: number, size: number, sort: string, order: string): Observable<ContratsTable[]> {
    let queryParams = new HttpParams()
      .set("page", page)
      .set("size", size)
      .set("sort", sort)
      .set("order", order);
    return this.http.get<ContratsTable[]>(environment.API_CONTRACT_SUPERVISION_ACTIVE + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  launchReplay(action: string, contracts: string[], date?: string): Observable<ReplayReport> {
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    let queryParams = new HttpParams()
      .set("action", action);
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    return this.http.post<ReplayReport>(environment.API_CONTRACT_REPLAY_ALL_CONTRACTS,
      contracts,
      { headers: head, params: queryParams }
    )
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  replaySynchedContracts(method: string, date?: string): Observable<ReplayReport> {
    let queryParams = new HttpParams()
      .set("action", method);
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    return this.http.post<ReplayReport>(environment.API_REPLAY_SYNCHRONIZED_CONTRACTS + queryParams, null)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  replayContractPerOffers(action: string, offers: string[], date?: string): Observable<ReplayReport> {
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    let queryParams = new HttpParams()
      .set("action", action);
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    return this.http.post<ReplayReport>(environment.API_REPLAY_CONTRACTS_OFFERS,
      offers,
      { headers: head, params: queryParams }
    )
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  replayClientsMass(action: string, coclicos: number[], refcomReplay: string, date?: string): Observable<ReplayReport> {
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    let queryParams = new HttpParams()
      .set("action", action);
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    queryParams = queryParams.set("refcom-replay", refcomReplay);
    return this.http.post<ReplayReport>(environment.API_CLIENT_REPLAY_UNIT,
      coclicos,
      { headers: head, params: queryParams }
    )
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  replayClientsAll(action: string, refcomReplay: string, date?: string): Observable<any> {
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    let queryParams = new HttpParams()
      .set("action", action)
      .set("refcom-replay", refcomReplay);
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    return this.http.post<any>(environment.API_CUSTOMER_REPLAY_ALL, null,
      { headers: head, params: queryParams },
    )
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  replayAllContracts(method: string, date?: string): Observable<ReplayReport> {
    let queryParams = new HttpParams()
      .set("action", method);
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    return this.http.post<ReplayReport>(environment.API_REPLAY_ALL_CONTRACTS + queryParams, null)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getFilteredContracts(actives: boolean, page: number, size: number, sort: string, order: string, filter: string): Observable<ContratsTable[]> {
    let queryParams = new HttpParams()
      .set("actives", actives)
      .set("page", page)
      .set("size", size)
      .set("sort", sort)
      .set("order", order)
      .set("filter", filter);
    return this.http.get<ContratsTable[]>(environment.API_CONTRACT_FILTER + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

}
