package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerPartialSupervisionDto {
    private int idLegalPerson;
    private int custAccNumber;
    private String type;
    private String marketType;
    private String name;
    private String brand;
    private boolean isSynchro;
    private Instant dateLastSynchro;
    private Instant dateError;
    private Long nbAddresses;
}
