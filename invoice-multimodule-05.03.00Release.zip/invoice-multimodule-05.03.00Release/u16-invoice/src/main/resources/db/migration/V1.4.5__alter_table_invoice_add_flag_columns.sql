ALTER TABLE invoice
    ADD COLUMN credit_flag boolean NOT NULL DEFAULT false,
    ADD COLUMN downpayment_flag boolean NOT NULL DEFAULT false,
    ADD COLUMN statement_flag boolean NOT NULL DEFAULT false,
    ADD COLUMN avispaiement_flag boolean NOT NULL DEFAULT false;

create index idx_credit_flag on invoice (credit_flag);
create index idx_downpayment_flag on invoice (downpayment_flag);
create index idx_statement_flag on invoice (statement_flag);
create index idx_avispaiement_flag on invoice (avispaiement_flag);