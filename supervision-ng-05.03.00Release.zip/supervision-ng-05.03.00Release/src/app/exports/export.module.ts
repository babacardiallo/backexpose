import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CdkStepperModule } from "@angular/cdk/stepper";
import { MatGridListModule } from '@angular/material/grid-list';
import { ChoixExportComponent } from './components/choix-export/choix-export.component';
import { LancementExportComponent } from './lancement-export.component';
import { LancementRoutingExportModule } from './lancement-export-routing.module';
import { InvoiceRejeuComponent } from './components/invoice-rejeu/invoice-rejeu.component';
import { InvoiceFilter } from './pipes/invoice-filter.pipe';
import { PrintFlagFilter } from './pipes/printfalg-filter.pipe';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { InvoiceToExportComponent } from './components/invoice-export/invoice-export.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { SendFileComponent } from './components/send-file/send-file.component';
import { ModalService } from 'ngx-modal-ease';

@NgModule({
    imports: [
        SharedModule,
        NgxDatatableModule,
        MatStepperModule,
        CdkStepperModule,
        MatSnackBarModule,
        MatGridListModule,
        LancementRoutingExportModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        NgxPermissionsModule.forChild()
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [LancementExportComponent, ChoixExportComponent, InvoiceRejeuComponent, InvoiceFilter, PrintFlagFilter, InvoiceToExportComponent, SendFileComponent],
    exports: [LancementExportComponent]
})
export class ExportModule { }
