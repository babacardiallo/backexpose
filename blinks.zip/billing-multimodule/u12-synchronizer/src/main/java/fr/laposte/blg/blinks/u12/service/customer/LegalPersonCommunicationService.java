package fr.laposte.blg.blinks.u12.service.customer;

import fr.laposte.blg.blinks.u12.dto.LegalPersonDTO;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public interface LegalPersonCommunicationService {

    Mono<LegalPersonDTO> fetchLegalPerson(int coclico);
}
