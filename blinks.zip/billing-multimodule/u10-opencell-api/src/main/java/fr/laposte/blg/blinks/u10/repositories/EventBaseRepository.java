package fr.laposte.blg.blinks.u10.repositories;

import fr.laposte.blg.blinks.u10.entities.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Repository
public interface EventBaseRepository extends JpaRepository<Event, UUID> {

    @Query("SELECT DISTINCT evt.errorCode FROM Event evt ORDER BY evt.errorCode asc")
    List<String> getAllCodeErrors();

    @Modifying
    @Transactional
    @Query("""
            UPDATE Event evt SET evt.replayStatus='PENDING' WHERE
            (evt.errorDate BETWEEN :startDate AND :endDate)
             AND (evt.replayStatus = 'FAILED')
             AND (evt.errorCode <> 'U2007')""")
    int updateFilteredEvent (@Param("startDate") Instant startDate, @Param("endDate") Instant endDate);

    @Query("""
            SELECT evt FROM Event evt WHERE
             (evt.errorDate BETWEEN :startDate AND :endDate)
             AND (evt.replayStatus IN ('PENDING','FAILED'))
             AND (evt.errorCode <> 'U2007')
             ORDER BY evt.errorDate desc""")
    List<Event> exportEvents (@Param("startDate") Instant startDate, @Param("endDate")Instant endDate);
}
