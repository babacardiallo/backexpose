package fr.laposte.blg.blinks.lib.common.entities;

import fr.laposte.blg.blinks.lib.common.exceptions.CodeError;
import fr.laposte.blg.blinks.lib.common.exceptions.WorkFlowStep;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("rejected_invoice")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RejectedInvoice {
    @Id
    @Column("id_rejected_invoice")
    private Long idRejectedInvoice;

    @Column("invoice_number")
    private String invoiceNumber;

    @Column("invoice_json")
    private String invoiceJson;

    @Column("error_code")
    private CodeError errorCode;

    @Column("error_message")
    private String errorMessage;

    @Column("status")
    private RejectedInvoiceStatus status;

    @Column("error_date")
    private Instant errorDate;

    @Column("replayed_date")
    private Instant replayedDate;

    @Column("work_flow_step")
    private WorkFlowStep workFlowStep;
}
