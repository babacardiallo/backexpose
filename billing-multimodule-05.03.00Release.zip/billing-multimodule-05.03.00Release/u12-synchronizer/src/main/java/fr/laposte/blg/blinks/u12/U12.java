package fr.laposte.blg.blinks.u12;

import fr.laposte.blg.blinks.lib.common.config.EnableBillingLibrary;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe Application du module u12.
 */
@SpringBootApplication(scanBasePackages = "fr.laposte.blg.blinks")
@EnableBillingLibrary
public class U12 {

    public static void main(String[] args) {
        SpringApplication.run(U12.class, args);
    }

}
