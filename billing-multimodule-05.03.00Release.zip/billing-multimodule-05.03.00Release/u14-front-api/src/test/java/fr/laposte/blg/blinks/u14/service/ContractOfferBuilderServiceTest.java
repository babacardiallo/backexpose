package fr.laposte.blg.blinks.u14.service;

import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.OfferCriteria;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ProductCriteria;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ServiceCriteria;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = ContractOfferBuilderService.class)
class ContractOfferBuilderServiceTest {

    @Autowired
    private ContractOfferBuilderService contractOfferBuilderService;

    @Test
    void buildContractTest() {
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("test-contract.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        try {
            var contract = jsonAvroConverter.convertToSpecificRecord(inputStream.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());

            var updatedContract = this.contractOfferBuilderService.buildContract(contract);
            var offer = updatedContract.getContract().getOffer();
            assertAll(() -> {
                offer.getOfferCriteria().forEach(offerCriteria -> {
                    if (offerCriteria.getOfferCriterionKey().toString().equals("contactGroup")) {
                        assertInstanceOf(List.class, offerCriteria.getOfferCriterionCriteria());
                        offerCriteria.getOfferCriterionCriteria().forEach(o -> {
                            assertInstanceOf(List.class, o);
                            ((List) o).forEach(o1 -> {
                                assertInstanceOf(OfferCriteria.class, o1);
                            });
                        });
                    } else {
                        assertNull(offerCriteria.getOfferCriterionCriteria());
                    }
                });
                offer.getProducts().forEach(offerProduct -> {
                    offerProduct.getProductCriteria().forEach(productCriteria -> {
                        if (productCriteria.getProductCriterionKey().toString().equals("grp_adr")) {
                            assertInstanceOf(List.class, productCriteria.getProductCriterionCriteria());
                            productCriteria.getProductCriterionCriteria().forEach(o -> {
                                assertInstanceOf(List.class, o);
                                ((List) o).forEach(o1 -> {
                                    assertInstanceOf(ProductCriteria.class, o1);
                                });
                            });
                        } else {
                            assertNull(productCriteria.getProductCriterionCriteria());
                        }
                    });
                    offerProduct.getProductService().forEach(productService -> {
                        productService.getServiceCriteria().forEach(serviceCriteria -> {
                            if (serviceCriteria.getServiceCriterionKey().toString().equals("daysGroup")
                                || serviceCriteria.getServiceCriterionKey().toString().equals("LIE_PREST")
                                || serviceCriteria.getServiceCriterionKey().toString().equals("G_DATE_HEURE")) {
                                assertInstanceOf(List.class, serviceCriteria.getServiceCriterionCriteria());
                                serviceCriteria.getServiceCriterionCriteria().forEach(o -> {
                                    assertInstanceOf(List.class, o);
                                    ((List) o).forEach(o1 -> {
                                        assertInstanceOf(ServiceCriteria.class, o1);
                                    });
                                });
                            } else {
                                assertNull(serviceCriteria.getServiceCriterionCriteria());
                            }
                        });
                    });
                });
            });
        } catch (IOException e) {
            fail(e);
        }

    }

    @Test
    void buildOfferCriteriaTest() {
        List<Object> offerCriteriaList = new ArrayList<>();
        List<Map> subList = new ArrayList<>();

        Map<String, Object> criteriaMap = new HashMap<>();
        criteriaMap.put("offerCriterionKey", "ITL_OPE");
        criteriaMap.put("offerCriterionValueId", "5193873");
        criteriaMap.put("offerCriterionOccur", 0);
        criteriaMap.put("offerCriterionCriteria", null);

        subList.add(criteriaMap);
        offerCriteriaList.add(subList);

        List<Object> result = this.contractOfferBuilderService.buildOfferCriteria(offerCriteriaList);

        assertNotNull(result);
        assertNotNull(result.get(0));
        assertInstanceOf(List.class, result.get(0));
        List<OfferCriteria> list = (List) result.get(0);
        assertInstanceOf(OfferCriteria.class, list.get(0));

        OfferCriteria criteria = list.get(0);

        assertAll(() -> {
            assertEquals(criteriaMap.get("offerCriterionKey"), criteria.getOfferCriterionKey());
            assertEquals(criteriaMap.get("offerCriterionValueId"), criteria.getOfferCriterionValueId());
            assertEquals(criteriaMap.get("offerCriterionOccur"), criteria.getOfferCriterionOccur());
            assertEquals(criteriaMap.get("offerCriterionCriteria"), criteria.getOfferCriterionCriteria());
        });
    }

    @Test
    void buildServiceCriteriaTest() {
        List<Object> serviceCriteriaList = new ArrayList<>();
        List<Map> subList = new ArrayList<>();

        Map<String, Object> criteriaMap = new HashMap<>();
        criteriaMap.put("serviceCriterionKey", "ITL_OPE");
        criteriaMap.put("serviceCriterionValueId", "5193873");
        criteriaMap.put("serviceCriterionOccur", 0);
        criteriaMap.put("serviceCriterionCriteria", null);

        subList.add(criteriaMap);
        serviceCriteriaList.add(subList);

        List<Object> result = this.contractOfferBuilderService.buildServiceCriteria(serviceCriteriaList);

        assertNotNull(result);
        assertNotNull(result.get(0));
        assertInstanceOf(List.class, result.get(0));
        List<ServiceCriteria> list = (List) result.get(0);
        assertInstanceOf(ServiceCriteria.class, list.get(0));

        ServiceCriteria criteria = list.get(0);

        assertAll(() -> {
            assertEquals(criteriaMap.get("serviceCriterionKey"), criteria.getServiceCriterionKey());
            assertEquals(criteriaMap.get("serviceCriterionValueId"), criteria.getServiceCriterionValueId());
            assertEquals(criteriaMap.get("serviceCriterionOccur"), criteria.getServiceCriterionOccur());
            assertEquals(criteriaMap.get("servicetCriterionCriteria"), criteria.getServiceCriterionCriteria());
        });
    }

    @Test
    void buildProductCriteriaTest() {
        List<Object> productCriteriaList = new ArrayList<>();
        List<Map> subList = new ArrayList<>();

        Map<String, Object> criteriaMap = new HashMap<>();
        criteriaMap.put("productCriterionKey", "ITL_OPE");
        criteriaMap.put("productCriterionValueId", "5193873");
        criteriaMap.put("productCriterionOccur", 0);
        criteriaMap.put("productCriterionCriteria", null);

        subList.add(criteriaMap);
        productCriteriaList.add(subList);

        List<Object> result = this.contractOfferBuilderService.buildProductCriteria(productCriteriaList);

        assertNotNull(result);
        assertNotNull(result.get(0));
        assertInstanceOf(List.class, result.get(0));
        List<ProductCriteria> list = (List) result.get(0);
        assertInstanceOf(ProductCriteria.class, list.get(0));

        ProductCriteria criteria = list.get(0);

        assertAll(() -> {
            assertEquals(criteriaMap.get("productCriterionKey"), criteria.getProductCriterionKey());
            assertEquals(criteriaMap.get("productCriterionValueId"), criteria.getProductCriterionValueId());
            assertEquals(criteriaMap.get("productCriterionOccur"), criteria.getProductCriterionOccur());
            assertEquals(criteriaMap.get("productCriterionCriteria"), criteria.getProductCriterionCriteria());
        });
    }

}
