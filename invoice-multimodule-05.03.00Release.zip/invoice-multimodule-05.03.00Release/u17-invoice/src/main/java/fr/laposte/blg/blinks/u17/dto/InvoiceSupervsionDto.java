package fr.laposte.blg.blinks.u17.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class InvoiceSupervsionDto {
    private Long idInvoice;
    private String invoiceNumber;
    private Instant created;
    private Integer client;
    private String billrunId;
    private String docaposteExportStatus;
    private String infocaExportStatus;
    private String coeurfinanceExportStatus;
    private Instant docaposteExportDate;
    private Instant infocaExportDate;
    private Instant coeurfinanceExportDate;
    private Long docaposteExportId;
    private Long infocaExportId;
    private Long coeurfinanceExportId;
    private int present;
    private boolean fromTableOnly;

}
