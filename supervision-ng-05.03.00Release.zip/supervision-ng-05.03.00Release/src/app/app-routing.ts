import { ReplayerClientsComponent } from './replayer/components/replayer-contract/replayer-clients/replayer-clients.component';
import { ReplayerContractComponent } from './replayer/components/replayer-contract/replayer-contract.component';
import { AuthOidcAutoLoginComponent, AuthOidcUnauthorizedComponent } from '@cddng/auth-oidc-apim';
import { AuthGuard } from './auth/auth-guard.service';
import { LoadGuard } from './auth/load-guard.service';
import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: 'autologin',
        component: AuthOidcAutoLoginComponent,
        data: {
            message: 'Vous allez être redirigé vers la mire de connexion I2A!'
        }
    },
    {
        path: 'unauthorized',
        component: AuthOidcUnauthorizedComponent,
        data: {
            message: 'Attention! Vous n\'êtes pas autorisé à accéder à cette ressource!',
            aRoute: ['/autologin'],
            aLabel: 'Rafraîchir'
        }
    },

    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN', 'ADV'], } } },
    { path: 'offres', loadChildren: () => import('./offres/offres.module').then(m => m.OffresModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN'], } } },
    { path: 'replayQueue', loadChildren: () => import('./replay-queue/replay-queue.module').then(m => m.ReplayQueueModule), canLoad: [LoadGuard], data: { permissions: { only: ['ADMIN'], } } },
    { path: 'contrats', loadChildren: () => import('./contrats/contrats.module').then(m => m.ContratsModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN'], } } },
    { path: 'clients', loadChildren: () => import('./clients/clients.module').then(m => m.ClientsModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN'], } } },
    { path: 'replay', loadChildren: () => import('./replayer/replayer.module').then(m => m.ReplayerModule) },
    { path: 'replayClients', component: ReplayerClientsComponent, canActivate: [AuthGuard], data: { permissions: { only: ['ADMIN'], } } },
    { path: 'replayContracts', component: ReplayerContractComponent, canActivate: [AuthGuard], data: { permissions: { only: ['ADMIN'], } } },
    { path: 'export', loadChildren: () => import('./exports/export.module').then(m => m.ExportModule), canLoad: [LoadGuard], data: { permissions: { only: ['ADMIN'], } } },
    { path: 'audit', loadChildren: () => import('./audit/audit.module').then(m => m.AuditModule) },
    { path: 'supervision', loadChildren: () => import('./supervision/supervision.module').then(m => m.SupervisionModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN'], } } },
    { path: 'opencell', loadChildren: () => import('./edr/edr.module').then(m => m.EdrModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN'], } } },
    { path: 'opencell', loadChildren: () => import('./rejetcontracts/rejet-contract.module').then(m => m.RejetContractModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN'], } } },
    { path: 'seres', loadChildren: () => import('./seres/seres.module').then(m => m.SeresModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN', 'ADV'], } } },
    { path: 'factures', loadChildren: () => import('./invoice-supervision/invoice-supervision.module').then(m => m.InvoiceSupervisionModule), canLoad: [LoadGuard], data: { permissions: { only: ['CONS', 'ADMIN', 'ADV'], } } }

];
