package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.u17.dto.InvoiceRestDTO;
import fr.laposte.blg.blinks.u17.dto.PrepareExportDto;
import fr.laposte.blg.blinks.u17.service.InvoiceRestService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.*;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/invoice")
@OpenAPIDefinition(tags = {@Tag(name = "InvoiceController")})
public class InvoiceController {

    private final InvoiceRestService invoiceRestService;
    @GetMapping("/all")
    @Operation(
            summary = "Liste des factures",
            description = "Retourne toutes les factures des contracts provenant de openCell")
    Mono<Page<InvoiceRestDTO>> getAllInvoices(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "invoiceNumber") String sort,
            @RequestParam(defaultValue = "desc") String order,
            @RequestParam(defaultValue = "default") String filter,
            @RequestParam(defaultValue = "0") boolean doca,
            @RequestParam(defaultValue = "0") boolean seres
    ) {

        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idInvoice"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if(doca && seres){
            if(filter.equalsIgnoreCase("default")){
                return invoiceRestService.getAllInvoices(pageable);
            } else {
                return invoiceRestService.filterInvoices(pageable, filter);
            }
        } else {
            if(!doca && !seres){
                return Mono.just(new PageImpl<>(new ArrayList<>(), pageable, 0));
            } else {
                return invoiceRestService.getByPrintFlag(filter,sort, order, size,  page,  doca , seres);
            }
        }
    }

    @PostMapping("/prepare-export-docaposte")
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "preparer la Liste des factures à exporter pour Docaposte",
            description = "modifier la table invoice en mettant le champ docaposte_export_id à null pour les factures à exporter")
    Mono<Boolean> prepareExportDocaposte(@RequestBody Set<String> numInvoices) {
        return invoiceRestService.prepareExportDocaposte(numInvoices); }

    @PostMapping("/prepare-export-coeurfinance")
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "preparer la Liste des factures à exporter pour Docaposte",
            description = "modifier la table invoice en mettant le champ coeurfinance_export_id à null pour les factures à exporter")
    Mono<Boolean> prepareExportCoeurfinance(@RequestBody Set<String> numInvoices) {
        return invoiceRestService.prepareExportCoeurfinance(numInvoices); }

    @PostMapping("/prepare-export-infoca")
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "preparer la Liste des factures à exporter pour Docaposte",
            description = "modifier la table invoice en mettant le champ infoca_export_id à null pour les factures à exporter")
    Mono<Boolean> prepareExportInfoca(@RequestBody Set<String> numInvoices) {
        return invoiceRestService.prepareExportInfoca(numInvoices); }

    @PostMapping("/prepare-export")
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "preparer la Liste des factures à exporter",
            description = "modifier la table invoice en mettant les champ *_export_id à null pour les factures à exporter")
    Mono<Boolean> prepareExport(@RequestBody PrepareExportDto exportDto) {
        return invoiceRestService.prepareExport(exportDto); }

    @GetMapping("/exports")
    @Operation(
            summary = "Liste des factures à exporter",
            description = "Retourne toutes les factures des contracts à exporter")
    Mono<Page<InvoiceRestDTO>>getAllInvoicesToExport( @RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "5") int size,
                                                 @RequestParam(defaultValue = "invoiceNumber") String sort,
                                                 @RequestParam(defaultValue = "desc") String order) {

        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idInvoice"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return invoiceRestService.getRecentInvoicesToExport(pageable);
    }


    @PostMapping("/customer/nbInvoices")
    @Operation(
            summary = "Nombre de factures",
            description = "Retourne le nombre de facture pour un client donné")
    Mono<Map<Integer, Integer>> getCustomerNbInvoices(@RequestBody List<Integer> clientIds) {
        return invoiceRestService.getCustomerNbInvoices(clientIds);
    }


    @GetMapping("/message")
    @Operation(
            summary = "Liste des factures",
            description = "Retourne toutes les factures des contracts provenant de openCell")
    Mono<String> getMessage(
            @RequestParam() Long id
    ) {
        return invoiceRestService.getMessage(id);
    }

    @PostMapping("/replay-failed")
    @Operation(
            summary = "Rejeux factures failed",
            description = "Repasse les factures failed choisies au statut NEW et sans id_export")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> replayFailedInvoices(@RequestBody Optional<List<String>> invoices,
                                                       @RequestParam boolean docaposte,
                                                       @RequestParam boolean infoca,
                                                       @RequestParam boolean coeurfinance) {
        if (invoices.isPresent()) {
            Mono.fromRunnable(() -> invoiceRestService.processFailedInvoices(invoices.get(), docaposte, infoca, coeurfinance))
                    .subscribeOn(Schedulers.boundedElastic())
                    .subscribe();
        }
        else {
            List<String> emptyInvoices = new ArrayList<>();
            Mono.fromRunnable(() -> invoiceRestService.processFailedInvoices(emptyInvoices, docaposte, infoca, coeurfinance))
                    .subscribeOn(Schedulers.boundedElastic())
                    .subscribe();
        }
            return ResponseEntity.accepted().body("Failed invoices are being processed for replay");
    }

}
