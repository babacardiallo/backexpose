CREATE TABLE blg_invoice.export_history
(
    id              int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    file_type       enum ('DOCAPOST','INFOCA','EQUINOX'),
    file_name       varchar(40)  NOT NULL,
    file_date       datetime     NOT NULL,
    message_count   int,
    export_duration bigint,
    export_status   enum ('SUCCESS', 'FAILED'),
    comment         text
);

CREATE TABLE blg_invoice.invoice
(
    id                  int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    invoice_number      varchar(20)  NOT NULL,
    reference_number    varchar(40)  NOT NULL,
    billrun_id          varchar(40)  NOT NULL,
    billrun_date        datetime     NOT NULL,
    message             json,
    docaposte_export_id int UNSIGNED,
    infoca_export_id    int UNSIGNED,
    equinox_export_id   int UNSIGNED,
    created             datetime     NOT NULL,
    updated             datetime     NOT NULL,
    CONSTRAINT unq_reference_number UNIQUE (reference_number),
    CONSTRAINT fk_docaposte_export_id FOREIGN KEY (docaposte_export_id) REFERENCES blg_invoice.export_history (id) ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT fk_infoca_export_id FOREIGN KEY (infoca_export_id) REFERENCES blg_invoice.export_history (id) ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT fk_equinox_export_id FOREIGN KEY (equinox_export_id) REFERENCES blg_invoice.export_history (id) ON DELETE CASCADE ON UPDATE RESTRICT
);
CREATE TABLE blg_invoice.batch_config
(
    id         int unsigned NOT NULL AUTO_INCREMENT,
    code       enum ('DOCAPOST','INFOCA','EQUINOX'),
    exec_order int      DEFAULT NULL,
    is_enable  tinyint  DEFAULT NULL,
    updated    datetime DEFAULT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE blg_invoice.file_sequence
(
    sequence_name    enum ('DOCAPOST','INFOCA','EQUINOX') PRIMARY KEY,
    current_sequence bigint,
    last_updated     datetime NOT NULL DEFAULT NOW() ON UPDATE NOW()
);

INSERT INTO blg_invoice.file_sequence(sequence_name, current_sequence)
VALUES ('EQUINOX', 0);

INSERT INTO blg_invoice.batch_config(code, exec_order, is_enable) VALUES
('EQUINOX', 1, 0);
INSERT INTO blg_invoice.batch_config(code, exec_order, is_enable) VALUES
('INFOCA', 2, 0);
INSERT INTO blg_invoice.batch_config(code, exec_order, is_enable) VALUES
('DOCAPOST', 3, 0 );
