package fr.laposte.blg.blinks.u14.controller.dto;

import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import lombok.Data;

import java.time.Instant;

@Data
public class AddressDTO {
    private Long idAddress;
    private String addressIdRefPM;
    private Long idLegalPerson;
    private Integer custAccNumber;
    private Instant creationDatetime;
    private Instant modificationDatetime;
    private String name1;
    private String add2;
    private String add3;
    private String add4;
    private String add5;
    private String add6;
    private String add7;
    private String addressJson;
    private AddressType addressType;

    public AddressDTO(Long idAddress, String addressIdRefPM, Long idLegalPerson, Integer custAccNumber, Instant creationDatetime, Instant modificationDatetime, String name1, String add2, String add3, String add4, String add5, String add6, String add7, String addressJson, AddressType addressType) {
        this.idAddress = idAddress;
        this.addressIdRefPM = addressIdRefPM;
        this.idLegalPerson = idLegalPerson;
        this.custAccNumber = custAccNumber;
        this.creationDatetime = creationDatetime;
        this.modificationDatetime = modificationDatetime;
        this.name1 = name1;
        this.add2 = add2;
        this.add3 = add3;
        this.add4 = add4;
        this.add5 = add5;
        this.add6 = add6;
        this.add7 = add7;
        this.addressJson = addressJson;
        this.addressType = addressType;
    }
}


