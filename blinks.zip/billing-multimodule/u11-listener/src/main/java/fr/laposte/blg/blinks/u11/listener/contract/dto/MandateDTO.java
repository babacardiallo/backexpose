package fr.laposte.blg.blinks.u11.listener.contract.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Map;

@Data
public class MandateDTO {

    private Long idMandate;
    private String rum;
    private String iban;
    private String bic;
    private String status;
    private Map<String, String> debtorAccount;

    @JsonProperty("debtor")
    @SuppressWarnings("unchecked")
    private void unpackDebtorJson(Map<String, Object> debtor) {
        this.debtorAccount = (Map<String, String>)debtor.get("debtorAccount");
        this.iban = debtorAccount.get("iban");
        this.bic = debtorAccount.get("bic");
    }
}
