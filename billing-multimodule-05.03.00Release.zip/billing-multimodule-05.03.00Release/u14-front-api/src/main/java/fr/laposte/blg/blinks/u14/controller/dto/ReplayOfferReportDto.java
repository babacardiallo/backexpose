package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;


@Data
@NoArgsConstructor
public class ReplayOfferReportDto {

    private AtomicLong nbSuccess = new AtomicLong();
    private AtomicLong nbErrors = new AtomicLong();
    private long nbTotal;
    private HashMap<String, String> mapErrors = new HashMap<>();
    private List<String> listSuccess = new ArrayList<String>();

    private AtomicLong numberSuccessOffers = new AtomicLong();
    private AtomicLong numberKoOffers = new AtomicLong();

    private List<String> offersSynch = new ArrayList<>();
    private List<String> offersNotSynch = new ArrayList<>();

    private boolean isWaitingResponse = true;
    private String shortMessage;

}
