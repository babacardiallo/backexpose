package fr.laposte.blg.blinks.u12.service.contract;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.constant.KibanaCustomField;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.InvoiceInformationMessageRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.QueueSynchronizationRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ValuedOfferMessageRepository;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.u12.listener.exception.*;
import fr.laposte.blg.blinks.u12.dto.LogSynchro;
import fr.laposte.blg.blinks.u12.mapper.ContractOpencellMapper;
import fr.laposte.blg.blinks.u12.mapper.CustomerOpencellMapper;
import fr.laposte.blg.blinks.u12.service.ImportService;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.billing.*;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.Offer;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.OfferProduct;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ProductPrice;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ProductService;
import jakarta.validation.Validator;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.JsonDecoder;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.commons.lang3.EnumUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Instant;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class ContractSyncService {

    private static final String ADR_PREST_KEY = "ADR_PREST";
    private static final String ETB_PREST_KEY = "ETB_PREST";
    private final ImportService importService;
    private final ContractService contractService;
    private final ErrorLogService errorLogService;
    private final Validator validator;
    private final ContractOpencellMapper contractOpencellMapper;
    private final CustomerOpencellMapper customerOpencellMapper;
    private final ValuedOfferParser valuedOfferParser;
    private final QueueService queueService;
    private final LegalPersonService legalPersonService;
    private final QueueSynchronizationRepository queueSynchronizationRepository;
    private final ValuedOfferMessageRepository valuedOfferMessageRepository;
    private final InvoiceInformationMessageRepository invoiceInformationMessageRepository;
    private final ObjectMapper objectMapper1 = new ObjectMapper();
    /**
     * Synchronizing a contract using its contractId and sending it to the consolidated topic
     *
     * @param contractId The contractId in database
     * @param actionEnum create or update
     * @return The contract consolidated to send in the topic
     */
    public Flux<ContractConsolidated> synchronize(int contractId, ActionEnum actionEnum) {
        if (!EnumUtils.isValidEnum(ActionEnum.class, actionEnum.name())) {
            return Flux.error(new IllegalArgumentException("[CONTRACT ID: " + contractId + "] ActionEnum has to be create or update"));
        }
        return this.synchronizeCreateUpdate(contractId, actionEnum);
    }

    /**
     * Synchronization for creation and update
     * Return a full contract consolidated with all information for contract and customer
     *
     * @param contractId The contractId in database
     * @param actionEnum The enum for create or update
     * @return The contract consolidated to send in the topic
     */

    public Flux<ContractConsolidated> synchronizeCreateUpdate(int contractId, ActionEnum actionEnum) {
        Mono<ContractConsolidated> fallbackAfterError = Mono.defer(() ->
                queueSynchronizationRepository.existsQueueSynchronizationEntityByIdContract((long) contractId)
                        .flatMap(exists -> exists ?
                                Mono.empty() :
                                queueService.enQueueContract((long) contractId, Instant.now(), actionEnum)
                                        .then(Mono.empty())
                        )
        );

        return contractService
                .findContractVersionsToSynchronizeByContractId(contractId)
                .switchIfEmpty(Mono.error(new SynchronizationContractException(
                        "[CONTRACT ID: " + contractId + "] Unable to find the contract's versions"
                        , null
                        , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT
                        , (long) contractId
                        , null
                        , null
                        , null
                        , null
                        , null
                        , CodeErrorEnum.U12001
                )))
                .onErrorResume(throwable ->
                        Mono.error(new SynchronizationContractException(
                                "Error after fetching contract with versions"
                                , throwable
                                , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT
                                , (long) contractId
                                , null
                                , null
                                , null
                                , null
                                , null
                                , CodeErrorEnum.U12001
                        ))
                )
                .filter(contractVersionEntity -> !contractVersionEntity.isSynchronized())
                .switchIfEmpty(
                        Mono.defer(() -> {
                            log.info("[CONTRACT: " + contractId + "] All versions from contract: {} have already been synchronized", contractId);
                            return Mono.error(new NoSynchronizationRequiredException(
                                    "[CONTRACT: " + contractId + "] All versions from contract: {} have already been synchronized"
                                    , null
                                    , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT
                                    , (long) contractId
                            ));
                        })
                )
                .flatMap(contractVersionEntity -> {
                    LogSynchro logSynchro = new LogSynchro();
                    logSynchro.setContractNumber(contractVersionEntity.getContract().getContractNumber());
                    logSynchro.setAmendmentNumber(contractVersionEntity.getAmendmentNumber());
                    logSynchro.setRevisionNumber(contractVersionEntity.getRevisionNumber());
                    logSynchro.setCustAccNumber(contractVersionEntity.getContract().getCustAccNumber().toString());
                    logSynchro.setMessage("Debut de synchronisation");
                    ObjectMapper obj = new ObjectMapper();
                    obj.registerModule(new JavaTimeModule());
                    JsonNode nodeDebut = obj.convertValue(logSynchro, JsonNode.class);
                    log.info(Markers.append(KibanaCustomField.CLEFS_DEBUT_SYNCHRO_CONTRACT, nodeDebut), "[CONTRACT NUMBER: " + logSynchro.getContractNumber() + "] Debut Synchronization contract: {}, message: {}", logSynchro.getContractNumber(), logSynchro);
                    var valuedOffer = contractVersionEntity.getValuedOffer();
                    var contractEntity = contractVersionEntity.getContract();
                    return importService.createOrFetchCustomerChain(contractEntity)
                            .onErrorMap(throwable -> { //We wrap here all potential exceptions from customer logic
                                var exceptionWrapped = new SynchronizationLegalPersonException(throwable.getMessage());
                                exceptionWrapped.setIdLegalPerson(contractEntity.getIdLegalPerson());
                                exceptionWrapped.setCoclico(Optional.ofNullable(contractEntity.getCustAccNumber()).map(Integer::longValue).orElse(null));
                                exceptionWrapped.initCause(throwable);
                                exceptionWrapped.setCodeError(CodeErrorEnum.U12002);
                                if (throwable instanceof SynchronizationLegalPersonException synchronizationLegalPersonException) {
                                    exceptionWrapped
                                            .setWorkflowStepEnum((synchronizationLegalPersonException)
                                                    .getWorkflowStepEnum());
                                } else {
                                    exceptionWrapped
                                            .setWorkflowStepEnum(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER);
                                }
                                return exceptionWrapped;
                            })
                            //At this step, contractVersionEntity contains a contractEntity which is related to a LegalPersonEntity.
                            //so the accountHolderName can be fetched from the legalPersonEntity
                            .thenReturn(contractVersionEntity)
                            .flatMap(contractVersionEntity1 -> this.fillIdAddressInvoice(contractVersionEntity1, contractEntity.getLegalPersonEntity()))
                            .flatMap(contractVersionEntityLegalPersonEntityTuple ->
                                    Mono.zip(this.addMandate(contractVersionEntityLegalPersonEntityTuple.getT1()),
                                            Mono.just(contractVersionEntityLegalPersonEntityTuple.getT2()),
                                            valuedOfferMessageRepository.findByIdValuedOffer(contractVersionEntity.getIdValuedOffer()),
                                            invoiceInformationMessageRepository.findByIdInvoiceInformation(contractVersionEntity.getIdInvoiceInformation()))
                            )
                            .map(contractVersionLegalPersonTuple -> contractVersionLegalPersonTuple
                                    .mapT1(this.contractOpencellMapper::contractVersionEntityToContractOpencell)
                                    .mapT2(this.customerOpencellMapper::legalPersonEntityToCustomerOpencell))
                            .flatMap(tuple -> Mono.zip(Mono.just(buildValuedOfferAndOfferInformationAndInvoiceInformation(tuple.getT1(), tuple.getT3(), tuple.getT4())), Mono.just(tuple.getT2()), Mono.just(tuple.getT3())))
                            .flatMap(contractOpencellCustomerOpencellTuple -> this.addMissingData(valuedOffer, contractOpencellCustomerOpencellTuple.getT1(), contractId, contractOpencellCustomerOpencellTuple.getT3())
                                    .zipWith(Mono.just(contractOpencellCustomerOpencellTuple.getT2())))
                            .map(contractCustomerTuple -> this.buildContractConsolidated(contractCustomerTuple.getT1()
                                    , contractCustomerTuple.getT2()
                                    , OpencellActionEnum.UPDATE_CONTRACT))
                            .onErrorResume(SynchronizationLegalPersonException.class
                                    , e -> errorLogService.logErrorCustomer(e.getIdLegalPerson()
                                                    , e.getCoclico()
                                                    , e.getMessage()
                                                    , e.getWorkflowStepEnum()
                                                    , e.getCodeError())
                                            .flatMap(r -> errorLogService.findErrorEntityForThisContractVersion(contractEntity.getContractNumber(), contractVersionEntity.getAmendmentNumber()))
                                            .flatMap(errorLogEntity -> {
                                                errorLogEntity.setDateError(Instant.now());
                                                errorLogEntity.setWorkflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT);
                                                errorLogEntity.setErrorMessage(e.getMessage());
                                                errorLogEntity.setAmendmentNumber(contractVersionEntity.getAmendmentNumber());
                                                errorLogEntity.setRevisionNumber(contractVersionEntity.getRevisionNumber());
                                                errorLogEntity.setStatus(contractVersionEntity.getStatus());
                                                errorLogEntity.setSubstatus(contractVersionEntity.getSubstatus());
                                                errorLogEntity.setOpsCode(valuedOffer.getOpsCode());
                                                errorLogEntity.setCustAccNumber(e.getCoclico());
                                                errorLogEntity.setIdLegalPerson(e.getIdLegalPerson());
                                                errorLogEntity.setCodeError(e.getCodeError());
                                                return Mono.just(errorLogEntity);
                                            })
                                            .switchIfEmpty(Mono.defer(() -> {
                                                var errorLog = ErrorLogEntity.builder()
                                                        .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT)
                                                        .idContract((long) contractId)
                                                        .errorMessage(e.getMessage())
                                                        .amendmentNumber(contractVersionEntity.getAmendmentNumber())
                                                        .revisionNumber(contractVersionEntity.getRevisionNumber())
                                                        .contractNumber(contractEntity.getContractNumber())
                                                        .status(contractVersionEntity.getStatus())
                                                        .substatus(contractVersionEntity.getSubstatus())
                                                        .opsCode(valuedOffer.getOpsCode())
                                                        .custAccNumber(e.getCoclico())
                                                        .idLegalPerson(e.getIdLegalPerson())
                                                        .codeError(e.getCodeError())
                                                        .build();
                                                return Mono.just(errorLog);
                                            }))
                                            .flatMap(errorLog -> {
                                                ObjectMapper objectMapper = new ObjectMapper();
                                                objectMapper.registerModule(new JavaTimeModule());
                                                JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                                log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CONTRACT, node), "[CONTRACT NUMBER: " + contractEntity.getContractNumber() + "] Synchronization contract: {}, error: {}", contractEntity.getContractNumber(), errorLog);
                                                return errorLogService.logError(errorLog);
                                            }).then(fallbackAfterError))
                            .onErrorResume(SynchronizationContractException.class, e -> errorLogService.findErrorEntityForThisContractVersion(e.getContractNumber(), e.getAmendmentNumber())
                                    .flatMap(errorLogEntity -> {
                                        errorLogEntity.setDateError(Instant.now());
                                        errorLogEntity.setWorkflowStep(e.getWorkflowStepEnum());
                                        errorLogEntity.setErrorMessage(e.getMessage());
                                        errorLogEntity.setAmendmentNumber(e.getAmendmentNumber());
                                        errorLogEntity.setRevisionNumber(e.getRevisionNumber());
                                        errorLogEntity.setStatus(Optional.ofNullable(e.getContractVersionEntity()).map(ContractVersionEntity::getStatus).orElse(null));
                                        errorLogEntity.setSubstatus(Optional.ofNullable(e.getContractVersionEntity()).map(ContractVersionEntity::getSubstatus).orElse(null));
                                        errorLogEntity.setOpsCode(e.getOpsCode());
                                        errorLogEntity.setCustAccNumber(Long.valueOf(contractEntity.getCustAccNumber()));
                                        errorLogEntity.setCodeError(e.getCodeError());
                                        return Mono.just(errorLogEntity);
                                    })
                                    .switchIfEmpty(Mono.defer(() -> {
                                        var errorLog = ErrorLogEntity.builder()
                                                .workflowStep(e.getWorkflowStepEnum())
                                                .idContract(e.getIdContract())
                                                .errorMessage(e.getMessage())
                                                .amendmentNumber(e.getAmendmentNumber())
                                                .revisionNumber(e.getRevisionNumber())
                                                .contractNumber(e.getContractNumber())
                                                .status(Optional.ofNullable(e.getContractVersionEntity()).map(ContractVersionEntity::getStatus).orElse(null))
                                                .substatus(Optional.ofNullable(e.getContractVersionEntity()).map(ContractVersionEntity::getSubstatus).orElse(null))
                                                .opsCode(e.getOpsCode())
                                                .custAccNumber(Long.valueOf(contractEntity.getCustAccNumber()))
                                                .codeError(e.getCodeError())
                                                .build();
                                        return Mono.just(errorLog);
                                    }))
                                    .flatMap(errorLog -> {
                                        ObjectMapper objectMapper = new ObjectMapper();
                                        objectMapper.registerModule(new JavaTimeModule());
                                        JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                        log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CONTRACT, node), "[CONTRACT NUMBER: " + contractEntity.getContractNumber() + "] Synchronization contract: {} error: {}", contractEntity.getContractNumber(), errorLog);
                                        return errorLogService.logError(errorLog)
                                                .then(fallbackAfterError);
                                    })
                            )
                            .onErrorResume(throwable -> errorLogService.findErrorEntityForThisContractVersion(contractVersionEntity.getContract().getContractNumber(), contractVersionEntity.getAmendmentNumber())
                                    .flatMap(errorLogEntity -> {
                                        errorLogEntity.setDateError(Instant.now());
                                        errorLogEntity.setWorkflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT);
                                        errorLogEntity.setErrorMessage("[CONTRACT NUMBER: " + contractVersionEntity.getContract().getContractNumber() + "] Unhandled exception during version synchronization :" + throwable.getMessage());
                                        errorLogEntity.setRevisionNumber(contractVersionEntity.getRevisionNumber());
                                        errorLogEntity.setStatus(contractVersionEntity.getStatus());
                                        errorLogEntity.setSubstatus(contractVersionEntity.getSubstatus());
                                        errorLogEntity.setOpsCode(valuedOffer.getOpsCode());
                                        errorLogEntity.setCustAccNumber(Long.valueOf(contractEntity.getCustAccNumber()));
                                        errorLogEntity.setCodeError(CodeErrorEnum.U12001);
                                        return Mono.just(errorLogEntity);
                                    })
                                    .switchIfEmpty(Mono.defer(() -> {
                                        var errorLog = ErrorLogEntity.builder()
                                                .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT)
                                                .idContract((long) contractId)
                                                .errorMessage("[CONTRACT NUMBER: " + contractVersionEntity.getContract().getContractNumber() + "] Unhandled exception during version synchronization :" + throwable.getMessage())
                                                .contractNumber(contractVersionEntity.getContract().getContractNumber())
                                                .amendmentNumber(contractVersionEntity.getAmendmentNumber())
                                                .revisionNumber(contractVersionEntity.getRevisionNumber())
                                                .status(contractVersionEntity.getStatus())
                                                .substatus(contractVersionEntity.getSubstatus())
                                                .opsCode(valuedOffer.getOpsCode())
                                                .custAccNumber(Long.valueOf(contractEntity.getCustAccNumber()))
                                                .codeError(CodeErrorEnum.U12001)
                                                .build();
                                        return Mono.just(errorLog);
                                    }))
                                    .flatMap(errorLog -> {
                                        ObjectMapper objectMapper = new ObjectMapper();
                                        objectMapper.registerModule(new JavaTimeModule());
                                        JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                        log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CONTRACT, node), "[CONTRACT NUMBER:" + contractEntity.getContractNumber() + "] Synchronization contract: {}, error: {}", contractEntity.getContractNumber(), errorLog);
                                        return errorLogService.logError(errorLog)
                                                .then(fallbackAfterError);
                                    })
                            );
                        }
                );
    }

    /**
     * Add extra data which is not in contract and legal person entities
     *
     * @param contractOpencell The contract for opencell
     * @param contractId       the contract id from the database
     * @return The complete contract for opencell
     */
    public Mono<ContractOpencell> addMissingData(ValuedOfferEntity valuedOfferEntity, ContractOpencell contractOpencell, long contractId, ValuedOfferMessage valuedOfferMessage) {
        return this.addLinkedContracts(contractOpencell, contractId)
                .flatMap(contractOpencell1 -> this.addValuesFromOfferCriteria(valuedOfferEntity, contractOpencell1, valuedOfferMessage))
                .flatMap(this::addEstablishmentLabels)
                .onErrorMap(SynchronizationContractException.class::isInstance, e -> {
                    var exception = new SynchronizationContractException(e.getMessage(),
                            e
                            , ((SynchronizationContractException) e).getWorkflowStepEnum()
                            , contractId
                            , contractOpencell.getContractInformation().getContractNumber().toString()
                            , contractOpencell.getContractVersionInformation().getAmendmentNumber()
                            , contractOpencell.getContractVersionInformation().getVersionNumber()
                            , null
                            , contractOpencell.getOfferInformation().getOpsCode().toString()
                            , CodeErrorEnum.U12005
                    );
                    if (e instanceof SynchronizationMandateAPICallException synchronizationMandateAPICallException) {
                        exception.setRum((synchronizationMandateAPICallException).getRum());
                    }
                    if (e instanceof SynchronizationSourceOrgaAPICallException synchronizationSourceOrgaAPICallException) {
                        exception.setRegate((synchronizationSourceOrgaAPICallException).getRegate());
                    }
                    return exception;
                })
                .onErrorMap(e -> !(e instanceof SynchronizationContractException), e -> new SynchronizationContractException(
                                "[CONTRACT NUMBER:"+ contractOpencell.getContractInformation().getContractNumber().toString() + "] Unhandled error while we addMissingData :" + e.getMessage()
                                , e
                                , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT
                                , contractId
                                , contractOpencell.getContractInformation().getContractNumber().toString()
                                , contractOpencell.getContractVersionInformation().getAmendmentNumber()
                                , contractOpencell.getContractVersionInformation().getVersionNumber()
                                , null
                                , contractOpencell.getOfferInformation().getOpsCode().toString()
                                , null
                                , null
                        )
                )
                ;
    }

    /**
     * Fill the list of linkedContracts for the consolidated contract
     * Add extra data which is not in contract and legal person entities
     *
     * @param contractOpencell The contract for opencell
     * @param contractId       the contract id from the database
     * @return The same contract with the linked contracts
     */
    public Mono<ContractOpencell> addLinkedContracts(ContractOpencell contractOpencell, long contractId) {
        return this.contractService.findContractLinked(contractId)
                .map(contractLinkedEntity -> LinkedContract.newBuilder()
                        .setContractNumber(contractLinkedEntity.getLinkedContractNumber())
                        .setLinkType(contractLinkedEntity.getLinkType())
                        .build())
                .collectList()
                .map(linkedContracts -> {
                    contractOpencell.setLinkedContracts(linkedContracts);
                    return contractOpencell;
                })
                .defaultIfEmpty(contractOpencell);
    }

    /**
     * Find estasblishment labels to fill the contractEstablishment list
     *
     * @param contractOpencell The contract for opencell containing the establishments
     * @return the contract with establishment labels filled
     */
    public Mono<ContractOpencell> addEstablishmentLabels(ContractOpencell contractOpencell) {
        if (contractOpencell.getContractEstablishment() != null) {
            return Flux.fromIterable(contractOpencell.getContractEstablishment())
                    .flatMap(contractEstablishment -> this.importService.findOrFetchEstablishment(contractEstablishment.getPrestationEstablishmentCode().toString())
                            .map(establishmentEntity -> {
                                contractEstablishment.setPrestationEstablishmentLabel(establishmentEntity.getLabel());
                                return contractEstablishment;
                            })
                            .onErrorMap(SynchronizationSourceOrgaAPICallException.class, e ->
                                    new SynchronizationContractException(e.getMessage()
                                            , e
                                            , e.getWorkflowStepEnum()
                                            , null
                                            , contractOpencell.getContractInformation().getContractNumber().toString()
                                            , contractOpencell.getContractVersionInformation().getAmendmentNumber()
                                            , contractOpencell.getContractVersionInformation().getVersionNumber()
                                            , null
                                            , contractOpencell.getOfferInformation().getOpsCode().toString()
                                            , null
                                            , e.getRegate()
                                            , CodeErrorEnum.U12005))
                            .onErrorMap(throwable -> !(throwable instanceof SynchronizationSourceOrgaAPICallException), throwable ->
                                    new SynchronizationContractException(
                                            "[ESTABLISHMENT: " + contractEstablishment.getPrestationEstablishmentCode().toString() + "] Unhandled exception while we fetch establishments " + throwable.getMessage()
                                            , throwable
                                            , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT
                                            , null
                                            , contractOpencell.getContractInformation().getContractNumber().toString()
                                            , contractOpencell.getContractVersionInformation().getAmendmentNumber()
                                            , contractOpencell.getContractVersionInformation().getVersionNumber()
                                            , null
                                            , contractOpencell.getOfferInformation().getOpsCode().toString()
                                            , null
                                            , contractEstablishment.getPrestationEstablishmentCode().toString()
                                            , CodeErrorEnum.U12005)
                            )
                    )
                    .collectList()
                    .map(contractEstablishments -> {
                        contractOpencell.setContractEstablishment(contractEstablishments);
                        return contractOpencell;
                    })

                    .defaultIfEmpty(contractOpencell);
        } else {
            return Mono.just(contractOpencell);
        }
    }

    /**
     * Fill the list of delivery address ids
     *
     * @param contractOpencell The contract for opencell
     * @return The contract with mandate filled
     */
    public Mono<ContractOpencell> addValuesFromOfferCriteria(ValuedOfferEntity valuedOfferEntity, ContractOpencell contractOpencell, ValuedOfferMessage valuedOfferMessage) {
        return Mono.just(contractOpencell)
                .map(contractOpencell1 -> {
                    Map<String, List<String>> parsedMap = this.valuedOfferParser.fetchAllDeliveryAddressIdsInOffer(valuedOfferEntity, valuedOfferMessage);
                    contractOpencell.setContractDeliveryAddressIds(
                            parsedMap.get(ADR_PREST_KEY)
                                    .stream().map(Long::parseLong).collect(Collectors.toList())
                    );
                    contractOpencell.setContractEstablishment(new ArrayList<>());
                    if (parsedMap.get(ETB_PREST_KEY) != null) {
                        for (String codeRegateEtabs : parsedMap.get(ETB_PREST_KEY)) {
                            ContractEstablishment contractEstablishment = new ContractEstablishment();
                            contractEstablishment.setPrestationEstablishmentCode(codeRegateEtabs);
                            contractOpencell.getContractEstablishment().add(contractEstablishment);
                        }
                    }
                    return contractOpencell;
                })
                .onErrorMap(SynchronizationMappingException.class,
                        e -> new SynchronizationMappingException(e.getMessage(), e, null, contractOpencell.getContractInformation().getContractNumber().toString()
                                , contractOpencell.getContractVersionInformation().getVersionNumber(), contractOpencell.getContractVersionInformation().getAmendmentNumber(),
                                null, contractOpencell.getOfferInformation().getOpsCode().toString(),CodeErrorEnum.U12006))
                .onErrorResume(throwable -> !(throwable instanceof SynchronizationSourceOrgaAPICallException),
                        throwable -> {
                            StringWriter sw = new StringWriter();
                            throwable.printStackTrace(new PrintWriter(sw));
                            String stackTrace = sw.toString();

                            return Mono.error(new SynchronizationMappingException("Unhandled exception while we add values from OfferCriteria : "
                                    + throwable.getMessage() + "\nSTACK TRACE : "
                                    + stackTrace, throwable, null, contractOpencell.getContractInformation().getContractNumber().toString(), null, null, null, contractOpencell.getOfferInformation().getOpsCode().toString(), CodeErrorEnum.U12006));
                        }

                );
    }

    /**
     * Build the complete contractConsolidated avro with the contract and the customer
     *
     * @param contractOpencell The contract for opencell
     * @param customerOpencell The customer for opencell (null in case of update)
     * @param action
     * @return The complete contract consolidated
     */
    public ContractConsolidated buildContractConsolidated(ContractOpencell contractOpencell, CustomerOpencell customerOpencell, OpencellActionEnum action) {
        return ContractConsolidated.newBuilder()
                .setAction(action)
                .setContractOpencell(contractOpencell)
                .setCustomerOpencell(customerOpencell)
                .build();
    }

    public Mono<Tuple2<ContractVersionEntity, LegalPersonEntity>> fillIdAddressInvoice(ContractVersionEntity contractVersionEntity, LegalPersonEntity legalPersonEntity) {
        if (legalPersonEntity != null && legalPersonEntity.getAddressEntityList() != null && contractVersionEntity.getInvoiceInformationEntity().getIdAddressInvoice() == null) {

            Predicate<AddressEntity> predicate = addressEntity -> contractVersionEntity.getInvoiceInformationEntity().getInvoiceAddressNumber()
                    .equals(addressEntity.getAddressIdRefPM());
            return Flux.fromIterable(legalPersonEntity.getAddressEntityList())
                    .filter(predicate) //We check if we find the addressNumber among the addresses related to the customer
                    .last()
                    .onErrorResume(NoSuchElementException.class, throwable -> Mono.empty())
                    .switchIfEmpty(Mono.defer(() -> //if not, we try to refresh the legalPerson from LegalPerson API
                                    importService.fetchLegalPerson(legalPersonEntity.getCustAccNumber())
                                            .map(tuple2 -> {
                                                LegalPersonEntity legalPersonEntity1 = tuple2.getT1();
                                                legalPersonEntity1.setIdLegalPerson(legalPersonEntity.getIdLegalPerson());
                                                if(legalPersonEntity.getCreated()!=null){
                                                    legalPersonEntity1.setCreated((legalPersonEntity.getCreated()));
                                                } else {
                                                    legalPersonEntity1.setCreated(Instant.now());
                                                }
                                                return Tuples.of(legalPersonEntity1, tuple2.getT2());
                                            })
                                            .flatMap(tuple2 -> Mono.zip(legalPersonService.save(tuple2.getT1(), true), Mono.just(tuple2.getT2())))
                                            .flatMap(tupleFinal -> legalPersonService.saveLegalPersonMessage(tupleFinal.getT1(), tupleFinal.getT2()).thenReturn(tupleFinal.getT1())))
                            .flatMapMany(legalPersonEntity1 -> Flux.fromIterable(legalPersonEntity1.getAddressEntityList()))
                            .filter(predicate)
                            .last()
                            .onErrorResume(NoSuchElementException.class, throwable -> Mono.empty())
                    )
                    .switchIfEmpty(Mono.error(new SynchronizationContractException("[CLIENT: "+ legalPersonEntity.getCustAccNumber() + "][ADDRESSID: " + contractVersionEntity.getInvoiceInformationEntity().getInvoiceAddressNumber() +
                            "] addressNumber of the contract is not present among addresses of the customer from REFPM despite a LegalPerson refresh"
                            , null
                            , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT, contractVersionEntity.getIdContract()
                            , contractVersionEntity.getContract().getContractNumber()
                            , contractVersionEntity.getAmendmentNumber()
                            , contractVersionEntity.getRevisionNumber(), contractVersionEntity
                            , contractVersionEntity.getValuedOffer().getOpsCode()
                            , CodeErrorEnum.U12003)))
                    .flatMap(addressEntity -> {
                        contractVersionEntity.getInvoiceInformationEntity().setAddressFacturation(addressEntity);
                        contractVersionEntity.getInvoiceInformationEntity().setIdAddressInvoice(addressEntity.getIdAddress());
                        return this.contractService.saveInvoiceInformation(contractVersionEntity.getInvoiceInformationEntity())
                                .thenReturn(Tuples.of(contractVersionEntity, legalPersonEntity));
                    });
        }
        return Mono.just(Tuples.of(contractVersionEntity, legalPersonEntity));
    }

    /**
     * Fill the mandate data if a RUM is present in the contract
     *
     * @param contractVersionEntity The contract_version entity from db
     * @return The contractVersionEntity with mandate filled
     */
    protected Mono<ContractVersionEntity> addMandate(ContractVersionEntity contractVersionEntity) {

        var rum = contractVersionEntity.getInvoiceInformationEntity().getRum();

        return Mono.justOrEmpty(rum)
                .filter(Strings::isNotBlank)
                .flatMap(importService::findOrFetchMandate)
                .onErrorMap(SynchronizationMandateAPICallException.class, e ->
                        new SynchronizationContractException(e.getMessage()
                                , e
                                , e.getWorkflowStepEnum()
                                , null
                                , contractVersionEntity.getContract().getContractNumber()
                                , contractVersionEntity.getAmendmentNumber()
                                , contractVersionEntity.getRevisionNumber()
                                , null
                                , contractVersionEntity.getValuedOffer().getOpsCode()
                                , e.getRum()
                                , CodeErrorEnum.U12004))
                .onErrorMap(throwable -> !(throwable instanceof SynchronizationMandateAPICallException), throwable ->
                        new SynchronizationContractException(
                                "[RUM: " + rum + "] Unhandled exception while fetching mandate. " + throwable.getMessage()
                                , throwable
                                , ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CONTRACT
                                , null
                                , contractVersionEntity.getContract().getContractNumber()
                                , contractVersionEntity.getAmendmentNumber()
                                , contractVersionEntity.getRevisionNumber()
                                , null
                                , contractVersionEntity.getValuedOffer().getOpsCode()
                                , rum
                                , CodeErrorEnum.U12004)
                )
                .flatMap(mandateEntity -> {
                    contractVersionEntity.getInvoiceInformationEntity().setIdMandate(mandateEntity.getIdMandate());
                    contractVersionEntity.getInvoiceInformationEntity().setMandate(mandateEntity);
                    log.debug("Updating contract version {} with mandate information {}", contractVersionEntity.getIdContract(), mandateEntity.getRum());
                    return contractService.saveInvoiceInformation(contractVersionEntity.getInvoiceInformationEntity());
                })
                .thenReturn(contractVersionEntity);

    }

    public ContractOpencell buildValuedOfferAndOfferInformationAndInvoiceInformation(ContractOpencell contractOpencell, ValuedOfferMessage valuedOfferMessage, InvoiceInformationEntityMessage invoiceInformationEntityMessage){
        try {
            JsonDecoder decoder = DecoderFactory.get().jsonDecoder(Offer.getClassSchema(), valuedOfferMessage.getMessage());
            SpecificDatumReader<Offer> reader = new SpecificDatumReader<>(Offer.getClassSchema());
            Offer offer = reader.read(null, decoder);
            contractOpencell.setOfferInformation(this.contractOfferToOfferInformation(offer));
            /**
             * BILLING-597 We finally give a non-strict json to Opencell through valuedOffer
             */
            contractOpencell.setValuedOffer(offer.toString());

            List<fr.laposte.bscc.billing.avro.billing.InvoicingComment> comments = this.objectMapper1.readValue(invoiceInformationEntityMessage.getInvoicingCommentsJsonArray(),
                    new TypeReference<>() {
                    });
            contractOpencell.setInvoicingComments(comments);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contractOpencell;
    }
    public OfferInformation contractOfferToOfferInformation(Offer offer) {
        List<ProductInformation> productList = new ArrayList<>();
        if (offer.getProducts() != null) {
            for (OfferProduct product : offer.getProducts()) {
                List<ServiceInformation> serviceInformationList = new ArrayList<>();
                List<ProductPrices> productPriceList = new ArrayList<>();
                if (product.getProductService() != null) {
                    for (ProductService service : product.getProductService()) {
                        serviceInformationList.add(ServiceInformation.newBuilder().setServiceCode(service.getServiceCode()).build());
                    }
                }
                if (product.getProductPrices() != null) {
                    for (ProductPrice price : product.getProductPrices()) {
                        productPriceList.add(ProductPrices.newBuilder()
                                .setProrata(price.getProrata())
                                .setInclusingTaxUnitPrice(price.getInclusingTaxUnitPrice())
                                .setChargeDescription(price.getChargeDescription())
                                .build());
                    }
                }

                productList.add(ProductInformation.newBuilder()
                        .setProductCode(product.getProductCode())
                        .setProductPrices(productPriceList)
                        .setServiceInformation(serviceInformationList)
                        .build());
            }
        }
        return OfferInformation.newBuilder()
                .setOpsId(Integer.parseInt(offer.getOpsId().toString()))
                .setOpsCode(offer.getOpsCode())
                .setOpsVersion(offer.getOpsVersion())
                .setProductInformation(productList)
                .build();
    }

}
