package fr.laposte.blg.blinks.u17.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SeresReplayDto {
    private Long id;
    private String invoiceNumber;
    private String errorDate;
    private Integer errorCode;
    private String errorMessage;
    private String invoiceUrl;
    private String printable;
}
