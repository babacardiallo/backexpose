# Dockerfile
It is the main file of the docker build. It content all the instruction for building an image for our application
