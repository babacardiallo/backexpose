package fr.laposte.blg.blinks.u14.controller;

import MD.LatestValue.Address;
import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.u14.service.KafkaSenderService;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@Profile("sloc")
public class TestMessageController {

    @Autowired
    private KafkaSenderService kafkaSenderService;

    @PostMapping("/contract")
    public Mono<Void> sendContract(@RequestBody gkContractFullOutV1 contractFullOutV1) {
        return this.kafkaSenderService.send(contractFullOutV1);
    }

    @PostMapping("/legalperson")
    public Mono<Void> sendLegalPerson(@RequestBody LegalPerson legalPerson) {
        return this.kafkaSenderService.send(legalPerson);
    }

    @PostMapping("/address")
    public Mono<Void> sendAddress(@RequestBody Address address) {
        return this.kafkaSenderService.send(address);
    }
}

