package fr.laposte.blg.blinks.u18.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.u18.service.FileWriterService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExportScheduler implements Runnable {

    private final FileWriterService fileWriterService;
    private final SchedulerParamsEntity schedulerParams;

    public ExportScheduler(FileWriterService fileWriterService, SchedulerParamsEntity schedulerParams) {
        this.fileWriterService = fileWriterService;
        this.schedulerParams = schedulerParams;
    }

    @Override
    public void run() {
        log.info("Starting TransferScheduler job for scheduler: {}", schedulerParams.getSchedulerName());

        log.info("Scheduled NDJSON export started.");
        fileWriterService.exportPendingMessagesToNdjson(schedulerParams.getExportPath());
        log.info("Scheduled NDJSON export completed.");
    }
}
