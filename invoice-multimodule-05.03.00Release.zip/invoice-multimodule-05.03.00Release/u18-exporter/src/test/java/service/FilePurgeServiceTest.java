package service;


import fr.laposte.blg.blinks.u18.service.impl.FilePurgeServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.Period;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FilePurgeServiceTest {

    @TempDir
    Path tempDir;
    Path archiveDir;
    @InjectMocks
    private FilePurgeServiceImpl filePurgeService;

    @BeforeEach
    void setUpDirectories() throws IOException {
        archiveDir = tempDir.resolve("archive");
        Files.createDirectories(archiveDir);
    }

    @Test
    void testPurgeSuccess() throws Exception {
        String fileName = "testfile.txt";
        Path archiveFile = archiveDir.resolve(fileName);
        Files.write(archiveFile, "dummy content".getBytes());
        filePurgeService.purgeFilesOlderThan(archiveDir.toString(), Instant.now().plus(Period.ofDays(1)));
        try (Stream<Path> archives = Files.list(archiveDir)) {
            assertEquals(0L, archives.count());
        }
    }
}
