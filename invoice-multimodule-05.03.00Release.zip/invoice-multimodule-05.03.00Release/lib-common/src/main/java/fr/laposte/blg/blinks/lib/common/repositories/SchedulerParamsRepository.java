package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface SchedulerParamsRepository extends ReactiveCrudRepository<SchedulerParamsEntity, Long> {
    Flux<SchedulerParamsEntity> findAllByIsEnabled(boolean isEnabled);
    Flux<SchedulerParamsEntity> findAllByIsEnabledAndModule(boolean isEnabled, String module);
    Flux<SchedulerParamsEntity> findAllByModule(String module);
    Mono<SchedulerParamsEntity> findAllBySchedulerName(String schedulerName);
}