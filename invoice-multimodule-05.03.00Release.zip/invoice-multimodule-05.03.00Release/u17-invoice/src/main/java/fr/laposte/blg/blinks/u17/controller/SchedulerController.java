package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.u17.service.SchedulerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


@RestController
@RequestMapping("/api/v1/scheduler")
public class SchedulerController {
    private final SchedulerService schedulerService;

    public SchedulerController(SchedulerService schedulerService) {
        this.schedulerService = schedulerService;
    }

    @GetMapping
    public Flux<SchedulerParamsEntity> getAllSchedulers() {
        return schedulerService.getAllSchedulers();
    }

    @PutMapping("/{id}/update")
    public Mono<ResponseEntity<SchedulerParamsEntity>> updateSchedulerParams(
            @PathVariable Long id,
            @RequestBody SchedulerParamsEntity newParams) {
        return schedulerService.updateTask(id, newParams)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/disable")
    public Mono<ResponseEntity<SchedulerParamsEntity>> disableScheduler(@PathVariable Long id) {
        return schedulerService.cancelTask(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/enable")
    public Mono<ResponseEntity<SchedulerParamsEntity>> enableScheduler(@PathVariable Long id) {
        return schedulerService.enableTask(id)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/run")
    public Mono<ResponseEntity<String>> runOnce(@PathVariable Long id){
        return schedulerService.runOnce(id)
                .then(Mono.just(ResponseEntity.ok("Scheduler will run once")))
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage()))
                );
    }

    @PostMapping("/{id}/organize-archives")
    public Mono<ResponseEntity<String>> organizeExistingArchives(@PathVariable Long id) {
        return schedulerService.organizeExistingArchives(id)
                .map(count -> ResponseEntity.ok("Successfully organized " + count + " files"))
                .onErrorResume(e -> Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Error organizing archives: " + e.getMessage())));
    }
}