package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferMessage;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface ValuedOfferMessageRepository extends ReactiveCrudRepository<ValuedOfferMessage, Long> {

    @Query("SELECT message from valued_offer_message where id_valued_offer = :id")
    Mono<String> getLegalPersonMessage(long id);

    Mono<ValuedOfferMessage> findByIdValuedOffer(long id);
}
