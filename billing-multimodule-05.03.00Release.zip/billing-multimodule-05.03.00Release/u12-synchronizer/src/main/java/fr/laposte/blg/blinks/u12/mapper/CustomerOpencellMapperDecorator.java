package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationException;
import fr.laposte.bscc.billing.avro.billing.AddressOpencell;
import fr.laposte.bscc.billing.avro.billing.CustomerOpencell;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
public class CustomerOpencellMapperDecorator implements CustomerOpencellMapper {

    @Autowired
    @Qualifier("delegate")
    private CustomerOpencellMapper delegate;

    @Autowired
    private AddressOpencellMapper addressOpencellMapper;

    @Override
    public CustomerOpencell legalPersonEntityToCustomerOpencell(LegalPersonEntity legalPersonEntity) {
        CustomerOpencell customerOpencell = this.delegate.legalPersonEntityToCustomerOpencell(legalPersonEntity);

        AddressOpencell customerAddress = null;
        List<AddressOpencell> deliveryAddress = new ArrayList<>();
        String compared = "NOT_FOUND";
        if(compared.equals(legalPersonEntity.getBusinessTeamLongName())) {
            customerOpencell.getCustomerInformation().setBusinessTeamId(null);
            customerOpencell.getCustomerInformation().setBusinessTeamLongname(null);
        } else {
            customerOpencell.getCustomerInformation().setBusinessTeamId(legalPersonEntity.getBusinessTeamId());
            customerOpencell.getCustomerInformation().setBusinessTeamLongname(legalPersonEntity.getBusinessTeamLongName());
        }
        if (legalPersonEntity.getAddressEntityList() != null) {
            for (AddressEntity addressEntity : legalPersonEntity.getAddressEntityList()) {
                if (addressEntity.getAddressType().equals(AddressType.PRINCIPALE)) {
                    customerAddress = this.addressOpencellMapper.addressEntityToCustomerAddress(addressEntity);
                } else if (addressEntity.getAddressType().equals(AddressType.PRESTATION)) {
                    deliveryAddress.add(this.addressOpencellMapper.addressEntityToCustomerAddress(addressEntity));
                }
            }
        }

        customerOpencell.setCustomerAddress(
            Optional.ofNullable(customerAddress)
                .orElseThrow(() -> new SynchronizationException("No main address related to the customer", null, null, null))
        );
        customerOpencell.setCustomerDeliveryAddress(deliveryAddress);
        return customerOpencell;
    }
}
