package scheduler;

import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcessStatus;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.u17.scheduler.ExportOnceScheduler;
import fr.laposte.blg.blinks.u17.service.DocaposteService;
import fr.laposte.blg.blinks.u17.service.CoeurfinanceService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.scheduling.TaskScheduler;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExportOnceSchedulerTest {

    @TempDir
    Path tempDir;
    Path exportDir;

    @InjectMocks private ExportOnceScheduler exportOnceScheduler;
    @Mock private DocaposteService docaposteService;
    @Mock private CoeurfinanceService coeurfinanceService;
    @Mock private InfocaInvoiceExportService infocaInvoiceExportService;
    @Mock private ExportProcessRepository exportProcessRepository;
    @Mock private TaskScheduler taskScheduler;

    @BeforeEach
    void setUpDirectories() throws IOException {
        exportDir = tempDir.resolve("export");
        Files.createDirectories(exportDir);
        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(1L, "export_scheduler");
        exportOnceScheduler = new ExportOnceScheduler(docaposteService, coeurfinanceService, infocaInvoiceExportService, exportProcessRepository, schedulerParams, taskScheduler);
    }
    ExportProcess getExport(Long id){
        return new ExportProcess(1L,1L, 2L, Instant.now(), FileType.DOCAPOSTE, ExportProcessStatus.SUCCESS, null, null, 0);
    }


    private SchedulerParamsEntity createSchedulerParamsEntity(Long id, String schedulerName) {
        SchedulerParamsEntity params = new SchedulerParamsEntity();
        params.setId(id);
        params.setSchedulerName(schedulerName);
        params.setCronExpression("0 * * * * *");
        params.setExportPath(exportDir.toString());
        params.setWaitingDelay(1);
        params.setCustomParams("");
        params.setIsEnabled(true);
        return params;
    }
    @Test
    void testExportWithSuccessLastFailedProcess() {
        when(this.exportProcessRepository.findTopByExportProcessStatusOrderByExecutionSequenceAsc(ExportProcessStatus.FAILED))
                .thenReturn(Mono.just(new ExportProcess(1L,1L, 2L, Instant.now(), FileType.DOCAPOSTE, ExportProcessStatus.FAILED, "U170017", "failed export", 0)));
        when(this.exportProcessRepository.findTopByExportProcessStatusOrderByExecutionSequenceAsc(ExportProcessStatus.NEW))
                .thenReturn(Mono.empty());
        when(this.exportProcessRepository.findById(anyLong())).thenReturn(Mono.just(new ExportProcess(1L,1L, 2L, Instant.now(), FileType.DOCAPOSTE, ExportProcessStatus.FAILED, "U170017", "failed export", 0)));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(exportProcessRepository).save(any(ExportProcess.class));
        exportOnceScheduler.run();
    }




}
