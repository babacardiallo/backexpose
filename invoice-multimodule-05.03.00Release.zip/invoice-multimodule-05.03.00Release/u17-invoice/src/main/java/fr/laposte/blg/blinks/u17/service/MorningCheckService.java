package fr.laposte.blg.blinks.u17.service;


import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.u17.dto.CalendarEventDto;
import fr.laposte.blg.blinks.u17.dto.MorningCheckDto;
import fr.laposte.blg.blinks.u17.dto.TransferIhmDto;
import fr.laposte.blg.blinks.u17.mapper.MorningCheckMapper;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Service
@RequiredArgsConstructor
@Data
public class MorningCheckService {

    private final ExportHistoryRepository exportHistoryRepository;
    private final MorningCheckMapper morningCheckMapper;
    private final DateUtil dateUtil;

    public Flux<MorningCheckDto> getExportHistories(LocalDate date) {
        String comparedDate=null;
        if(date!=null){
            comparedDate = dateUtil.yyyyMMddDash(date);
            comparedDate +="%";
        }
        return Flux.concat(
                        exportHistoryRepository.getLastExportedFileByType(FileType.COEURFINANCE, comparedDate),
                        exportHistoryRepository.getLastExportedFileByType(FileType.INFOCA, comparedDate),
                        exportHistoryRepository.getLastExportedFileByType(FileType.DOCAPOSTE, comparedDate),
                        exportHistoryRepository.getLastExportedFileByType(FileType.EQUINOX, comparedDate))
                .map(morningCheckMapper::exportHistoryEntityToMorningCheckDto);
    }


    public Mono<Integer> updateFileSendStatus(FileType fileType, LocalDateTime date, LocalDateTime fileSendDate) {
        return exportHistoryRepository.updateFileSendStatus(fileType, date, fileSendDate);

    }

    public Flux<CalendarEventDto> getMonthlyTreatment(Integer year,Integer month) {
        Flux<MonthlyTreatment> monthlyTreatmentFlux;
        if(year!=null || month !=null){
            monthlyTreatmentFlux = exportHistoryRepository.getMonthlyTreatmentByMonthAndYear(year, month, FileType.REFCOM_BATCH);
        } else {
            monthlyTreatmentFlux = exportHistoryRepository.getMonthlyTreatment(FileType.REFCOM_BATCH);
        }
        return monthlyTreatmentFlux
                .map(monthlyTreatment -> {
                    CalendarEventDto calendarEventDto = new CalendarEventDto();
                    calendarEventDto.setStart(Date.from(monthlyTreatment.getDate()));
                    calendarEventDto.setEnd(Date.from(monthlyTreatment.getDate()));
                    calendarEventDto.setStatus(monthlyTreatment.getTransferStatus());
                    if(monthlyTreatment.getExportStatus().equals(ExportStatus.SUCCESS)){
                        calendarEventDto.setColor(0);
                        if(BooleanUtils.isFalse(monthlyTreatment.getIsFileEmpty())){
                            calendarEventDto.setTitle("Traitement " + monthlyTreatment.getFileType().toLowerCase() + " du " + DateUtil.ddMMyyyyHHmm(monthlyTreatment.getDate()) + ", succès: le fichier a été généré");
                        } else {
                            calendarEventDto.setTitle("Traitement " + monthlyTreatment.getFileType().toLowerCase() + " du " + DateUtil.ddMMyyyyHHmm(monthlyTreatment.getDate()) + ", succès: le fichier est vide");
                        }
                    }

                    if(monthlyTreatment.getExportStatus().equals(ExportStatus.WARNING)){
                        calendarEventDto.setColor(1);
                        if(BooleanUtils.isFalse(monthlyTreatment.getIsFileEmpty())){
                            calendarEventDto.setTitle("Traitement " + monthlyTreatment.getFileType().toLowerCase() + " du " + DateUtil.ddMMyyyyHHmm(monthlyTreatment.getDate()) + ", succès avec warning(s): le fichier a été généré");
                        } else {
                            calendarEventDto.setTitle("Traitement " + monthlyTreatment.getFileType().toLowerCase() + " du " + DateUtil.ddMMyyyyHHmm(monthlyTreatment.getDate()) + ", succès avec warning(s): le fichier est vide");
                        }
                    }

                    if(monthlyTreatment.getExportStatus().equals(ExportStatus.FAILED)){
                        calendarEventDto.setColor(2);
                        calendarEventDto.setTitle("Traitement " + monthlyTreatment.getFileType().toLowerCase() + " du " + DateUtil.ddMMyyyyHHmm(monthlyTreatment.getDate()) + ": Le fichier n'a pas été généré");
                    }
                    return calendarEventDto;
                });

    }

    public Mono<Map<FileType, List<MorningCheckDto>>> getExportHistoriesDaily(LocalDate date) {
        String comparedDate=null;
        if(date!=null){
            comparedDate = dateUtil.yyyyMMddDash(date);
            comparedDate +="%";
        }
        Mono<List<ExportHistoryEntity>> coeurfinanceExports = exportHistoryRepository.getDailyExportFileByType(FileType.COEURFINANCE, comparedDate)
                .collectList();
        Mono<List<ExportHistoryEntity>> infocaExports = exportHistoryRepository.getDailyExportFileByType(FileType.INFOCA, comparedDate)
                .collectList();
        Mono<List<ExportHistoryEntity>> docaposteExports = exportHistoryRepository.getDailyExportFileByType(FileType.DOCAPOSTE, comparedDate)
                .collectList();
        Mono<List<ExportHistoryEntity>> docaposteAvisPaiementsExports = exportHistoryRepository.getDailyExportFileByType(FileType.DOCAPOSTE_AVIS_PAIEMENT, comparedDate)
                .collectList();
        Mono<List<ExportHistoryEntity>> equinoxExports = exportHistoryRepository.getDailyExportFileByType(FileType.EQUINOX, comparedDate)
                .collectList();
        return Mono.zip(coeurfinanceExports, infocaExports, docaposteExports, docaposteAvisPaiementsExports, equinoxExports)
                .flatMap(tuple4 -> {
                    Map<FileType, List<MorningCheckDto>> exports = new HashMap<>();
                    exports.put(FileType.COEURFINANCE, morningCheckMapper.exportHistoryEntityToMorningCheckDto(tuple4.getT1()));
                    exports.put(FileType.INFOCA, morningCheckMapper.exportHistoryEntityToMorningCheckDto(tuple4.getT2()));
                    exports.put(FileType.DOCAPOSTE, morningCheckMapper.exportHistoryEntityToMorningCheckDto(tuple4.getT3()));
                    exports.put(FileType.DOCAPOSTE_AVIS_PAIEMENT, morningCheckMapper.exportHistoryEntityToMorningCheckDto(tuple4.getT4()));
                    exports.put(FileType.EQUINOX, morningCheckMapper.exportHistoryEntityToMorningCheckDto(tuple4.getT5()));
                    return Mono.just(exports);
                });
    }

    public Flux<TransferIhmDto> getTransferStatusDuJour(LocalDate date) {
        String comparedDate = null;
        comparedDate = dateUtil.yyyyMMddDash(Objects.requireNonNullElseGet(date, LocalDate::now));
        comparedDate += "%";
        return exportHistoryRepository.getDailyExportFile(comparedDate)
                .map(exportHistoryEntity -> {
                    TransferIhmDto transferIhmDto = new TransferIhmDto();
                    transferIhmDto.setId(exportHistoryEntity.getIdExport());
                    transferIhmDto.setType(exportHistoryEntity.getFileType().toString());
                    transferIhmDto.setName(exportHistoryEntity.getFileName());
                    transferIhmDto.setGenerationDate(DateUtil.yyyyMMddHHmmSSMorningCheck(exportHistoryEntity.getDate()));
                    transferIhmDto.setTransferDate(DateUtil.yyyyMMddHHmmSSMorningCheck(exportHistoryEntity.getFileSendDate()));
                    transferIhmDto.setStatus(exportHistoryEntity.getTransferStatus().toString());
                    transferIhmDto.setErrorCode(exportHistoryEntity.getTransferErrorCode());
                    transferIhmDto.setErrorMessage(exportHistoryEntity.getTransferErrorMessage());
                    return transferIhmDto;
                });
    }

    public Mono<Map<FileType, MorningCheckMonthly>> getMonthlyMorningCheck(Integer year, Integer month) {
        Mono<MorningCheckMonthly> coeurfinanceMorningCheckMonthly = exportHistoryRepository.getMonthlyMorningCheck(year, month, FileType.COEURFINANCE);
        Mono<MorningCheckMonthly> docaposteMorningCheckMonthly = exportHistoryRepository.getMonthlyMorningCheckForDocaposte(year, month);
        Mono<MorningCheckMonthly> infocaMorningCheckMonthly = exportHistoryRepository.getMonthlyMorningCheck(year, month, FileType.INFOCA);
        Mono<MorningCheckMonthly> equinoxMorningCheckMonthly = exportHistoryRepository.getMonthlyMorningCheck(year, month, FileType.EQUINOX);
        return Mono.zip(coeurfinanceMorningCheckMonthly, docaposteMorningCheckMonthly, infocaMorningCheckMonthly, equinoxMorningCheckMonthly)
                .flatMap(tuple3 -> {
                    Map<FileType, MorningCheckMonthly> exports = new HashMap<>();
                    exports.put(FileType.COEURFINANCE, tuple3.getT1());
                    exports.put(FileType.DOCAPOSTE, tuple3.getT2());
                    exports.put(FileType.INFOCA, tuple3.getT3());
                    exports.put(FileType.EQUINOX, tuple3.getT4());
                    return Mono.just(exports);
                });

    }

    public Flux<TransferIhmDto> getTransferStatusMonthly(Integer year, Integer month) {
        return exportHistoryRepository.getMonthlyExportFile(year, month)
                .map(exportHistoryEntity -> {
                    TransferIhmDto transferIhmDto = new TransferIhmDto();
                    transferIhmDto.setId(exportHistoryEntity.getIdExport());
                    transferIhmDto.setType(exportHistoryEntity.getFileType().toString());
                    transferIhmDto.setName(exportHistoryEntity.getFileName());
                    transferIhmDto.setGenerationDate(DateUtil.yyyyMMddHHmmSSMorningCheck(exportHistoryEntity.getDate()));
                    transferIhmDto.setTransferDate(DateUtil.yyyyMMddHHmmSSMorningCheck(exportHistoryEntity.getFileSendDate()));
                    transferIhmDto.setStatus(exportHistoryEntity.getTransferStatus().toString());
                    transferIhmDto.setErrorCode(exportHistoryEntity.getTransferErrorCode());
                    transferIhmDto.setErrorMessage(exportHistoryEntity.getTransferErrorMessage());
                    return transferIhmDto;
                });
    }
}
