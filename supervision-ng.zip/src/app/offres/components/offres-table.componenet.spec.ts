import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OffresTableComponent } from './offres-table.component';

describe('DataTableComponentComponent', () => {
  let component: OffresTableComponent;
  let fixture: ComponentFixture<OffresTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OffresTableComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OffresTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
