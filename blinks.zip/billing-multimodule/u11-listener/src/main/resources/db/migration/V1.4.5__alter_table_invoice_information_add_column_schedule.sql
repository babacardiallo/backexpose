ALTER TABLE blg_contract_importer.invoice_information
    ADD COLUMN schedule varchar(255);