package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.an.testcontainers.mysql.MySQLContainer;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.*;
import fr.laposte.bscc.billing.avro.billing.ContractConsolidated;
import fr.laposte.bscc.billing.avro.billing.ContractInformation;
import fr.laposte.bscc.billing.avro.billing.ContractOpencell;
import fr.laposte.bscc.billing.avro.billing.ContractVersionInformation;
import io.r2dbc.spi.ConnectionFactory;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.r2dbc.DataR2dbcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.r2dbc.connection.init.CompositeDatabasePopulator;
import org.springframework.r2dbc.connection.init.ConnectionFactoryInitializer;
import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Testcontainers;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple2;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

@Testcontainers
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DataR2dbcTest
class ContractServiceIT {

    @Autowired
    private ContractRepository contractRepository;

    @Autowired
    private ContractVersionRepository contractVersionRepository;

    @Autowired
    private InvoiceInformationRepository invoiceInformationRepository;

    @Autowired
    private ValuedOfferRepository valuedOfferRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private ContractLinkedRepository contractLinkedRepository;

    @Autowired
    private ContractVersionMessageRepository contractVersionMessageRepository;

    @Autowired
    private ContractMessageRepository contractMessageRepository;

    @Autowired
    private ValuedOfferMessageRepository valuedOfferMessageRepository;

    @Autowired
    private InvoiceInformationMessageRepository invoiceInformationMessageRepository;

    private ContractService contractService;

    private final ContractEntity contract = new ContractEntity();
    private final ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
    private final ContractVersionEntity versionEntity = new ContractVersionEntity();
    private final ContractLinkedEntity contractLinkedEntity = new ContractLinkedEntity();
    private final InvoiceInformationEntity invoiceInformationEntity = new InvoiceInformationEntity();

    private static final MySQLContainer sqlContainer = new MySQLContainer()
        .withDatabaseName("blg_contract_importer");

    static {
        sqlContainer.start();
    }

    @DynamicPropertySource
    static void registerDynamicProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.r2dbc.url", ContractServiceIT::r2dbcUrl);
        registry.add("spring.r2dbc.username", sqlContainer::getUsername);
        registry.add("spring.r2dbc.password", sqlContainer::getPassword);
    }

    private static String r2dbcUrl() {
        return String.format("r2dbc:mysql://%s:%s/%s?sslMode=DISABLED",
            sqlContainer.getContainerIpAddress(),
            sqlContainer.getFirstMappedPort(),
            sqlContainer.getDatabaseName());
    }

    @TestConfiguration
    static class TestConfig {
        @Bean
        public ConnectionFactoryInitializer initializer(ConnectionFactory connectionFactory) {

            ConnectionFactoryInitializer initializer = new ConnectionFactoryInitializer();
            initializer.setConnectionFactory(connectionFactory);

            CompositeDatabasePopulator populator = new CompositeDatabasePopulator();
            populator.addPopulators(new ResourceDatabasePopulator(new ClassPathResource("V1.0.0__init_blling_tables.sql")));
            initializer.setDatabasePopulator(populator);
            return initializer;
        }
    }

    @BeforeAll
    void init() {
        contractService = new ContractService(contractRepository, contractVersionRepository, invoiceInformationRepository, valuedOfferRepository, addressRepository, contractLinkedRepository, contractVersionMessageRepository, contractMessageRepository, valuedOfferMessageRepository, invoiceInformationMessageRepository);

        contract.setContractNumber("1-1");
        contract.setType("type");
        contract.setSubtype("subtype");
        contract.setEffectiveDatetime(Instant.now());
        contract.setCustAccNumber(1111111);
        contract.setRenewalMode("renewalMode");
        contract.setManagementMode("managementMode");
        contract.setSignatureDatetime(Instant.now());

        valuedOfferEntity.setOpsId("150");
        valuedOfferEntity.setOpsCode("150");


        contractLinkedEntity.setIdContract(1L);
        contractLinkedEntity.setLinkedContractNumber("1-1");
        contractLinkedEntity.setLinkType("link");
        contractLinkedEntity.setLinkedContractId(1L);

        invoiceInformationEntity.setInvoicePeriodicityLabel("periodicity");
        invoiceInformationEntity.setInvoiceMode("invoiceMode");
        invoiceInformationEntity.setBosco("bosco");
        invoiceInformationEntity.setDedicatedInvoiceFlag(true);
        invoiceInformationEntity.setInArrearsInvoiceFlag(false);
        invoiceInformationEntity.setInvoiceAddressNumber("invoiceAddressNumber");
        invoiceInformationEntity.setPaymentMeans("paymentMeans");
        invoiceInformationEntity.setPaymentPeriod("paymentPeriod");
        invoiceInformationEntity.setRum("rum");
        invoiceInformationEntity.setVatLiabilityFlag(true);

        versionEntity.setAmendmentNumber(2);
        versionEntity.setContract(contract);
        versionEntity.setInvoiceInformationEntity(invoiceInformationEntity);
        versionEntity.setValuedOffer(valuedOfferEntity);
        versionEntity.setIdContract(1L);
        versionEntity.setRevisionNumber(1);
        versionEntity.setValidityStartDatetime(Instant.now());
        versionEntity.setValidityEndDatetime(Instant.now());
        versionEntity.setStatus(ContractStatusEnum.VALIDE);
        versionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        versionEntity.setTerminationDatetime(Instant.now());
        versionEntity.setTerm("term");
        versionEntity.setCategory("category");
        versionEntity.setParentContractNumber("0-1");
        versionEntity.setParentAmendmentNumber(0);
        versionEntity.setIsPurged(false);
        versionEntity.setSynchronized(true);
        versionEntity.setDateSynchronization(Instant.now());
        versionEntity.setPreviousDateSynchronization(null);

        this.contractService.checkIfContractIsNew(versionEntity)
            .flatMap(contractEntityIsNewTuple -> contractService.save(contractEntityIsNewTuple.getT1(), new ContractMessage()).thenReturn(contractEntityIsNewTuple))
            .flatMap(tuple2 -> this.contractService.createOrUpdateContractVersionChain(versionEntity, tuple2.getT1(), new ContractVersionMessage(), new ValuedOfferMessage(), new InvoiceInformationEntityMessage()))
            .block();
    }

    @Test
    void findContractTest() {
        Mono<ContractEntity> mono = this.contractService.findContractByContractNumberWithVersions(contract.getContractNumber(),true);
        StepVerifier.create(mono)
            .assertNext(contractEntity -> {
                assertEquals(contract.getContractNumber(), contractEntity.getContractNumber());
                assertEquals(1, contractEntity.getIdContract());
                assertEquals(1, contractEntity.getContractVersionEntities().size());
                assertEquals(2, contractEntity.getContractVersionEntities().get(0).getAmendmentNumber());
            })
            .verifyComplete();
    }

    @Test
    void checkIfContractExistsTest() {
        ContractEntity contract1 = new ContractEntity();
        contract1.setContractNumber("9898");
        contract1.setType("type");
        contract1.setSubtype("subtype");
        contract1.setEffectiveDatetime(Instant.now());
        contract1.setCustAccNumber(1111111);
        contract1.setRenewalMode("renewalMode");
        contract1.setManagementMode("managementMode");

        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setContract(contract1);
        StepVerifier.create(this.contractService.checkIfContractIsNew(contractVersionEntity))
            .expectSubscription()
            .expectNextMatches(Tuple2::getT2)
            .verifyComplete();
    }

    @Test
    void findContractVersionByIdTest() {

        StepVerifier.create(this.contractService.findContractVersionById(0L, true))
            .verifyComplete();

        StepVerifier.create(this.contractService.findContractVersionById(1L, true))
            .assertNext(contractVersionEntity -> {
                assertNotNull(contractVersionEntity);
                assertEquals(1L, contractVersionEntity.getIdContractVersion());
                assertEquals(1L, contractVersionEntity.getIdContract());
                assertNotNull(contractVersionEntity.getInvoiceInformationEntity());
                assertNotNull(contractVersionEntity.getValuedOffer());
            })
            .verifyComplete();

        StepVerifier.create(this.contractService.findContractVersionById(1L, false))
            .assertNext(contractVersionEntity -> {
                assertNotNull(contractVersionEntity);
                assertEquals(1L, contractVersionEntity.getIdContractVersion());
                assertEquals(1L, contractVersionEntity.getIdContract());
                assertNull(contractVersionEntity.getInvoiceInformationEntity());
                assertNull(contractVersionEntity.getValuedOffer());
            })
            .verifyComplete();
    }

    @Test
    void findContractVersionsToSynchronizeByContractIdTest() {

        StepVerifier.create(this.contractService.findContractVersionsToSynchronizeByContractId(0L))
            .verifyComplete();

        StepVerifier.create(this.contractService.findContractVersionsToSynchronizeByContractId(1L))
            .assertNext(contractVersionEntity -> {
                assertNotNull(contractVersionEntity);
                assertEquals(1L, contractVersionEntity.getIdContractVersion());
                assertEquals(1L, contractVersionEntity.getIdContract());
                assertNotNull(contractVersionEntity.getInvoiceInformationEntity());
                assertNotNull(contractVersionEntity.getValuedOffer());
            })
            .verifyComplete();
    }
    @Test
    void markContractSynchronizedTest() {
        ContractConsolidated contractConsolidated = new ContractConsolidated();
        ContractOpencell open = new ContractOpencell();
        contractConsolidated.setContractOpencell(open);
        ContractVersionInformation contractVersion = new ContractVersionInformation();
        ContractInformation contractInformation = new ContractInformation();
        contractInformation.setContractNumber("1-1");
        contractVersion.setVersionNumber(1);
        contractVersion.setAmendmentNumber(1);
        open.setContractVersionInformation(contractVersion);
        open.setContractInformation(contractInformation);

        TopicPartition topicPartition = new TopicPartition("topic",6);
        RecordMetadata message = new RecordMetadata(topicPartition,1,1,1,1,1);

        StepVerifier.create(this.contractService.markVersionSynchronized(open,message)
        .flatMapMany(contractVersionEntity -> this.contractService.findContractVersionsToSynchronizeByContractId(1L)))
                .assertNext(contractResult -> {
                    assertNotNull(contractResult);
                    assertEquals(Instant.now(), contractResult.getDateSynchronization());
                    assertEquals(6, contractResult.getPartitionNumConsolidated());
                    assertEquals(1, contractResult.getOffsetNumConsolidated());
                    assertTrue(contractResult.isSynchronized());

            })
                .expectComplete();
//                .verify();
    }
}
