package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonPropertyOrder({
        "criterionCode",
        "criterionValue"
})
public class CriterionDto {

    String criterionCode;
    String criterionValue;
}
