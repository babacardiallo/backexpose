import { CdkStepperModule } from '@angular/cdk/stepper';
import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ModalService } from 'ngx-modal-ease';
import { NgxPermissionsModule } from 'ngx-permissions';
import { SharedModule } from '../shared/shared.module';
import { RejetContractDetailsComponent } from './components/rejet-contract-details-pop-up/rejet-contract-details.component';
import { RejetContractSaisiePopupComponent } from './components/rejet-contract-saisie-pop-pup/rejet-contract-saisie-pop-pup.component';
import { RejetContractTableComponent } from './components/rejet-contract-table.component';
import { RejetContractRoutingModule } from './rejet-contract-routing.module';
import { RejetContractComponent } from './rejet-contract.component';


@NgModule({
    imports: [
        SharedModule,
        NgxPermissionsModule.forChild(),
        MatSelectModule,
        RejetContractRoutingModule,
        MatProgressSpinnerModule,
        NgxDatatableModule,
        MatSnackBarModule
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [RejetContractComponent, RejetContractTableComponent, RejetContractDetailsComponent, RejetContractSaisiePopupComponent],
    exports: [RejetContractComponent]
})
export class RejetContractModule { }
