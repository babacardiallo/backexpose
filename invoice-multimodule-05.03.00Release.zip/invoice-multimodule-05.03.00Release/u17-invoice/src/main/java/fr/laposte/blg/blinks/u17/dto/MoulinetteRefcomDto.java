package fr.laposte.blg.blinks.u17.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MoulinetteRefcomDto {
    private String coclico;
    private String entityCode;
    private String regateCode;
}
