package fr.laposte.blg.blinks.u11.listener.contract.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogIntegration {
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionNumber;
    private String custAccNumber;
    private String message;
}
