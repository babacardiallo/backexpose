package fr.laposte.blg.blinks.u18.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.u18.service.FilePurgeService;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Slf4j
public class FilePurgeScheduler implements Runnable {

    private final FilePurgeService filePurgeService;
    private final SchedulerParamsEntity schedulerParams;

    public FilePurgeScheduler(FilePurgeService filePurgeService, SchedulerParamsEntity schedulerParams) {
        this.filePurgeService = filePurgeService;
        this.schedulerParams = schedulerParams;
    }

    @Override
    public void run() {
        log.info("Starting TransferScheduler job for scheduler: {}", schedulerParams.getSchedulerName());

        String outputFolder = schedulerParams.getArchivePath();
        int retentionDays = schedulerParams.getRetentionDays();

        Instant threshold = Instant.now().minus(retentionDays, ChronoUnit.DAYS);
        log.info("Starting archive purge in '{}' for files older than {} days (before {}).",
                outputFolder, retentionDays, threshold);

        int deletedCount = filePurgeService.purgeFilesOlderThan(outputFolder, threshold);
        log.info("Archive purge completed. {} file(s) deleted.", deletedCount);
    }
}
