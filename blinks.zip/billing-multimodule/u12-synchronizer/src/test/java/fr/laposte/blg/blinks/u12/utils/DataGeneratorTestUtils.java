package fr.laposte.blg.blinks.u12.utils;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.bscc.billing.avro.billing.*;

import java.time.Instant;
import java.util.Collections;
import java.util.List;

public class DataGeneratorTestUtils {

    public static ContractVersionEntity generateContractVersionEntity() {

        AddressEntity address = AddressEntity.builder()
                .idAddress(1L)
                .build();

        LegalPersonEntity legalPerson = new LegalPersonEntity();
        legalPerson.setIdLegalPerson(1L);
        legalPerson.setCustAccNumber(1);
        legalPerson.setAddressEntityList(Collections.singletonList(address));

        ContractEntity contract = new ContractEntity();
        contract.setIdContract(1L);
        contract.setContractNumber("1-1");
        contract.setType("type");
        contract.setSubtype("subtype");
        contract.setEffectiveDatetime(Instant.now());
        contract.setCustAccNumber(1111111);
        contract.setRenewalMode("renewalMode");
        contract.setManagementMode("managementMode");
        contract.setSignatureDatetime(Instant.now());
        contract.setIdLegalPerson(1L);
        contract.setLegalPersonEntity(legalPerson);

        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("150");
        valuedOfferEntity.setOpsCode("150");

        ContractLinkedEntity contractLinkedEntity = new ContractLinkedEntity();
        contractLinkedEntity.setIdContract(1L);
        contractLinkedEntity.setLinkedContractNumber("1-1");
        contractLinkedEntity.setLinkType("link");
        contractLinkedEntity.setLinkedContractId(1L);

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setIdAddress(5L);
        addressEntity.setAddressType(AddressType.FACTURATION);
        addressEntity.setName1("chez moi");
        addressEntity.setAdd2("rue des poulpes");
        addressEntity.setAdd6("34000 Montpellier");

        InvoiceInformationEntity invoiceInformationEntity = new InvoiceInformationEntity();
        invoiceInformationEntity.setInvoicePeriodicityLabel("periodicity");
        invoiceInformationEntity.setInvoiceMode("invoiceMode");
        invoiceInformationEntity.setBosco("bosco");
        invoiceInformationEntity.setDedicatedInvoiceFlag(true);
        invoiceInformationEntity.setInArrearsInvoiceFlag(false);
        invoiceInformationEntity.setInvoiceAddressNumber("5");
        invoiceInformationEntity.setPaymentMeans("paymentMeans");
        invoiceInformationEntity.setPaymentPeriod("paymentPeriod");
        invoiceInformationEntity.setRum("rum");
        invoiceInformationEntity.setVatLiabilityFlag(true);
        invoiceInformationEntity.setAddressFacturation(addressEntity);

        ContractVersionEntity versionEntity = new ContractVersionEntity();
        versionEntity.setAmendmentNumber(2);
        versionEntity.setContract(contract);
        versionEntity.setInvoiceInformationEntity(invoiceInformationEntity);
        versionEntity.setValuedOffer(valuedOfferEntity);
        versionEntity.setIdContract(1L);
        versionEntity.setRevisionNumber(1);
        versionEntity.setValidityStartDatetime(Instant.now());
        versionEntity.setValidityEndDatetime(Instant.now());
        versionEntity.setStatus(ContractStatusEnum.VALIDE);
        versionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        versionEntity.setTerminationDatetime(Instant.now());
        versionEntity.setTerm("10");
        versionEntity.setCategory("category");
        versionEntity.setParentContractNumber("0-1");
        versionEntity.setParentAmendmentNumber(0);
        versionEntity.setIdValuedOffer(1L);
        versionEntity.setIdInvoiceInformation(1L);

        contract.setContractVersionEntities(List.of(versionEntity));

        return versionEntity;
    }

    public static LegalPersonEntity generateLegalPersonEntity() {
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(3L);
        legalPersonEntity.setCustAccNumber(1111111);
        legalPersonEntity.setCompName("my company");
        legalPersonEntity.setBrandName("my brand");
        legalPersonEntity.setBusinessTeamId(1);
        legalPersonEntity.setBusinessTeamLongName("team");

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setIdAddress(6L);
        addressEntity.setAddressType(AddressType.PRINCIPALE);
        addressEntity.setName1("chez lui");
        addressEntity.setAdd2("rue des calamars");
        addressEntity.setAdd6("34000 Montpellier");

        AddressEntity invoiceAddress = new AddressEntity();
        invoiceAddress.setIdAddress(5L);
        invoiceAddress.setAddressType(AddressType.FACTURATION);
        invoiceAddress.setAddressIdRefPM("5");
        invoiceAddress.setName1("chez moi");
        invoiceAddress.setAdd2("rue des poulpes");
        invoiceAddress.setAdd6("34000 Montpellier");

        legalPersonEntity.setAddressEntityList(List.of(addressEntity, invoiceAddress));
        return legalPersonEntity;
    }

    public static MandateEntity generateMandateEntity() {
        MandateEntity mandateEntity = new MandateEntity();
        mandateEntity.setIban("IBAN");
        mandateEntity.setRum("rum");
        mandateEntity.setBic("bic");

        return mandateEntity;
    }

    public static InvoiceInformationEntity generateInvoice() {
        return new InvoiceInformationEntity()
                .setIdAddressInvoice(1L);
    }

    public static ContractOpencell generateContractOpencell() {
        ContractInformation contractInformation = ContractInformation.newBuilder()
                .setContractNumber("D-TEST")
                .setType("Aff")
                .setSubType("Aff")
                .setEffectiveDateTime("2025-03-19T00:00:00Z")
                .setSignatureDateTime("2025-03-19T00:00:00Z")
                .setRenewalMode("renewal")
                .build();

        InvoiceInformation invoiceInformation = InvoiceInformation.newBuilder()
                .setName1("La Poste")
                .setVatInformation(new VATInformation())
                .build();

        OfferInformation offerInformation = OfferInformation.newBuilder()
                .setOpsId(3055)
                .setOpsVersion("1")
                .setOpsCode("3055")
                .build();

        ContractVersionInformation contractVersionInformation =
                ContractVersionInformation.newBuilder().build();

        PaymentInformation paymentInformation =
                PaymentInformation.newBuilder().build();

        FinancialSecurityInformation financialSecurityInformation =
                FinancialSecurityInformation.newBuilder().build();

        return ContractOpencell.newBuilder()
                .setContractInformation(contractInformation)
                .setContractVersionInformation(contractVersionInformation)
                .setInvoiceInformation(invoiceInformation)
                .setPaymentInformation(paymentInformation)
                .setFinancialSecurityInformation(financialSecurityInformation)
                .setOfferInformation(offerInformation)
                .build();
    }
}
