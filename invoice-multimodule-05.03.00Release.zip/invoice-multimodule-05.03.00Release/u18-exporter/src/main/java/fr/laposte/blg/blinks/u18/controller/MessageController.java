package fr.laposte.blg.blinks.u18.controller;



import fr.laposte.blg.blinks.u18.service.FileWriterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import fr.laposte.bscc.avro.compteconsommateur.Consommateur;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/message")
@Profile("mar-sdev|mar-srec|sloc")
public class MessageController {

    @Autowired
    private KafkaTemplate<String, Consommateur> kafkaTemplate;

    @Autowired
    private FileWriterService fileWriterService;

    @Value("${module-config.consumers.topic}")
    private String topic;


    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public void send(@RequestBody Consommateur value) {
        this.kafkaTemplate.send(topic, value.getContract().getContractInfo().getContractNumber().toString(), value);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public void generate() {
        this.fileWriterService.exportPendingMessagesToNdjson("/opt/app/transfer");
    }
}
