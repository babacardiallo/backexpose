export class OffresRefops {
    codeOps?: string;
    nameOps?: string;
    activationDate?: number;

}