import { Component, ViewChild } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { CalendarView } from 'angular-calendar';
import { filter } from 'rxjs';
import { environment } from '../../environments/environment';
import { CalendarViewComponent } from './components/calendar-view/calendar-view.component';
import { DailySupervisionComponent } from './components/daily-supervision/daily-supervision.component';
import { FileTransferComponent } from './components/file-transfer/file-transfer.component';
import { MonthViewComponent } from './components/month-view/month-view.component';
import { CalendarRequest } from './models/calendar-request';

@Component({
    selector: 'app-supervision',
    templateUrl: './supervision.component.html',
    styleUrls: ['./supervision.component.scss'],
    standalone: false
})
export class SupervisionComponent {
  appName = environment.appName;
  selected: Date  = new Date();
  view: CalendarView = CalendarView.Month;
  displayText: string  = 'Vous etes en vue jour. Cliquez pour passer en vue mois';
  displayMonthMode: boolean = false;
  @ViewChild('calendarView') calendarViewCmp!: CalendarViewComponent;
  @ViewChild('dailyCmp') dailyCmp!: DailySupervisionComponent;
  @ViewChild('fileTranfer') fileTranferCmp!: FileTransferComponent;
  @ViewChild('monthlyCmp') monthlyCmp!: MonthViewComponent;

  constructor(
    private router: Router,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.updateTitle();
    this.router.events
      .pipe(filter((event: any) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateTitle();
      });
  }

  private updateTitle() {
    this.titleService.setTitle("Factura : Supervision Exports");

  }
  onMonthChange(data: CalendarRequest) {
    this.selected = data.date;
    this.calendarViewCmp.getMonthlyTreatment(data.date);
    if(this.displayMonthMode) {
      this.monthlyCmp.getMonthlyTreatment(data.date);
      this.fileTranferCmp.callFileTransferStatusMonthly(data.date);
    } else {
      this.dailyCmp.getDalilyListTreatment(data.date);
      this.fileTranferCmp.callFileTransferStatus(data.date);
    }

  }

  onDayClicked(data: Date){
    this.selected = data;
    this.displayMonthMode = false;
    setTimeout(() => {
      this.dailyCmp.getDalilyListTreatment(data);
      this.fileTranferCmp.callFileTransferStatus(data);
    }, 500);
  }

  onModeChange(event: MatSlideToggleChange){
    if(this.displayMonthMode){
      this.displayText = 'Vous etes en vue mois. Cliquez pour passer en vue jour';
      this.fileTranferCmp.callFileTransferStatusMonthly(this.selected);
    } else {
      this.displayText = 'Vous etes en vue jour. Cliquez pour passer en vue mois';
      this.fileTranferCmp.callFileTransferStatus(this.selected);
    }
    
  }

  getDisplayedMonth(): string {
    const displayedDate =  new Intl.DateTimeFormat('fr-FR', { month: 'long' }).format(this.selected) + " " + this.selected.getFullYear();
    return displayedDate.toLocaleUpperCase();
  }

}