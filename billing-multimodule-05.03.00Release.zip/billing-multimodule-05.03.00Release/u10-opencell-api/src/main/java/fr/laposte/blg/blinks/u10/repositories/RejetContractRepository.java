package fr.laposte.blg.blinks.u10.repositories;


import fr.laposte.blg.blinks.u10.entities.RejetContract;
import fr.laposte.blg.blinks.u10.entities.RejetContractWithId;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@CrossOrigin
@RepositoryRestResource(collectionResourceRel = "rejetContracts", path = "rejetcontracts")
@Primary
public interface RejetContractRepository extends JpaRepository<RejetContract, UUID> {

    @RestResource()
    RejetContractWithId findAllById(UUID id);

    @Query("SELECT rjc FROM RejetContract rjc WHERE (CAST(rjc.id AS text)) IN (SELECT MIN(CAST(rjcS.id AS text)) FROM RejetContract rjcS GROUP BY rjcS.errorCode)")
    List<RejetContract> getAllCodeError();

    @Query("""
            SELECT rjc FROM RejetContract rjc WHERE
             (rjc.errorDate BETWEEN :startDate AND :endDate)
             AND (rjc.status IN ('PENDING','FAILED'))
             AND (rjc.status = :status OR :status IS NULL OR :status='')
             AND (rjc.errorCode IN :errors OR :errors IS NULL)
             AND (CAST(rjc.id AS text) LIKE CONCAT('%',:filter,'%') OR
             rjc.contractNumber LIKE CONCAT('%',:filter,'%') OR
             rjc.custAccNumber LIKE CONCAT('%',:filter,'%') OR
             rjc.errorCode LIKE CONCAT('%',:filter,'%') OR
             rjc.errorMessage LIKE CONCAT('%',:filter,'%') OR
             rjc.offerCode LIKE CONCAT('%',:filter,'%') OR
             :filter IS NULL OR
             :filter='')""")
    Page<RejetContract> getAllByDateAndStatus(@Param("startDate") Instant startDate, @Param("endDate")Instant endDate, @Param("filter")String filter, @Param("status") String status, @Param("errors") String[] errors, @Param("pageable") Pageable pageable);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("UPDATE RejetContract rjc SET rjc.status='PENDING' where rjc.id = :id")
    int updateRejetContractStatusById (@Param("id") UUID id);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("UPDATE RejetContract rjc SET rjc.status='PENDING' where rjc.id IN :ids")
    int updateSelectedRejetContracts (@Param("ids") UUID[] ids);


    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("""
            UPDATE RejetContract rjc SET rjc.status='PENDING' WHERE
             (rjc.errorDate BETWEEN :startDate AND :endDate)
             AND (rjc.status = :status OR :status IS NULL OR :status='')
             AND (rjc.errorCode IN :errors OR :errors IS NULL)
             AND (CAST(rjc.id AS text) LIKE CONCAT('%',:filter,'%') OR
             rjc.contractNumber LIKE CONCAT('%',:filter,'%') OR
             rjc.custAccNumber LIKE CONCAT('%',:filter,'%') OR
             rjc.errorCode LIKE CONCAT('%',:filter,'%') OR
             rjc.errorMessage LIKE CONCAT('%',:filter,'%') OR
             :filter IS NULL OR
             :filter='')""")
    int updateFilteredRejetContracts(@Param("startDate") Instant startDate, @Param("endDate")Instant endDate, @Param("filter")String filter, @Param("status") String status, @Param("errors") String[] errors);

    @Query("""
            SELECT rjc FROM RejetContract rjc WHERE
             (rjc.errorDate BETWEEN :startDate AND :endDate)
             AND (rjc.status IN ('PENDING','FAILED'))
             AND (rjc.status = :status OR :status IS NULL OR :status='')
             AND (rjc.errorCode IN :errors OR :errors IS NULL)
             AND (CAST(rjc.id AS text) LIKE CONCAT('%',:filter,'%') OR
             rjc.contractNumber LIKE CONCAT('%',:filter,'%') OR
             rjc.custAccNumber LIKE CONCAT('%',:filter,'%') OR
             rjc.errorCode LIKE CONCAT('%',:filter,'%') OR
             rjc.errorMessage LIKE CONCAT('%',:filter,'%') OR
             :filter IS NULL OR
             :filter='')
             ORDER BY rjc.errorDate desc""")
    List<RejetContract> getExportedRejetContracts(@Param("startDate") Instant startDate, @Param("endDate")Instant endDate, @Param("filter")String filter, @Param("status") String status, @Param("errors") String[] errors);
}
