package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractVersionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.u14.controller.dto.ReplayOfferReportDto;
import fr.laposte.bscc.billing.avro.ActionEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class ReplayerSyncServiceTest {

    @InjectMocks
    private ReplayerSyncService replayerSyncService;

    @Mock
    private ContractService contractService;

    @Mock
    private ContractRepository contractRepository;

    @Mock
    private ContractVersionRepository contractVersionRepository;

    @Mock
    private OfferFilterRepository offerFilterRepository;

    @Mock
    private QueueService queueService;


    private ContractVersionEntity contractVersionEntity;

    private OfferFilterEntity offerFilterEntity;

    private ReplayOfferReportDto replayOfferReportDto;

    private ContractEntity contract;

    private  List<String> listOffers = new ArrayList<>();

    private QueueSynchronizationEntity queueSynchronizationEntity;

    @BeforeEach
    void setUp() {
        contract = new ContractEntity();
        contract.setContractNumber("D-123456-1");

        contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setAmendmentNumber(2);
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);

        contractVersionEntity.setContract(contract);
        contractVersionEntity.setIdContract(1111l);

        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("358");
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setContractNumber("D-123456-1");
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setValuedOffer(valuedOfferEntity);
        contractVersionEntity.setAmendmentNumber(2);
        offerFilterEntity = new OfferFilterEntity(0002l,"","");
        replayOfferReportDto = new ReplayOfferReportDto();
        replayOfferReportDto.setNbTotal(1);
        listOffers.add("002");

        queueSynchronizationEntity = new QueueSynchronizationEntity();

    }

    @Test
    void replayContractSynchronizationByOfferTest() {

        Mockito.when(offerFilterRepository.findFirstByOpsCode("002"))
            .thenReturn(Mono.just(offerFilterEntity));

        ContractVersionEntity[] array = {contractVersionEntity};
        Mockito.when(contractRepository.getContractVersionByOpsCode("002"))
            .thenReturn(Flux.fromArray(array));

        Mockito.when(contractService.save(contractVersionEntity))
            .thenReturn(Mono.just(contractVersionEntity));

        Mockito.when(queueService.enQueueContract(Mockito.anyString(), Mockito.any(), Mockito.any()))
            .thenReturn(Mono.just(queueSynchronizationEntity));

        Mockito.when(contractService.findContractByIdContract(Mockito.anyLong()))
                .thenReturn(Mono.just(contract));

        StepVerifier.create(replayerSyncService.replayContractSynchronizationByOffer(ActionEnum.create,Instant.now(), List.of("002"), new ReplayOfferReportDto()))
            .assertNext(
                x ->  { assertNotNull(x);
                    assertEquals(replayOfferReportDto.getNbTotal(), x.getNbTotal());
    })
            .verifyComplete();
    }
}


