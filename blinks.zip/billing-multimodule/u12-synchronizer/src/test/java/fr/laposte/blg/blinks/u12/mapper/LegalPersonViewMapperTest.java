package fr.laposte.blg.blinks.u12.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.u12.dto.AddressDTO;
import fr.laposte.blg.blinks.u12.dto.LegalPersonDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@Slf4j
@ActiveProfiles("test")
class LegalPersonViewMapperTest {

    @Autowired
    LegalPersonViewMapper legalPersonViewMapper;

    @Autowired
    ObjectMapper objectMapper;


    @Test
    void legalPersonDTOToLegalPersonEntity() throws JsonProcessingException {
        var legalPersonDtoJsoned = "{" +
                "    \"email\": null," +
                "    \"siret\": \"67980497100076\"," +
                "    \"active\": \"1\"," +
                "    \"cvatno\": \"FR13 679804971\"," +
                "    \"adresses\": [" +
                "        {" +
                "            \"add1\": \"DATA PRINT\"," +
                "            \"add2\": \"\"," +
                "            \"add3\": \"\"," +
                "            \"add4\": \"47 AVENUE LAKANAL\"," +
                "            \"add5\": \"\"," +
                "            \"add6\": \"33110 LE BOUSCAT\"," +
                "            \"add7\": \"\"," +
                "            \"addressType\": \"PRINCIPALE\"," +
                "            \"refpmAddressId\": \"1938943\"," +
                "            \"creationDateTime\": \"1999-08-02T00:00:00\"," +
                "            \"establishCountyCode\": null," +
                "            \"modificationDateTime\": \"2024-10-07T13:14:55.183Z\"" +
                "        }," +
                "        {" +
                "            \"add1\": \"DATA PRINT                            \"," +
                "            \"add2\": \"                                      \"," +
                "            \"add3\": \"                                      \"," +
                "            \"add4\": \"1 RUE DE L YSER                       \"," +
                "            \"add5\": \"                                      \"," +
                "            \"add6\": \"92210 ST CLOUD                        \"," +
                "            \"add7\": null," +
                "            \"addressType\": \"FACTURATION\"," +
                "            \"refpmAddressId\": \"94\"," +
                "            \"creationDateTime\": \"2007-01-30T11:48:00\"," +
                "            \"establishCountyCode\": null," +
                "            \"modificationDateTime\": \"2008-04-09T20:19:00\"" +
                "        }," +
                "        {" +
                "            \"add1\": \"DATA PRINT\"," +
                "            \"add2\": null," +
                "            \"add3\": null," +
                "            \"add4\": \"133 RUE DE SÈVRES\"," +
                "            \"add5\": null," +
                "            \"add6\": \"75006 PARIS\"," +
                "            \"add7\": null," +
                "            \"addressType\": \"PRESTATION\"," +
                "            \"refpmAddressId\": \"5743835\"," +
                "            \"creationDateTime\": \"2023-09-15T18:13:00\"," +
                "            \"establishCountyCode\": null," +
                "            \"modificationDateTime\": null" +
                "        }" +
                "    ]," +
                "    \"compName\": \"DATA PRINT\"," +
                "    \"brandName\": null," +
                "    \"custTypeCode\": \"0\"," +
                "    \"custAccNumber\": \"33\"," +
                "    \"legalNatureCode\": \"5499\"," +
                "    \"legalNatureName\": \"Société à responsabilité limitée (sans autre indication)\"," +
                "    \"establishZoneCode\": \"01\"," +
                "    \"marketingTypeCode\": \"B2B\"" +
                "}";
        LegalPersonDTO legalPersonDTO = objectMapper.readValue(legalPersonDtoJsoned, LegalPersonDTO.class);
//        log.info("AddressList {} ", legalPersonDTO.getAdresses().toString());

        LegalPersonEntity legalPersonEntity = legalPersonViewMapper.legalPersonDTOToLegalPersonEntity(legalPersonDTO);
        assertEquals(legalPersonEntity.getTypeLabel(), "privé");

    }

    @Test
    void addressDTOToAddressEntity() throws JsonProcessingException {

        String addressJsoned = "{" +
                "    \"add1\": \"DATA PRINT                            \"," +
                "    \"add2\": \"                                      \"," +
                "    \"add3\": \"                                      \"," +
                "    \"add4\": \"1 RUE DE L YSER                       \"," +
                "    \"add5\": \"                                      \"," +
                "    \"add6\": \"92210 ST CLOUD                        \"," +
                "    \"add7\": null," +
                "    \"addressType\": \"FACTURATION\"," +
                "    \"refpmAddressId\": \"94\"," +
                "    \"creationDateTime\": \"2007-01-30T11:48:00\"," +
                "    \"establishCountyCode\": null," +
                "    \"modificationDateTime\": \"2008-04-09T20:19:00\"" +
                "}";
        String addressJsoned2 = "{" +
                "    \"add1\": \"DATA PRINT                            \"," +
                "    \"add2\": \"                                      \"," +
                "    \"add3\": \"                                      \"," +
                "    \"add4\": \"2 RUE DE L YSER                       \"," +
                "    \"add5\": \"                                      \"," +
                "    \"add6\": \"93210 ST CLOUD                        \"," +
                "    \"add7\": null," +
                "    \"addressType\": \"FACTURATION\"," +
                "    \"refpmAddressId\": \"95\"," +
                "    \"creationDateTime\": \"2007-01-30T11:48:00\"," +
                "    \"establishCountyCode\": null," +
                "    \"modificationDateTime\": \"2008-04-09T20:19:00\"" +
                "}";
        AddressDTO addressDto = objectMapper.readValue(addressJsoned, AddressDTO.class);
        AddressEntity addressEntity = legalPersonViewMapper.addressDTOToAddressEntity(addressDto);
        log.info("AddressEntity json att : {}", addressEntity.getAddressJson());
        assertNotNull(addressEntity.getAddressJson());
        Assertions.assertEquals(addressEntity.getAddressType(), AddressType.FACTURATION);
    }
}