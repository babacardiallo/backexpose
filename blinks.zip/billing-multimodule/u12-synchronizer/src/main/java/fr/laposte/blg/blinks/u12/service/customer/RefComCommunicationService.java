package fr.laposte.blg.blinks.u12.service.customer;

import fr.laposte.blg.blinks.u12.dto.RefEquipeCommerciale;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

@Service
public interface RefComCommunicationService {

    Mono<RefEquipeCommerciale> fetchTeamCodeAndName(int coclico, LocalDate dateConsultation);

}
