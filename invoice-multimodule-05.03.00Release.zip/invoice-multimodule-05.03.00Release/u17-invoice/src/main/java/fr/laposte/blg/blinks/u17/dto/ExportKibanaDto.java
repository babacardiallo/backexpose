package fr.laposte.blg.blinks.u17.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportKibanaDto {
    private String exportInvoiceNumber;
    private String exportTreatment;
    private Long exportId;
    private String exportStatus;
    private String exportMessage;
    private String errorMessage;
    private String errorCode;

}
