package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface ValuedOfferRepository extends ReactiveCrudRepository<ValuedOfferEntity, Long> {

    Mono<ValuedOfferEntity> findByIdValuedOffer(Long idValuedOffer);
}
