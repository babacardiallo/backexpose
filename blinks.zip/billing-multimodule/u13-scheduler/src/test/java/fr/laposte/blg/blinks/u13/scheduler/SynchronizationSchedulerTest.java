package fr.laposte.blg.blinks.u13.scheduler;

import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.QueueMigrationService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueMigrationEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SynchronizationSchedulerTest {

    @Mock
    private QueueService queueSynchronizationService;
    @Mock
    private QueueMigrationService queueMigrationService;
    @Mock
    private SynchronizationSender synchronizationSender;
    @Mock
    private SchedulerService schedulerService;
    @Mock
    private ErrorLogService errorLogService;

    @InjectMocks
    private SynchronizationScheduler synchronizationScheduler;

    @Mock
    private QueueSynchronizationEntity queueSynchronizationEntity;
    @Mock
    private QueueMigrationEntity queueMigrationEntity;

    @Test
    void synchronizeContracts_shouldSynchronizeEligibleContracts() {
        when(queueSynchronizationEntity.getIdContract()).thenReturn(1L);
        when(queueSynchronizationEntity.getIdQueue()).thenReturn(1L);
        when(queueSynchronizationService.findEntitiesToSynchronizeImmediately()).thenReturn(Flux.just(queueSynchronizationEntity));
        when(schedulerService.isOfferOfContractEligibleForSynchronization(any())).thenReturn(Mono.just(true));
        when(queueSynchronizationService.deleteQueueSynchronizationById(any())).thenReturn(Mono.empty());
        when(synchronizationSender.sendQueuedItem(any())).thenReturn(Mono.just(queueSynchronizationEntity));
        when(errorLogService.purgeErrorOfSchedulerForOneContract(any())).thenReturn(Mono.empty());

        synchronizationScheduler.synchronizeContracts();

        verify(synchronizationSender, atLeastOnce()).sendQueuedItem(queueSynchronizationEntity);
        verify(errorLogService, atLeastOnce()).purgeErrorOfSchedulerForOneContract(1L);
    }

    @Test
    void synchronizeContracts_shouldDeleteNonEligibleContracts() {
        when(queueSynchronizationEntity.getIdContract()).thenReturn(1L);
        when(queueSynchronizationEntity.getIdQueue()).thenReturn(1L);
        when(queueSynchronizationService.findEntitiesToSynchronizeImmediately()).thenReturn(Flux.just(queueSynchronizationEntity));
        when(schedulerService.isOfferOfContractEligibleForSynchronization(any())).thenReturn(Mono.just(false));
        when(queueSynchronizationService.deleteQueueSynchronizationById(any())).thenReturn(Mono.empty());
        when(errorLogService.purgeErrorOfSchedulerForOneContract(any())).thenReturn(Mono.empty());

        synchronizationScheduler.synchronizeContracts();

        verify(queueSynchronizationService, atLeastOnce()).deleteQueueSynchronizationById(1L);
        verify(errorLogService, atLeastOnce()).purgeErrorOfSchedulerForOneContract(1L);
        verify(synchronizationSender, never()).sendQueuedItem(any());
    }

    @Test
    void migrateContracts_shouldMigrateContracts() {
        when(queueMigrationService.findQueueMigrationToMigrateByOffer()).thenReturn(Flux.just(queueMigrationEntity));
        when(synchronizationSender.sendQueuedMigrationItem(any())).thenReturn(Mono.just(queueMigrationEntity));
        when(queueMigrationService.deleteQueueMigrationById(1L)).thenReturn(Mono.empty());
        when(errorLogService.purgeErrorOfSchedulerForOneContract(any())).thenReturn(Mono.empty());
        when(queueMigrationEntity.getIdQueue()).thenReturn(1L);
        when(queueMigrationEntity.getIdContract()).thenReturn(1L);

        synchronizationScheduler.migrateContracts();


        verify(synchronizationSender, atLeastOnce()).sendQueuedMigrationItem(queueMigrationEntity);
        verify(queueMigrationService, atLeastOnce()).deleteQueueMigrationById(1L);
        verify(errorLogService, atLeastOnce()).purgeErrorOfSchedulerForOneContract(1L);
    }
}
