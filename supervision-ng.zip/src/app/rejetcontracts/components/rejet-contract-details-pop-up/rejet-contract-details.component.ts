import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { RejetContractDetail } from "../../models/rejet-contract-detail";
import { RejetContractTableModel } from "../../models/rejet-contract-table.model";
import { RejetContractService } from "../../service/rejet-contract.service";


@Component({
    selector: 'rejet-contract-details',
    templateUrl: './rejet-contract-details.component.html',
    styleUrls: ['./rejet-contract-detail.component.scss'],
    standalone: false
})
  
export class RejetContractDetailsComponent implements OnInit {

    rejetContract: any;

    rejetContractDetails: RejetContractDetail = new RejetContractDetail();

    name = 'RejetContractDetailsComponent';

    constructor(private rejetContractService: RejetContractService, private snackBar: MatSnackBar, private modalService: ModalService){
        
    }


    ngOnInit(): void {
        this.getRejetContractDetails(this.rejetContract.id);
    }


    getRejetContractDetails(id: string) {
        this.rejetContractService.getRejetContractDetails(id).subscribe({
            next: (response: any) => {
                this.rejetContractDetails = <RejetContractDetail>{
                    id: response.id,
                    meansCode: response.meansCode,
                    periodCode: response.invoicePeriodicityCode,
                    offset: response.offset,
                    partition: response.partition,
                    action: response.action,
                    kafkaMessage: JSON.parse(response.kafkaMessage)
                };
            },
            complete: () => {
            },

        })
    }


    replayRejetContract(rejetContract: RejetContractTableModel, e: Event) {
        if (rejetContract.status == 'FAILED') {
            let returnValue: number;
            this.rejetContractService.updateRejetContractPending(rejetContract.id!).subscribe({
                next: (response: number) => {
                    returnValue = response;
                },
                complete: () => {
                    if (returnValue == 1) {
                        this.snackBar.open("Le status du rejet " + rejetContract.id + " est passé à PENDING", 'Fermer', { duration: 5000 });
                        this.close();
                        this.rejetContractService.emitLoadRjc();
                    }
                    else {
                        this.snackBar.open("Une erreur a eu lieu lors du rejeu du rejet " + rejetContract.id + ". Veuillez réessayer", 'Fermer', { duration: 5000 });
                    }
                },
            })
        }
        else {
            this.snackBar.open("Le rejet " + rejetContract.id + ". est déjà au statut PENDING", 'Fermer', { duration: 5000 });
        }

    }

    close(){
        this.modalService.close(this.name);
    }

  }