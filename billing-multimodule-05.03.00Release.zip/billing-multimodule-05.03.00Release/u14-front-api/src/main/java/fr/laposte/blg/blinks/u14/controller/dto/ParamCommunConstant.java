package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ParamCommunConstant {

    public static final String PREFIX = "F-ELE24";
    public static final String TYPE = "Elections européennes 2024";
    public static final String DATE = "2024-01-01T00:00:00+00:00";
    public static final String CREATION_CHANNEL ="TV";
    public static final String SUPPORT = "PDF Signé";
    public static final String ZONE_DEPOT = "METROPOLE-CORSE-MONACO";
    public static final String ASSUJETTI_TVA = "1";
    public static final String PERIODICITE = "Mensuelle";
    public static final String RENEWAL_MODE = "Non applicable";
    public static final String MANAGEMENT_MODE = "Périodique";
    public static final String CONTRACT_VERSION_NUMBER = "1";
    public static final String AMENDMENT_NUMBER = "0";
    public static final String STATUS = "Valide";
    public static final String TERM = "12";
    public static final String CATEGORY = "Contrat Simple";
    public static final String CENTRALIZED_REVENUE_FLAG = "0";
    public static final String VAT_LIABILITY_FLAG = "1";
    public static final String TBA_CONTRACT_FLAG = "0";
    public static final String MODE = "Décentralisé";
    public static final String DEDICATED_INVOICE_FLAG = "1";
    public static final String IN_ARREARS_INVOICE_FLAG = "0";
    public static final String TYPE_INVOICE_TERM = "Standard";

}

