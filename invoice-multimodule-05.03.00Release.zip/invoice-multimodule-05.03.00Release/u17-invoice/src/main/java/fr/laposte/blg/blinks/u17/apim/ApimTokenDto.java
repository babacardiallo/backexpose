package fr.laposte.blg.blinks.u17.apim;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApimTokenDto implements Serializable {
    String access_token;
    String scope;
    String token_type;
    Long expires_in;
}
