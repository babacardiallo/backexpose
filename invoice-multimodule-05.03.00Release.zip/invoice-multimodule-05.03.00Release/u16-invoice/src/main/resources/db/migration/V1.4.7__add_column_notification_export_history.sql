ALTER TABLE export_history
    ADD COLUMN notification_status ENUM('NEW','CREATED','SENT','DISABLED','ERROR') not null default 'DISABLED',
    ADD COLUMN notification_uuid VARCHAR(36) default null,
    ADD COLUMN notification_error_code VARCHAR(32) default null,
    ADD COLUMN notification_error_message TEXT default null;