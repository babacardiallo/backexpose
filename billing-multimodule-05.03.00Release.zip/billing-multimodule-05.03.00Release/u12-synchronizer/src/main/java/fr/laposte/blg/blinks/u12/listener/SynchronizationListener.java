package fr.laposte.blg.blinks.u12.listener;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.constant.KibanaCustomField;
import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.u12.listener.exception.*;
import fr.laposte.blg.blinks.u12.dto.LogSynchro;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.billing.ContractConsolidated;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderRecord;
import reactor.kafka.sender.SenderResult;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

@Data
@Component
@Slf4j
@ConfigurationProperties(prefix = "fr.laposte.billing.synchronization.listener.canal-suez")
@ConditionalOnProperty(value = "fr.laposte.billing.synchronization.listener.activated", havingValue = "true")
@Profile("!test")
@RequiredArgsConstructor
public class SynchronizationListener {
    // Nom du topic à consommer
    String kafkaTopic;
    // Groupe de consommation
    String kafkaGroupId;
    @Value("${fr.laposte.topic.contractconsolidated}")
    private String topicContractConsolidated;

    private final KafkaSender<String, ContractConsolidated> contractConsolidatedKafkaSender;


    private final SynchronizationService synchronizationService;

    private final ErrorLogService errorLogService;

    private final QueueService queueService;

    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", kafkaTopic);
        log.info("Kafka groupId: {}", kafkaGroupId);
        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", kafkaTopic, kafkaGroupId);
    }

    @KafkaListener(groupId = "${fr.laposte.billing.synchronization.listener.canal-suez.kafka-group-id}", topics = "${fr.laposte.billing.synchronization.listener.canal-suez.kafka-topic}")

    public void onMessages(List<ConsumerRecord<String, Synchronization>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} contracts from topic '{}'", total, kafkaTopic);
        AtomicInteger errorCount = new AtomicInteger(0);
        try {
            Flux.fromIterable(records)
                    .concatMap(message -> {
                                log.info("Record received: key={}, topic={}, partition={}, offset={}",
                                        message.key(), message.topic(), message.partition(), message.offset());

                                return synchronizationService.readSynchronizationCommand(message.value())
                                        .onErrorResume(NoSynchronizationRequiredException.class, e -> {
                                            // Log and move to the next message
                                            log.info("Skipping synchronization as no synchronization is required for contract: {}", message.key());
                                            return Mono.empty();
                                        })
                                        .map(contractConsolidated -> SenderRecord.create(
                                                new ProducerRecord<>(this.topicContractConsolidated,
                                                        this.synchronizationService.getMessageKey(contractConsolidated),
                                                        contractConsolidated), contractConsolidated))
                                        .transform(this.contractConsolidatedKafkaSender::send)
                                        .flatMap(treatMessageAfterPublish())
                                        .onErrorResume(throwable -> {
                                            errorCount.incrementAndGet();
                                            log.error("Error processing contract key={}", message.key(), throwable);
                                            return Mono.empty();
                                        });
                            }
                    )
                    .then()
                    .block();

            if (errorCount.get() > 0) {
                log.warn("Batch processing failed with {} errors — retrying individually {} records ))",
                        errorCount.get(), total);
                retryIndividually(records, ack);
            } else {
                ack.acknowledge();
                log.info("Batch processed and acknowledged successfully");
            }
        } catch (Exception error) {
            log.error("Unexpected error during batch processing — retrying individually ({} record(s))", total, error);
            retryIndividually(records, ack);
        }
    }



    private void retryIndividually(List<ConsumerRecord<String, Synchronization>> records, Acknowledgment ack) {
        Flux.fromIterable(records)
                .concatMap(message -> synchronizationService.readSynchronizationCommand(message.value())
                        .flatMap(contractConsolidated ->
                                Mono.just(contractConsolidated)
                                        .doOnSuccess(c -> {
                                            log.info("Contract key: {} is acknowledged successfully", message.key());
                                            ack.acknowledge();
                                        })
                                        .map(c -> SenderRecord.create(
                                                new ProducerRecord<>(
                                                        topicContractConsolidated,
                                                        synchronizationService.getMessageKey(c),
                                                        c),
                                                c))
                        )
                        .transform(this.contractConsolidatedKafkaSender::send)
                        .flatMap(treatMessageAfterPublish())
                        .doOnError(e -> log.error("Error processing contract key={}", message.key(), e))
                        .onErrorResume(throwable -> Mono.empty())
                )
                .then()
                .block();
    }

    private Function<SenderResult<ContractConsolidated>, Publisher<Void>> treatMessageAfterPublish(){
        return contractConsolidatedSenderResult ->{
           Optional<Exception> optionalException = Optional.ofNullable(contractConsolidatedSenderResult.exception());
            Mono<ContractConsolidated> contractConsolidatedMono;
            Mono<ContractConsolidated> monoToReturn=null;
           if (optionalException.isPresent()) { //En cas d'erreur lors de la publication.
               var exception = optionalException.get();
               if (Objects.nonNull(contractConsolidatedSenderResult.correlationMetadata().getContractOpencell())
               ) {
                   if (Objects.nonNull(contractConsolidatedSenderResult.correlationMetadata().getCustomerOpencell())) {
                       monoToReturn = Mono.error(new SynchronizationPublishingUpdateContractException("Error after publishing contract (create): "
                               + exception.getMessage()
                               , exception
                               , contractConsolidatedSenderResult.correlationMetadata()
                               .getContractOpencell().getContractInformation().getContractNumber().toString()
                               , contractConsolidatedSenderResult.correlationMetadata().getContractOpencell()
                               .getContractVersionInformation().getAmendmentNumber()
                               , contractConsolidatedSenderResult.correlationMetadata().getContractOpencell()
                               .getContractVersionInformation().getVersionNumber()
                               ,contractConsolidatedSenderResult.correlationMetadata().getContractOpencell()
                               .getOfferInformation().getOpsCode().toString()
                               , CodeErrorEnum.U12007));
                   } else {
                       monoToReturn = Mono.error(new SynchronizationPublishingCreateContractException("Error after publishing contract : "
                               + exception.getMessage()
                               , exception
                               , contractConsolidatedSenderResult.correlationMetadata()
                               .getContractOpencell().getContractInformation().getContractNumber().toString()
                               , contractConsolidatedSenderResult.correlationMetadata().getContractOpencell()
                               .getContractVersionInformation().getAmendmentNumber()
                               , contractConsolidatedSenderResult.correlationMetadata().getContractOpencell()
                               .getContractVersionInformation().getVersionNumber()
                               ,contractConsolidatedSenderResult.correlationMetadata().getContractOpencell()
                               .getOfferInformation().getOpsCode().toString()
                               ,CodeErrorEnum.U12008));
                   }
               } else {
                   monoToReturn = Mono.error(new SynchronizationPublishingCustomerException("Error after publishing customer : "
                           + exception.getMessage()
                           , exception
                           , Long.parseLong(contractConsolidatedSenderResult.correlationMetadata()
                           .getCustomerOpencell().getCustomerInformation().getCustAccNumber().toString())
                           ,CodeErrorEnum.U12009
                   ));
               }
           }
           if(monoToReturn!=null){
               contractConsolidatedMono = monoToReturn;
           } else {
               contractConsolidatedMono = this.synchronizationService.markSynchronized(contractConsolidatedSenderResult.correlationMetadata(), contractConsolidatedSenderResult.recordMetadata());
           }

           return contractConsolidatedMono
                   .flatMap(contractConsolidated -> {
                       Mono<Void> whatToPurge = Mono.empty();
                       if (Objects.nonNull(contractConsolidated.getContractOpencell())) {
                           LogSynchro logSynchro = new LogSynchro();
                           logSynchro.setContractNumber(contractConsolidated.getContractOpencell().getContractInformation().getContractNumber().toString());
                           logSynchro.setAmendmentNumber(contractConsolidated.getContractOpencell().getContractVersionInformation().getAmendmentNumber());
                           logSynchro.setRevisionNumber(contractConsolidated.getContractOpencell().getContractVersionInformation().getVersionNumber());
                           logSynchro.setCustAccNumber(contractConsolidated.getCustomerOpencell() != null ? contractConsolidated.getCustomerOpencell().getCustomerInformation().getCustAccNumber().toString(): "");
                           logSynchro.setMessage("Fin de synchronisation");
                           ObjectMapper obj = new ObjectMapper();
                           obj.registerModule(new JavaTimeModule());
                           JsonNode nodeFin = obj.convertValue(logSynchro, JsonNode.class);
                           log.info(Markers.append(KibanaCustomField.CLEFS_FIN_SYNCHRO_CONTRACT, nodeFin), "[CONTRACT NUMBER: " + logSynchro.getContractNumber() + "] Fin Synchronization contract: {}, message: {}", logSynchro.getContractNumber(), logSynchro);
                           whatToPurge = whatToPurge
                                   .then(errorLogService.purgeErrorLogForOneContractVersion(
                                           contractConsolidated.getContractOpencell().getContractInformation().getContractNumber().toString()
                                           , contractConsolidated.getContractOpencell().getContractVersionInformation().getAmendmentNumber(),
                                           contractConsolidated.getContractOpencell().getContractVersionInformation().getVersionNumber()));

                       }

                       if (Objects.nonNull(contractConsolidated.getCustomerOpencell())) {
                           whatToPurge = whatToPurge.and(
                                   errorLogService.purgeErrorLogForOneLegalPersonByCoclico(Long.parseLong(
                                                   contractConsolidated.getCustomerOpencell().getCustomerInformation().getCustAccNumber().toString()),
                                           ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER)
                           );
                       }
                       return whatToPurge;
                   })
                   .onErrorResume(SynchronizationContractException.class, e -> errorLogService.findErrorEntityForThisContractVersion(e.getContractNumber(), e.getAmendmentNumber())
                           .flatMap(errorLogEntity -> {
                               errorLogEntity.setDateError(Instant.now());
                               errorLogEntity.setErrorMessage(e.getMessage());
                               errorLogEntity.setWorkflowStep(e.getWorkflowStepEnum());
                               errorLogEntity.setRevisionNumber(e.getRevisionNumber());
                               errorLogEntity.setStatus(Optional.ofNullable(e.getContractVersionEntity())
                                       .map(ContractVersionEntity::getStatus)
                                       .orElse(null));
                               errorLogEntity.setSubstatus(Optional.ofNullable(e.getContractVersionEntity())
                                       .map(ContractVersionEntity::getSubstatus)
                                       .orElse(null));
                               errorLogEntity.setCodeError(e.getCodeError());
                               return Mono.just(errorLogEntity);
                           })
                           .switchIfEmpty(Mono.defer(() -> {
                               ErrorLogEntity errorLog = ErrorLogEntity.builder()
                                       .workflowStep(e.getWorkflowStepEnum())
                                       .idContract(e.getIdContract())
                                       .errorMessage(e.getMessage())
                                       .amendmentNumber(e.getAmendmentNumber())
                                       .revisionNumber(e.getRevisionNumber())
                                       .contractNumber(e.getContractNumber())
                                       .status(Optional.ofNullable(e.getContractVersionEntity())
                                               .map(ContractVersionEntity::getStatus)
                                               .orElse(null))
                                       .substatus(Optional.ofNullable(e.getContractVersionEntity())
                                               .map(ContractVersionEntity::getSubstatus)
                                               .orElse(null))
                                       .codeError(e.getCodeError())
                                       .build();
                               return Mono.just(errorLog);

                           }))
                           .flatMap(errorLogEntity -> {
                               var action = e.getWorkflowStepEnum() == ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_PUBLISHING_CREATE_CONTRACT ? ActionEnum.create : ActionEnum.update;
                               ObjectMapper objectMapper = new ObjectMapper();
                               objectMapper.registerModule(new JavaTimeModule());
                               JsonNode node = objectMapper.convertValue(errorLogEntity, JsonNode.class);
                               log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CONTRACT, node), "Synchronization contract, Fatal Error : {}", errorLogEntity);
                               return errorLogService.logError(errorLogEntity)
                                       .and(queueService.enQueueContract(e.getContractNumber(), Instant.now(), action));
                           }))
                   .onErrorResume(SynchronizationPublishingCustomerException.class, e -> {
                       var errorLog = ErrorLogEntity.builder()
                               .workflowStep(e.getWorkflowStepEnum())
                               .custAccNumber(e.getCoclico())
                               .errorMessage(e.getMessage())
                               .codeError(e.getCodeError())
                               .build();
                       ObjectMapper objectMapper = new ObjectMapper();
                       objectMapper.registerModule(new JavaTimeModule());
                       JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                       log.error(Markers.append(KibanaCustomField.CLEFS_SYNCHRO_CUSTOMER, node), "Synchronization customer, Fatal Error : {}", errorLog);
                       return errorLogService.logError(errorLog)
                               .and(queueService.enQueueCustomerByCoclico(e.getCoclico().intValue(), Instant.now(), ActionEnum.update));
                   })
                   .onErrorResume(e -> {
                       log.error("Fatal Error : Unhandled error after publishing message to consolidated topic", e);
                       return Mono.empty();
                   });
       };
    }
}
