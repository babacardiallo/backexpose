package fr.laposte.blg.blinks.lib.common.repositories.organization;

import fr.laposte.blg.blinks.lib.common.entities.organization.OrganizationEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface OrganizationRepository extends ReactiveCrudRepository<OrganizationEntity, Long> {

    Mono<OrganizationEntity> findByCode(String code);

    Mono<OrganizationEntity> findByCodeRegate(String codeRegate);

}
