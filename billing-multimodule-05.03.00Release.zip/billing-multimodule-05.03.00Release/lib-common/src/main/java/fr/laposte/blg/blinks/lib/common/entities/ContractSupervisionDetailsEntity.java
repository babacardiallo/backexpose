package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table ("contract_supervision_details")
public class ContractSupervisionDetailsEntity {

    @Id
    private String id;

    @Column("contract_number")
    @NotBlank
    private String contractNumber;

    @Column ("amendment_number")
    private Integer amendmentNumber;

    @Column ("revision_number")
    private Integer revisionNumber;

    @Column("date_error")
    private Instant dateError;

    @Column("first_error_date")
    private Instant firstErrorDate;

    @Column("error_message")
    private String errorMessage;

    @Column("invoice_address_number")
    private String invoiceAddressNumber;

    @Column("dedicated_invoice_flag")
    private Boolean dedicatedInvoiceFlag;

    @Column("invoice_periodicity_label")
    private String invoicePeriodicityLabel;

    @Column("sending_support_label")
    private String sendingSupportLabel;

    @Column("payment_means")
    private String paymentMeans;

    @Column("rum")
    private String rum;

    @Column("cust_purchase_order_number")
    private String custPurchaseOrderNumber;

    @Column("contracting_cust_ref1")
    private String contractingCustRef;

    @Column("market_number")
    private String marketNumber;

    @Column("offset_num_consolidated")
    private String offsetConsolidated;

    @Column("partition_num_consolidated")
    private String partitionConsolidated;

    @Column("offset")
    private String offsetOdc;

    @Column("partition")
    private String partitionOdc;

    @Column("category")
    private String category;

}
