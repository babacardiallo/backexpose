package fr.laposte.blg.blinks.lib.common.entities;

public enum NotificationStatus {
    NEW, CREATED, SENT, DISABLED, ERROR
}
