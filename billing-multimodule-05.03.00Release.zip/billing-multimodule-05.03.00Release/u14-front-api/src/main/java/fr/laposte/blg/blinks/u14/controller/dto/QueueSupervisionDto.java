package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueueSupervisionDto {
    private Long id;
    private Long idContract;
    private Long idLegalPerson;
    private Instant dateSynchronizationExpected;
    private String action;
    private Boolean refcomReplay;
    private String contractNumber;
    private String opsCode;
    private String custAccNumber;
}
