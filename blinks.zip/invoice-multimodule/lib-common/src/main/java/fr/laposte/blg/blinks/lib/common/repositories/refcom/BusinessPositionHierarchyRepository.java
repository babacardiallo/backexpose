package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessPositionHierarchy;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessPositionHierarchyRepository extends ReactiveCrudRepository<BusinessPositionHierarchy, Long> {


    Mono<BusinessPositionHierarchy> findByBusinessPositionId(Long businessPositionId);

}
