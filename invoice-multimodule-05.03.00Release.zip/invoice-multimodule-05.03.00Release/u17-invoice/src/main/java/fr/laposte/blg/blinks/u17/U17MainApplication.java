package fr.laposte.blg.blinks.u17;

import fr.laposte.blg.blinks.lib.security.EnableInvoiceLibrarySecurity;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.reactive.config.EnableWebFlux;

@EnableWebFlux
@EnableScheduling
@SpringBootApplication
@EnableR2dbcRepositories({"fr.laposte.blg.blinks.lib.common.repositories", "fr.laposte.blg.blinks.u17.repository"})
@EntityScan
@OpenAPIDefinition(info = @Info(title = "u17-invoice", version = "1.0", description = "Documentation de l'api exposé par u17"))
@EnableInvoiceLibrarySecurity
public class U17MainApplication {

    public static void main(String[] args) {
        SpringApplication.run(U17MainApplication.class, args);
    }

    @GetMapping("/")
    public ResponseEntity<String> get() {
        return ResponseEntity.ok("Welcome in the u17 module of Factura");
    }
}
