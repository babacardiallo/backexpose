package fr.laposte.blg.blinks.u11.config.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import java.util.*;

@Configuration
@Slf4j
@Profile("!sloc")
public class KafkaListenerConfig {
    private final KafkaProperties kafkaProperties;
    @Value("${fr.laposte.keystore-location}")
    private String keystoreLocation;
    @Value("${fr.laposte.keystore-password}")
    private String keyStorePassword;

    public KafkaListenerConfig(KafkaProperties kafkaProperties) {
        this.kafkaProperties = kafkaProperties;
    }

    private Map<String, Object> baseConfigs() {
        log.debug("CREATE SSL CONFIG FOR CONNECTION FROM KAFKA BROKER");
        Map<String, Object> props = new HashMap<>(kafkaProperties.buildConsumerProperties());
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "JKS");
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLocation);
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keyStorePassword);
        props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "JKS");
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, keystoreLocation);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, keyStorePassword);
        props.put("schema.registry.ssl.keystore.type", "JKS");
        props.put("schema.registry.ssl.keystore.location", keystoreLocation);
        props.put("schema.registry.ssl.keystore.password", keyStorePassword);
        props.put("schema.registry.ssl.truststore.type", "JKS");
        props.put("schema.registry.ssl.truststore.location", keystoreLocation);
        props.put("schema.registry.ssl.truststore.password", keyStorePassword);
        return props;
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> stringValueConsumerFactory(){
        Map<String, Object> props = new HashMap<>(baseConfigs());
        props.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class);
        ConsumerFactory<String, String> consumerFactory = new DefaultKafkaConsumerFactory<>(props);
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.setBatchListener(true);
        return factory;
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, KafkaDeserializer> specificAvroValueConsumerFactory(){
        Map<String, Object> props = new HashMap<>(baseConfigs());
        props.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, KafkaDeserializer.class);
        ConsumerFactory<String, KafkaDeserializer> consumerFactory = new DefaultKafkaConsumerFactory<>(props);
        ConcurrentKafkaListenerContainerFactory<String, KafkaDeserializer> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.setConsumerFactory(consumerFactory);
        factory.setBatchListener(true);
        return factory;
    }



}
