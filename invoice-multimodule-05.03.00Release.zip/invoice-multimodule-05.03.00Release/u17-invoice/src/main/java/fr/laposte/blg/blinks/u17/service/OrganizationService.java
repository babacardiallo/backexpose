package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.entities.organization.OrganizationEntity;
import fr.laposte.blg.blinks.lib.common.repositories.organization.OrganizationRepository;
import fr.laposte.blg.blinks.u17.dto.organization.ImportOrganizationReportDto;
import fr.laposte.blg.blinks.u17.mapper.OrganizationMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@Slf4j
@Data
public class OrganizationService {

    private final OrganizationCommunicationService organizationCommunicationService;

    private final OrganizationRepository organizationRepository;
    private final OrganizationMapper organizationMapper;

    public static List<String> listActivities = Arrays.asList("COURRIER", "ELP");

    private final TransactionalOperator transactionalOperator;

    public Mono<OrganizationEntity> save(OrganizationEntity organizationEntity) {
        return organizationRepository.findByCodeRegate(organizationEntity.getCodeRegate())
                .switchIfEmpty(Mono.just(organizationEntity))
                .flatMap(organizationRepository::save)
                .as(transactionalOperator::transactional);
    }

    public Flux<OrganizationEntity> findAll() {
        return organizationRepository.findAll();
    }

    public Mono<OrganizationEntity> findByCodeRegate(String codeRegate) {
        return organizationRepository.findByCodeRegate(codeRegate)
                .onErrorMap(error -> new RuntimeException("Aucun établisement trouvé", error));
    }

    public Mono<OrganizationEntity> findByCode(String code) {
        return organizationRepository.findByCode(code)
                .onErrorMap(error -> new RuntimeException("Aucun établisement trouvé", error));
    }

    public Mono<ImportOrganizationReportDto> importAndUpdateAllEntities(Optional<LocalDate> fromDate) {
        AtomicInteger nbSuccess = new AtomicInteger();
        AtomicInteger nbErrors = new AtomicInteger();
        return organizationCommunicationService.fetchOrganizations(fromDate, listActivities)
                .map(organizationMapper::organizationDtoToOrganizationEntity)
                .flatMap(organizationEntity -> this.save(organizationEntity)
                        .doOnError((e) -> {
                            log.error("L'enregistrement de l'entité de code régate {} a échoué. Exception :{}",
                                    organizationEntity.getCodeRegate(), e.getMessage());
                            nbErrors.incrementAndGet();
                        })
                        .onErrorResume((e) -> Mono.empty())) //On transforme une erreur particulière sur un élément du flux
                // en elément vide pour ne pas bloquer la chaine de traitement pour le reste des éléments
                .doOnNext(organizationEntity -> nbSuccess.incrementAndGet())
                .count().map(nbTotal -> ImportOrganizationReportDto.builder()
                        .nbSuccess(nbSuccess.toString())
                        .nbWarnings(nbErrors.toString())
                        .nbTotal(nbTotal.toString())
                        .status(nbErrors.get() > 0 ? "WARNING" : "SUCCESS")
                        .build()
                );
    }

//    private boolean isValid(OrganizationDto organizationDto) {
//        return organizationDto.getRegateType().contains("PDC1")
//                || organizationDto.getRegateType().contains("PDC2")
//                || organizationDto.getRegateType().contains("PIC")
//                || organizationDto.getRegateType().contains("PPDC")
//                || organizationDto.getRegateType().contains("BP");
//    }
}
