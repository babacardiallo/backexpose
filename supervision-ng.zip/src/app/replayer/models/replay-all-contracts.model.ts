export class ReplayAllContractsParameters {
    method: string;
    date: Date;
}