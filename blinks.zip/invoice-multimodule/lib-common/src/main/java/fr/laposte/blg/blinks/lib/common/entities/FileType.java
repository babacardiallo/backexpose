package fr.laposte.blg.blinks.lib.common.entities;

public enum FileType {
    DOCAPOSTE, INFOCA, EQUINOX, REFCOM_BATCH
}
