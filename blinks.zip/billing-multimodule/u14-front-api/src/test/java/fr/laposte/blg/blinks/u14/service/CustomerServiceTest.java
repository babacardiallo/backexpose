package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionActivesEntity;
import fr.laposte.blg.blinks.lib.common.entities.CustomerSupervisionEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.AddressRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractSupervisionActivesRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.CustomerSupervisionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LegalPersonRepository;
import fr.laposte.blg.blinks.u14.controller.dto.CustomerPartialSupervisionDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Duration;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class CustomerServiceTest {

    @Mock
    private CustomerSupervisionRepository repository;
    @InjectMocks
    private CustomerService service;
    @Mock
    private AddressRepository addressRepository;
    @Mock
    private ContractSupervisionActivesRepository contractSupervisionActivesRepository;
    @InjectMocks
    private AddressService addressService;
    private CustomerSupervisionEntity partialPrune;
    private CustomerSupervisionEntity partialPoire;
    private AddressEntity firstAdress;
    private AddressEntity secondAdress;
    private ContractSupervisionActivesEntity firstContractSupervision;
    private ContractSupervisionActivesEntity secondContractVersion;

    @Mock
    private LegalPersonRepository legalPersonRepository;

    @BeforeEach
    void initData() {
        partialPrune = new CustomerSupervisionEntity("1",1, 1, "2", "B2B", "toto", "leboncoin", true, Instant.now(), Instant.now().minus(Duration.ofHours(1)), "1");
        partialPoire = new CustomerSupervisionEntity("2",2, 2, "4", "B2C", "titi", "leboncoin", true, Instant.now(), Instant.now().minus(Duration.ofHours(1)), "2");
        firstAdress = AddressEntity.builder()
                .idAddress(1L)
                .addressIdRefPM("test")
                .idLegalPerson(2L)
                .custAccNumber(3)
                .creationDatetime(Instant.now().minus(Duration.ofHours(1)))
                .modificationDatetime(Instant.now())
                .name1("TOTO")
                .add2("add2")
                .add3("add3")
                .add4("add4")
                .add5("add5")
                .add6("add6")
                .add7("add7")
                .addressJson("json")
                .addressType(AddressType.SIEGE)
                .build();

        secondAdress = AddressEntity.builder()
                .idAddress(11L)
                .addressIdRefPM("test2")
                .idLegalPerson(22L)
                .custAccNumber(33)
                .creationDatetime(Instant.now().minus(Duration.ofHours(2)))
                .modificationDatetime(Instant.now())
                .name1("TITO")
                .add2("add22")
                .add3("add33")
                .add4("add44")
                .add5("add55")
                .add6("add66")
                .add7("add77")
                .addressJson("json2")
                .addressType(AddressType.PRESTATION)
                .build();

        firstContractSupervision = new ContractSupervisionActivesEntity("106",
                "1",
                1L,
                0,
                6,
                "test",
                "substatus",
                1L,
                "type", "subtype",
                "3055",
                2L,
                "cip",
                true,
                Instant.now().minus(Duration.ofDays(5)),
                Instant.now().minus(Duration.ofDays(3)),
                Instant.now().minus(Duration.ofDays(2)),
                45,
                45);

        new ContractSupervisionActivesEntity("106",
                "2",
                1L,
                1,
                5,
                "test",
                "substatus2",
                1L,
                "type", "subtype",
                "3055",
                2L,
                "cip",
                true,
                Instant.now().minus(Duration.ofDays(6)),
                Instant.now().minus(Duration.ofDays(2)),
                Instant.now().minus(Duration.ofDays(1)),
                122,
                122);
    }

   @Test
    void getAllPartialsCustomersForTable_shouldReturnAllCustomer() {
       Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");

       Mockito.when(repository.findAllByDateErrorIsNotNullAndCustAccNumberTextLikeOrDateErrorIsNotNullAndTypeLikeOrDateErrorIsNotNullAndMarketTypeLikeOrDateErrorIsNotNullAndNameLikeOrDateErrorIsNotNullAndBrandLike(Mockito.any(PageRequest.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class)))
                .thenReturn(Flux.fromArray(new CustomerSupervisionEntity[]{partialPrune, partialPoire}));

        Mockito.when(repository.findAllByCustAccNumberTextLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(Mockito.any(PageRequest.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class)))
                .thenReturn(Flux.fromArray(new CustomerSupervisionEntity[]{partialPrune, partialPoire}));

       Mockito.when(repository.countElementByCriteria(Mockito.any(String.class)))
               .thenReturn(Mono.just(2L));

       Mockito.when(repository.countAllByCustAccNumberTextLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(Mockito.any(String.class)))
               .thenReturn(Mono.just(2L));

       Mockito.when(addressRepository.countByIdLegalPerson(Mockito.anyLong())).thenReturn(Mono.just(1L))
               .thenReturn(Mono.just(2L));


        StepVerifier.create(service.filterCustomer(false, PageRequest.of(0, 1, sortOrder), "filter"))
                .assertNext(customerPage -> {
                    assertNotNull(customerPage);

                    CustomerPartialSupervisionDto lg1 = customerPage.getContent().get(0);
                    CustomerPartialSupervisionDto lg2 = customerPage.getContent().get(1);

                    assertEquals(partialPrune.getIdLegalPerson(), lg1.getIdLegalPerson());
                    assertEquals(partialPrune.getCustAccNumber(), lg1.getCustAccNumber());
                    assertEquals(partialPrune.getType(), lg1.getType());
                    assertEquals(partialPrune.getMarketType(), lg1.getMarketType());
                    assertEquals(partialPrune.getName(), lg1.getName());
                    assertEquals(partialPrune.getBrand(), lg1.getBrand());
                    assertEquals(partialPrune.isSynchro(), lg1.isSynchro());
                    assertEquals(partialPrune.getDateLastSynchro(), lg1.getDateLastSynchro());
                    assertEquals(partialPrune.getDateError(), lg1.getDateError());

                    assertEquals(partialPoire.getIdLegalPerson(), lg2.getIdLegalPerson());
                    assertEquals(partialPoire.getCustAccNumber(), lg2.getCustAccNumber());
                    assertEquals(partialPoire.getType(), lg2.getType());
                    assertEquals(partialPoire.getMarketType(), lg2.getMarketType());
                    assertEquals(partialPoire.getName(), lg2.getName());
                    assertEquals(partialPoire.getBrand(), lg2.getBrand());
                    assertEquals(partialPoire.isSynchro(), lg2.isSynchro());
                    assertEquals(partialPoire.getDateLastSynchro(), lg2.getDateLastSynchro());
                    assertEquals(partialPoire.getDateError(), lg2.getDateError());
                })
                .verifyComplete();
    }


    @Test
    void getAddressByLegalPerson_shouldReturnAddress() {
        Mockito.when(addressRepository.findByIdLegalPerson(anyLong()))
                .thenReturn(Flux.fromArray(new AddressEntity[]{firstAdress, secondAdress}));
        StepVerifier.create(addressService.getAddress(anyLong()))
                .assertNext(address1 -> {
                    assertNotNull(address1);
                    assertEquals(firstAdress.getIdAddress(), address1.getIdAddress());
                    assertEquals(firstAdress.getAddressIdRefPM(), address1.getAddressIdRefPM());
                    assertEquals(firstAdress.getIdLegalPerson(), address1.getIdLegalPerson());
                    assertEquals(firstAdress.getCustAccNumber(), address1.getCustAccNumber());
                    assertEquals(firstAdress.getCreationDatetime(), address1.getCreationDatetime());
                    assertEquals(firstAdress.getModificationDatetime(), address1.getModificationDatetime());
                    assertEquals(firstAdress.getName1(), address1.getName1());
                    assertEquals(firstAdress.getAdd2(), address1.getAdd2());
                    assertEquals(firstAdress.getAdd3(), address1.getAdd3());
                    assertEquals(firstAdress.getAdd4(), address1.getAdd4());
                    assertEquals(firstAdress.getAdd5(), address1.getAdd5());
                    assertEquals(firstAdress.getAdd6(), address1.getAdd6());
                    assertEquals(firstAdress.getAdd7(), address1.getAdd7());
                    assertEquals(firstAdress.getAddressJson(), address1.getAddressJson());
                    assertEquals(firstAdress.getAddressType(), address1.getAddressType());
                })
                .assertNext(address2 -> {
                    assertNotNull(address2);
                    assertEquals(secondAdress.getIdAddress(), address2.getIdAddress());
                    assertEquals(secondAdress.getAddressIdRefPM(), address2.getAddressIdRefPM());
                    assertEquals(secondAdress.getIdLegalPerson(), address2.getIdLegalPerson());
                    assertEquals(secondAdress.getCustAccNumber(), address2.getCustAccNumber());
                    assertEquals(secondAdress.getCreationDatetime(), address2.getCreationDatetime());
                    assertEquals(secondAdress.getModificationDatetime(), address2.getModificationDatetime());
                    assertEquals(secondAdress.getName1(), address2.getName1());
                    assertEquals(secondAdress.getAdd2(), address2.getAdd2());
                    assertEquals(secondAdress.getAdd3(), address2.getAdd3());
                    assertEquals(secondAdress.getAdd4(), address2.getAdd4());
                    assertEquals(secondAdress.getAdd5(), address2.getAdd5());
                    assertEquals(secondAdress.getAdd6(), address2.getAdd6());
                    assertEquals(secondAdress.getAdd7(), address2.getAdd7());
                    assertEquals(secondAdress.getAddressJson(), address2.getAddressJson());
                    assertEquals(secondAdress.getAddressType(), address2.getAddressType());
                })
                .verifyComplete();
    }

    @Test
    @Disabled
    void getByCoclico_shouldReturnContractVersion() {
        Mockito.when(contractSupervisionActivesRepository.findByCustAccNumberBeforeSynchronisation(anyInt()))
                .thenReturn(Flux.fromArray(new ContractSupervisionActivesEntity[]{firstContractSupervision, secondContractVersion}));
        StepVerifier.create(service.getContractVersionByCustAccNumber(anyInt()))
                .assertNext(contractSupervision1 -> {
                    assertNotNull(contractSupervision1);
                    assertEquals(firstContractSupervision.getContractNumber(), contractSupervision1.getContractNumber());
                    assertEquals(firstContractSupervision.getAmendmentNumber(), contractSupervision1.getAmendmentNumber());
                    assertEquals(firstContractSupervision.getRevisionNumber(), contractSupervision1.getRevisionNumber());
                    assertEquals(firstContractSupervision.getSubtype(), contractSupervision1.getSubType());
                    assertEquals(firstContractSupervision.getIsSynchronized(), contractSupervision1.isSynchronized());
                    assertEquals(firstContractSupervision.getLastDateSynchronization(), contractSupervision1.getSynchronisationDate());
                    assertEquals(firstContractSupervision.getFirstErrorDate(), contractSupervision1.getFistDateError());
                    assertEquals(firstContractSupervision.getOpsCode(), contractSupervision1.getOpsCode());
                })
                .assertNext(contractSupervision2 -> {
                    assertNotNull(contractSupervision2);
                    assertEquals(secondContractVersion.getContractNumber(), contractSupervision2.getContractNumber());
                    assertEquals(secondContractVersion.getAmendmentNumber(), contractSupervision2.getAmendmentNumber());
                    assertEquals(secondContractVersion.getRevisionNumber(), contractSupervision2.getRevisionNumber());
                    assertEquals(secondContractVersion.getSubtype(), contractSupervision2.getSubType());
                    assertEquals(secondContractVersion.getIsSynchronized(), contractSupervision2.isSynchronized());
                    assertEquals(secondContractVersion.getLastDateSynchronization(), contractSupervision2.getSynchronisationDate());
                    assertEquals(secondContractVersion.getFirstErrorDate(), contractSupervision2.getFistDateError());
                    assertEquals(secondContractVersion.getOpsCode(), contractSupervision2.getOpsCode());
                }).verifyComplete();
    }
}
