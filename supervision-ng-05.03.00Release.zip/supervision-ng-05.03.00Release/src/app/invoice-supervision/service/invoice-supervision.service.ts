import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { InvoiceSupervisionDetailsModel } from '../models/invoice-supervision-details.model';
import { InvoiceSupervisionTable } from '../models/invoice-supervision-table.model';


@Injectable({
  providedIn: 'root',
})
export class InvoiceSupervisionService {
  ngUnsubscribe$ = new Subject<void>();

  public busService: Observable<boolean>;

  private _busService: Subject<boolean> = new Subject();

  constructor(private http: HttpClient) {
    this.busService = this._busService.asObservable();
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }),
  }



  getAllInvoiceSupervision(page: number, size: number, sort: string, order: string, invoiceNumbers: string[], inBlinks: boolean, outOfBlinks: boolean, isMultiSearch: boolean): Observable<any> {
    let queryParams = new HttpParams()
      .set("page", page)
      .set("size", size)
      .set("sort", sort)
      .set("order", order)
      .set("inBlinks", inBlinks)
      .set("outOfBlinks", outOfBlinks)
      .set("isMultiSearch", isMultiSearch)
      .set("invoiceNumber", invoiceNumbers.join(', '))
    return this.http.get<InvoiceSupervisionTable[]>(environment.API_INVOICE_SUPERVISION_ALL + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getInvoiceDetails(idInvoice: number, idsExport: number[]): Observable<any> {
    let queryParams = new HttpParams()
      .set("idsExport", idsExport.join());
    let finalUrl = environment.API_INVOICE_SUPERVISION_DETAILS + idInvoice + "/details?";
    return this.http.get<InvoiceSupervisionDetailsModel>(finalUrl + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }


}
