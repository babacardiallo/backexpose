package fr.laposte.blg.blinks.u11.mapper;

import MD.LatestValue.Address;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(classes = {AddressListenerMapper.class, AddressListenerMapperImpl_.class, AddressListenerMapperImpl.class})
class AddressListenerMapperTest {

    @Autowired
    private AddressListenerMapper addressListenerMapper;

    @Test
    void legalPersonToLegalPersonEntityCaseFTest() {
        Address address = new Address();
        address.setRefpmAdressId("184");
        address.setCustAccNumber("9851");
        address.setAddressType("F");
        address.setName1("MON ENTREPRISE");
        address.setAdd2("myAdd2");
        address.setAdd3("myAdd3");
        address.setAdd4("myAdd4");
        address.setAdd5("myAdd5");
        address.setAdd6("myAdd6");
        address.setAdd7("myAdd7");
        address.setCDateTime("2020-02-25T00:00:00");;
        address.setMDateTime("2020-02-25T13:04:00");

        AddressEntity addressEntity = this.addressListenerMapper.addressToAddressEntity(address);

        assertAll(() -> {
            assertEquals(address.getRefpmAdressId().toString(), addressEntity.getAddressIdRefPM());
            assertEquals(Integer.parseInt(address.getCustAccNumber().toString()), addressEntity.getCustAccNumber());
            assertEquals(AddressType.FACTURATION, addressEntity.getAddressType());
            assertEquals(address.getName1().toString(), addressEntity.getName1());
            assertEquals(address.getAdd2().toString(), addressEntity.getAdd2());
            assertEquals(address.getAdd3().toString(), addressEntity.getAdd3());
            assertEquals(address.getAdd4().toString(), addressEntity.getAdd4());
            assertEquals(address.getAdd5().toString(), addressEntity.getAdd5());
            assertEquals(address.getAdd6().toString(), addressEntity.getAdd6());
            assertEquals(address.getAdd7().toString(), addressEntity.getAdd7());
            assertEquals(address.getCDateTime().toString(), addressEntity.getCreationDatetime().atZone(ZoneId.of("Europe/Paris")).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            assertEquals(address.getMDateTime().toString(), addressEntity.getModificationDatetime().atZone(ZoneId.of("Europe/Paris")).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        });
    }

    @Test
    void legalPersonToLegalPersonEntityCasePTest() {
        Address address = new Address();
        address.setRefpmAdressId("184");
        address.setCustAccNumber("9851");
        address.setAddressType("P");
        address.setName1("MON ENTREPRISE");
        address.setAdd2("myAdd2");
        address.setAdd3("myAdd3");
        address.setAdd4("myAdd4");
        address.setAdd5("myAdd5");
        address.setAdd6("myAdd6");
        address.setAdd7("myAdd7");
        address.setCDateTime("2020-02-25T00:00:00");;
        address.setMDateTime("2020-02-25T13:04:00");

        AddressEntity addressEntity = this.addressListenerMapper.addressToAddressEntity(address);

        assertAll(() -> {
            assertEquals(address.getRefpmAdressId().toString(), addressEntity.getAddressIdRefPM());
            assertEquals(Integer.parseInt(address.getCustAccNumber().toString()), addressEntity.getCustAccNumber());
            assertEquals(AddressType.PRESTATION, addressEntity.getAddressType());
            assertEquals(address.getName1().toString(), addressEntity.getName1());
            assertEquals(address.getAdd2().toString(), addressEntity.getAdd2());
            assertEquals(address.getAdd3().toString(), addressEntity.getAdd3());
            assertEquals(address.getAdd4().toString(), addressEntity.getAdd4());
            assertEquals(address.getAdd5().toString(), addressEntity.getAdd5());
            assertEquals(address.getAdd6().toString(), addressEntity.getAdd6());
            assertEquals(address.getAdd7().toString(), addressEntity.getAdd7());
            assertEquals(address.getCDateTime().toString(), addressEntity.getCreationDatetime().atZone(ZoneId.of("Europe/Paris")).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            assertEquals(address.getMDateTime().toString(), addressEntity.getModificationDatetime().atZone(ZoneId.of("Europe/Paris")).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        });
    }

    @Test
    void toStringTest(){
        CharSequence charSequence = "1";
        assertEquals("1", addressListenerMapper.toString(charSequence));
    }
    @Test
    void asInstantTest(){
        String date = "2025-03-17T00:00:00+02:00";
        Instant instant = LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant();
        assertEquals(instant, addressListenerMapper.asInstant(date));
    }
}
