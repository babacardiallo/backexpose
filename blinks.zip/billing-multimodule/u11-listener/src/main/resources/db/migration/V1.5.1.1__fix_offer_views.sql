CREATE OR REPLACE VIEW offer_errors_view
AS
SELECT
        `er`.`contract_number` AS `contract_number`,
        `er`.`revision_number` AS `revision_number`,
        `er`.`amendment_number` AS `amendment_number`,
        `er`.`date_error` AS `date_error`,
        `er`.`first_error_date` AS `first_error_date`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        `cv`.`date_synchronization` AS `previous_date_synchronization`,
        `er`.`workflow_step` AS `workflow_step`,
        `er`.`error_message` AS `error_message`,
        `er`.`ops_code` AS `ops_code`
    FROM
        ((`error_log` `er`
        LEFT JOIN `contract` `c` ON ((`er`.`contract_number` = `c`.`contract_number`)))
        LEFT JOIN `contract_version` `cv` ON (((`c`.`id_contract` = `cv`.`id_contract`)
            AND (`er`.`amendment_number` = `cv`.`amendment_number`))))
    WHERE
        (`er`.`ops_code` IS NOT NULL);