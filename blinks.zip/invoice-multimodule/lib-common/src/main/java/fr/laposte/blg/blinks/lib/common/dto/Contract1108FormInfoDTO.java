package fr.laposte.blg.blinks.lib.common.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;

@Setter
@Getter
@Slf4j
@JsonPropertyOrder({
        "paymentCashLabel",
        "regateCode",
        "formNumber",
        "paidCashAmount",
        "paymentRef",
        "paymentDate"
})
public class Contract1108FormInfoDTO {
    String paymentCashLabel;
    String regateCode;
    String formNumber;
    Double paidCashAmount;
    String paymentRef;
    @JsonFormat(pattern = "dd/MM/yyyy")
    LocalDate paymentDate;
}
