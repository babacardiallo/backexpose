package fr.laposte.blg.blinks.u12.service.customer;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u12.okapi.OkapiServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class LegalPersonCommunicationServiceImplTest {

    private OkapiServiceImpl okapiService;
    private ObjectMapper objectMapper;
    private LegalPersonCommunicationServiceImpl legalPersonCommunicationService;

    @BeforeEach
    void setup() {
        okapiService = Mockito.mock(OkapiServiceImpl.class);
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false);
        legalPersonCommunicationService = new LegalPersonCommunicationServiceImpl(okapiService, objectMapper);
        legalPersonCommunicationService.setApiName("apiName");
        legalPersonCommunicationService.setEndpoint("/endpoint");
    }

    @Test
    void testMissingActiveField_ShouldThrowException() {
        int coclico = 12345;

        String jsonResponse = "{" +
                "  \"data\": {" +
                "    \"legalPersonView\": {" +
                "      \"data\": [" +
                "        {" +
                "          \"custAccNumber\": \"12345\"," +
                "          \"compName\": \"Company Name\"," +
                "          \"custTypeCode\": \"TYPE_CODE\"," +
                "          \"establishZoneCode\": \"ZONE_CODE\"" +
                "        }" +
                "      ]" +
                "    }," +
                "    \"legalPersonAddress\": {" +
                "      \"data\": []" +
                "    }" +
                "  }" +
                "}";

        Mockito.when(okapiService.get(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap()))
                .thenReturn(Mono.just(jsonResponse));

        StepVerifier.create(legalPersonCommunicationService.fetchLegalPerson(coclico))
                .expectErrorMatches(throwable -> throwable instanceof LegalPersonCommunicationException &&
                        throwable.getMessage().equals("Field 'active' is missing"))
                .verify();
    }

    @Test
    void testMissingName1Field_ShouldThrowException() {

        String jsonResponse = "{" +
                "    \"data\": {" +
                "        \"legalPersonView\": {" +
                "            \"paging\": {" +
                "                \"totalResults\": 1" +
                "            }," +
                "            \"data\": [" +
                "                {" +
                "                    \"custAccNumber\": \"33\"," +
                "                    \"compName\": \"DATA PRINT\"," +
                "                    \"brandName\": null," +
                "                    \"custTypeCode\": \"0\"," +
                "                    \"active\": \"1\"," +
                "                    \"establishZoneCode\": \"01\"," +
                "                    \"marketingTypeCode\": \"B2B\"," +
                "                    \"cvatno\": \"FR13 679804971\"," +
                "                    \"siret\": \"67980497100084\"," +
                "                    \"email\": null," +
                "                    \"legalNatureCode\": \"5499\"," +
                "                    \"legalNatureName\": \"Société à responsabilité limitée (sans autre indication)\"" +
                "                }" +
                "            ]" +
                "        }," +
                "        \"legalPersonAddress\": {" +
                "            \"paging\": {" +
                "                \"totalResults\": 4" +
                "            }," +
                "            \"data\": [" +
                "                {" +
                "                    \"refpmAddressId\": \"1938943\"," +
                "                    \"custAccNumber\": \"33\"," +
                "                    \"creationDateTime\": \"1999-08-02T00:00:00\"," +
                "                    \"modificationDateTime\": \"2024-11-04T11:32:59.883Z\"," +
                "                    \"add1\": null," +
                "                    \"add2\": \"\"," +
                "                    \"add3\": \"\"," +
                "                    \"add4\": \"69 AVENUE DU MARECHAL JUIN\"," +
                "                    \"add5\": \"\"," +
                "                    \"add6\": \"64200 BIARRITZ\"," +
                "                    \"add7\": \"\"," +
                "                    \"addressType\": \"PRINCIPALE\"" +
                "                }," +
                "                {" +
                "                    \"refpmAddressId\": null," +
                "                    \"custAccNumber\": null," +
                "                    \"creationDateTime\": \"2022-11-03\"," +
                "                    \"modificationDateTime\": \"2024-11-04T11:21:40\"," +
                "                    \"add1\": \"DATA PRINT\"," +
                "                    \"add2\": \"\"," +
                "                    \"add3\": \"\"," +
                "                    \"add4\": \"69 AVENUE DU MARECHAL JUIN\"," +
                "                    \"add5\": \"\"," +
                "                    \"add6\": \"64200 BIARRITZ\"," +
                "                    \"add7\": null," +
                "                    \"addressType\": \"SIEGE\"" +
                "                }," +
                "                {" +
                "                    \"refpmAddressId\": \"94\"," +
                "                    \"custAccNumber\": \"33\"," +
                "                    \"creationDateTime\": \"2007-01-30T11:48:00\"," +
                "                    \"modificationDateTime\": \"2008-04-09T20:19:00\"," +
                "                    \"add1\": \"DATA PRINT                            \"," +
                "                    \"add2\": \"                                      \"," +
                "                    \"add3\": \"                                      \"," +
                "                    \"add4\": \"1 RUE DE L YSER                       \"," +
                "                    \"add5\": \"                                      \"," +
                "                    \"add6\": \"92210 ST CLOUD                        \"," +
                "                    \"add7\": null," +
                "                    \"addressType\": \"FACTURATION\"" +
                "                }," +
                "                {" +
                "                    \"refpmAddressId\": \"5743835\"," +
                "                    \"custAccNumber\": \"33\"," +
                "                    \"creationDateTime\": \"2023-09-15T18:13:00\"," +
                "                    \"modificationDateTime\": null," +
                "                    \"add1\": \"DATA PRINT\"," +
                "                    \"add2\": null," +
                "                    \"add3\": null," +
                "                    \"add4\": \"133 RUE DE SÈVRES\"," +
                "                    \"add5\": null," +
                "                    \"add6\": \"75006 PARIS\"," +
                "                    \"add7\": null," +
                "                    \"addressType\": \"PRESTATION\"" +
                "                }" +
                "            ]," +
                "            \"errors\": null" +
                "        }" +
                "    }" +
                "}";

        Mockito.when(okapiService.get(Mockito.anyString(), Mockito.anyString(), Mockito.anyMap()))
                .thenReturn(Mono.just(jsonResponse));

        StepVerifier.create(legalPersonCommunicationService.fetchLegalPerson(33))
                .expectErrorMatches(throwable -> throwable instanceof LegalPersonCommunicationException &&
                        throwable.getMessage().equals("Field 'name1' (add1) is missing in address number 1938943"))
                .verify();
    }

}
