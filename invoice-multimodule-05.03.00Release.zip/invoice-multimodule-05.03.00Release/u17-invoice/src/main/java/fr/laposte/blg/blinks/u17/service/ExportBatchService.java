package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.u17.entities.BatchConfig;
import fr.laposte.blg.blinks.u17.repository.BatchConfigRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class ExportBatchService {

    @Autowired
    BatchConfigRepository batchConfigRepository;

    public List<BatchConfig> get() {

        //TODO creer qui fetch la table ExportBatch tableau 2
        List<BatchConfig> configList = batchConfigRepository.findAll()
                .filter(BatchConfig::isEnabled)
                .collectList().block();

        /*List<ExportBatch> batches = Arrays.asList(new ExportBatch("D",2, "D", true),
                new ExportBatch("I",3, "I", true),
                new ExportBatch("E",1, "E", true));*/

        return configList;
    }
}
