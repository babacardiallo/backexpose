import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClientsReplayerPopUpComponent } from './clients-replayer-pop-up.component';

describe('ClientsReplayerPopUpComponent', () => {
    let component: ClientsReplayerPopUpComponent;
    let fixture: ComponentFixture<ClientsReplayerPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ClientsReplayerPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ClientsReplayerPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
