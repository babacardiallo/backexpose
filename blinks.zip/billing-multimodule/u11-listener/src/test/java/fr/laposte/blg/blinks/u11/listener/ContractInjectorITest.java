package fr.laposte.blg.blinks.u11.listener;


import fr.laposte.blg.blinks.u11.config.ssl.SSLContextConfig;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;
import reactor.kafka.sender.SenderResult;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

@Slf4j
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ContractInjectorITest {

    String topic = "gk_contractFull_fakeLoc_v1";
    KafkaSender<String, gkContractFullOutV1> kafkaProducer;


    @BeforeAll
    public void initKafka() throws IOException, InterruptedException {
        Properties props = configuration();
        SenderOptions<String, gkContractFullOutV1> producerOptions = SenderOptions.create(props);
        kafkaProducer = KafkaSender.create(producerOptions);
    }

    Properties configuration() throws IOException {
        SSLContextConfig store = new SSLContextConfig();
        store.trustSSL();
        Properties props = new Properties();
        InputStream input = this.getClass()
            .getClassLoader()
//                    .getResourceAsStream("conf/kafka/local/kafka-sloc-cap.properties");
            .getResourceAsStream("kafka/local/kafka-sloc.properties");
        props.load(input);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
//        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, GenericAvroSerializer.class);
        // props.put("proxy.port", Integer.parseInt("8080"));
        return props;
    }


    public Mono<SenderResult<Integer>> publishContractLikeODC(String key, gkContractFullOutV1 contract) throws IOException, InterruptedException {
        ProducerRecord<String, gkContractFullOutV1> record = new ProducerRecord(topic, key, contract);
        SenderRecord<String, gkContractFullOutV1, Integer> message = SenderRecord.create(record, 1);
        return kafkaProducer.send(Mono.just(message))
            .next();
    }

    gkContractFullOutV1 createContract() throws IOException {

        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        gkContractFullOutV1 record = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());

        return record;

    }

    @Test
    public void testActiveManagedOffer() throws InterruptedException, IOException {
        var contract = createContract();
        var key = contract.getContract().getContractInformation().getContractNumber().toString();
        // WHEN the contract is published
        publishContractLikeODC(key, contract)
            .subscribe();
        Thread.sleep(5000);
    }
}