package fr.laposte.blg.blinks.u18.config;


import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import jakarta.persistence.EntityManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@EnableJpaRepositories(basePackageClasses = {CustomerAccountMessage.class})
@EnableTransactionManagement
@Slf4j
public class JpaConfig {



    @Value("${fr.laposte.datasource.url}")
    private String url;
    @Value("${fr.laposte.datasource.username}")
    private String username;
    @Value("${fr.laposte.datasource.password}")
    private String password;

    @Value("${fr.laposte.hibernate.format_sql}")
    private boolean format;
    @Value("${fr.laposte.hibernate.hbm2ddl.auto}")
    private String ddlAuto;
    @Value("${fr.laposte.hibernate.show_sql}")
    private boolean showSql;
    @Value("${fr.laposte.hibernate.dialect}")
    private String dialect;


    private static final String ENV_HIBERNATE_DIALECT = "hibernate.dialect";
    private static final String ENV_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
    private static final String ENV_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
    private static final String ENV_HIBERNATE_FORMAT_SQL = "hibernate.format_sql";



    private Environment env;

    @Bean
    public DataSource dataSource() {
       return new DriverManagerDataSource(
                url,
                username,
                password
        );
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource) {
        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
        emf.setDataSource(dataSource);
        emf.setPackagesToScan(CustomerAccountMessage.class.getPackage().getName());
        emf.setPersistenceProvider(new HibernatePersistenceProvider());
        emf.setJpaProperties(jpaProperties());
        return emf;
    }

    private Properties jpaProperties() {
        Properties extraProperties = new Properties();
        extraProperties.put(ENV_HIBERNATE_FORMAT_SQL, format);
        extraProperties.put(ENV_HIBERNATE_SHOW_SQL, showSql);
        extraProperties.put(ENV_HIBERNATE_HBM2DDL_AUTO, ddlAuto);
        extraProperties.put(ENV_HIBERNATE_DIALECT, dialect);
        return extraProperties;
    }

    @Primary
    @Bean(name="transactionManager")
    public PlatformTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }


}