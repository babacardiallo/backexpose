package fr.laposte.blg.blinks.u11.mapper;

import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class LegalPersonListenerDecorator implements LegalPersonListenerMapper {

    @Autowired
    @Qualifier("delegate")
    private LegalPersonListenerMapper delegate;


    @Override
    public AddressEntity legalPersonToAddressEntity(LegalPerson legalPerson) {
        AddressEntity addressEntity = this.delegate.legalPersonToAddressEntity(legalPerson);
        addressEntity.setAddressJson(legalPerson.toString());
        addressEntity.setAddressType(AddressType.PRINCIPALE);
        return addressEntity;
    }

}
