package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessPositionLinkTerritory;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessPositionLinkTerritoryRepository extends ReactiveCrudRepository<BusinessPositionLinkTerritory, Long> {

    @Query("SELECT * from refcom_business_position_link_territory WHERE business_position_id = :businessPositionId AND business_position_link_territory_start_date <= NOW() AND (business_position_link_territory_end_date IS NULL OR business_position_link_territory_end_date > NOW())")
    Mono<BusinessPositionLinkTerritory> findActiveLinkByBusinessPosiitonId(Long businessPositionId);


    Mono<BusinessPositionLinkTerritory> findByBusinessPositionLinkTerritoryId(Long businessPositionLinkTerritoryId);
}
