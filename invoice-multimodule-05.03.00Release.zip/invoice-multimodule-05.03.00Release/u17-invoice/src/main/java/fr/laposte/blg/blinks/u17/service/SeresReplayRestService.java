package fr.laposte.blg.blinks.u17.service;


import fr.laposte.blg.blinks.lib.common.entities.SeresReplaySupervision;
import fr.laposte.blg.blinks.lib.common.repositories.SeresReplayEntityRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SeresReplaySupervisionRepository;
import fr.laposte.blg.blinks.u17.dto.SeresReplayDto;
import fr.laposte.blg.blinks.u17.mapper.SeresReplayMapper;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@Data
public class SeresReplayRestService {

    private final SeresReplayEntityRepository seresReplayEntityRepository;
    private final SeresReplaySupervisionRepository seresReplaySupervisionRepository;

    private final SeresReplayMapper seresReplayMapper;

    public Flux<Integer> getAllCodeErrors(){
        return seresReplayEntityRepository.getAllCodeErrors();
    }

    public Mono<Page<SeresReplayDto>> getAllSeresReplay(Instant startDate, Instant endDate, List<String> errorCodes, String filter, boolean noPrintableOnly, Pageable pageable){
        if(!filter.isEmpty()){
            filter = "%" + filter + "%";
        }
        Flux<SeresReplaySupervision> seresReplaySupervisionFlux;
        Mono<Long> totalMono;
        if(filter.isEmpty() && errorCodes.isEmpty()){
            seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEquals(startDate, endDate,"Non", pageable )
                    :seresReplaySupervisionRepository.findAllByErrorDateBetween(startDate, endDate, pageable);

            totalMono = noPrintableOnly ? seresReplaySupervisionRepository.countAllByErrorDateBetweenAndPrintFlagEquals(startDate, endDate, "Non")
                    :seresReplaySupervisionRepository.countAllByErrorDateBetween(startDate, endDate);

        } else {
            if(!filter.isEmpty() && !errorCodes.isEmpty()){
                seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLike(startDate, endDate, errorCodes, "Non", filter, startDate, endDate, errorCodes,"Non", filter,  pageable)
                        :seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(startDate, endDate, errorCodes, filter, startDate, endDate, errorCodes, filter,  pageable);

                totalMono = noPrintableOnly ? seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLike(startDate, endDate, errorCodes,"Non", filter, startDate, endDate, errorCodes,"Non", filter)
                        :seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(startDate, endDate, errorCodes, filter, startDate, endDate, errorCodes, filter);
            } else {
                if(filter.isEmpty()){
                    seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEquals(startDate, endDate, errorCodes, "Non", pageable)
                            :seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeIn(startDate, endDate, errorCodes, pageable);

                    totalMono = noPrintableOnly ? seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEquals(startDate, endDate, errorCodes, "Non")
                            :seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeIn(startDate, endDate, errorCodes);

                } else {
                    seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLike(startDate, endDate, "Non", filter, startDate, endDate, "Non", filter, pageable)
                            :seresReplaySupervisionRepository.findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(startDate, endDate, filter, startDate, endDate, filter, pageable);

                    totalMono = noPrintableOnly ? seresReplaySupervisionRepository.countAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLike(startDate, endDate, "Non", filter, startDate, endDate, "Non", filter)
                            :seresReplaySupervisionRepository.countAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(startDate, endDate, filter, startDate, endDate, filter);
                }
            }

        }

        return  seresReplaySupervisionFlux
                .map(seresReplayMapper::seresReplayEntityToSeresReplayDto)
                .collectList()
                .zipWith(totalMono)
                .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
    }

    public Mono<SeresReplayDto> getSeresReplayById(Long id){
        return seresReplaySupervisionRepository.findById(id).map(seresReplayMapper::seresReplayEntityToSeresReplayDto);
    }


    public Flux<SeresReplayDto> exportAllSeresReplay(Instant startDate, Instant endDate, List<String> errorCodes, String filter, boolean noPrintableOnly){
        if(!filter.isEmpty()){
            filter = "%" + filter + "%";
        }
        Flux<SeresReplaySupervision> seresReplaySupervisionFlux;
        if(filter.isEmpty() && errorCodes.isEmpty()){
            seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEqualsOrderByErrorDateDesc(startDate, endDate, "Non")
                    :seresReplaySupervisionRepository.findAllByErrorDateBetweenOrderByErrorDateDesc(startDate, endDate);


        } else {
            if(!filter.isEmpty() && !errorCodes.isEmpty()){
                seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLikeOrderByErrorDateDesc(startDate, endDate, errorCodes,"Non", filter, startDate, endDate, errorCodes,"Non", filter)
                        :seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLikeOrderByErrorDateDesc(startDate, endDate, errorCodes, filter, startDate, endDate, errorCodes, filter);
            } else {
                if(filter.isEmpty()){
                    seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsOrderByErrorDateDesc(startDate, endDate, errorCodes, "Non")
                            :seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInOrderByErrorDateDesc(startDate, endDate, errorCodes);

                } else {
                    seresReplaySupervisionFlux = noPrintableOnly ? seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLikeOrderByErrorDateDesc(startDate, endDate, "Non", filter, startDate, endDate, "Non", filter)
                            :seresReplaySupervisionRepository.findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLikeOrderByErrorDateDesc(startDate, endDate, filter, startDate, endDate, filter);

                }
            }

        }
        return  seresReplaySupervisionFlux
                .map(seresReplayMapper::seresReplayEntityToSeresReplayDto);
    }
}
