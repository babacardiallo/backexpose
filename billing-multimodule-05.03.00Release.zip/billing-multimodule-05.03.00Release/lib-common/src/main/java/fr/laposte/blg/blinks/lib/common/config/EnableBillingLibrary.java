package fr.laposte.blg.blinks.lib.common.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@ComponentScan(basePackages = "fr.laposte.blg.blinks.lib")
@EnableR2dbcRepositories(basePackages = "fr.laposte.blg.blinks.lib.common.entities.repositories")
public @interface EnableBillingLibrary {
}
