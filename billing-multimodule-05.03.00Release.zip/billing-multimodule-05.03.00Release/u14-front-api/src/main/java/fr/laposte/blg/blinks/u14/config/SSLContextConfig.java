package fr.laposte.blg.blinks.u14.config;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import jakarta.annotation.PostConstruct;
import javax.net.ssl.*;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Objects;


@Slf4j
@Data
@Configuration
public class SSLContextConfig {
    WebClient.Builder builder = null;

    @PostConstruct
    public void trustSSL() {
        try {
            log.debug("Create SSL context and trust all certificates");
            SSLContext sslContext = SSLContext.getInstance("SSL");
            TrustManager[] trustAll = new TrustManager[]{new TrustAllCertificates()};
            sslContext.init(null, trustAll, new java.security.SecureRandom());
            // Set trust all certificates context to HttpsURLConnection
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
        } catch (NoSuchAlgorithmException | KeyManagementException ex) {
            log.warn("Impossible de charger le magasin (trustore) des certificats des serveurs de confiance", ex);
        }
    }

    public WebClient.Builder insecureWebClient() {
        if (Objects.isNull(this.builder)) {
            try {
                SslContext sslContext = SslContextBuilder
                        .forClient()
                        .trustManager(InsecureTrustManagerFactory.INSTANCE)
                        .build();
                HttpClient httpClient = HttpClient.create()
                        .secure(sslContextSpec -> sslContextSpec.sslContext(sslContext));
                ClientHttpConnector httpConnector = new ReactorClientHttpConnector(httpClient);
                builder = WebClient.builder().clientConnector(httpConnector);
            } catch (SSLException e) {
                log.error("Création du client HTTP WebClient", e);
            }
        }
        return builder;
    }


    /**
     * Dummy class implementing X509TrustManager to trust all certificates
     */
    private static class TrustAllCertificates implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] certs, String authType) {
        }

        public void checkServerTrusted(X509Certificate[] certs, String authType) {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
    }
}

