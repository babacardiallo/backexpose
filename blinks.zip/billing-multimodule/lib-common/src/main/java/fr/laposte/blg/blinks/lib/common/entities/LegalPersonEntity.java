package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.List;

@Table("legal_person")
@Accessors(chain = true)
@Data
public class LegalPersonEntity {

    @Id
    @Column("id_legal_person")
    private Long idLegalPerson;

    @Column("cust_acc_number")
    private Integer custAccNumber;

    @Column("comp_name")
    private String compName;

    @Column("brand_name")
    private String brandName;

    @Column("type_code")
    private Integer typeCode;

    @Column("type_label")
    private String typeLabel;

    @Column("status")
    private String status;

    @Column("marketing_type_code")
    private String marketingTypeCode;

    @Column("establish_zone_code")
    private String establishZoneCode;

    @Column("vat_number")
    private String vatNumber;

    @Column("siret_code")
    private String siretCode;

    @Column("email")
    private String email;

    @Column("legal_nature_code")
    private String legalNatureCode;

    @Column("legal_nature_name")
    private String legalNatureName;

    @Column("is_synchronized")
    private boolean isSynchronized = false;

    @Column("date_synchronization")
    private Instant dateSynchronization;

    @Column("business_team_id")
    private Integer businessTeamId;

    @Column("business_team_long_name")
    private String businessTeamLongName;

    @Column("created")
    private Instant created;

    @Column("billing_typology")
    private String billingTypology;

    @Transient
    List<AddressEntity> addressEntityList;
}
