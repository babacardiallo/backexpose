package service;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceSupervisionRepository;
import fr.laposte.blg.blinks.u17.dto.InvoiceSupervsionDto;
import fr.laposte.blg.blinks.u17.service.InvoiceSupervisionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.mockito.InjectMocks;
import org.springframework.data.domain.Sort;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.r2dbc.core.RowsFetchSpec;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class InvoiceSupervisionServiceTest {

    @InjectMocks
    private InvoiceSupervisionService invoiceSupervisionService;
    @Mock
    private InvoiceSupervisionRepository invoiceSupervisionRepository;
    @Mock
    private ExportHistoryRepository exportHistoryRepository;
    @Mock
    private InvoiceMessageRepository invoiceMessageRepository;
    @Mock
    private DatabaseClient databaseClient;
    @Mock
    private DatabaseClient.GenericExecuteSpec executeSpec;
    @Mock
    private RowsFetchSpec rowsFetchSpec;

    List<InvoiceSupervision> invoiceSupervisions = new ArrayList<>();

    List<InvoiceSupervsionDto> invoiceSupervisionDtos = new ArrayList<>();

    InvoiceSupervision invoiceSupervision = new InvoiceSupervision(10L,
            "PF10", Instant.now(),
            10, "10",
            InvoiceStatusEnum.SUCCESS, InvoiceStatusEnum.FAILED, InvoiceStatusEnum.EXCLUDED,
            Instant.now(), 100L, Instant.now(), 101L, Instant.now(), 102L);

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
        invoiceSupervisionService = new InvoiceSupervisionService(invoiceSupervisionRepository, exportHistoryRepository, invoiceMessageRepository, databaseClient);
        InvoiceSupervision invoiceSupervision1 =
                new InvoiceSupervision(1L,
                        "PF0", Instant.now(),
                        1, "1",
                        InvoiceStatusEnum.SUCCESS, InvoiceStatusEnum.FAILED, InvoiceStatusEnum.EXCLUDED,
                        Instant.now(), 100L, Instant.now(), 101L, Instant.now(), 102L);
        InvoiceSupervision invoiceSupervision2 =
                new InvoiceSupervision(2L,
                        "PF1", Instant.now(),
                        2, "2",
                        InvoiceStatusEnum.NEW, InvoiceStatusEnum.SUCCESS, InvoiceStatusEnum.SUCCESS,
                        Instant.now(), 103L, Instant.now(), 104L, Instant.now(), 105L);
        invoiceSupervisions.add(invoiceSupervision1);
        invoiceSupervisions.add(invoiceSupervision2);
        InvoiceSupervsionDto invoiceSupervsionDto1 =
                InvoiceSupervsionDto.builder()
                        .idInvoice(1L)
                        .billrunId("1")
                        .created(Instant.now())
                        .client(1)
                        .invoiceNumber("PF00A1")
                        .build();
        InvoiceSupervsionDto invoiceSupervsionDto2 =
                InvoiceSupervsionDto.builder()
                        .idInvoice(2L)
                        .billrunId("2")
                        .created(Instant.now())
                        .client(2)
                        .invoiceNumber("PF00A2")
                        .build();
        invoiceSupervisionDtos.add(invoiceSupervsionDto1);
        invoiceSupervisionDtos.add(invoiceSupervsionDto2);
    }

    @Test
    void getAllByOnInvoiceNumberTest() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        when(this.invoiceSupervisionRepository.findAllByInvoiceNumber(any(Pageable.class), anyString())).thenReturn(Flux.just(this.invoiceSupervision));
        when(this.invoiceSupervisionRepository.countAllByInvoiceNumber(anyString())).thenReturn(Mono.just(1L));
        StepVerifier.create(this.invoiceSupervisionService.getAllByOnInvoiceNumber(PageRequest.of(0, 2, sortOrder), ""))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    assertEquals(1, invoiceResult.getTotalElements());
                    InvoiceSupervsionDto invoiceSupervsionDto = invoiceResult.getContent().get(0);
                    assertEquals(invoiceSupervision.getIdInvoice(), invoiceSupervsionDto.getIdInvoice());
                    assertEquals(invoiceSupervision.getInvoiceNumber(), invoiceSupervsionDto.getInvoiceNumber());
                    assertEquals(invoiceSupervision.getBillrunId(), invoiceSupervsionDto.getBillrunId());
                    assertEquals(invoiceSupervision.getClient(), invoiceSupervsionDto.getClient());
                    assertEquals(invoiceSupervision.getDocaposteExportStatus().toString(), invoiceSupervsionDto.getDocaposteExportStatus());
                    assertEquals(invoiceSupervision.getInfocaExportStatus().toString(), invoiceSupervsionDto.getInfocaExportStatus());
                    assertEquals(invoiceSupervision.getCoeurfinanceExportStatus().toString(), invoiceSupervsionDto.getCoeurfinanceExportStatus());
                    assertEquals(invoiceSupervision.getDocaposteExportId(), invoiceSupervsionDto.getDocaposteExportId());
                    assertEquals(invoiceSupervision.getInfocaExportId(), invoiceSupervsionDto.getInfocaExportId());
                    assertEquals(invoiceSupervision.getCoeurfinanceExportId(), invoiceSupervsionDto.getCoeurfinanceExportId());
                })
                .verifyComplete();
    }

    @Test
    void getAllByListOfInvoiceNumberTest() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        when(this.invoiceSupervisionRepository.findAllByInvoiceNumberIn(any(Pageable.class), any())).thenReturn(Flux.fromIterable(this.invoiceSupervisions));
        when(this.invoiceSupervisionRepository.countAllByInvoiceNumberIn(any())).thenReturn(Mono.just(2L));
        StepVerifier.create(this.invoiceSupervisionService.getAllByListOfInvoiceNumber(PageRequest.of(0, 2, sortOrder), List.of("")))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    assertEquals(2, invoiceResult.getTotalElements());
                    InvoiceSupervsionDto invoiceSupervsionDto1 = invoiceResult.getContent().get(0);
                    assertEquals(this.invoiceSupervisions.get(0).getInvoiceNumber(), invoiceSupervsionDto1.getInvoiceNumber());
                    assertEquals(this.invoiceSupervisions.get(0).getBillrunId(), invoiceSupervsionDto1.getBillrunId());
                    assertEquals(this.invoiceSupervisions.get(0).getClient(), invoiceSupervsionDto1.getClient());
                    assertEquals(this.invoiceSupervisions.get(0).getDocaposteExportStatus().toString(), invoiceSupervsionDto1.getDocaposteExportStatus());
                    assertEquals(this.invoiceSupervisions.get(0).getInfocaExportStatus().toString(), invoiceSupervsionDto1.getInfocaExportStatus());
                    assertEquals(this.invoiceSupervisions.get(0).getCoeurfinanceExportStatus().toString(), invoiceSupervsionDto1.getCoeurfinanceExportStatus());
                    assertEquals(this.invoiceSupervisions.get(0).getDocaposteExportId(), invoiceSupervsionDto1.getDocaposteExportId());
                    assertEquals(this.invoiceSupervisions.get(0).getInfocaExportId(), invoiceSupervsionDto1.getInfocaExportId());
                    assertEquals(this.invoiceSupervisions.get(0).getCoeurfinanceExportId(), invoiceSupervsionDto1.getCoeurfinanceExportId());
                    InvoiceSupervsionDto invoiceSupervsionDto2 = invoiceResult.getContent().get(1);
                    assertEquals(this.invoiceSupervisions.get(1).getInvoiceNumber(), invoiceSupervsionDto2.getInvoiceNumber());
                    assertEquals(this.invoiceSupervisions.get(1).getBillrunId(), invoiceSupervsionDto2.getBillrunId());
                    assertEquals(this.invoiceSupervisions.get(1).getClient(), invoiceSupervsionDto2.getClient());
                    assertEquals(this.invoiceSupervisions.get(1).getDocaposteExportStatus().toString(), invoiceSupervsionDto2.getDocaposteExportStatus());
                    assertEquals(this.invoiceSupervisions.get(1).getInfocaExportStatus().toString(), invoiceSupervsionDto2.getInfocaExportStatus());
                    assertEquals(this.invoiceSupervisions.get(1).getCoeurfinanceExportStatus().toString(), invoiceSupervsionDto2.getCoeurfinanceExportStatus());
                    assertEquals(this.invoiceSupervisions.get(1).getDocaposteExportId(), invoiceSupervsionDto2.getDocaposteExportId());
                    assertEquals(this.invoiceSupervisions.get(1).getInfocaExportId(), invoiceSupervsionDto2.getInfocaExportId());
                    assertEquals(this.invoiceSupervisions.get(1).getCoeurfinanceExportId(), invoiceSupervsionDto2.getCoeurfinanceExportId());

                })
                .verifyComplete();
    }

    @Test
    void getInvoiceDetails() throws IOException {
        String invoiceMessage = Files.readString(Paths.get("src/test/resources/invoiceMessage_corem.json"), Charset.defaultCharset());
        ExportHistoryEntity exportHistoryDoca = ExportHistoryEntity.builder()
                .fileName("blg3.ws")
                .transferStatus(TransferStatus.TRANSFERED)
                .fileSendDate(Instant.now())
                .fileType(FileType.DOCAPOSTE).build();
        ExportHistoryEntity exportHistoryCoeurfinance = ExportHistoryEntity.builder()
                .fileName("blg1.ep")
                .transferStatus(TransferStatus.FAILED)
                .fileSendDate(Instant.now())
                .fileType(FileType.COEURFINANCE).build();
        ExportHistoryEntity exportHistoryInfoca = ExportHistoryEntity.builder()
                .fileName("blg2.is")
                .transferStatus(TransferStatus.NEW)
                .fileSendDate(Instant.now())
                .fileType(FileType.INFOCA).build();

        when(invoiceMessageRepository.getMessage(anyLong())).thenReturn(Mono.just(invoiceMessage));
        when(exportHistoryRepository.findAllByIdExportIn(anyList())).thenReturn(Flux.just(exportHistoryInfoca, exportHistoryDoca, exportHistoryCoeurfinance));
        StepVerifier.create(this.invoiceSupervisionService.getInvoiceDetails(10L, new ArrayList<>()))
                .assertNext(invoiceDetailsDto -> {
                    assertNotNull(invoiceDetailsDto);
                    assertEquals("Papier", invoiceDetailsDto.getSupport());
                    assertEquals(exportHistoryDoca.getFileName(), invoiceDetailsDto.getDocaposteFileName());
                    assertEquals(exportHistoryDoca.getTransferStatus(), invoiceDetailsDto.getDocaposteTransferStatus());
                    assertEquals(exportHistoryDoca.getFileSendDate(), invoiceDetailsDto.getDocaposteTransfertDate());
                    assertEquals(exportHistoryCoeurfinance.getFileName(), invoiceDetailsDto.getCoeurfinanceFileName());
                    assertEquals(exportHistoryCoeurfinance.getTransferStatus(), invoiceDetailsDto.getCoeurfinanceTransferStatus());
                    assertEquals(exportHistoryCoeurfinance.getFileSendDate(), invoiceDetailsDto.getCoeurfinanceTransfertDate());
                    assertEquals(exportHistoryInfoca.getFileName(), invoiceDetailsDto.getInfocaFileName());
                    assertEquals(exportHistoryInfoca.getTransferStatus(), invoiceDetailsDto.getInfocaTransferStatus());
                    assertEquals(exportHistoryInfoca.getFileSendDate(), invoiceDetailsDto.getInfocaTransfertDate());
                    assertFalse(invoiceDetailsDto.isCredit());
                    assertTrue(invoiceDetailsDto.isPrintFlag());
                    assertFalse(invoiceDetailsDto.isOpencellPdf());
                    assertTrue(invoiceDetailsDto.isDedicated());
                    assertFalse(invoiceDetailsDto.isRefundable());
                    assertTrue(invoiceDetailsDto.isDownpayment());
                    assertNull(invoiceDetailsDto.getMappingError());
                })
                .verifyComplete();
    }

    @Test
    void getInvoiceDetails_failedMapping() {
        when(invoiceMessageRepository.getMessage(anyLong())).thenReturn(Mono.just("fakeMessage"));
        StepVerifier.create(this.invoiceSupervisionService.getInvoiceDetails(10L, new ArrayList<>()))
                .assertNext(invoiceDetailsDto -> {
                    assertNotNull(invoiceDetailsDto.getMappingError());
                })
                .verifyComplete();
    }

    @Test
    void getAllInAndOuOfBlinks() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        when(this.databaseClient.sql(anyString())).thenReturn(executeSpec);
        when(this.executeSpec.bind(anyString(), any())).thenReturn(executeSpec);
        when(this.executeSpec.bind(anyString(), any())).thenReturn(executeSpec);
        when(this.executeSpec.map(any(BiFunction.class))).thenReturn(rowsFetchSpec);
        when(this.rowsFetchSpec.all()).thenReturn(Flux.fromIterable(invoiceSupervisionDtos));
        when(this.rowsFetchSpec.one()).thenReturn(Mono.just(2L));

        StepVerifier.create(this.invoiceSupervisionService.getAllInvoicesInAndOutOfBlinks(List.of("PF00A1", "PF00A2"),PageRequest.of(0, 5, sortOrder), "invoiceNumber", "DESC"))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    assertEquals(2, invoiceResult.getTotalElements());
                    InvoiceSupervsionDto invoiceSupervsionDto = invoiceResult.getContent().get(0);
                    assertEquals(1L, invoiceSupervsionDto.getIdInvoice());
                    assertEquals("PF00A1", invoiceSupervsionDto.getInvoiceNumber());
                })
                .verifyComplete();
    }

    @Test
    void getAllOuOfBlinks() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        when(this.databaseClient.sql(anyString())).thenReturn(executeSpec);
        when(this.executeSpec.bind(anyString(), any())).thenReturn(executeSpec);
        when(this.executeSpec.bind(anyString(), any())).thenReturn(executeSpec);
        when(this.executeSpec.map(any(BiFunction.class))).thenReturn(rowsFetchSpec);
        when(this.rowsFetchSpec.all()).thenReturn(Flux.fromIterable(invoiceSupervisionDtos));
        when(this.rowsFetchSpec.one()).thenReturn(Mono.just(2L));

        StepVerifier.create(this.invoiceSupervisionService.getAllInvoicesOutOfBlinks(List.of("PF00A1", "PF00A2"),PageRequest.of(0, 5, sortOrder), "invoiceNumber", "DESC"))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    assertEquals(2, invoiceResult.getTotalElements());
                    InvoiceSupervsionDto invoiceSupervsionDto = invoiceResult.getContent().get(0);
                    assertEquals(1L, invoiceSupervsionDto.getIdInvoice());
                    assertEquals("PF00A1", invoiceSupervsionDto.getInvoiceNumber());
                })
                .verifyComplete();
    }
}