package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.u12.dto.AddressDTO;
import fr.laposte.blg.blinks.u12.dto.LegalPersonDTO;
import org.mapstruct.*;
import reactor.core.Exceptions;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

@Mapper
@DecoratedWith(LegalPersonViewMapperDecorator.class)
public interface LegalPersonViewMapper {

    @Mappings({
            @Mapping(source = "active", target = "status"),
            @Mapping(source = "compName", target = "compName"),
            @Mapping(source = "brandName", target = "brandName"),
            @Mapping(source = "custAccNumber", target = "custAccNumber"),
            @Mapping(source = "custTypeCode", target = "typeCode"),
            @Mapping(source = "custTypeCode", target = "typeLabel", qualifiedByName = "custTypeCodeToTypeLabel"),
            @Mapping(source = "CVATNO", target = "vatNumber"),
            @Mapping(source = "establishZoneCode", target = "establishZoneCode"),
            @Mapping(source = "marketingTypeCode", target = "marketingTypeCode"),
            @Mapping(source = "legalNatureCode", target = "legalNatureCode"),
            @Mapping(source = "legalNatureName", target = "legalNatureName"),
            @Mapping(source = "billingTypology", target = "billingTypology"),
            @Mapping(source = "siretCode", target = "siretCode"),
            @Mapping(source = "email", target = "email"),
            @Mapping(target = "idLegalPerson", ignore = true),
            @Mapping(target = "addressEntityList", ignore = true),
            @Mapping(target = "synchronized", ignore = true),
            @Mapping(target = "dateSynchronization", ignore = true),
            @Mapping(target = "created", ignore = true)
    })
    LegalPersonEntity legalPersonDTOToLegalPersonEntity(LegalPersonDTO legalPersonDTO);


    @Mappings(
            {
                    @Mapping(source = "addressId", target = "addressIdRefPM"),
                    @Mapping(source = "addressType", target = "addressType", qualifiedByName = "addressTypeMapper"),
                    @Mapping(source = "MDateTime", target = "modificationDatetime"),
                    @Mapping(source = "CDateTime", target = "creationDatetime"),
                    @Mapping(ignore = true, target = "legalPersonEntity"),
                    @Mapping(ignore = true, target = "idAddress"),
                    @Mapping(ignore = true, target = "idLegalPerson"),
                    @Mapping(ignore = true, target = "addressJson"),
                    @Mapping(ignore = true, target = "custAccNumber")
            }
    )
    AddressEntity addressDTOToAddressEntity(AddressDTO addressDTO);

    default Instant asInstant(String date) {
        return date != null && !date.isBlank() ? LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant() : null;
    }

    default String asString(Instant instant) {
        return instant != null ? ZonedDateTime.ofInstant(instant, ZoneId.of("Europe/Paris")).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) : null;
    }

    @Named("addressTypeMapper")
    default AddressType addressTypeMapper(String addressType) {
        return switch (addressType.toUpperCase()) {
            case "FACTURATION", "F" -> AddressType.FACTURATION;
            case "PRESTATION", "P" -> AddressType.PRESTATION;
            case "SIEGE" -> AddressType.SIEGE;
            case "PRINCIPALE" -> AddressType.PRINCIPALE;
            default -> throw Exceptions.propagate(
                    new RuntimeException("The addressType " + addressType + " is not allowed (only PRNCIPALE, " +
                            "PRESTATION, FACTURATION AND SIEGE are allowed)"));
        };
    }

    @Named("custTypeCodeToTypeLabel")
    default String custTypeCodeToTypeLabel(String sCustTypeCode) {
        if (sCustTypeCode.length() != 1) {
            throw new RuntimeException("custTypeCode length does not equal to 1");
        }
        int iCustTypeCode;
        try {
            iCustTypeCode = Integer.parseUnsignedInt(sCustTypeCode, 0, 1, 10);
        } catch (Exception e) {
            throw Exceptions.propagate(e);
        }

        return switch (iCustTypeCode) {
            case 0 -> "privé";
            case 1 -> "public";
            default ->
                    throw Exceptions.propagate(new RuntimeException("The custTypeCode " + iCustTypeCode + " is not allowed (only 0=privé or 1=public are allowed)"));
        };
    }
}
