package fr.laposte.blg.blinks.u17.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component("JsonMapper")
public class ObjectMapperWithModules extends ObjectMapper {

    public ObjectMapperWithModules() {
        super();
        this.registerModule(new JavaTimeModule());
    }
}
