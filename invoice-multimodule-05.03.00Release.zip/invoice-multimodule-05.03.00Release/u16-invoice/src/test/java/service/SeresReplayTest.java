package service;

import fr.laposte.blg.blinks.lib.common.entities.SeresOkEntity;
import fr.laposte.blg.blinks.lib.common.entities.SeresReplayEntity;
import fr.laposte.blg.blinks.lib.common.repositories.SeresOkRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SeresReplayEntityRepository;
import fr.laposte.blg.blinks.u16.service.SeresReplayService;
import fr.seres.avro.laposte.paktole.invoicing.PaktoleResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;


import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SeresReplayTest {
    @InjectMocks
    private SeresReplayService seresReplayService;
    @Mock
    private SeresOkRepository seresOkRepository;
    @Mock
    private SeresReplayEntityRepository seresReplayEntityRepository;

    private final String dateString = "2025-01-01 12:00:00";

    @Test
    void whenCodeNot0_saveSeresReplay() {
        PaktoleResponse paktoleResponse = PaktoleResponse.newBuilder()
                .setCode(1)
                .setDate(dateString)
                .setUrl("http://test/")
                .setInvoice("PF001")
                .setErrors("error")
                .build();
        when(seresReplayEntityRepository.save(any(SeresReplayEntity.class))).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));

        StepVerifier.create(seresReplayService.saveSeresReplay(paktoleResponse))
                .assertNext(seresReplayEntity -> {
                    assertEquals(paktoleResponse.getInvoice(), seresReplayEntity.getInvoiceNumber());
                    assertEquals(LocalDateTime.parse(paktoleResponse.getDate().toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.of("Europe/Paris")).toInstant(), seresReplayEntity.getErrorDate());
                    assertEquals(paktoleResponse.getCode(), seresReplayEntity.getErrorCode());
                    assertEquals(paktoleResponse.getErrors(), seresReplayEntity.getErrorMessage());
                    assertEquals(paktoleResponse.getUrl(), seresReplayEntity.getInvoiceUrl());
                    verify(seresReplayEntityRepository, times(1)).save(seresReplayEntity);
                    verify(seresOkRepository, times(0)).save(any());

                })
                .verifyComplete();
    }

    @Test
    void whenCode0_saveSeresOk() {
        PaktoleResponse paktoleResponse = PaktoleResponse.newBuilder()
                .setCode(0)
                .setDate(dateString)
                .setUrl("http://test/")
                .setInvoice("PF001")
                .setErrors("error")
                .build();
        when(seresOkRepository.save(any(SeresOkEntity.class))).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));

        StepVerifier.create(seresReplayService.saveSeresReplay(paktoleResponse))
                .verifyComplete();
        ArgumentCaptor<SeresOkEntity> captor = ArgumentCaptor.forClass(SeresOkEntity.class);
        verify(seresOkRepository, times(1)).save(captor.capture());
        SeresOkEntity captured = captor.getValue();

        assertEquals(paktoleResponse.getInvoice(), captured.getInvoiceNumber());
        assertEquals(LocalDateTime.parse(paktoleResponse.getDate().toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.of("Europe/Paris")).toInstant(), captured.getErrorDate());
        assertEquals(paktoleResponse.getCode(), captured.getErrorCode());
        assertEquals(paktoleResponse.getErrors(), captured.getErrorMessage());
        assertEquals(paktoleResponse.getUrl(), captured.getInvoiceUrl());
        verify(seresReplayEntityRepository, times(0)).save(any());
    }

}
