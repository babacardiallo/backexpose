package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.relational.core.mapping.Column;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefopsOfferFilter {

    @Column("ops_code")
    private String opsCode;

    @Column("ops_label")
    private String opsLabel;

    @Column("offer_activation_datetime")
    private Instant offerActivationDatetime;

}
