import { Pipe, PipeTransform } from '@angular/core';
import { Invoice } from '../models/invoice';

@Pipe({
    name: 'printFlagFilter',
    standalone: false
})
export class PrintFlagFilter implements PipeTransform {

  transform(list: any, texts: any[]): any {
    if (texts.length ==0) {
      return [];
    }
   

  }

}
