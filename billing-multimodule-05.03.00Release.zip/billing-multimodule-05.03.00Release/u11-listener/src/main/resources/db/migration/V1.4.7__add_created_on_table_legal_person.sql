ALTER TABLE legal_person
    ADD COLUMN created datetime default CURRENT_TIMESTAMP;