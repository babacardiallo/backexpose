package fr.laposte.blg.blinks.u17.dto;

public class ExportProcessKibanaCst {
    public static final String EXPORT_PROCESS_KEYS =  "exportProcessKeys";
}
