import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContratsDetailsPopUpComponent } from './contrats-details-pop-up.component';


describe('ContratsDetailsPopUpComponent', () => {
    let component: ContratsDetailsPopUpComponent;
    let fixture: ComponentFixture<ContratsDetailsPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ContratsDetailsPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ContratsDetailsPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
