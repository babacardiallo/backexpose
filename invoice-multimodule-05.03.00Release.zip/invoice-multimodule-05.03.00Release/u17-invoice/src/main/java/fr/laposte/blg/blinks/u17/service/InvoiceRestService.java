package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.entities.CustomerInvoice;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceStatusEnum;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.dto.InvoiceRestDTO;
import fr.laposte.blg.blinks.u17.dto.PrepareExportDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Data
public class InvoiceRestService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceMessageRepository invoiceMessageRepository;

    private static String COEURFINANCE = "coeurfinance";
    private static String INFOCA = "infoca";
    private static String DOCAPOSTE = "docaposte";

    public Mono<Page<InvoiceRestDTO>> getAllInvoices(Pageable pageable) {
        Instant dataRef = Instant.now().minus(90, ChronoUnit.DAYS);
        return invoiceRepository.findAllByCreatedGreaterThanEqual(pageable, dataRef)
                .flatMap(invoiceEntity -> Mono.zip(Mono.just(invoiceEntity), getMessage(invoiceEntity.getIdInvoice())))
                .map(this::mapToInvoiceDto)
                .collectList()
                .zipWith(invoiceRepository.countAllByCreatedGreaterThanEqual(dataRef))
                .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));

    }

   public InvoiceRestDTO mapToInvoiceDto(Tuple2<InvoiceEntity, String> tuple2) {
        return new InvoiceRestDTO(
                tuple2.getT1().getIdInvoice(),
                tuple2.getT1().getInvoiceNumber(),
                tuple2.getT2(),
                tuple2.getT1().getBillrunId(),
                tuple2.getT1().getDocaposteExportId() != null ? tuple2.getT1().getDocaposteExportId().intValue():0,
                tuple2.getT1().getInfocaExportId() != null ? tuple2.getT1().getInfocaExportId().intValue():0,
                tuple2.getT1().getCoeurfinanceExportId() != null ? tuple2.getT1().getCoeurfinanceExportId().intValue():0
        );
    }

    public Mono<Boolean> prepareExportDocaposte(Set<String> numInvoices) {
        return invoiceRepository.prepareExportDocaposte(numInvoices);
    }

    public Mono<Boolean> prepareExportCoeurfinance(Set<String> numInvoices) {
        return invoiceRepository.prepareExportCoeurfinance(numInvoices);
    }

    public Mono<Boolean> prepareExportInfoca(Set<String> numInvoices) {
        return invoiceRepository.prepareExportInfoca(numInvoices);
    }

    public Mono<Boolean> prepareExport(PrepareExportDto exportDto) {
       if(exportDto.getExportChoices()!=null){
           if(exportDto.getExportChoices().contains(DOCAPOSTE)){
               invoiceRepository.prepareExportDocaposte(exportDto.getInvoices())
                       .subscribe();
           }

           if(exportDto.getExportChoices().contains(INFOCA)){
               invoiceRepository.prepareExportInfoca(exportDto.getInvoices())
                       .subscribe();
           }

           if(exportDto.getExportChoices().contains(COEURFINANCE)){
               invoiceRepository.prepareExportCoeurfinance(exportDto.getInvoices())
                       .subscribe();
           }
       }
        return Mono.just(true);
    }

    public Mono<Page<InvoiceRestDTO>> getRecentInvoicesToExport(Pageable pageable) {
        return invoiceRepository.findAllByDocaposteExportIdIsNullAndDocaposteExportStatusEqualsOrInfocaExportIdIsNullAndInfocaExportStatusEqualsOrCoeurfinanceExportIdIsNullAndCoeurfinanceExportStatusEquals(InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, pageable)
                .flatMap(invoiceEntity -> Mono.zip(Mono.just(invoiceEntity), getMessage(invoiceEntity.getIdInvoice())))
                .map(this::mapToInvoiceDto)
                .collectList()
                .zipWith(invoiceRepository.countAllByDocaposteExportIdIsNullAndDocaposteExportStatusEqualsOrInfocaExportIdIsNullAndInfocaExportStatusEqualsOrCoeurfinanceExportIdIsNullAndCoeurfinanceExportStatusEquals(InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW))
                .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
    }

    public Mono<Map<Integer, Integer>> getCustomerNbInvoices(List<Integer> clientIds) {
        return invoiceRepository.getCustomerNbInvoices(clientIds)
                .collectMap(CustomerInvoice::getClient, CustomerInvoice::getNbInvoices);
    }


    public Mono<String> getMessage(Long id) {
        if(id!=null){
            return invoiceMessageRepository.getMessage(id);
        }
        return Mono.empty();
    }

    public Mono<Page<InvoiceRestDTO>> filterInvoices(Pageable pageable, String filter) {
        Instant dataRef = Instant.now().minus(90, ChronoUnit.DAYS);
        filter = "%"+filter.trim()+"%";
        return invoiceRepository.findAllByCreatedGreaterThanEqualAndInvoiceNumberLike(pageable, dataRef, filter)
                .flatMap(invoiceEntity -> Mono.zip(Mono.just(invoiceEntity), getMessage(invoiceEntity.getIdInvoice())))
                .map(this::mapToInvoiceDto)
                .collectList()
                .zipWith(invoiceRepository.countAllByCreatedGreaterThanEqualAndInvoiceNumberLike(dataRef, filter))
                .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));

    }


    public Mono<Page<InvoiceRestDTO>> getByPrintFlag(String filter,String sort, String order, Integer size, Integer page, boolean doca, boolean seres) {
        int offset = page*size;
        Instant dataRef = Instant.now().minus(90, ChronoUnit.DAYS);
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idInvoice"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);

        if(filter.equalsIgnoreCase("default")){
            filter = null;
        } else {
            filter = "%"+filter.trim()+"%";
        }
        if(sort.equalsIgnoreCase("invoiceNumber")){
            sort = "invoice_number";
        }
        if(sort.equalsIgnoreCase("billrunId")){
            sort = "billrun_id";
        }

        if(sort.equalsIgnoreCase("docaposteExportId")){
            sort = "docaposte_export_id";
        }

        if(sort.equalsIgnoreCase("infocaExportId")){
            sort = "infoca_export_id";
        }

        if(sort.equalsIgnoreCase("coeurfinanceExportId")){
            sort = "coeurfinance_export_id";
        }
        if(doca){
            return invoiceRepository.getByCriteriaDocaposte(dataRef,filter, sort, order, size, offset)
                    .flatMap(invoiceEntity -> Mono.zip(Mono.just(invoiceEntity), getMessage(invoiceEntity.getIdInvoice())))
                    .map(this::mapToInvoiceDto)
                    .collectList()
                    .zipWith(invoiceRepository.countByCriteriaDocaposte(dataRef,filter))
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        } else {
            return invoiceRepository.getByCriteriaSeres(dataRef,filter, sort, order, size, offset)
                    .flatMap(invoiceEntity -> Mono.zip(Mono.just(invoiceEntity), getMessage(invoiceEntity.getIdInvoice())))
                    .map(this::mapToInvoiceDto)
                    .collectList()
                    .zipWith(invoiceRepository.countByCriteriaSeres(dataRef,filter))
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        }

    }

    public void processFailedInvoices(List<String> invoices, boolean docaposte, boolean infoca, boolean coeurfinance){
        if (invoices.isEmpty()) {
            if (docaposte) {
                invoiceRepository.processFailedDocaposte().block();
            }
            if (infoca) {
                invoiceRepository.processFailedInfoca().block();
            }
            if (coeurfinance) {
                invoiceRepository.processFailedCoeurfinance().block();
            }
        }
        else {
            if (docaposte) {
                invoiceRepository.processFailedDocaposteIn(invoices).block();
            }
            if (infoca) {
                invoiceRepository.processFailedInfocaIn(invoices).block();
            }
            if (coeurfinance) {
                invoiceRepository.processFailedCoeurfinanceIn(invoices).block();
            }
        }
    }


}
