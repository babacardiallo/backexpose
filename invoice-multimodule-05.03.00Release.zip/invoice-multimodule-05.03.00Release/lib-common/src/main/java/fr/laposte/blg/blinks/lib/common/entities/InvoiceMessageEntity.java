package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("invoice_message")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceMessageEntity {

    @Id
    @Column("id_invoice_message")
    private Long idInvoiceMessage;

    @Column("id_invoice")
    private Long idInvoice;

    @Column("message")
    private String message;

}
