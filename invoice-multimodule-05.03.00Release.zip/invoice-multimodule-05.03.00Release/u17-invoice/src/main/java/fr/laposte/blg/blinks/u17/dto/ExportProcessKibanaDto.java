package fr.laposte.blg.blinks.u17.dto;

import fr.laposte.blg.blinks.lib.common.entities.ExportProcessStatus;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportProcessKibanaDto {
    private Long processId;
    private Long minId;
    private Long maxId;
    private Instant executionDate;
    private FileType fileType;
    private ExportProcessStatus exportProcessStatus;
    private String errorCode;
    private String errorMessage;
}
