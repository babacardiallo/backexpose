/** ***********************************************************
 *
 * CORE : The aim of this class is to store all the mdules adn components that
 * have to be declared only ones in the app. Here we are talking about
 * the core of the application, all the components/modules that represent
 * the layout of the application
 *
 *********************************************************** **/

/** Angular Common Imports */
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

/** Ui Theme Imports */

/** Materials Imports */
import { MatDialogModule } from '@angular/material/dialog';

/** Guards */
import { throwIfAlreadyLoaded } from './module-import-guard';

/** Error Management Imports */
import { ErrorHandler } from '@angular/core';
import { GlobalErrorHandler } from './errors/global-error-handler';
import { LoadingInterceptor } from './errors/http-interceptor';

@NgModule({ exports: [
        CommonModule,
        BrowserAnimationsModule,
        MatDialogModule
    ], imports: [CommonModule,
        BrowserAnimationsModule,
        MatDialogModule], providers: [
        {
            provide: ErrorHandler,
            useClass: GlobalErrorHandler,
        },
        {
            provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true
        },
        provideHttpClient(withInterceptorsFromDi())
    ] })
export class CoreModule {

    /**
     * CoreModule constructor
     *
     * @param parentModule
     */
    constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
        // Check if this module is beeing loaded already
        throwIfAlreadyLoaded(parentModule, 'CoreModule');
    }
}
