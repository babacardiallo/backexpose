package fr.laposte.blg.blinks.u17.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.json.JsonMapper;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.time.Duration;

@Component
public class SchedulerUtils {

    public Flux<ExportProcess> delaySignal(Flux<ExportProcess> originalFlux, SchedulerParamsEntity schedulerParams){
        return originalFlux.switchOnFirst((signal, flux) -> {
            if (signal.hasValue()) {
                return flux.skip(1)
                        .delayElements(Duration.ofSeconds(schedulerParams.getWaitingDelay()))
                        .startWith(signal.get());
            }
            return flux;
        });
    }

    public JsonNode mapStringToJson(String params) throws JsonProcessingException {
        return new JsonMapper().readTree(params);
    }
}
