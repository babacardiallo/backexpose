package fr.laposte.blg.blinks.u17.dto;

public class ExportKibanaCst {
    public static final String TREATMENT = "traitementExport";
    public static final String INVOICE_NUMBER =  "invoiceNumberExport";
    public static final String EXPORT_ID = "exportId";
    public static final String STATUS =  "exportStatus";
    public static final String MESSAGE =  "exportMessage";
    public static final String CLEFS =  "exportClefs";
}
