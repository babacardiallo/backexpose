import {
  require_hammer
} from "./chunk-5PLTYDIE.js";
import "./chunk-TXDUYLVM.js";
export default require_hammer();
