export class RejetContractTableModel {
    id?: string;
    errorDate?: Date;
    contractNumber?: string;
    custAccNumber?: string;
    errorCode?: string;
    errorMessage?:string;
    status?:string;
    nbRetry?: number;
    offerCode?: string;
    versionNumber?: string;
    amendmentNumber?: string;
}
