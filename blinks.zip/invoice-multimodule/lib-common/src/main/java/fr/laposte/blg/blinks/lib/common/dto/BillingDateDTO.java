package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Setter
@Getter
@JsonPropertyOrder({
        "startDate",
        "endDate",
        "calculationDate",
        "expiryDate",
        "paymentDate",
        "consumptionRefDate",
        "lastDepositDate"
})
public class BillingDateDTO {

    Instant startDate;
    Instant endDate;
    Instant calculationDate;
    Instant expiryDate;
    Instant paymentDate;
    Instant consumptionRefDate;
    Instant lastDepositDate;

}
