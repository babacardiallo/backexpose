import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, defer, from } from "rxjs";
import { switchMap } from "rxjs/operators";
import { AuthCheckService } from "./auth-check.service";

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

    constructor(public authCheckService: AuthCheckService){}
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>  {
        if(!request.url.includes("authentification")){
            return defer(() =>
                from(this.authCheckService.checkAuthToken()).pipe(
                    switchMap(token =>{
                        const authReq = request.clone({
                            headers: request.headers.set('I2A-JWT-Assertion', token)
                        });
                        return next.handle(authReq);
                    })
                )
            );
        }
        return next.handle(request);
    }
}