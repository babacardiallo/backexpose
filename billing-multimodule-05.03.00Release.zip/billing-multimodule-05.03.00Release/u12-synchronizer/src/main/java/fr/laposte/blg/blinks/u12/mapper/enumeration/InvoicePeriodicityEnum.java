package fr.laposte.blg.blinks.u12.mapper.enumeration;

import lombok.AllArgsConstructor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
public enum InvoicePeriodicityEnum {

    PER_FAC_10("10", "Mensuelle"),
    PER_FAC_20("20", "Hebdomadaire"),
    PER_FAC_30("30", "Bimensuelle"),
    PER_FAC_40("40", "Trimestrielle"),
    PER_FAC_50("50", "Bimestrielle"),
    PER_FAC_60("60", "Semestrielle"),
    PER_FAC_70("70", "Au plus tôt"),
    PER_FAC_80("80", "Cf. Convention"),
    PER_FAC_90("90", "Cf. Contrat principal");

    private static final Map<String, String> BY_LABEL = new HashMap<>();

    static {
        Arrays.stream(values()).forEach(e -> BY_LABEL.put(e.label, e.code));
    }

    private String code;
    private String label;

    public static String getCode(String label) {
        return BY_LABEL.get(label);
    }

}
