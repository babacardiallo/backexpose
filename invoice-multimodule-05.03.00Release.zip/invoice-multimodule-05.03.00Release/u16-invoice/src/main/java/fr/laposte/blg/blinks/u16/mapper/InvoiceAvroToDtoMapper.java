package fr.laposte.blg.blinks.u16.mapper;

import fr.laposte.bscc.avro.invoicing.*;
import fr.laposte.blg.blinks.lib.common.dto.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(uses = GenericMapper.class)
public interface InvoiceAvroToDtoMapper {

    @Mapping(target = "invoiceHeader", source = "invoiceHeader")
    @Mapping(target = "billingAccount", source = "billingAccount")
    @Mapping(target = "customer", source = "customer")
    @Mapping(target = "contracts", source = "contracts")
    @Mapping(target = "accountDetails", source = "accountDetails")
    InvoiceDTO avroToDto(Invoice invoice);

    HeaderDTO headerAvroToDto(Header header);

    @Mapping(target = "billingDate", source = "billingDate")
    @Mapping(target = "billingAmount", source = "billingAmount")
    @Mapping(target = "vats", source = "vats")
    @Mapping(target = "scheduledPayment", source = "scheduledPayment")
    @Mapping(target = "paymentCc", source = "paymentCC")
    InvoiceHeaderDTO invoiceHeaderAvroToDto(InvoiceHeader invoiceHeader);

    @Mapping(target = "startDate", source = "startDate")
    @Mapping(target = "endDate", source = "endDate")
    @Mapping(target = "calculationDate", source = "calculationDate")
    @Mapping(target = "expiryDate", source = "expiryDate")
    @Mapping(target = "paymentDate", source = "paymentDate", defaultValue = "")
    @Mapping(target = "consumptionRefDate", source = "consumptionRefDate")
    @Mapping(target = "lastDepositDate", source = "lastDepositDate", defaultValue = "")
    BillingDateDTO billingDateAvroToDto(BillingDate billingDate);

    @Mapping(target = "vatTotalAmount", source = "VATTotalAmount")
    @Mapping(target = "vatAmountPaid", source = "VATAmountPaid")
    BillingAmountDTO billingAmountAvroToDto(BillingAmount billingAmount);

    @Mapping(target = "paymentCcDateTime", source = "paymentCCDateTime")
    @Mapping(target = "paymentCcId", source = "paymentCCId")
    @Mapping(target = "amountCc", source = "amountCC")
    PaymentCcDTO paymentCcAvroToDto(PaymentCC paymentCc);

    @Mapping(target = "vatRate", source = "VATRate")
    VatDto vatAvroToDto(Vat vat);

    @Mapping(target = "seCode", source = "SECode", defaultValue = "")
    @Mapping(target = "ejCode", source = "EJCode", defaultValue = "")
    @Mapping(target = "uniqueMandateReference", source = "uniqueMandateReference")
    @Mapping(target = "billingAddress", source = "billingAddress")
    @Mapping(target = "vatliabilityFlag", source = "VATliabilityFlag")
    BillingAccountDTO billingAccountAvroToDto(BillingAccount billingAccount);

    @Mapping(target = "rum", source = "RUM", defaultValue = "")
    @Mapping(target = "iban", source = "IBAN", defaultValue = "")
    @Mapping(target = "bic", source = "BIC", defaultValue = "")
    UniqueMandateReferenceDto uniqueMandateReferenceAvroToDto(UniqueMandateReference uniqueMandateReference);

    BillingAddressDto billingAddressAvroToDto(BillingAddress billingAddress);

    @Mapping(target = "customerInformation", source = "customerInformation")
    @Mapping(target = "customerAddress", source = "customerAddress")
    CustomerDTO customerAvroToDto(Customer customer);

    @Mapping(target = "cvatno", source = "CVATNO", defaultValue = "")
    CustomerInformationDTO customerInformationAvroToDto(CustomerInformation customerInformation);

    CustomerAddressDTO customerAddressAvroToDto(CustomerAddress customerAddress);

    ContractDTO contractsAvroToDto(Contract contract);

    @Mapping(target = "contractVersionValidityStartDateTime", source = "contractVersionValidityStartDateTime")
    @Mapping(target = "contractVersionValidityEndDateTime", source = "contractVersionValidityEndDateTime")
    @Mapping(target = "inactivationDate", source = "inactivationDate")
    InvoiceContractInfoDTO invoiceContractInfoAvroToDto(InvoiceContractInfo invoiceContractInfo);

    ServiceEstablishmentDto serviceEstablishmentAvroToDto(ServiceEstablishment serviceEstablishment);

    DeliveryAddressDto deliveryAddressAvroToDto(DeliveryAddress deliveryAddress);

    @Mapping(target = "vatCode", source = "VATCode", defaultValue = "")
    @Mapping(target = "vatRate", source = "VATRate")
    @Mapping(target = "vatAmount", source = "VATAmount")
    @Mapping(target = "displayInvoiceLinePerDateRange", source = "displayInvoiceLinePerDateRange")
    @Mapping(target = "periodStartDate", source = "periodStartDate")
    @Mapping(target = "periodEndDate", source = "periodEndDate")
    @Mapping(target = "serviceDate", source = "serviceDate")
    @Mapping(target = "criteria", source = "criteria")
    InvoiceLineDTO invoiceLineAvroToDto(InvoiceLine invoiceLine);


    AccountDetailsDTO accountDetailAvroToDto(AccountDetail accountDetail);

    @Mapping(target = "consumerAccountCode", source = "consumerAccountCode")
    @Mapping(target = "clientAccountCode", source = "clientAccountCode")
    @Mapping(target = "externalReference", source = "externalReference")
    @Mapping(target = "excludingTaxTotalAmount", source = "excludingTaxTotalAmount")
    LinkedAccountDTO linkedAccountAvroToDto(LinkedAccount linkedAccount);

    AccountAdressDto accountAddressAvroToDto(AccountAddress accountAddress);

    @Mapping(target = "vatCode", source = "VATCode", defaultValue = "")
    @Mapping(target = "vatRate", source = "VATRate")
    @Mapping(target = "vatAmount", source = "VATAmount")
    @Mapping(target = "serviceDate", source = "serviceDate")
    @Mapping(target = "criteria", source = "criteria")
    ContractInvoiceLineDto contractInvoiceLineAvroToDto(ContractInvoiceLine contractInvoiceLine);
}
