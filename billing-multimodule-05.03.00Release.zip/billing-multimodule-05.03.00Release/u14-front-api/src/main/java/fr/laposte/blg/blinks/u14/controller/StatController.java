package fr.laposte.blg.blinks.u14.controller;


import fr.laposte.blg.blinks.u14.controller.dto.StatDto;
import fr.laposte.blg.blinks.u14.service.StatService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/stat")
@Validated
@OpenAPIDefinition(tags = {@Tag(name = "StatController")})
public class StatController {

    private final StatService statService;


    @GetMapping("/totaux-billing")
    @Operation(
        summary = "Totaux",
        description = "Service permettant de retourner les totaux sur les contrats synchronisés," +
            " les versions de contrats synchronisés," +
            " les offres ouvertes à la synchronisation," +
            " les clients en bases" +
            " et les erreurs de synchronisation encours ")
    Mono<StatDto[]> getTotaux() {
        return statService.getTotaux();
    }

}
