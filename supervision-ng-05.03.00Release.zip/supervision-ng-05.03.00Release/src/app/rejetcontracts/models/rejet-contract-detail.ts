export class RejetContractDetail{
    id?: string;
    meansCode?: string;
    periodCode?: string;
    offset?: number;
    partition?: number;
    action?: string;
    kafkaMessage?: JSON;
}