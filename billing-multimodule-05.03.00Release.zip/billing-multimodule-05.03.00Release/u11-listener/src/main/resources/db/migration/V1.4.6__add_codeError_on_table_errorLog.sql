ALTER TABLE error_log
    ADD COLUMN code_error varchar(255);