package fr.laposte.blg.blinks.lib.security;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.server.authentication.ServerAuthenticationConverter;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

public class ServerBodyAuthenticationConverter implements ServerAuthenticationConverter {

    @Override
    public Mono<Authentication> convert(ServerWebExchange exchange) {
        final ServerHttpRequest request = exchange.getRequest();
        List<String> username = request.getHeaders().get("username");
        List<String> password =  request.getHeaders().get("password");
        if(username!=null && !username.isEmpty() && password!=null && !password.isEmpty()){
            return Mono.just(new UsernamePasswordAuthenticationToken(username.get(0), password.get(0)));
        } else {
            return Mono.empty();
        }
    }

}