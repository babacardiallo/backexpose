package fr.laposte.blg.blinks.u12.listener;

import fr.laposte.blg.blinks.u12.service.contract.ContractSyncService;
import fr.laposte.blg.blinks.u12.service.customer.CustomerSyncService;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.EventOrigin;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.TypeEnum;
import fr.laposte.bscc.billing.avro.billing.ContractConsolidated;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class SynchronizationServiceTest {

    @InjectMocks
    SynchronizationService synchronizationServiceToTest;

    @Mock
    ContractSyncService contractSynchronizationService;

    @Mock
    CustomerSyncService customerSyncService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void readSynchronizationCommand_whenContractSync() {

        Synchronization syncMessage = Synchronization.newBuilder().setAction(ActionEnum.create)
            .setType(TypeEnum.contract)
            .setEventOrigin(EventOrigin.newBuilder().setKey("1").setTopic("gk_fullContract_out_V1").build())
            .setInternalId(1).build();
        Mockito.when(contractSynchronizationService.synchronize(Mockito.anyInt(), Mockito.any(ActionEnum.class)))
            .thenReturn(Flux.just(new ContractConsolidated()));

        StepVerifier.create(synchronizationServiceToTest.readSynchronizationCommand(syncMessage))
            .expectNextCount(1)
            .expectComplete()
            .verify();

        Mockito.verify(contractSynchronizationService, Mockito.times(1)).synchronize(Mockito.eq(1), Mockito.eq(ActionEnum.create));
        Mockito.verify(customerSyncService, Mockito.never()).synchronize(Mockito.eq(1), Mockito.eq(false));

    }

    @Test
    void readSynchronizationCommand_whenCustomerSync() {
        Mockito.when(customerSyncService.synchronize(Mockito.anyInt(), Mockito.eq(false)))
            .thenReturn(Mono.just(new ContractConsolidated()));
        Synchronization syncMessage = Synchronization.newBuilder().setAction(ActionEnum.create)
            .setType(TypeEnum.customer)
            .setEventOrigin(EventOrigin.newBuilder().setKey("1").setTopic("md_legalPerson").build())
            .setInternalId(1).build();
        StepVerifier.create(synchronizationServiceToTest.readSynchronizationCommand(syncMessage))
            .expectNextCount(1)
            .expectComplete()
            .verify();

        Mockito.verify(contractSynchronizationService, Mockito.never()).synchronize(Mockito.eq(1), Mockito.eq(ActionEnum.create));
        Mockito.verify(customerSyncService, Mockito.only()).synchronize(Mockito.eq(1), Mockito.eq(false));;

    }
}