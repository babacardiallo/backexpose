import { ContractOdcJson } from "./contract-odc-json";

export class ContratsRevisionError {
    contractNumber?: string;
    amendmentNumber?: number;
    revisionNumber?: number;
    supRevisionNumber?: number;
    supRevOdcMessage?: ContractOdcJson;
    errorMessage?: string;
    supErrorOffset?: string;
    supErrorPartition?: string;
}