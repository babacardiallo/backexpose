import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ClientsTableComponent } from './clients-table.component';

describe('DataTableComponentComponent', () => {
    let component: ClientsTableComponent;
    let fixture: ComponentFixture<ClientsTableComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ClientsTableComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ClientsTableComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
