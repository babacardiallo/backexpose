package mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.u16.mapper.InvoiceAvroToDtoMapper;
import fr.laposte.blg.blinks.u16.mapper.GenericMapper;
import fr.laposte.blg.blinks.u16.mapper.GenericMapperImpl;
import org.junit.jupiter.api.*;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceMapperTest {
    private static Invoice source;
    private static InvoiceDTO destination;
    @InjectMocks
    private static GenericMapper genericMapper = GenericMapperImpl.INSTANCE;

    @BeforeAll
    static void init() throws IOException {
        InvoiceAvroToDtoMapper mapper = Mappers.getMapper(InvoiceAvroToDtoMapper.class);
        ReflectionTestUtils.setField(mapper, "genericMapper", genericMapper);
        File src = new File("src/test/resources/invoice_cip_v6_test.json");
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
        source = objectMapper.readValue(src, Invoice.class);
        destination = mapper.avroToDto(source);
    }

    @Test
    void givenInvoiceAvro_whenMaps_thenBillingAccountOk() {
        assertEquals(source.getBillingAccount().getExtension(), destination.getBillingAccount().getExtension());
        assertEquals(source.getBillingAccount().getEfact(), destination.getBillingAccount().getEfact());
    }

    @Test
    void givenInvoice_whenMaps_thenAmountOfHeaderOk() {
        assertEquals(source.getInvoiceHeader().getBillingAmount().getVATTotalAmount(), destination.getInvoiceHeader().getBillingAmount().getVatTotalAmount());
        assertEquals(source.getInvoiceHeader().getBillingAmount().getVATAmountPaid(), destination.getInvoiceHeader().getBillingAmount().getVatAmountPaid());
    }

    @Test
    void givenInvoiceAvro_whenMaps_thenCustomerOk() {
        assertEquals(source.getCustomer().getCustomerInformation().getCustAccNumber(), destination.getCustomer().getCustomerInformation().getCustAccNumber());
        assertEquals(source.getCustomer().getCustomerInformation().getName(), destination.getCustomer().getCustomerInformation().getName());
        assertEquals(source.getCustomer().getCustomerInformation().getBrandName(), destination.getCustomer().getCustomerInformation().getBrandName());
        assertEquals(source.getCustomer().getCustomerInformation().getTypeCode(), destination.getCustomer().getCustomerInformation().getTypeCode());
        assertEquals(source.getCustomer().getCustomerInformation().getTypeLabel(), destination.getCustomer().getCustomerInformation().getTypeLabel());
        assertEquals(source.getCustomer().getCustomerInformation().getAdvPortfolioCode(), destination.getCustomer().getCustomerInformation().getAdvPortfolioCode());
        assertEquals(source.getCustomer().getCustomerInformation().getSiretCode(), destination.getCustomer().getCustomerInformation().getSiretCode());
        assertEquals(source.getCustomer().getCustomerInformation().getCVATNO(), destination.getCustomer().getCustomerInformation().getCvatno());
        assertEquals(source.getCustomer().getCustomerInformation().getBillingTypology(), destination.getCustomer().getCustomerInformation().getBillingTypology());

    }

    @Test
    @Disabled("No data in the test message for account details")
    void givenInvoiceAvro_whenMaps_thenAccountDetailsOk() {
        assertEquals(source.getAccountDetails().get(0).getAccountInvoiceNumber(), destination.getAccountDetails().get(0).getAccountInvoiceNumber());
    }

    @Nested
    @DisplayName("check invoice header")
    class givenInvoiceAvro_whenMaps_thenInvoiceHeaderOk {

        @Test
        void givenInvoiceAvro_whenMaps_thenInvoiceHeaderParamsOk() {
            assertEquals(source.getInvoiceHeader().getInvoiceNumber(), destination.getInvoiceHeader().getInvoiceNumber());
            assertEquals(source.getInvoiceHeader().getInvoiceAttachmentNumber(), destination.getInvoiceHeader().getInvoiceAttachmentNumber());
            assertEquals(source.getInvoiceHeader().getStatus(), destination.getInvoiceHeader().getStatus());
            assertEquals(source.getInvoiceHeader().getIsStatementFlag(), destination.getInvoiceHeader().getIsStatementFlag());
            assertEquals(source.getInvoiceHeader().getDecentralizedStatementFlag(), destination.getInvoiceHeader().getDecentralizedStatementFlag());
            assertEquals(source.getInvoiceHeader().getDedicatedInvoiceFlag(), destination.getInvoiceHeader().getDedicatedInvoiceFlag());
            assertEquals(source.getInvoiceHeader().getCreditFlag(), destination.getInvoiceHeader().getCreditFlag());
            assertEquals(source.getInvoiceHeader().getRefundableFlag(), destination.getInvoiceHeader().getRefundableFlag());
            assertEquals(source.getInvoiceHeader().getDownpaymentFlag(), destination.getInvoiceHeader().getDownpaymentFlag());
            assertEquals(source.getInvoiceHeader().getPrintFlag(), destination.getInvoiceHeader().getPrintFlag());
            assertEquals(source.getInvoiceHeader().getComment(), destination.getInvoiceHeader().getComment());
            assertEquals(source.getInvoiceHeader().getComment2(), destination.getInvoiceHeader().getComment2());
            assertEquals(source.getInvoiceHeader().getParentContractNumber(), destination.getInvoiceHeader().getParentContractNumber());
            assertEquals(source.getInvoiceHeader().getInvoiceDeliveryMode(), destination.getInvoiceHeader().getInvoiceDeliveryMode());
            assertEquals(source.getInvoiceHeader().getInvoiceDeliveryMails(), destination.getInvoiceHeader().getInvoiceDeliveryMails());
            assertEquals(source.getInvoiceHeader().getPdfGeneratedByOpencell(), destination.getInvoiceHeader().getPdfGeneratedByOpencell());
        }

        @Test
        void givenInvoiceAvro_whenMaps_thenInvoiceHeaderVATsOk() {
            assertEquals(source.getInvoiceHeader().getVats().get(0).getAmountVAT(), destination.getInvoiceHeader().getVats().get(0).getAmountVAT());
            assertEquals(source.getInvoiceHeader().getVats().get(0).getVATRate(), destination.getInvoiceHeader().getVats().get(0).getVatRate());
            assertEquals(source.getInvoiceHeader().getVats().get(0).getAmountIncludingVAT(), destination.getInvoiceHeader().getVats().get(0).getAmountIncludingVAT());
            assertEquals(source.getInvoiceHeader().getVats().get(0).getAmountExcludingVAT(), destination.getInvoiceHeader().getVats().get(0).getAmountExcludingVAT());
        }

        @Test
        void givenInvoiceAvro_whenMaps_thenInvoiceHeaderSchedulePaymentOk() {
            assertEquals(source.getInvoiceHeader().getScheduledPayment().get(0).getScheduledPaymentDate(), destination.getInvoiceHeader().getScheduledPayment().get(0).getScheduledPaymentDate());
            assertEquals(source.getInvoiceHeader().getScheduledPayment().get(0).getScheduledPaymentAmountIncludingVAT(), destination.getInvoiceHeader().getScheduledPayment().get(0).getScheduledPaymentAmountIncludingVAT());
        }
    }

    @Nested
    @DisplayName("check invoice contract")
    class givenInvoiceAvro_whenMaps_thenInvoiceContractOk {
        @Test
        void givenInvoiceAvro_whenMaps_thenContractInfoOk() {
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getContractNumber(), destination.getContracts().get(0).getInvoiceContractInfo().getContractNumber());
            assertNotNull(source.getContracts().get(0).getInvoiceContractInfo().getContractVersionValidityStartDateTime());
            assertNotNull(source.getContracts().get(0).getInvoiceContractInfo().getContractVersionValidityEndDateTime());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getContractParentContractNumber(), destination.getContracts().get(0).getInvoiceContractInfo().getContractParentContractNumber());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getContractType(), destination.getContracts().get(0).getInvoiceContractInfo().getContractType());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getContractSubType(), destination.getContracts().get(0).getInvoiceContractInfo().getContractSubType());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getOpsCode(), destination.getContracts().get(0).getInvoiceContractInfo().getOpsCode());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getCustContractualAgreementReference(), destination.getContracts().get(0).getInvoiceContractInfo().getCustContractualAgreementReference());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getCreationChannel(), destination.getContracts().get(0).getInvoiceContractInfo().getCreationChannel());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getSellerSector(), destination.getContracts().get(0).getInvoiceContractInfo().getSellerSector());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getComment(), destination.getContracts().get(0).getInvoiceContractInfo().getComment());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getCategoryLabel(), destination.getContracts().get(0).getInvoiceContractInfo().getCategoryLabel());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getRepaymentTypeCode(), destination.getContracts().get(0).getInvoiceContractInfo().getRepaymentTypeCode());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getRepaymentTypeLabel(), destination.getContracts().get(0).getInvoiceContractInfo().getRepaymentTypeLabel());
            assertNotNull(source.getContracts().get(0).getInvoiceContractInfo().getInactivationDate());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getInvoiceModeCode(), destination.getContracts().get(0).getInvoiceContractInfo().getInvoiceModeCode());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getInvoiceModeLabel(), destination.getContracts().get(0).getInvoiceContractInfo().getInvoiceModeLabel());
            assertNull(source.getContracts().get(0).getInvoiceContractInfo().getCustInvoiceTermId(), destination.getContracts().get(0).getInvoiceContractInfo().getCustInvoiceTermId());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getExcludingTaxTotalAmount(), destination.getContracts().get(0).getInvoiceContractInfo().getExcludingTaxTotalAmount());
            assertEquals(source.getContracts().get(0).getInvoiceContractInfo().getTotalAmount(), destination.getContracts().get(0).getInvoiceContractInfo().getTotalAmount());
        }
    }

    @Test
    void givenInvoiceAvro_whenMaps_thenContractLinkedAccountsOk() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getConsumerAccountCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getConsumerAccountCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getClientAccountCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getClientAccountCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getExternalReference(), destination.getContracts().get(0).getLinkedAccounts().get(0).getExternalReference());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getExcludingTaxTotalAmount(), destination.getContracts().get(0).getLinkedAccounts().get(0).getExcludingTaxTotalAmount());

    }

    @Test
    void givenInvoiceAvro_whenMaps_thenAccountAddressOk() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getName1(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getName1());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd2(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd2());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd3(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd3());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd4(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd4());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd5(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd5());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd6(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd6());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd7(), destination.getContracts().get(0).getLinkedAccounts().get(0).getAccountAddress().getAdd7());
    }

    @Test
    @Disabled("No data in message")
    void givenInvoiceAvro_whenMaps_thenServiceEstablishmentOk() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getServiceEstablishments().get(0).getRegateCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getServiceEstablishments().get(0).getRegateCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getServiceEstablishments().get(0).getRegateLabel(), destination.getContracts().get(0).getLinkedAccounts().get(0).getServiceEstablishments().get(0).getRegateLabel());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getServiceEstablishments().get(0).getExcludingTaxTotalAmount(), destination.getContracts().get(0).getLinkedAccounts().get(0).getServiceEstablishments().get(0).getExcludingTaxTotalAmount());
    }

    @Test
    @Disabled("No data in message")
    void givenInvoiceAvro_whenMaps_thenDeliveryAdressOk() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getDeliveryAddresses().get(0).getAddressId(), destination.getContracts().get(0).getLinkedAccounts().get(0).getDeliveryAddresses().get(0).getAddressId());
    }

    @Test
    void givenInvoiceAvro_whenMaps_thenInvoiceLinesOk() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getAttachedNumber(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getAttachedNumber());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getToDisplay(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getToDisplay());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDisplayPriority(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDisplayPriority());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getConsumerAccountCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getConsumerAccountCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getCoclicoEmitterCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getCoclicoEmitterCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDepositCustAccNumber(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDepositCustAccNumber());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getExternalRef(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getExternalRef());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getType(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getType());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getProductCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getProductCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getServiceCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getServiceCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getAccountingCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getAccountingCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getLabel(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getLabel());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getComment(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getComment());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getQuantity(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getQuantity());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getUnitPrice(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getUnitPrice());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getExcludingTaxAmount(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getExcludingTaxAmount());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getVATCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getVatCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getVATAmount(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getVatAmount());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getVATRate(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getVatRate());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getStampingCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getStampingCode());
        assertNotNull(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getServiceDate());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getRegateCode(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getRegateCode());
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getAddressId(), destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getAddressId());
    }

}
