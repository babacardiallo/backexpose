package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface QueueSynchronizationRepository extends ReactiveCrudRepository<QueueSynchronizationEntity, Long> {

    Mono<QueueSynchronizationEntity> findQueueSynchronizationEntityByIdContract(Long idContract);

    Mono<QueueSynchronizationEntity> findQueueSynchronizationEntityByIdLegalPerson(Long idLegalPerson);

    Mono<Boolean> existsQueueSynchronizationEntityByIdContract(Long idContract);

    @Query("SELECT * FROM queue_synchronization_after_error WHERE date_synchronization_expected < NOW()")
    Flux<QueueSynchronizationEntity> findAllByDateSynchronizationExpectedBeforeNow();

    Mono<Void> deleteByIdQueue(Long idQueue);
}
