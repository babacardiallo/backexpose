import { AfterViewInit, Component, HostListener, OnInit } from '@angular/core';
import { environment } from '../environments/environment';
import { NavigationEnd, NavigationStart, Router } from "@angular/router";
import { NgxPermissionsService } from 'ngx-permissions';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
import { AuthOidcService } from '@cddng/auth-oidc-apim';
import { SharedService } from './shared/services/shared.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    standalone: false
})
export class AppComponent implements OnInit, AfterViewInit {

  url: any;

  roles: string[] = [];

  userRole = '';

  isAuthorized = false;

  authenticatedUser: any;

  currentUrl: any;

  constructor(public authOidcService: AuthOidcService,
    private router: Router,
    private permissionsService: NgxPermissionsService,
    private matIconRegistry: MatIconRegistry,
    private domeSanitizer: DomSanitizer,
    public sharedService: SharedService) {

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.url = event.url;
      }
      if (event instanceof NavigationStart) {
        this.currentUrl = event.url;
      }
    });

    this.matIconRegistry.addSvgIcon('saisieEdr',
      this.domeSanitizer.bypassSecurityTrustResourceUrl('../assets/images/create-edr.svg'))
    this.authOidcService.autologin('/autologin').subscribe(res => {
    });
  }
  ngAfterViewInit(): void {
    if(environment.name=='prod') {
      document.documentElement.style.setProperty('--bandeau-color', 'red');
    } else {
      if(environment.name=='prod1') {
        document.documentElement.style.setProperty('--bandeau-color', 'blue');
      }
    }
  }
  ngOnInit(): void {
    console.log(environment);
    this.authOidcService.sessionChanged$.subscribe(auth => {
      this.isAuthorized = auth;
      if (this.isAuthorized) {
        this.sharedService.connectedUserData = this.authOidcService.getAuthenticatedUserFromJwt();
        console.log(this.sharedService.connectedUserData);
      } else {
        this.sharedService.connectedUserData = null;
      }
      this.loadPermissions();

    })
  }

  public getEnvDisplayName(){
    switch (environment.name) {
      case "loc": return "LOCAL";
      case "sdev": return "DEV";
      case "srec": return "REC";
      case "sacc": return "ACC";
      case "sass": return "ASS";
      case "sfor": return "FOR";
      case "prod1": return "LAB";
      case "prod": return "PROD";
      default: return '';
    }
  }


  @HostListener('window:UserDisconnectBtnClicked') userLogout() {
    this.authOidcService.logout();
    this.sharedService.connectedUserData = null;
  }

  loadPermissions() {
    let role='';
    if (environment.name == 'loc') {
      this.permissionsService.loadPermissions(this.sharedService.localPermissions);
      role= this.sharedService.displayLocalRole;
    } else {
      this.permissionsService.loadPermissions(this.sharedService.connectedUserData ? this.sharedService.connectedUserData.roles : []);
      if (this.sharedService.connectedUserData?.roles.includes('ADMIN')) {
        role = 'ADMIN';
      } else {
        if (this.sharedService.connectedUserData?.roles.includes('CONS')) {
          role = 'CONS';
        } else {
          if (this.sharedService.connectedUserData?.roles.includes('ADV')) {
            role = 'ADV';
          } else {
            role = '';
          }
        }
      }
    }
    setTimeout(() => {
      this.userRole = role + " - " + this.getEnvDisplayName();
    }, 1000);
  }


  bandeauUrl = environment.corpHeaderJsUrl;
  appName: string = environment.appName;
  projectName = "FACTURA";
  appVersion = "05.03.00";





}
