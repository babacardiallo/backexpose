export class InvoiceSupervisionTable {
    idInvoice!: number;
    invoiceNumber?: string;
    created?: string;
    client?: number;
    billrunId?: string;
    docaposteExportStatus?: string;
    infocaExportStatus?: string;
    coeurfinanceExportStatus?: string;
    docaposteExportDate?: string;
    infocaExportDate?: string;
    coeurfinanceExportDate?: string;
    docaposteExportId?: number;
    infocaExportId?: number;
    coeurfinanceExportId?: number;
    present?: number;
    fromTableOnly?: boolean;
}
