import { Component, Input } from '@angular/core';
import { Clipboard } from '@angular/cdk/clipboard';

@Component({
    selector: 'json-viewer',
    templateUrl: './json-widget.component.html',
    styleUrls: ['./json-widget.component.scss'],
    standalone: false
})
export class JsonWidgetComponent {
 
  @Input() data: JSON;
  isDataExpanded: boolean = false;
  dataExpandTitle = 'Tout déplier';
  copyJsonStatus = 'Copier';
  constructor(private clipboard: Clipboard) {
    
  }

  moreOrLessJson() {
    this.isDataExpanded = !this.isDataExpanded;
    if (this.isDataExpanded) {
        this.dataExpandTitle = 'Tout plier'
    } else {
        this.dataExpandTitle = 'Tout déplier'
    }
  } 

  copyJson() {
    this.clipboard.copy(JSON.stringify(this.data));
    this.copyJsonStatus = 'Donnée copiée';
    setTimeout(() => {
        this.copyJsonStatus = 'Copier';
    }, 3000);
  }
  
}
