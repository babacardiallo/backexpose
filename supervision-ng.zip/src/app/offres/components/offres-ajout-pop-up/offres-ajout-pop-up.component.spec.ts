import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OffresAjoutPopUpComponent } from './offres-ajout-pop-up.component';

describe('OffreErrorDetailPopUpComponent', () => {
    let component: OffresAjoutPopUpComponent;
    let fixture: ComponentFixture<OffresAjoutPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [OffresAjoutPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(OffresAjoutPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
