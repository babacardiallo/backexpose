package fr.laposte.blg.blinks.u17.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.opencsv.CSVWriter;
import com.opencsv.ICSVWriter;
import fr.laposte.blg.blinks.lib.common.dto.*;
import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.lib.common.repositories.FileSequenceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.utils.TrackExecutionTime;
import fr.laposte.blg.blinks.u17.dto.InvoiceExportDto;
import fr.laposte.blg.blinks.u17.util.Constant;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import fr.laposte.blg.blinks.u17.util.ObjectMapperWithModules;
import fr.laposte.blg.blinks.u17.util.StringExportUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;

import java.io.FileWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Slf4j
@Service
@Configuration
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class InfocaInvoiceExportService implements ExportBaseService {

    private static final DecimalFormat df = new DecimalFormat("0.00", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
    private final InvoiceRepository invoiceRepository;
    private final InvoiceMessageRepository invoiceMessageRepository;
    private final ObjectMapperWithModules objectMapper;
    private final DateUtil dateUtil;
    private final ExportService exportService;
    private final ExportProcessRepository exportProcessRepository;

    private final FileSequenceRepository fileSequenceRepository;
    @Value("${fr.laposte.infoca.file.name}")
    String baseName;
    //File version
    @Value("${fr.laposte.infoca.file.version}")
    String version;
    //location of file
    @Value("${fr.laposte.infoca.file.location}")
    String location;
    private String fileName;

    @TrackExecutionTime
    public Mono<ExportHistoryEntity> process(ExportProcess exportProcess, String exportPath) {
        log.info("Début de l'export Infoca");
        if (exportProcess.getMaxId().equals(Long.MAX_VALUE)){
            exportProcess.setMaxId(invoiceRepository.getMaxIdForProcess().block());
        }
        String finalLocation = exportPath != null ? exportPath:location;
        var startTime = Instant.now();
        List<InvoiceExportDto> failedInvoices = new ArrayList<>();
        List<InvoiceExportDto> excludedInvoices = new ArrayList<>();
        List<InvoiceExportDto> validInvoices = new ArrayList<>();
        List<InvoiceDTO> validInvoicesDto = new ArrayList<>();
        List<String[]> finalFileLines = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        this.fileName = baseName + "_" + LocalDateTime.now().format(formatter) + ".is";
        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(finalLocation + fileName)
                , '¤'
                , ICSVWriter.NO_QUOTE_CHARACTER
                , ICSVWriter.NO_ESCAPE_CHARACTER
                , ICSVWriter.DEFAULT_LINE_END
        )) {
            List<Pair<InvoiceEntity, InvoiceDTO>> validInvoicePairs =
                    this.invoiceRepository.findByInfocaExportIdIsNullAndIdBetweenOrderByReferenceAsc(exportProcess.getMinId(), exportProcess.getMaxId())
                            .flatMap(invoiceEntity -> this.invoiceMessageRepository.getMessage(invoiceEntity.getIdInvoice())
                                    .flatMap(message -> {
                                        try {
                                            InvoiceDTO invoiceDTO = this.objectMapper.readValue(message, InvoiceDTO.class);
                                            return Mono.just(Pair.of(invoiceEntity, invoiceDTO));
                                        } catch (JsonProcessingException e) {
                                            log.info("Failure for invoice {} : error when parsing invoice JSON : {}",
                                                    invoiceEntity.getInvoiceNumber(), e.getMessage());
                                            failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Error when parsing invoice JSON: " + e.getMessage(), "U170001"));
                                            return Mono.empty();
                                        }
                                    })
                            )
                            .collectList()
                            .block();
            if (!ObjectUtils.isEmpty(validInvoicePairs)) {
                for (Pair<InvoiceEntity, InvoiceDTO> invoicePair : validInvoicePairs) {
                   finalFileLines.addAll(writeValidInvoices(invoicePair, validInvoices, validInvoicesDto, failedInvoices));
                }
            }
            String[] headerFile = generateHeaderFile(baseName +".is", getFileLines(validInvoicesDto));
            csvWriter.writeNext(headerFile);
            if (!finalFileLines.isEmpty()){
                csvWriter.writeAll(finalFileLines);
            }
        } catch (Exception e) {
            log.error("Couldn't export Infoca file : {}", e.getMessage(), e);
        }
       return this.exportService.generateHistory(startTime, validInvoicesDto, validInvoices, failedInvoices, excludedInvoices, FileType.INFOCA, this.fileName);
    }

    private int getFileLines(List<InvoiceDTO> finalInvoices) {
        int lines = 0;
        if (!ObjectUtils.isEmpty(finalInvoices)) {
            List<InvoiceDTO> invoicesToWrite = finalInvoices.stream()
                    .toList();
            for (InvoiceDTO invoiceDTO : invoicesToWrite) {
                lines = lines + 2;
                for (ContractDTO contract : invoiceDTO.getContracts()) {
                    lines++;
                    for (LinkedAccountDTO linkedAccount : contract.getLinkedAccounts()) {
                        for (InvoiceLineDTO invoiceLine : linkedAccount.getInvoiceLines()) {
                            lines++;
                        }
                    }
                    for (ContractInvoiceLineDto contractInvoiceLineDto : contract.getContractInvoiceLines()) {
                        lines++;
                    }
                }
            }
        }
        return lines;
    }

    private List<String[]> writeValidInvoices(Pair<InvoiceEntity, InvoiceDTO> invoicePair, List<InvoiceExportDto> validInvoices, List<InvoiceDTO> validInvoicesDto, List<InvoiceExportDto> failedInvoices) {
        InvoiceEntity invoiceEntity = invoicePair.getFirst();
        InvoiceDTO invoiceDTO = invoicePair.getSecond();
        List<String[]> validLines = new ArrayList<>();
        List<String[]> linesToWrite = new ArrayList<>();

        try {
            addLineA(invoiceEntity, invoiceDTO, validLines, failedInvoices);
            addLineB(invoiceEntity, invoiceDTO, validLines, failedInvoices);
            addLinesCAndD(invoiceEntity, invoiceDTO, validLines, failedInvoices);
            log.info("Treating invoice {}", invoiceEntity.getInvoiceNumber());
            validInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), null, null));
            validInvoicesDto.add(invoiceDTO);
            linesToWrite.addAll(validLines);
        } catch (Exception e) {
            log.info("Failure for invoice {} : error while proccessing lines: {}", invoiceEntity.getInvoiceNumber(), e.getMessage());
        }
        return linesToWrite;
    }

    private void addLineA(InvoiceEntity invoiceEntity,
                          InvoiceDTO invoiceDTO,
                          List<String[]> validLines,
                          List<InvoiceExportDto> failedInvoices) {
        try {
            String[] lineA = prepareLigneA(invoiceDTO);
            validLines.add(StringExportUtils.replaceNewLineChar(lineA));
        } catch (Exception e) {
            log.info("Failure for invoice {} : error when processing line A: {}",
                    invoiceEntity.getInvoiceNumber(), e.getMessage());
            markInvoiceAsFailed(e, "U170003", "A", failedInvoices, invoiceEntity);
            throw e;
        }
    }

    private void addLineB(InvoiceEntity invoiceEntity,
                          InvoiceDTO invoiceDTO,
                          List<String[]> validLines,
                          List<InvoiceExportDto> failedInvoices) {
        try {
            String[] lineB = prepareLigneB(invoiceDTO);
            validLines.add(StringExportUtils.replaceNewLineChar(lineB));
        } catch (Exception e) {
            log.info("Failure for invoice {} : error when processing line B: {}",
                    invoiceEntity.getInvoiceNumber(), e.getMessage());
            markInvoiceAsFailed(e, "U170004", "B", failedInvoices, invoiceEntity);
            throw e;
        }
    }

    private void addLinesCAndD(InvoiceEntity invoiceEntity,
                               InvoiceDTO invoiceDTO,
                               List<String[]> validLines,
                               List<InvoiceExportDto> failedInvoices) {
        for (ContractDTO contract : invoiceDTO.getContracts()) {
            addLineC(invoiceEntity, invoiceDTO, contract, validLines, failedInvoices);
            for (LinkedAccountDTO linkedAccount : contract.getLinkedAccounts()) {
                addLineD(invoiceEntity, invoiceDTO, contract, linkedAccount, validLines, failedInvoices);
            }
            addLineDC(invoiceEntity, invoiceDTO, contract, validLines, failedInvoices);
        }
    }

    private void addLineC(InvoiceEntity invoiceEntity,
                          InvoiceDTO invoiceDTO,
                          ContractDTO contract,
                          List<String[]> validLines,
                          List<InvoiceExportDto> failedInvoices) {
        try {
            String[] lineC = prepareLigneC(contract, invoiceDTO);
            validLines.add(StringExportUtils.replaceNewLineChar(lineC));
        } catch (Exception e) {
            log.info("Failure for invoice {} : error when processing line C: {}",
                    invoiceEntity.getInvoiceNumber(), e.getMessage());
            markInvoiceAsFailed(e, "U170005", "C", failedInvoices, invoiceEntity);
            throw e;
        }
    }

    private void addLineD(InvoiceEntity invoiceEntity,
                          InvoiceDTO invoiceDTO,
                          ContractDTO contract,
                          LinkedAccountDTO linkedAccount,
                          List<String[]> validLines,
                          List<InvoiceExportDto> failedInvoices) {
        for (InvoiceLineDTO invoiceLine : linkedAccount.getInvoiceLines()) {
            try {
                String[] lineD = prepareLigneD(invoiceLine, contract, invoiceDTO, linkedAccount);
                validLines.add(StringExportUtils.replaceNewLineChar(lineD));
            } catch (Exception e) {
                log.info("Failure for invoice {} : error when processing line D: {}",
                        invoiceEntity.getInvoiceNumber(), e.getMessage());
                markInvoiceAsFailed(e, "U170006", "D", failedInvoices, invoiceEntity);
                throw e;
            }
        }
    }

    private void addLineDC(InvoiceEntity invoiceEntity,
                           InvoiceDTO invoiceDTO,
                           ContractDTO contract,
                           List<String[]> validLines,
                           List<InvoiceExportDto> failedInvoices) {
        for (ContractInvoiceLineDto contractInvoiceLineDto : contract.getContractInvoiceLines()) {
            try {
                String[] lineDC = prepareLigneDCInvoice(contract, invoiceDTO, contractInvoiceLineDto);
                validLines.add(StringExportUtils.replaceNewLineChar(lineDC));
            } catch (Exception e) {
                log.info("Failure for invoice {} : error when processing line DC: {}",
                        invoiceEntity.getInvoiceNumber(), e.getMessage());
                markInvoiceAsFailed(e, "U170007", "DC", failedInvoices, invoiceEntity);
                throw e;
            }
        }
    }

    private void markInvoiceAsFailed(Exception e, String errorCode, String line, List<InvoiceExportDto> failedInvoices, InvoiceEntity invoiceEntity) {
        failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Error when processing line " + line + ": " + e.getMessage(), errorCode));
    }

    private String[] generateHeaderFile(String name, int nbLines) {
        Long sequenceNumber = fileSequenceRepository.incrementSequenceForInfoCA()
                .then(fileSequenceRepository.getCurrentSequenceForInfoCAExport())
                .switchIfEmpty(Mono.error(new RuntimeException("No sequence number for InfoCA")))
                .block();

        return new String[]{
                name,
                dateUtil.yyyyMMdd(Instant.now()),
                String.valueOf(nbLines),
                String.valueOf(sequenceNumber),
        };
    }


    String getInvoiceStatusValue(String value) {
        return value.equals("Blocked") ? "X" : getCancelled(value);
    }

    private String getCancelled(String value) {
        return value.equals("Cancelled") ? "A" : "V";
    }

    private String[] prepareLigneA(InvoiceDTO invoiceDto) {
        var optBillingAccount = Optional.ofNullable(invoiceDto.getBillingAccount());
        var optCustomer = Optional.ofNullable(invoiceDto.getCustomer())
                .map(CustomerDTO::getCustomerInformation);
        return new String[]{"A",
                optBillingAccount.map(BillingAccountDTO::getCustAccNumber).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getExtension).orElse(Constant.EMPTY),
                optCustomer.map(CustomerInformationDTO::getName).orElse(Constant.EMPTY),
                optCustomer.map(CustomerInformationDTO::getBrandName).orElse(Constant.EMPTY),
                optCustomer.map(CustomerInformationDTO::getTypeCode).map(s -> s.equals("A") ? "0" : "1").orElse(Constant.EMPTY),
                optCustomer.map(CustomerInformationDTO::getTypeLabel).orElse(Constant.EMPTY),
                optCustomer.map(CustomerInformationDTO::getSiretCode).orElse(Constant.EMPTY),
                optCustomer.map(CustomerInformationDTO::getCvatno).orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDto.getCustomer())
                        .map(CustomerDTO::getCustomerAddress)
                        .map(CustomerAddressDTO::getAddressId)
                        .map(String::valueOf)
                        .orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getPeriodicityCode).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getPeriodicityLabel).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getPaymentMeanCode).orElse(Constant.EMPTY),
                /**
                 * Suppression de la transco mais la fonction reste présente en code mort pour un éventuel changement
                 * @see #transformPaymentLabel(String)
                */
                optBillingAccount.map(BillingAccountDTO::getPaymentMeanLabel).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getPaymentPeriodCode).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getPaymentPeriodLabel).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getSendingSupportCode).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getSendingSupportLabel).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getUniqueMandateReference)
                        .map(UniqueMandateReferenceDto::getRum).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getUniqueMandateReference)
                        .map(UniqueMandateReferenceDto::getIban).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getUniqueMandateReference)
                        .map(UniqueMandateReferenceDto::getBic).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getUniqueMandateReference)
                        .map(UniqueMandateReferenceDto::getSignatoryLastName).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getSeCode).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getEjCode).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getMarketNumber).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getBillingAddress).map(BillingAddressDto::getAddress).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getSectorCode).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getVatliabilityFlag).map(aBoolean -> aBoolean ? "1" : "0").orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getBusinessTeamId).orElse(Constant.EMPTY),
                optBillingAccount.map(BillingAccountDTO::getBusinessTeamLongname).orElse(Constant.EMPTY)

        };
    }

    private String[] prepareLigneB(InvoiceDTO invoiceDto) {

        var optInvoiceHeader = Optional.ofNullable(invoiceDto.getInvoiceHeader());

        var optBillingAmount = optInvoiceHeader.map(InvoiceHeaderDTO::getBillingAmount);
        return new String[]{"B",
                optInvoiceHeader.map(InvoiceHeaderDTO::getInvoiceNumber).orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDto.getBillingAccount()).map(BillingAccountDTO::getCustAccNumber).orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDto.getBillingAccount()).map(BillingAccountDTO::getExtension).orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDto.getInvoiceHeader().getInvoiceAttachmentNumber()).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getStatus).map(this::getInvoiceStatusValue).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getDedicatedInvoiceFlag)
                        .map(aBoolean -> aBoolean ? "1" : "0")
                        .orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getCreditFlag)
                        .map(aBoolean -> aBoolean ? "1" : "0").orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getDownpaymentFlag)
                        .map(aBoolean -> aBoolean ? "1" : "0")
                        .orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getComment).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getBillingDate)
                        .map(BillingDateDTO::getStartDate).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getBillingDate)
                        .map(BillingDateDTO::getEndDate).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getBillingDate)
                        .map(BillingDateDTO::getCalculationDate).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getBillingDate)
                        .map(BillingDateDTO::getExpiryDate).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getBillingDate)
                        .map(BillingDateDTO::getPaymentDate).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getExcludingTaxTotalAmount)
                        .map(df::format).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getExcludingTaxNetTotalAmount).map(df::format).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getTotalAmount).map(df::format).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getVatTotalAmount).map(df::format).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getDiscountLineExcludingTaxAmount).map(df::format).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getVatAmountPaid).map(df::format).orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getAmountDue).map(df::format).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getIsStatementFlag)
                        .map(aBoolean -> aBoolean ? "1" : "0").orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getDecentralizedStatementFlag)
                        .map(aBoolean -> aBoolean ? "1" : "0").orElse(Constant.EMPTY),
                optBillingAmount.map(BillingAmountDTO::getPaymentCashAmount).map(df::format).orElse(Constant.EMPTY),
                optInvoiceHeader.map(InvoiceHeaderDTO::getRefundableFlag)
                        .map(aBoolean -> aBoolean ? "1" : "0").orElse(Constant.EMPTY),

        };
    }

    private String[] prepareLigneC(ContractDTO contract, InvoiceDTO invoiceDtoFlux) {
        var optInvoiceContractInfo = Optional.ofNullable(contract)
                .map(ContractDTO::getInvoiceContractInfo);
        return new String[]{"C",
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getContractNumber).orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDtoFlux.getInvoiceHeader())
                        .map(InvoiceHeaderDTO::getInvoiceNumber).orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDtoFlux.getBillingAccount()).map(BillingAccountDTO::getCustAccNumber)
                        .orElse(Constant.EMPTY),
                Optional.ofNullable(invoiceDtoFlux.getBillingAccount()).map(BillingAccountDTO::getExtension)
                        .orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getContractVersionValidityStartDateTime).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getContractVersionValidityEndDateTime).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getContractParentContractNumber).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getContractType).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getContractSubType).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getOpsCode).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getCustContractualAgreementReference).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getComment).orElse(Constant.EMPTY),
                //TODO Code de la catégorie à déterminer à partir du libelle
                Constant.EMPTY,
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getCategoryLabel).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getCustInvoiceTermId).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getRepaymentTypeCode).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getRepaymentTypeLabel).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getInvoiceModeCode).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getInvoiceModeLabel).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getCreationChannel).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getSellerSector).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getExcludingTaxTotalAmount).map(df::format).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getTotalAmount).map(df::format).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getInactivationDate).map(dateUtil::yyyyMMddDash).orElse(Constant.EMPTY),
                optInvoiceContractInfo.map(InvoiceContractInfoDTO::getExcludingDiscountAndTaxAmount).map(df::format).orElse(Constant.EMPTY),

        };
    }

    private String[] prepareLigneD(InvoiceLineDTO invoiceLine, ContractDTO contract, InvoiceDTO invoiceDtoFlux, LinkedAccountDTO linkedAccount) {
        var optInvoiceLine = Optional.ofNullable(invoiceLine);
        return new String[]{"D",
                optInvoiceLine.map(InvoiceLineDTO::getNumber).map(String::valueOf)
                        .orElse(Constant.EMPTY),
                Optional.ofNullable(contract.getInvoiceContractInfo())
                        .map(InvoiceContractInfoDTO::getContractNumber).orElse(Constant.EMPTY),
                Optional.of(invoiceDtoFlux).map(InvoiceDTO::getInvoiceHeader).map(InvoiceHeaderDTO::getInvoiceNumber)
                        .orElse(Constant.EMPTY),
                Optional.of(invoiceDtoFlux).map(InvoiceDTO::getBillingAccount)
                        .map(BillingAccountDTO::getCustAccNumber).orElse(Constant.EMPTY),
                Optional.of(invoiceDtoFlux).map(InvoiceDTO::getBillingAccount)
                        .map(BillingAccountDTO::getExtension).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getAttachedNumber)
                        .map(String::valueOf).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getType).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getProductCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getServiceCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getAccountingCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getLabel).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getComment).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getQuantity).map(String::valueOf).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getUnitPrice).map(df::format).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getExcludingTaxAmount).map(df::format).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getVatCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getVatRate).map(df::format).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getVatAmount).map(df::format).orElse(Constant.EMPTY),
                //RGTaxCode vide pour l'instant, nous ne l'avons pas
                Constant.EMPTY,
                optInvoiceLine.map(InvoiceLineDTO::getStampingCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getServiceDate).map(dateUtil::yyyyMMddDash)
                        .orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getRegateCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getAddressId).map(String::valueOf).orElse(Constant.EMPTY),
                //Discount code : inexistant dans invoice -> vide
                Constant.EMPTY,
                //Discount label : vide
                Constant.EMPTY,
                //Discount type : vide
                optInvoiceLine.map(InvoiceLineDTO::getDiscountLineType).orElse(Constant.EMPTY),
                //Discount rate : vide
                Constant.EMPTY,
                //Discount Base : vide
                Constant.EMPTY,
                //LumpSumDiscount : vide
                Constant.EMPTY,
                optInvoiceLine.map(InvoiceLineDTO::getComment).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getConsumerAccountCode).orElse(Constant.EMPTY),
                Optional.of(linkedAccount).map(LinkedAccountDTO::getAccountAddress).map(AccountAdressDto::getAddressId)
                        .map(String::valueOf).orElse(Constant.EMPTY),
                Optional.of(linkedAccount).map(LinkedAccountDTO::getClientAccountCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getCoclicoEmitterCode).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getDepositCustAccNumber).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getExternalRef).orElse(Constant.EMPTY),
                optInvoiceLine.map(InvoiceLineDTO::getDiscountedAccountingCode).orElse(Constant.EMPTY),
                // Le fuelTax est toujours 0 pour les invoiceLine
                "0"
        };
    }

    private String[] prepareLigneDCInvoice(ContractDTO contract, InvoiceDTO invoiceDtoFlux, ContractInvoiceLineDto contractInvoiceLineDto) {
        var optContractInvoiceLine = Optional.ofNullable(contractInvoiceLineDto);
        return new String[]{"D",
                optContractInvoiceLine.map(ContractInvoiceLineDto::getNumber).map(String::valueOf)
                        .orElse(Constant.EMPTY),
                Optional.ofNullable(contract.getInvoiceContractInfo())
                        .map(InvoiceContractInfoDTO::getContractNumber).orElse(Constant.EMPTY),
                Optional.of(invoiceDtoFlux).map(InvoiceDTO::getInvoiceHeader).map(InvoiceHeaderDTO::getInvoiceNumber)
                        .orElse(Constant.EMPTY),
                Optional.of(invoiceDtoFlux).map(InvoiceDTO::getBillingAccount)
                        .map(BillingAccountDTO::getCustAccNumber).orElse(Constant.EMPTY),
                Optional.of(invoiceDtoFlux).map(InvoiceDTO::getBillingAccount)
                        .map(BillingAccountDTO::getExtension).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getAttachedNumber)
                        .map(String::valueOf).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getType).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getProductCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getServiceCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getAccountingCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getLabel).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getComment).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getQuantity).map(String::valueOf).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getUnitPrice).map(df::format).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getExcludingTaxAmount).map(df::format).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getVatCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getVatRate).map(df::format).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getVatAmount).map(df::format).orElse(Constant.EMPTY),
                //RGTaxCode vide pour l'instant, nous ne l'avons pas
                Constant.EMPTY,
                optContractInvoiceLine.map(ContractInvoiceLineDto::getStampingCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getServiceDate).map(dateUtil::yyyyMMddDash)
                        .orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getRegateCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getAddressId).map(String::valueOf).orElse(Constant.EMPTY),
                //Discount code : inexistant dans invoice -> vide
                Constant.EMPTY,
                //Discount label : vide
                Constant.EMPTY,
                //Discount type : vide
                optContractInvoiceLine.map(ContractInvoiceLineDto::getDiscountLineType).orElse(Constant.EMPTY),
                //Discount rate : vide
                Constant.EMPTY,
                //Discount Base : vide
                Constant.EMPTY,
                //LumpSumDiscount : vide
                Constant.EMPTY,
                optContractInvoiceLine.map(ContractInvoiceLineDto::getComment).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getConsumerAccountCode).orElse(Constant.EMPTY),
                // vide sur ContractInvoiceLine
                Constant.EMPTY,
                Constant.EMPTY,
                optContractInvoiceLine.map(ContractInvoiceLineDto::getCoclicoEmitterCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getDepositCustAccNumber).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getExternalRef).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getDiscountedAccountingCode).orElse(Constant.EMPTY),
                optContractInvoiceLine.map(ContractInvoiceLineDto::getFuelTax).map(fuelTax -> fuelTax ? "1" : "0").orElse(String.valueOf(Boolean.valueOf(Constant.EMPTY)))
        };
    }
}
