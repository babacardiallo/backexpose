package fr.laposte.blg.blinks.u11.listener.refops;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.entities.RefopsEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.RefopsRepository;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.u11.mapper.RefopsListenerMapper;
import fr.laposte.r5.uk.kafka.avro.viewoscar.Oscar;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Data
@Slf4j
@RequiredArgsConstructor
public class RefopsListenerService {


    private final RefopsListenerMapper refopsListenerMapper;
    private final ErrorLogService errorLogService;
    private final RefopsRepository refopsRepository;

    public Mono<Void> readRefopsOffer(ConsumerRecord<String, Oscar> receiverRecord) {
        Oscar refopsOffer;
        RefopsEntity refopsEntity;
        try {
            refopsOffer = receiverRecord.value();
        } catch (Exception e) {
            return Mono.error(e);
        }
        try {
            refopsEntity = refopsListenerMapper.refopsToRefopsEntity(refopsOffer);
            return refopsRepository.findByOpsCode(refopsEntity.getOpsCode())
                .map(refopsEntity1 -> {
                    refopsEntity1.setOfferTechnicalVersion(refopsEntity.getOfferTechnicalVersion());
                    refopsEntity1.setOfferFunctionalVersion(refopsEntity.getOfferFunctionalVersion());
                    refopsEntity1.setOfferVersionCreationDatetime(refopsEntity.getOfferVersionCreationDatetime());
                    refopsEntity1.setOpsLabel(refopsEntity.getOpsLabel());
                    refopsEntity1.setData(refopsEntity.getData());
                    return refopsEntity1;
                })
                .flatMap(this.refopsRepository::save)
                .switchIfEmpty(this.refopsRepository.save(refopsEntity))
                .then();
        } catch (JsonProcessingException e) {
            var errorMessage = String.format("Error during json processing of Refops on offer: %s", refopsOffer.getOfferCode());
            log.error(errorMessage, e);
            return Mono.empty();
        }
    }
}