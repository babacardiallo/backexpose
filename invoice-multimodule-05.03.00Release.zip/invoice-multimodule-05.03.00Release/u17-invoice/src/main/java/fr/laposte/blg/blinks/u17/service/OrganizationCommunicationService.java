package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.u17.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u17.dto.organization.OrganizationDto;
import fr.laposte.blg.blinks.u17.mapper.OrganizationMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@ConfigurationProperties(prefix = "fr.laposte.apim.organization")
@ConditionalOnProperty(value = "fr.laposte.apim.organization.service", havingValue = "true")
@Slf4j
@Data
public class OrganizationCommunicationService {

    private String apiName;
    private String endpoint;

    private final ApimServiceImpl apimService;
    private final OrganizationMapper organizationMapper;

    public Flux<OrganizationDto> fetchOrganizations(Optional<LocalDate> date, List<String> listActivitiesToFilter) {
        // Préparation des queryParams pour Source Orga
        // Formattage de la date dans le format attendu par Source Orga
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("metier", String.join(",", listActivitiesToFilter));
        date.ifPresent(dateValue -> queryParams.add("date", dateValue.toString()));
        log.info("QUERY PARAMS {}", queryParams);
        return apimService.get(apiName + endpoint, queryParams)
                .flatMapIterable(this::splitStringToFluxForEachLine)
                .switchOnFirst((signal, stringFlux) -> {
                    //On intercepte ici le premier élément du flux cad le header
                    if (signal.hasValue() && Objects.nonNull(signal.get())) {
                        List<String> metas = this.setMappingArray(signal.get());
                        log.debug("HEADER deserialized {}", metas);
                        return stringFlux.skip(1)
                                .parallel()
                                .runOn(Schedulers.boundedElastic())
                                .map(lineCsv -> organizationMapper
                                        .rawDataToOrganizationtDto(lineCsv, metas));
                    } else {
                        // L'erreur est fatale ici et on bloque toute la chaine (flux) de traitement
                        return Flux.error(new RuntimeException("No Header returned by Source Orga"));
                    }
                });
    }

    private List<String> splitStringToFluxForEachLine(String response) {
        List<String> lines = Arrays.asList(response.split("\n"));
        return lines;
    }

    private List<String> setMappingArray(String firstLine) {
        List<String> metas = Arrays.asList(firstLine.split(";"));
        return metas;
    }

}
