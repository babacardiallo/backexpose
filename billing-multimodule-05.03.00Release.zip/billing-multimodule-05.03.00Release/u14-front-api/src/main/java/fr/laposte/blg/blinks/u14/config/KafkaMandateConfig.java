package fr.laposte.blg.blinks.u14.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Slf4j
@Data
@Configuration
@ConfigurationProperties(prefix = "fr.laposte.kafka-config")
public class KafkaMandateConfig {
    String properties;
    @Value("${fr.laposte.keystore-location}")
    String keyStoreLocation;
    @Value("${fr.laposte.keystore-password}")
    String keyStorePassword;

    @Bean
    Properties kafkaMandateSenderConfig() {
        log.debug("Loading kafka file configuration {}", properties);
        Properties props = new Properties();
        try (InputStream input = this.getClass()
                .getClassLoader()
                .getResourceAsStream(properties)) {
            props.load(input);
            props.put("ssl.keystore.location", keyStoreLocation);
            props.put("ssl.keystore.password", keyStorePassword);
            props.put("ssl.truststore.location", keyStoreLocation);
            props.put("ssl.truststore.password", keyStorePassword);
            props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
            props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
            props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 5);
            props.put("proxy.port", Integer.parseInt("8080"));
            log.debug("KAFKA stream Configuration properties : {}", props);
        } catch (IOException ex) {
            log.debug("Loading kafka file configuration error: {}", ex.getMessage());
        }
        return props;
    }
}

