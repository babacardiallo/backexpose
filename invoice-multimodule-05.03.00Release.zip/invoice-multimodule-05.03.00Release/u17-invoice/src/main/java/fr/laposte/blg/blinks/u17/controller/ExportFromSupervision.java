package fr.laposte.blg.blinks.u17.controller;


import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.u17.service.DocaposteService;
import fr.laposte.blg.blinks.u17.service.CoeurfinanceService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;


@RestController
@RequestMapping("/supervision-export")
@CrossOrigin
@Data
public class ExportFromSupervision {
    private final CoeurfinanceService coeurfinanceService;

    private final DocaposteService docaposteService;

    private final InfocaInvoiceExportService infocaService;

    @PostMapping(value = "/coeurfinance/run")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Boolean> runCoeurfinanceExport(
            @RequestParam(required = false) Long minId,
            @RequestParam(required = false) Long maxId,
            @RequestParam(required = false) String exportPath
    ) {
        Long finalMinId = minId !=null ? minId : 1L;
        Long finalMaxId = maxId != null ? maxId : Long.MAX_VALUE;
        ExportProcess e = new ExportProcess();
        e.setMinId(finalMinId);
        e.setMaxId(finalMaxId);
        Mono.fromRunnable(() -> coeurfinanceService.process(e, exportPath))
                .subscribeOn(Schedulers.boundedElastic())
                .subscribe();
        return Mono.just(true);
    }


    @PostMapping(value = "/docaposte/run")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Boolean> runDocaposteExport(
            @RequestParam(required = false) Long minId,
            @RequestParam(required = false) Long maxId,
            @RequestParam(required = false) String exportPath,
            @RequestParam(defaultValue = "0") boolean isAvis
    ) {
        Long finalMinId = minId !=null ? minId : 1L;
        Long finalMaxId = maxId != null ? maxId : Long.MAX_VALUE;
        ExportProcess e = new ExportProcess();
        e.setMinId(finalMinId);
        e.setMaxId(finalMaxId);
        if(isAvis){
            e.setFileType(FileType.DOCAPOSTE_AVIS_PAIEMENT);
        } else {
            e.setFileType(FileType.DOCAPOSTE);
        }
        Mono.fromRunnable(() -> docaposteService.process(e, exportPath))
                .subscribeOn(Schedulers.boundedElastic())
                .subscribe();
        return Mono.just(true);
    }

    @PostMapping(value = "/infoca/run")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Boolean> runInfocaExport(
            @RequestParam(required = false) Long minId,
            @RequestParam(required = false) Long maxId,
            @RequestParam(required = false) String exportPath
    ) {
        Long finalMinId = minId !=null ? minId : 1L;
        Long finalMaxId = maxId != null ? maxId : Long.MAX_VALUE;
        ExportProcess e = new ExportProcess();
        e.setMinId(finalMinId);
        e.setMaxId(finalMaxId);
        Mono.fromRunnable(() -> infocaService.process(e, exportPath))
                .subscribeOn(Schedulers.boundedElastic())
                .subscribe();

        return Mono.just(true);
    }
}
