CREATE OR REPLACE VIEW `offer_errors_view` AS
SELECT
        `er`.`contract_number` AS `contract_number`,
        `er`.`revision_number` AS `revision_number`,
        `er`.`amendment_number` AS `amendment_number`,
        `er`.`date_error` AS `date_error`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        `cv`.`date_synchronization` AS `previous_date_synchronization`,
        `er`.`workflow_step` AS `workflow_step`,
        `er`.`error_message` AS `error_message`,
        `er`.`ops_code` AS `ops_code`
    FROM
        ((`error_log` `er`
        LEFT JOIN `contract` `c` ON ((`er`.`contract_number` = `c`.`contract_number`)))
        LEFT JOIN `contract_version` `cv` ON (((`c`.`id_contract` = `cv`.`id_contract`)
            AND (`er`.`amendment_number` = `cv`.`amendment_number`))))
    WHERE
        ((`er`.`ops_code` IS NOT NULL)
            AND (`er`.`contract_number` , `er`.`amendment_number`,
            `er`.`date_error`) IN (SELECT
                `error_log`.`contract_number`,
                    `error_log`.`amendment_number`,
                    MAX(`error_log`.`date_error`)
            FROM
                `error_log`
            GROUP BY `error_log`.`contract_number` , `error_log`.`amendment_number` , `error_log`.`workflow_step`)
            AND (((`er`.`workflow_step` LIKE 'CONTRACT%')
            AND ((`cv`.`revision_number` IS NULL)
            OR (`er`.`revision_number` > `cv`.`revision_number`)))
            OR ((`er`.`workflow_step` LIKE '%SYNCH%')
            AND ((`c`.`contract_number` IS NULL)
            OR (`er`.`amendment_number` <> `cv`.`amendment_number`)
            OR (`er`.`revision_number` >= `cv`.`revision_number`)))))