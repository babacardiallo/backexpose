package fr.laposte.blg.blinks.u11.mapper;

import fr.laposte.blg.blinks.lib.common.entities.MandateEntity;
import fr.laposte.blg.blinks.u11.listener.contract.dto.MandateDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest(classes=MandateMapper.class)
class MandateMapperTest {

    @Autowired
    MandateMapper mapper;

    @Test
    void mandateToMandateEntityNotNullTest(){
        MandateEntity mandateEntity = new MandateEntity();
        MandateDTO mandateDTO = new MandateDTO();
        mandateDTO.setIdMandate(1L);
        mandateDTO.setRum("RUM");
        mandateDTO.setBic("BIC");
        mandateDTO.setIban("IBAN");
        mandateDTO.setStatus("STATUS");
        mandateEntity = mapper.mandateToMandateEntity(mandateDTO, mandateEntity);
        assertEquals(mandateDTO.getRum(), mandateEntity.getRum());
        assertEquals(mandateDTO.getBic(), mandateEntity.getBic());
        assertEquals(mandateDTO.getIban(), mandateEntity.getIban());
        assertEquals(mandateDTO.getStatus(), mandateEntity.getStatus());
    }


    @Test
    void mandateToMandateEntityNullTest(){
        MandateEntity mandateEntity = new MandateEntity();
        mandateEntity = mapper.mandateToMandateEntity(null, mandateEntity);
        assertNull(mandateEntity);
    }
}

