/* eslint-disable @typescript-eslint/no-unused-vars */
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { OffresComponent } from './offres.component';

describe('OffresComponent', () => {
  let component: OffresComponent;
  let fixture: ComponentFixture<OffresComponent>;

  /** Async Before each */
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [OffresComponent]
    }).compileComponents();
  }));

  /** Sync before each */
  beforeEach(() => {
    fixture = TestBed.createComponent(OffresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  /** @Test: Component creation test */
  it('Should create component', () => {
    expect(component).toBeTruthy();
  });

  /** @Test: Component display external HTML template */
  it('Should display external HTML template', () => {
    // query for the message <p> by CSS element selector
    expect(fixture.debugElement.query(By.css('#home'))).toBeTruthy();
  });
});

