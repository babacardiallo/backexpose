import { HttpParams } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ModalService } from 'ngx-modal-ease';
import { map, mergeAll, mergeMap, toArray } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Invoice } from '../../models/invoice';
import { InvoicePage } from '../../models/invoice.page';
import { LancementExportService } from '../../services/Lancement-export.service';
import { SendFileComponent } from '../send-file/send-file.component';

@Component({
    selector: 'invoice-export',
    templateUrl: './invoice-export.component.html',
    styleUrls: ['./invoice-export.component.scss'],
    standalone: false
})

export class InvoiceToExportComponent implements OnInit, AfterViewInit {


    appName = environment.appName;

    @ViewChild(DatatableComponent) invoicesToExport: DatatableComponent;


    @Output() emitRefreshData: EventEmitter<boolean> = new EventEmitter<boolean>();

    listInvoicesToExport: Array<Invoice> = [];

    initialListToExport: Array<Invoice> = [];

    listChoix = ['docapostExportId', 'infocaExportId', 'coeurfinanceExportId'];

    public searchText = '';

    public isLoading = false;

    isDocaposte: boolean = true;

    isInfoca: boolean = true;

    isCoeurfinance: boolean = true;

    selectedInvoices: Array<string> = [];


    invoicePage: InvoicePage = new InvoicePage();

    env = environment.name;

    M1_MODAL_PROPERTIES = {
        animation: 'enter-scale-down',
        duration: '0.1s',
        easing: 'ease-out',
        padding: '1rem',
        width: '600px'
    };


    constructor(private _cdr: ChangeDetectorRef, private lancementExportService: LancementExportService, private modalService: ModalService) { }

    ngAfterViewInit(): void {
    }

    ngOnInit(): void {
        this.getAllInvoices(0, 5, "invoiceNumber", "desc");
    }
    getAllInvoices(page: number, itemPerPage: number, sort: string, order: string): void {

        this.lancementExportService.getAllInvoicesToExport(page, itemPerPage, sort, order).subscribe({
            next: (response: any) => {
                this.listInvoicesToExport = response.content.map((data: any) => {
                    const message = data.message ? JSON.parse(data.message) : '';
                    return <Invoice>{
                        id: data.id,
                        invoiceNumber : data.invoiceNumber,
                        message : data.message,
                        billRunId : data.billRunId,
                        docapostExportId : data.docapostExportId,
                        infocaExportId : data.infocaExportId,
                        coeurfinanceExportId : data.coeurfinanceExportId,
                        custAccNumber:  message != '' ? message.billingAccount.custAccNumber  + "-" + message.billingAccount.extension : '',
                        printFlag: message != '' ? message.invoiceHeader.printFlag ? "Docaposte" : "Seres" : "Docaposte",
                    };
                })
                this.invoicePage = {
                    currentPage: response.pageable.pageNumber,
                    itemsOnPage: response.pageable.pageSize,
                    currentOffset: response.pageable.offset,
                    totalPages: response.totalPages,
                    totalItems: response.totalElements
                }
            },
            complete: () => {

            },
        });

    }

    fetchAllInvoices() {
        this.getAllInvoices(0, 5, "invoiceNumber", "desc");
    }


    onSelect(event: any) {
        this.selectedInvoices = event.selected.map((value: Invoice) => value.invoiceNumber);
    }



    launchExport() {
        if (!this.isDocaposte && !this.isInfoca && !this.isCoeurfinance) {
            return;
        }
        this.isLoading = true;
        if (this.isDocaposte) {
            let queryParams = new HttpParams()
            .set("isAvis", false);
            this.lancementExportService.export(environment.API_EXPORT_DOCAPOSTE + "?" + queryParams ).subscribe(res => { });
            setTimeout(() => {
                let queryParams = new HttpParams()
                .set("isAvis", true);
                this.lancementExportService.export(environment.API_EXPORT_DOCAPOSTE + "?" + queryParams).subscribe(res => { });
            }, 5000);
        }
        if (this.isInfoca) {
            this.lancementExportService.export(environment.API_EXPORT_INFOCA).subscribe(res => { });
        }
        if (this.isCoeurfinance) {
            this.lancementExportService.export(environment.API_EXPORT_COEURFINANCE).subscribe(res => { });
        }
        setTimeout(() => {
            this.getAllInvoices(0, 5, "invoiceNumber", "desc");
            this.emitRefreshData.emit(true);
            this.isLoading = false;
        }, 10000);
    }


    onPageChange(event: any) {
        this.getAllInvoices(event.offset, 5, this.invoicesToExport.sorts[0].prop, this.invoicesToExport.sorts[0].dir);
    }

    onSort(event: any) {
        this.getAllInvoices(this.invoicePage.currentPage!, 5, event.sorts[0].prop, event.sorts[0].dir);
        this.invoicesToExport.offset = this.invoicePage.currentPage!;
    }
    sendFile() {
        this.modalService
        .open(SendFileComponent, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
          },
          data: {
            env: this.env,
          }
        })
        .then((response) => console.log(response));
    }

}
