package fr.laposte.blg.blinks.u11.listener.address;

import MD.LatestValue.Address;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.AddressRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractVersionRepository;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u11.listener.contract.ContractFullService;
import fr.laposte.blg.blinks.u11.mapper.AddressListenerMapper;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.EventOrigin;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.TypeEnum;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Slf4j
@RequiredArgsConstructor
public class AddressListenerService {

    private final AddressRepository addressRepository;

    private final ContractRepository contractRepository;

    private final ContractVersionRepository contractVersionRepository;

    private final ContractService contractService;

    private final ContractFullService contractFullService;

    private final AddressListenerMapper addressListenerMapper;

    private final SynchronizationSender synchronizationSender;

    private final LegalPersonService legalPersonService;

    private final ErrorLogService errorLogService;

    public Mono<Void> updateAddress(ConsumerRecord<String, Address> addressReceiverRecord) {
        Address address;
        try { //To avoid any message of other type than Address as we got LegalPerson
            address = addressReceiverRecord.value();
        } catch (Exception e) {
            return Mono.error(e);
        }
        return Mono.justOrEmpty(address.getRefpmAdressId().toString())
            // Search for old address in database
            .flatMap(this.addressRepository::findByAddressIdRefPM)
            .doOnNext(addressEntity -> log.debug("Found address ID {} in database, triggering update", addressEntity.getIdAddress()))
            .map(addressEntity -> {
                AddressEntity updatedEntity = this.addressListenerMapper.addressToAddressEntity(address);
                updatedEntity.setIdLegalPerson(addressEntity.getIdLegalPerson());
                updatedEntity.setIdAddress(addressEntity.getIdAddress());
                return updatedEntity;
            })
            //New address on a customer use case
            .switchIfEmpty(Mono.defer(() -> Mono.justOrEmpty(this.addressListenerMapper.addressToAddressEntity(address)) //Pas très couteux
                    .flatMap(addressEntity -> legalPersonService.findLegalPersonByCoclico(addressEntity.getCustAccNumber(), false)
                        .map(legalPersonEntity -> {
                                addressEntity.setLegalPersonEntity(legalPersonEntity);
                                addressEntity.setIdLegalPerson(legalPersonEntity.getIdLegalPerson());
                                return addressEntity;
                            }
                        )
                    )
                )
            )
            // Save the new address in database only if the refPmID was found and the type is FACTURATION
            .filter(addressEntity -> addressEntity.getAddressType().equals(AddressType.FACTURATION)
                || addressEntity.getAddressType().equals(AddressType.PRESTATION)
            )
            .flatMap(this.addressRepository::save)
            // Trigger contract resync for all contracts using this invoice address
            .flatMap(addressEntity ->
                {
                    if (addressEntity.getAddressType().equals(AddressType.FACTURATION)) {
                        //Je récupère toutes les versions de contrats utilisant cette adresse
                        return this.contractVersionRepository.findContractVersionUsingRefPMAddressId(addressEntity.getAddressIdRefPM())
                                .filterWhen(contractVersionEntity -> contractFullService.isOfferOfContractEligibleUpdate(contractVersionEntity))
                                .flatMap(contractVersionEntity -> {
                                //Je passe toutes les versions qui utilisent l'adresse en candidats à la synchro
                                contractVersionEntity.setSynchronized(false);
                                return contractVersionRepository.save(contractVersionEntity);
                            })
                            .map(ContractVersionEntity::getIdContract)
                            .distinct() //Pour éviter de publier plusieurs demandes de synchro sur le contrat
                            .flatMap(idContract -> this.publishAddressSyncCommand(idContract, addressReceiverRecord.topic(), addressReceiverRecord.key()))
                            .then();
                    } else if (addressEntity.getAddressType().equals(AddressType.PRESTATION)) {
                        return
                            legalPersonService.findLegalPersonByIdLegalPerson(addressEntity.getIdLegalPerson(), false)
                                .flatMap(legalPersonEntity -> { // On marque le client comme étant à synchroniser
                                    legalPersonEntity.setSynchronized(false);
                                    return legalPersonService.save(legalPersonEntity, false);
                                })
                                .flatMap(legalPersonEntity ->
                                    publishCustomerSyncCommand(legalPersonEntity.getIdLegalPerson()
                                        , addressReceiverRecord.topic()
                                        , addressReceiverRecord.key()));

                    }
                    return Mono.empty();
                }
            )
            .onErrorResume(
                throwable -> {
                    var errorLog = ErrorLogEntity.builder().idAddressREFPM(Long.parseLong(addressReceiverRecord.key()))
                        .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.ADDRESS_LISTENING)
                        .errorMessage("Error during address listening :" + throwable.getMessage())
                        .codeError(CodeErrorEnum.U11006)
                        .build();
                    return errorLogService.logError(errorLog)
                        .then(Mono.empty());
                }
            )
            .then();
    }

    public Mono<Void> publishAddressSyncCommand(long idContract, String topic, String key) {
        return Mono.just(idContract)
            .map(id ->
                Synchronization.newBuilder()
                    .setAction(ActionEnum.update)
                    .setType(TypeEnum.contract)
                    .setInternalId(id.intValue())
                    .setEventOrigin(EventOrigin.newBuilder()
                        .setKey(key)
                        .setTopic(topic).build())
                    .build()
            )
            .flatMap(this.synchronizationSender::send);
    }

    public Mono<Void> publishCustomerSyncCommand(long idLegalPerson, String topic, String key) {
        return Mono.just(idLegalPerson)
            .map(id ->
                Synchronization.newBuilder()
                    .setAction(ActionEnum.update)
                    .setType(TypeEnum.customer)
                    .setInternalId(id.intValue())
                    .setEventOrigin(EventOrigin.newBuilder()
                        .setKey(key)
                        .setTopic(topic).build())
                    .build()
            )
            .flatMap(this.synchronizationSender::send);
    }

}
