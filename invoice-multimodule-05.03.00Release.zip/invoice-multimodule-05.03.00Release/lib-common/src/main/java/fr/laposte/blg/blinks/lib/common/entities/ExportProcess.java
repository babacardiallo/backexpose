package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("export_process")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExportProcess {
    @Id
    @Column("id")
    private Long id;
    @Column("min_id")
    private Long minId;
    @Column("max_id")
    private Long maxId;
    @Column("execution_date")
    private Instant executionDate;
    @Column("file_type")
    private FileType fileType;
    @Column("export_process_status")
    private ExportProcessStatus exportProcessStatus;
    @Column("error_code")
    private String errorCode;
    @Column("error_message")
    private String errorMessage;
    @Column("execution_sequence")
    private int executionSequence;

    public ExportProcess(Long minId, Long maxId, Instant executionDate, FileType fileType, ExportProcessStatus exportProcessStatus, String errorCode, String errorMessage, int executionSequence){
        this.minId = minId;
        this.maxId = maxId;
        this.executionDate = executionDate;
        this.fileType  = fileType;
        this.exportProcessStatus = exportProcessStatus;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.executionSequence = executionSequence;
    }

}
