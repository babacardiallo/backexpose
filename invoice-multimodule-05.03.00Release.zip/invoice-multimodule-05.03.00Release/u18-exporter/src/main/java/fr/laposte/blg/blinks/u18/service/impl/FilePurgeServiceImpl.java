package fr.laposte.blg.blinks.u18.service.impl;

import fr.laposte.blg.blinks.u18.service.FilePurgeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
@Service
@Slf4j
public class FilePurgeServiceImpl implements FilePurgeService {

    @Override
    public int purgeFilesOlderThan(String folderPath, Instant threshold) {
        Path directory = Paths.get(folderPath);
        int deletedCount = 0;

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
            for (Path file : stream) {
                if (isOlderThan(file, threshold)) {
                    try {
                        Files.delete(file);
                        log.info("Deleted old file: {}", file.getFileName());
                        deletedCount++;
                    } catch (IOException e) {
                        log.warn("Failed to delete file '{}': {}", file.getFileName(), e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            log.error("Failed to access directory '{}': {}", folderPath, e.getMessage());
        }

        return deletedCount;
    }

    private boolean isOlderThan(Path file, Instant threshold) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
            return attrs.lastModifiedTime().toInstant().isBefore(threshold);
        } catch (IOException e) {
            log.warn("Failed to read attributes for file '{}': {}", file.getFileName(), e.getMessage());
            return false;
        }
    }
}
