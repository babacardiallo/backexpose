package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Data
@NoArgsConstructor
public class ReplayReportDto {

    private AtomicLong nbSuccess = new AtomicLong();
    private AtomicLong nbErrors = new AtomicLong();
    private long nbTotal;
    private HashMap<String, String> mapErrors = new HashMap<>();
    private List<String> listSuccess = new ArrayList<String>();
    private boolean isWaitingResponse = true;
    private String shortMessage;

}
