package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public interface ExportBaseService {
    public Mono<ExportHistoryEntity> process(ExportProcess exportProcess, String exportPath);
}
