package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("mandate")
@Accessors(chain = true)
@Data
public class MandateEntity {

    @Id
    @Column("id_mandate")
    private Long idMandate;

    @Column("rum")
    @NotNull
    private String rum;

    @Column("iban")
    @NotNull
    private String iban;

    @Column("bic")
    @NotNull
    private String bic;

    @Column("status")
    @NotNull
    private String status;
}
