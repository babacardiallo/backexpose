package fr.laposte.blg.blinks.u12.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.EstablishmentRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.MandateRepository;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u12.dto.RefEquipeCommerciale;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationLegalPersonAPICallException;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationMandateAPICallException;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationSourceOrgaAPICallException;
import fr.laposte.blg.blinks.u12.mapper.EstablishmentMapper;
import fr.laposte.blg.blinks.u12.mapper.LegalPersonViewMapper;
import fr.laposte.blg.blinks.u12.mapper.MandateDTOMapper;
import fr.laposte.blg.blinks.u12.service.customer.LegalPersonCommunicationService;
import fr.laposte.blg.blinks.u12.service.customer.RefComCommunicationService;
import fr.laposte.blg.blinks.u12.service.establishment.EstablishmentService;
import fr.laposte.blg.blinks.u12.service.mandate.MandateService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.Exceptions;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

@Service
@Data
@RequiredArgsConstructor
public class ImportService {

    private final LegalPersonCommunicationService legalPersonCommunicationService;
    private final LegalPersonService legalPersonService;
    private final LegalPersonViewMapper legalPersonViewMapper;
    private final MandateService mandateService;
    private final MandateRepository mandateRepository;
    private final MandateDTOMapper mandateDTOMapper;
    private final EstablishmentService establishmentService;
    private final EstablishmentMapper establishmentMapper;
    private final EstablishmentRepository establishmentRepository;
    private final ContractRepository contractRepository;
    private final RefComCommunicationService refComCommunicationService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Transactional
    public Mono<LegalPersonEntity> createOrFetchCustomerChain(ContractEntity contractEntity) {
        assert (Objects.nonNull(contractEntity.getCustAccNumber()));

        var coclicoCustAccNumber = contractEntity.getCustAccNumber();

        return
            Mono.justOrEmpty(contractEntity.getIdLegalPerson())
                //1. Première tentative de récup via la clé étrangère - cas update contrat client existant
                .flatMap(idLegalPerson -> legalPersonService.findLegalPersonByIdLegalPerson(idLegalPerson, true))
                //2. Deuxième tentative par le coclicoCustAccNumber - cas création contrat avec client existant
                .switchIfEmpty(Mono.defer(() -> legalPersonService.findLegalPersonByCoclico(coclicoCustAccNumber, true)))
                //3. Troisième tentative par appel API - cas création contrat sans client
                .switchIfEmpty(Mono.defer(() ->
                    this.fetchLegalPerson(coclicoCustAccNumber)
                        .flatMap(tuple2 -> {
                            LegalPersonEntity legalPersonEntity = tuple2.getT1();
                            legalPersonEntity.setCreated(Instant.now());
                            return Mono.zip(legalPersonService.save(legalPersonEntity, true), Mono.just(tuple2.getT2()));
                        })
                        .flatMap(tupleFinal -> legalPersonService.saveLegalPersonMessage(tupleFinal.getT1(), tupleFinal.getT2()).thenReturn(tupleFinal.getT1()))))
                .flatMap(legalPersonEntity -> {
                    if(legalPersonEntity.getBusinessTeamLongName()==null || legalPersonEntity.getBusinessTeamLongName().isBlank()){
                        return fetchBusinessTeam(coclicoCustAccNumber, legalPersonEntity, LocalDate.now());
                    } else {
                        return Mono.just(legalPersonEntity);
                    }
                })
                .map(legalPersonEntity -> contractEntity
                    .setLegalPersonEntity(legalPersonEntity)
                    .setIdLegalPerson(legalPersonEntity.getIdLegalPerson())
                )
                .flatMap(contractRepository::save)
                .map(ContractEntity::getLegalPersonEntity)
            ;
    }

    public Mono<Tuple2<LegalPersonEntity, LegalPersonMessage>> fetchLegalPerson(int coclico) {
        return this.legalPersonCommunicationService.fetchLegalPerson(coclico)
            .map(legalPersonDTO -> {
                try {
                    LegalPersonEntity legalPersonEntity = legalPersonViewMapper.legalPersonDTOToLegalPersonEntity(legalPersonDTO);
                    objectMapper.registerModule(new JavaTimeModule());
                    String json = this.objectMapper.writeValueAsString(legalPersonDTO);
                    LegalPersonMessage legalPersonMessage = new LegalPersonMessage();
                    legalPersonMessage.setLegalPersonJson(json);
                    return Tuples.of(legalPersonEntity, legalPersonMessage);
                } catch (Exception e) {
                    throw Exceptions.propagate(e);
                }
            })
                .onErrorMap(throwable ->
                new SynchronizationLegalPersonAPICallException("[CLIENT: " + coclico + "] Unable to fetch legalPerson API or to parse the answer from the API: " + throwable.getMessage()
                    , throwable
                    , coclico
                    , CodeErrorEnum.U12002)
            );
    }

    public Mono<MandateEntity> findOrFetchMandate(String rum) {
        return Mono.justOrEmpty(rum)
            .flatMap(this.mandateRepository::findFirstByRum)
            .switchIfEmpty(Mono.defer(() -> this.mandateService.fetchMandate(rum)
                .map(this.mandateDTOMapper::mandateDTOToMandateEntity)
                .flatMap(this.mandateRepository::save)
                .onErrorMap(throwable -> new SynchronizationMandateAPICallException("Unable to fetch mandate through SEPA API: " + throwable.getMessage()
                        , throwable
                        , rum
                        , CodeErrorEnum.U12004))
            ));
    }

    public Mono<EstablishmentEntity> findOrFetchEstablishment(String regate) {
        return this.establishmentRepository.findByRegateCode(regate)
            .switchIfEmpty(Mono.defer(() -> this.establishmentService.fetchEstablishment(regate)
                .onErrorMap(e ->
                    new SynchronizationSourceOrgaAPICallException(
                        "[ESTABLISHMENT: "+ regate +"] Unable to fetch establishement API " + e.getMessage()
                        , e
                        , regate
                        , CodeErrorEnum.U12005
                    ))
                .map(this.establishmentMapper::establishmentDTOToEstablishmentEntity)
                .flatMap(this.establishmentRepository::save)
            ));
    }

    public Mono<LegalPersonEntity> fetchBusinessTeam(int coclico, LegalPersonEntity legalPersonEntity, LocalDate localDate) {
        return this.refComCommunicationService.fetchTeamCodeAndName(coclico, localDate)
                .switchIfEmpty(Mono.defer(() -> Mono.just(new RefEquipeCommerciale(99999999, "NOT_FOUND"))))
                .map(refEquipeCommerciale -> {
                    if(refEquipeCommerciale.getBusinessTeamId() == null || refEquipeCommerciale.getBusinessTeamLongName() == null || refEquipeCommerciale.getBusinessTeamLongName().isBlank()){
                        legalPersonEntity.setBusinessTeamId(99999999);
                        legalPersonEntity.setBusinessTeamLongName("NOT_FOUND");
                    } else {
                        legalPersonEntity.setBusinessTeamId(refEquipeCommerciale.getBusinessTeamId());
                        legalPersonEntity.setBusinessTeamLongName(refEquipeCommerciale.getBusinessTeamLongName());
                    }

                    return legalPersonEntity;
                })
                .flatMap(legalPersonEntity1 -> legalPersonService.save(legalPersonEntity, false))
                .onErrorMap(throwable ->
                        new SynchronizationLegalPersonAPICallException("[REFCOM CLIENT: "+ coclico + "] Unable to fetch BusinessAssignment API or to parse the answer from the API " + throwable.getMessage()
                                , throwable
                                , coclico
                                , CodeErrorEnum.U12002)
                );
    }

}
