import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SeresDetailsPopUpComponent } from './seres-details-pop-up.component';


describe('SeresDetailsPopUpComponent', () => {
    let component: SeresDetailsPopUpComponent;
    let fixture: ComponentFixture<SeresDetailsPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [SeresDetailsPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(SeresDetailsPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
