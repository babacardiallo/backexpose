package fr.laposte.blg.blinks.u14.config;

import MD.LatestValue.Address;
import MD.LatestValue.LegalPerson;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;

@Configuration
public class TestMessageSenderConfig {

    @Bean
    public KafkaSender<String, gkContractFullOutV1> contractKafkaSender(KafkaProperties kafkaProperties) {
        SenderOptions<String, gkContractFullOutV1> basicSenderOptions = SenderOptions.create(kafkaProperties.buildProducerProperties());
        return KafkaSender.create(basicSenderOptions);
    }

    @Bean
    public KafkaSender<String, LegalPerson> legalPersonKafkaSender(KafkaProperties kafkaProperties) {
        SenderOptions<String, LegalPerson> basicSenderOptions = SenderOptions.create(kafkaProperties.buildProducerProperties());
        return KafkaSender.create(basicSenderOptions);
    }

    @Bean
    public KafkaSender<String, Address> addressKafkaSender(KafkaProperties kafkaProperties) {
        SenderOptions<String, Address> basicSenderOptions = SenderOptions.create(kafkaProperties.buildProducerProperties());
        return KafkaSender.create(basicSenderOptions);
    }

    @Bean
    public KafkaSender<String, String> mandateKafkaSender(KafkaProperties kafkaProperties) {
        SenderOptions<String, String> basicSenderOptions = SenderOptions.create(kafkaProperties.buildProducerProperties());
        return KafkaSender.create(basicSenderOptions);
    }
}

