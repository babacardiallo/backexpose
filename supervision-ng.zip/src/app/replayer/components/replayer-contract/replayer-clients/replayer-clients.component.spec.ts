import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReplayerClientsComponent } from './replayer-clients.component';

describe('ReplayerClientsComponent', () => {
  let component: ReplayerClientsComponent;
  let fixture: ComponentFixture<ReplayerClientsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReplayerClientsComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplayerClientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
