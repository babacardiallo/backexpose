package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.CustomerSupervisionEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Repository
public interface LegalPersonRepository extends ReactiveCrudRepository<LegalPersonEntity, Long> {

    Mono<LegalPersonEntity> findByCustAccNumber(int cutAccNumber);

    @Query("""
            SELECT lp.cust_acc_number,
                   lp.id_legal_person,
                   lp.type_code            as type,
                   lp.marketing_type_code  as market_type,
                   lp.comp_name            as name,
                   lp.brand_name           as brand,
                   lp.is_synchronized      as is_synchro,
                   lp.date_synchronization as date_last_synchronization,
                   MAX(`el`.`date_error`)  as max_date_error,
                   COUNT(distinct addr.id_address)  as count_address
            
            FROM legal_person lp
                     LEFT JOIN error_log el on lp.id_legal_person = el.id_legal_person
                     join address addr on lp.id_legal_person = addr.id_legal_person
            
            GROUP BY lp.id_legal_person;""")
    Flux<CustomerSupervisionEntity> getAllCustomers();

    @Query("""
            SELECT lp.cust_acc_number,
                   lp.id_legal_person,
                   lp.type_code            as type,
                   lp.marketing_type_code  as market_type,
                   lp.comp_name            as name,
                   lp.brand_name           as brand,
                   lp.is_synchronized      as is_synchro,
                   lp.date_synchronization as date_last_synchronization,
                   MAX(`el`.`date_error`)  as max_date_error,
                   COUNT(distinct addr.id_address)  as count_address
            
            FROM legal_person lp
                     LEFT JOIN error_log el on lp.id_legal_person = el.id_legal_person
                     join address addr on lp.id_legal_person = addr.id_legal_person
            WHERE lp.cust_acc_number= :custAccNumber;""")
    Mono<CustomerSupervisionEntity> getOneCustomer(@Param("custAccNumber") int custAccNumber);

    Flux<LegalPersonEntity> findAllByIsSynchronizedTrue();

    Flux<LegalPersonEntity> findAllBy();
    @Transactional(readOnly = true)
    @Query("SELECT count(id_legal_person) from legal_person")
    Mono<Long> countLegalPerson();

    @Query("SELECT cust_acc_number FROM legal_person WHERE created > :lastExecutionDate")
    Flux<Integer> getListCoclicoByLastExecutionDate(Instant lastExecutionDate);

    @Query("SELECT cust_acc_number FROM legal_person")
    Flux<Integer> getListCoclico();
}
