package service;

import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.NotificationStatus;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import fr.laposte.blg.blinks.u17.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u17.service.NotificationService;
import fr.laposte.blg.blinks.u17.service.NotificationService.UpdateEmailsRequest;
import fr.laposte.blg.blinks.u17.util.SchedulerUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private ApimServiceImpl apimService;
    @Mock
    private ExportHistoryRepository exportHistoryRepository;
    @Mock
    private SchedulerParamsRepository schedulerParamsRepository;
    @Mock
    private SchedulerUtils schedulerUtils;

    @InjectMocks
    private NotificationService notificationService;

    private SchedulerParamsEntity schedulerParams;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        schedulerParams = new SchedulerParamsEntity();
        schedulerParams.setId(1L);
        schedulerParams.setSchedulerName("scheduler_notification");
        schedulerParams.setCustomParams("{\"emails\":[\"a@test.fr\"],\"partner\":\"PARTNER\",\"code\":\"MODEL\",\"version\":1}");
        ReflectionTestUtils.setField(notificationService, "appEnv", "mar-sdev");
    }

    @Test
    void sendNotification_shouldReturnEmptyWhenNoExports() {
        StepVerifier.create(notificationService.sendNotification(Collections.emptyList(), schedulerParams))
                .verifyComplete();

        verifyNoInteractions(apimService);
    }

    @Test
    void checkNotificationStatus_shouldReturnEmptyWhenNoExports() {
        StepVerifier.create(notificationService.checkNotificationStatus(Collections.emptyList()))
                .verifyComplete();

        verifyNoInteractions(apimService);
    }

    @Test
    void getEmails_shouldReturnEmailsFromSchedulerParams() {
        when(schedulerParamsRepository.findAllBySchedulerName(anyString()))
                .thenReturn(Mono.just(schedulerParams));

        StepVerifier.create(notificationService.getEmails())
                .assertNext(response -> assertThat(response.getEmails())
                        .containsExactly("a@test.fr"))
                .verifyComplete();
    }

    @Test
    void updateEmails_shouldAddAndRemoveEmails() {
        schedulerParams.setCustomParams("{\"emails\":[\"a@test.fr\"],\"partner\":\"PARTNER\",\"code\":\"MODEL\",\"version\":1}");
        when(schedulerParamsRepository.findAllBySchedulerName(anyString()))
                .thenReturn(Mono.just(schedulerParams));
        when(schedulerParamsRepository.save(any(SchedulerParamsEntity.class)))
                .thenAnswer(invocation -> Mono.just(invocation.getArgument(0)));

        UpdateEmailsRequest request = new UpdateEmailsRequest();
        request.setAdd(List.of("b@test.fr"));
        request.setRemove(List.of("a@test.fr"));

        StepVerifier.create(notificationService.updateEmails(request))
                .assertNext(response -> assertThat(response.getEmails())
                        .containsExactly("b@test.fr"))
                .verifyComplete();
    }

    @Test
    void sendNotification_shouldUpdateStatusAndStoreUuidWhenApimCallIsSuccessful() throws Exception {
        ExportHistoryEntity export = new ExportHistoryEntity();
        export.setIdExport(42L);
        export.setFileSendDate(Instant.now());
        export.setDate(Instant.now());
        export.setFileName("export.txt");
        export.setFileType(FileType.COEURFINANCE);
        export.setMessageCount(10);
        export.setCaHtHorsRelevesAndAcomptes(100.0);
        export.setCaTtcHorsRelevesAndAcomptes(120.0);

        ReflectionTestUtils.setField(notificationService, "notificationCommandPath", "/notification/command");
        ReflectionTestUtils.setField(notificationService, "notificationQueryPath", "/notification/query");

        String apimResponse = "{\"uuid\":\"123e4567-e89b-12d3-a456-426614174000\"}";

        JsonNode customParamsJson = objectMapper.readTree(schedulerParams.getCustomParams());
        when(schedulerUtils.mapStringToJson(anyString())).thenReturn(customParamsJson);
        when(apimService.post(anyString(), anyString())).thenReturn(Mono.just(apimResponse));
        when(exportHistoryRepository.updateNotificationStatusWithUuid(eq(42L), eq(NotificationStatus.CREATED), anyString()))
                .thenReturn(Mono.empty());

        StepVerifier.create(notificationService.sendNotification(List.of(export), schedulerParams))
                .verifyComplete();

        verify(apimService).post(anyString(), anyString());
        verify(exportHistoryRepository).updateNotificationStatusWithUuid(eq(42L), eq(NotificationStatus.CREATED), anyString());
        verify(exportHistoryRepository, never()).updateNotificationStatusWithErrorCode(eq(42L), any(), anyString(), anyString());
    }

    @Test
    void sendNotification_shouldUpdateStatusToErrorWhenApimCallFails() throws Exception {
        ExportHistoryEntity export = new ExportHistoryEntity();
        export.setIdExport(42L);
        export.setFileSendDate(Instant.now());
        export.setDate(Instant.now());
        export.setFileName("export.txt");
        export.setFileType(FileType.COEURFINANCE);
        export.setMessageCount(10);
        export.setCaHtHorsRelevesAndAcomptes(100.0);
        export.setCaTtcHorsRelevesAndAcomptes(120.0);

        ReflectionTestUtils.setField(notificationService, "notificationCommandPath", "/notification/command");
        ReflectionTestUtils.setField(notificationService, "notificationQueryPath", "/notification/query");

        JsonNode customParamsJson = objectMapper.readTree(schedulerParams.getCustomParams());
        when(schedulerUtils.mapStringToJson(anyString())).thenReturn(customParamsJson);
        when(apimService.post(anyString(), anyString())).thenReturn(Mono.error(new RuntimeException("APIM service unavailable")));
        when(exportHistoryRepository.updateNotificationStatusWithErrorCode(eq(42L), eq(NotificationStatus.ERROR), anyString(), anyString()))
                .thenReturn(Mono.empty());

        StepVerifier.create(notificationService.sendNotification(List.of(export), schedulerParams))
                .verifyComplete();

        verify(apimService).post(anyString(), anyString());
        verify(exportHistoryRepository).updateNotificationStatusWithErrorCode(eq(42L), eq(NotificationStatus.ERROR), eq("U171002"), anyString());
        verify(exportHistoryRepository, never()).updateNotificationStatusWithUuid(eq(42L), any(), anyString());
    }

    @Test
    void sendNotification_shouldUpdateStatusToErrorWhenMessageCountIsMissing() throws Exception {
        ExportHistoryEntity export = new ExportHistoryEntity();
        export.setIdExport(42L);
        export.setFileSendDate(Instant.now());
        export.setDate(Instant.now());
        export.setFileName("export.txt");
        export.setFileType(FileType.COEURFINANCE);
        // messageCount est null - volontairement manquant
        export.setMessageCount(null);
        export.setCaHtHorsRelevesAndAcomptes(100.0);
        export.setCaTtcHorsRelevesAndAcomptes(120.0);

        ReflectionTestUtils.setField(notificationService, "notificationCommandPath", "/notification/command");
        ReflectionTestUtils.setField(notificationService, "notificationQueryPath", "/notification/query");

        JsonNode customParamsJson = objectMapper.readTree(schedulerParams.getCustomParams());
        when(schedulerUtils.mapStringToJson(anyString())).thenReturn(customParamsJson);
        when(exportHistoryRepository.updateNotificationStatusWithErrorCode(eq(42L), eq(NotificationStatus.ERROR), eq("U171001"), anyString()))
                .thenReturn(Mono.empty());

        StepVerifier.create(notificationService.sendNotification(List.of(export), schedulerParams))
                .verifyComplete();

        verify(apimService, never()).post(anyString(), anyString());
        verify(exportHistoryRepository).updateNotificationStatusWithErrorCode(
                eq(42L),
                eq(NotificationStatus.ERROR),
                eq("U171001"),
                argThat(msg -> msg.contains("message_count manquant pour l'export 42"))
        );
        verify(exportHistoryRepository, never()).updateNotificationStatusWithUuid(eq(42L), any(), anyString());
    }
}
