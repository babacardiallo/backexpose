package fr.laposte.blg.blinks.u11.listener.contract.exception;

import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import reactor.util.function.Tuple2;

@Data
@EqualsAndHashCode(callSuper=false)
public class ListeningOrderContractVersionException extends ContractListenerException {


    public ListeningOrderContractVersionException(String message, Tuple2<ContractVersionEntity, gkContractFullOutV1> tuple) {
        super("Error in the order of the versions received from the contracts topic" + message
            , null
            , ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING_ORDER
            , tuple.getT1().getContract().getContractNumber()
            , tuple.getT1().getAmendmentNumber()
            , tuple.getT1().getRevisionNumber()
            , tuple.getT1()
            , tuple.getT1().getPartition()
            , tuple.getT1().getOffset()
            , tuple.getT2().toString()
            , tuple.getT1().getValuedOffer().getOpsCode()
        );
    }
}
