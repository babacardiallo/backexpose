package fr.laposte.blg.blinks.lib.common.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * SUEZ KAFKA Configuration
 */
@Slf4j
@Data
@Configuration
@ConfigurationProperties(prefix = "fr.laposte.kafka-config")
public class KafkaConfiguration {
    // Configuration file for kafka connection
    String properties;
    @Value("${fr.laposte.keystore-location}")
    String keyStoreLocation;
    @Value("${fr.laposte.keystore-password}")
    String keyStorePassword;

    @Bean
    Properties kafkaConfig() {
        log.debug("Loading kafka file configuration {}", properties);
        Properties props = new Properties();
        try (InputStream input = this.getClass()
            .getClassLoader()
            .getResourceAsStream(properties)) {
            props.load(input);
            props.put("ssl.keystore.location", keyStoreLocation);
            props.put("ssl.keystore.password", keyStorePassword);
            props.put("ssl.truststore.location", keyStoreLocation);
            props.put("ssl.truststore.password", keyStorePassword);
            props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
            props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
            props.put("proxy.port", Integer.parseInt("8080"));
            log.debug("KAFKA stream Configuration properties : {}", props);
        } catch (IOException ex) {
            log.debug("Loading kafka file configuration error: {}", ex.getMessage());
        }
        return props;
    }

}