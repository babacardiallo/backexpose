package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.relational.core.mapping.Column;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MorningCheckMonthly {
    private int size;
    @Column("nbTotalTreatedInvoices")
    private Integer nbTotalTreatedInvoices;
    @Column("nbTotalInvoiceExportedInFile")
    private Integer nbTotalInvoiceExportedInFile;
    @Column("nbTotalNormalInvoices")
    private Integer nbTotalNormalInvoices;
    @Column("nbTotalAcomptes")
    private Integer nbTotalAcomptes;
    @Column("nbTotalAvoirs")
    private Integer nbTotalAvoirs;
    @Column("nbTotalReleves")
    private Integer nbTotalReleves;
    @Column("totalCaHtHorsRelevesAndAcomptes")
    private Double totalCaHtHorsRelevesAndAcomptes;
    @Column("totalCaTtcHorsRelevesAndAcomptes")
    private Double totalCaTtcHorsRelevesAndAcomptes;
    @Column("nbTotalExcludedInvoices")
    private Integer nbTotalExcludedInvoices;
    @Column("nbTotalFailedInvoices")
    private Integer nbTotalFailedInvoices;
}
