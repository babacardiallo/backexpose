CREATE OR REPLACE VIEW queue_synchro_supervision_view AS
SELECT
       queue.id_queue                           AS id,
       queue.id_contract                        AS id_contract,
       queue.id_legal_person                    AS id_legal_person,
       queue.date_synchronization_expected      AS date_synchronization_expected,
       queue.action                             AS action,
       queue.refcom_replay                      AS refcom_replay,
       co.contract_number                       AS contract_number,
       vo.ops_code                              AS ops_code,
       (CASE WHEN (queue.id_legal_person IS NOT NULL) THEN CAST(lp.cust_acc_number as CHAR(50))
             ELSE CAST(co.cust_acc_number as CHAR(50))
       END) AS cust_acc_number

FROM queue_synchronization_after_error queue
         LEFT JOIN legal_person lp ON queue.id_legal_person = lp.id_legal_person
         LEFT JOIN contract co ON queue.id_contract = co.id_contract
         LEFT JOIN contract_version cv ON co.id_contract = cv.id_contract
         LEFT JOIN valued_offer vo ON cv.id_valued_offer = vo.id_valued_offer;