package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.CustomerSupervisionEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomerSupervisionRepository extends ReactiveCrudRepository<CustomerSupervisionEntity, String> {


    Flux<CustomerSupervisionEntity> findAllBy(@Param("pageable") Pageable pageable);


    Flux<CustomerSupervisionEntity> findAllByCustAccNumberTextLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(@Param("pageable") Pageable pageable, String filter1, String filter2,String filter3, String filter4, String filter5) ;

    @Query("SELECT COUNT(*) FROM blg_contract_importer.customer_supervision WHERE cust_acc_number_text LIKE :filter OR type LIKE :filter OR market_type LIKE :filter OR name LIKE :filter OR brand LIKE :filter")
    Mono<Long> countAllByCustAccNumberTextLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(@Param("filter") String filter);

    Flux<CustomerSupervisionEntity> findAllByDateErrorIsNotNull(@Param("pageable") Pageable pageable);

    Mono<Long> countAllByDateErrorIsNotNull();

    Flux<CustomerSupervisionEntity> findAllByDateErrorIsNotNullAndCustAccNumberTextLikeOrDateErrorIsNotNullAndTypeLikeOrDateErrorIsNotNullAndMarketTypeLikeOrDateErrorIsNotNullAndNameLikeOrDateErrorIsNotNullAndBrandLike(@Param("pageable") Pageable pageable, String filter1, String filter2,String filter3, String filter4, String filter5);

    @Query("SELECT COUNT(*) FROM blg_contract_importer.customer_supervision WHERE max_date_error IS NOT NULL AND (cust_acc_number_text LIKE :filter OR type LIKE :filter OR market_type LIKE :filter OR name LIKE :filter OR brand LIKE :filter)")
    Mono<Long> countElementByCriteria(@Param("filter") String filter);


    Mono<CustomerSupervisionEntity> findByCustAccNumber(int coclico);


    Flux<CustomerSupervisionEntity> findAllByDateErrorIsNotNullAndCustAccNumberLikeOrDateErrorIsNotNullAndTypeLikeOrDateErrorIsNotNullAndMarketTypeLikeOrDateErrorIsNotNullAndNameLikeOrDateErrorIsNotNullAndBrandLike(String filter1, String filter2,String filter3, String filter4, String filter5);


    Flux<CustomerSupervisionEntity> findAllByCustAccNumberLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(String filter1, String filter2,String filter3, String filter4, String filter5) ;


    Flux<CustomerSupervisionEntity> findAllByDateErrorIsNotNull();


    Flux<CustomerSupervisionEntity> findAllBy();



}
