package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionAllEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ContractSupervisionAllRepository extends ReactiveCrudRepository<ContractSupervisionAllEntity, String> {

    Flux<ContractSupervisionAllEntity> findAllBy(@Param("pageable") Pageable pageable);

    Flux<ContractSupervisionAllEntity> findByCustAccNumberBeforeSynchronisation(int coclico);

    @Query("""
            SELECT *            
              FROM (
                            SELECT *,
                                    ROW_NUMBER() OVER(PARTITION BY contract_number) rn
                                FROM blg_contract_importer.contract_supervision_actives
                               WHERE is_synchronized = 1
            
                          ) a
            WHERE rn = 1""")
    Flux<ContractSupervisionAllEntity> findAllByIsSynchronizedTrue();

    Flux<ContractSupervisionAllEntity> findAllByFirstErrorDateIsNotNull(@Param("pageable") Pageable pageable);

    Mono<Long> countAllByFirstErrorDateIsNotNull();

    Flux<ContractSupervisionAllEntity> findAllByFirstErrorDateIsNotNullAndContractNumberLikeOrFirstErrorDateIsNotNullAndOpsCodeLikeOrFirstErrorDateIsNotNullAndOpsLabelLikeOrFirstErrorDateIsNotNullAndSubtypeLike(String filterContract, String filterOpsCode, String filterLabel, String filterSubtype, @Param("pageable") Pageable pageable);

    @Query("SELECT COUNT(*) FROM blg_contract_importer.contract_supervision_all WHERE first_error_date IS NOT NULL AND (contract_number LIKE :filter OR ops_code LIKE :filter OR ops_label LIKE :filter)")
    Mono<Long> countAllByFirstErrorDateIsNotNullAndContractNumberLikeOrOpsCodeLikeOrOpsLabelLike(@Param("filter") String filter);

    Flux<ContractSupervisionAllEntity> findAllByContractNumberLikeOrOpsCodeLikeOrOpsLabelLikeOrSubtypeLike(String filterContract, String filterOpsCode, String filterLabel, String filterSubtype, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByContractNumberLikeOrOpsCodeLikeOrOpsLabelLikeOrSubtypeLike(String filterContract, String filterOpsCode, String filterLabel, String filterSubtype);




}
