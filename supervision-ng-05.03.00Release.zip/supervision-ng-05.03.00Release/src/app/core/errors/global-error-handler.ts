import { HttpErrorResponse } from "@angular/common/http";
import { ErrorHandler, Injectable, NgZone } from "@angular/core";
import { ObservableInput, throwError } from "rxjs";
import { ErrorDialogService } from "../../shared/errors/service/error-dialog.service";

@Injectable({
    providedIn: 'root',
})
export class GlobalErrorHandler implements ErrorHandler {
    constructor(
        private errorDialogService: ErrorDialogService,
        private zone: NgZone
    ) { }

    handleError(error: any): ObservableInput<any> {
        console.log(error);
        switch (error?.status) {
            case 0: {
                error.message = "Une erreur est survenue lors de l'appel. Vérifiez que le module approprié est lancé.";
                break;
            }
            case 401: {
                error.message = "Problème d'authentification, vérifiez que vous êtes connecté.";
                break;
            }
            case 301:
            case 302: {
                error.message = "Cette page n'est pas disponible pour le moment";
                break;
            }
            case 404: {
                error.message = "Impossible d'acceder à cette ressource";
            }
        }
        this.zone.run(() =>
            this.errorDialogService.openDialog(
                error?.message || 'Erreur coté client non définie',
                error?.status || 'Inconnu'
            )
        );
        console.error('Error caught :', error);
        return throwError(() => new Error(error));

    }
}