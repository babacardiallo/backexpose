package fr.laposte.blg.blinks.u12.service.mandate;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u12.apim.ApimServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import reactor.test.StepVerifier;


@SpringBootTest
@ActiveProfiles("test")
class MandateServiceImplTest {

    @Autowired
    MandateService mandateService;
    @Mock
    private ApimServiceImpl apimService;
    @Mock
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
    }


    @Disabled
    @Test
    // Disabled mandate API instable
    void fetchMandate_validResponse() {
        StepVerifier.create(mandateService.fetchMandate("MCCOU1322104"))
                .expectNextMatches(mandateDTO -> mandateDTO.getRum().equals("MCCOU1322104")
                        && mandateDTO.getIban().equals("FR76XXXXXXXXXXXXXXXXXXXX362")
                        && mandateDTO.getBic().equals("CEPAFRPP333")
                        && mandateDTO.getStatus().equals("Valid"))
                .verifyComplete();
    }

}
