package fr.laposte.blg.blinks.u17.dto;

import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import lombok.*;

import java.time.Instant;

@Data
@Builder
@Getter
@Setter

public class InvoiceDetailsDto {
    private boolean isCredit;
    private boolean isRefundable;
    private boolean isDownpayment;
    private boolean isStatement;
    private boolean isOpencellPdf;
    private boolean isDedicated;
    private String support;
    private boolean printFlag;
    private Double htAmount;
    private Double amount;
    private String coeurfinanceFileName;
    private String docaposteFileName;
    private String infocaFileName;
    private Instant coeurfinanceTransfertDate;
    private Instant docaposteTransfertDate;
    private Instant infocaTransfertDate;
    private TransferStatus coeurfinanceTransferStatus;
    private TransferStatus docaposteTransferStatus;
    private TransferStatus infocaTransferStatus;
    private String invoiceJson;
    private String mappingError;


}
