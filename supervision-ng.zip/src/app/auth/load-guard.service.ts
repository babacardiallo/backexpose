import { inject } from '@angular/core';
import {Router, CanActivateFn } from '@angular/router';
import {environment} from '../../environments/environment';
import { SharedService } from '../shared/services/shared.service';
import { AuthCheckService } from './auth-check.service';


export const LoadGuard: CanActivateFn = async (route, state)   => {    
    const router: Router = inject(Router);
    const sharedService: SharedService = inject(SharedService);
    const authCheckService: AuthCheckService  = inject(AuthCheckService);
    console.log(route);  
    sharedService.connectedUserData = await authCheckService.checkAuthenticatedUser();
    console.log('guard user', sharedService.connectedUserData);
    const requiredPermissions = route.data.permissions.only;
    const userPermissions = environment.name == 'loc' ? sharedService.localPermissions : sharedService.connectedUserData.roles;
    console.log("required ==> ", requiredPermissions);
    console.log("user permissions ==> ", userPermissions);
    for(let element of userPermissions){
        if(requiredPermissions.includes(element)){                    
            return true;
        }
    }
    router.navigateByUrl('/unauthorized');
    return false;
}