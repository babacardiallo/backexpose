package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.QueueMigrationEntity;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Repository
public interface QueueMigrationRepository extends ReactiveCrudRepository<QueueMigrationEntity, Long> {

    Mono<Void> deleteByIdQueue(Long idQueue);

    @Query("SELECT q.* from queue_migration_by_offer q WHERE q.offer_ops_code IN (SELECT ops_code FROM offer_filter) AND q.date_synchronization_expected < NOW()")
    Flux<QueueMigrationEntity> findQueueMigrationEligible();

    Mono<QueueMigrationEntity> findQueueMigrationEntityByIdContract(long idContract);

    @Modifying
    @Query("UPDATE queue_migration_by_offer SET date_synchronization_expected = :dateMigrationExpected WHERE offer_ops_code = :offerOpsCode")
    Mono<Integer> setDateMigrationExpectedForOffer(Instant dateMigrationExpected, String offerOpsCode);
}
