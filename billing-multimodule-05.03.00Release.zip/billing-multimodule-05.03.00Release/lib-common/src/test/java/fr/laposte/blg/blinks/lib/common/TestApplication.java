package fr.laposte.blg.blinks.lib.common;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestApplication {
}
