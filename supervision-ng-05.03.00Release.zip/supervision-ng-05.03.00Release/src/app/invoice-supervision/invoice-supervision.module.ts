import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CdkStepperModule } from "@angular/cdk/stepper";
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { NgxPermissionsModule } from 'ngx-permissions';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { InvoiceSupervisionComponent } from './invoice-supervision.component';
import { InvoiceSupervisionRoutingModule } from './invoice-supervision-routing.module';
import { InvoiceSupervisionTableComponent } from './components/invoice-supervision-table.component';
import { InvoiceSupervisionSearchPopupComponent } from './components/invoice-supervision-search-popup/invoice-supervision-search-popup.component';
import { InvoiceSupervisionDetails } from './components/invoice-supervision-details-popup/invoice-supervision-details-popup';
import { ModalService } from 'ngx-modal-ease';


@NgModule({
    imports: [
        SharedModule,
        NgxDatatableModule,
        MatStepperModule,
        CdkStepperModule,
        MatSnackBarModule,
        MatGridListModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        NgxPermissionsModule.forChild(),
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        FormsModule,
        ReactiveFormsModule,
        MatSelectModule,
        InvoiceSupervisionRoutingModule
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [InvoiceSupervisionComponent, InvoiceSupervisionTableComponent, InvoiceSupervisionSearchPopupComponent, InvoiceSupervisionDetails],
    exports: [InvoiceSupervisionComponent]
})
export class InvoiceSupervisionModule { }
