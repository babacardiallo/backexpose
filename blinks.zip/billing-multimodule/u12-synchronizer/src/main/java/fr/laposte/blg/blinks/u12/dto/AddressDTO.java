package fr.laposte.blg.blinks.u12.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AddressDTO {

    @JsonProperty("establishCountyCode")
    String countyCode;

    @JsonProperty("creationDateTime")
    String cDateTime;

    @JsonProperty("modificationDateTime")
    String mDateTime;

    @JsonProperty("refpmAddressId")
    String addressId;
    
    @JsonProperty("add1")
    String name1;

    @JsonProperty("add2")
    String add2;

    @JsonProperty("add3")
    String add3;

    @JsonProperty("add4")
    String add4;

    @JsonProperty("add5")
    String add5;

    @JsonProperty("add6")
    String add6;

    @JsonProperty("add7")
    String add7;

    @JsonProperty("addressType")
    String addressType;
}
