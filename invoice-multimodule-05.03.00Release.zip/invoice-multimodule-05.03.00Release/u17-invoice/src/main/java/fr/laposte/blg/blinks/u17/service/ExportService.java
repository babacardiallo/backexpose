package fr.laposte.blg.blinks.u17.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import fr.laposte.blg.blinks.u17.dto.ExportKibanaCst;
import fr.laposte.blg.blinks.u17.dto.ExportKibanaDto;
import fr.laposte.blg.blinks.u17.dto.InvoiceExportDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExportService {

    private final DecimalFormat df = new DecimalFormat("0.00", DecimalFormatSymbols.getInstance(Locale.ENGLISH));

    private final ExportHistoryRepository exportHistoryRepository;
    private final SchedulerParamsRepository schedulerParamsRepository;
    private final InvoiceRepository invoiceRepository;
    private final ObjectMapper objectMapper;

    public void setCompteursAttributs(ExportHistoryEntity exportHistoryEntity, List<InvoiceDTO> validInvoicesDto, List<InvoiceExportDto> validInvoices, List<InvoiceExportDto> failedInvoices, List<InvoiceExportDto> excludedInvoices) {
        exportHistoryEntity.setMessageCount(validInvoices.size() + failedInvoices.size() + excludedInvoices.size());
        exportHistoryEntity.setNbInvoiceExportedInFile(validInvoices.size());
        exportHistoryEntity.setNbFailedInvoices(failedInvoices.size());
        exportHistoryEntity.setNbExcludedInvoices(excludedInvoices.size());
        if (!validInvoicesDto.isEmpty()) {
            long nbNormalInvoices = validInvoicesDto.stream()
                    .filter(invoiceDTO ->
                            invoiceDTO.getInvoiceHeader().getIsStatementFlag().equals(false) &&
                                    invoiceDTO.getInvoiceHeader().getCreditFlag().equals(false) &&
                                    invoiceDTO.getInvoiceHeader().getDownpaymentFlag().equals(false))
                    .count();
            exportHistoryEntity.setNbNormalInvoices(Math.toIntExact(nbNormalInvoices));

            long nbAcomptes = validInvoicesDto.stream()
                    .filter(invoiceDTO -> invoiceDTO.getInvoiceHeader().getDownpaymentFlag())
                    .count();
            exportHistoryEntity.setNbAcomptes(Math.toIntExact(nbAcomptes));

            long nbAvoirs = validInvoicesDto.stream()
                    .filter(invoiceDTO -> invoiceDTO.getInvoiceHeader().getCreditFlag() && !invoiceDTO.getInvoiceHeader().getIsStatementFlag())
                    .count();
            exportHistoryEntity.setNbAvoirs(Math.toIntExact(nbAvoirs));

            long nbReleves = validInvoicesDto.stream()
                    .filter(invoiceDTO -> invoiceDTO.getInvoiceHeader().getIsStatementFlag())
                    .count();
            exportHistoryEntity.setNbReleves(Math.toIntExact(nbReleves));

            Double caHtHorRelevesAndAcomptes = getCaHtHorsRelevesAndAcomptes(validInvoicesDto).stream().mapToDouble(Double::doubleValue).sum();

            exportHistoryEntity.setCaHtHorsRelevesAndAcomptes(Double.valueOf(df.format(caHtHorRelevesAndAcomptes)));

            Double caTtcHorRelevesAndAcomptes = getCaTtcHorsRelevesAndAcomptes(validInvoicesDto).stream().mapToDouble(Double::doubleValue).sum();

            exportHistoryEntity.setCaTtcHorsRelevesAndAcomptes(Double.valueOf(df.format(caTtcHorRelevesAndAcomptes)));


        }

    }


    private static List<Double> getCaHtHorsRelevesAndAcomptes(List<InvoiceDTO> invoiceDtos) {
        return invoiceDtos.stream()
                .filter(invoiceDTO -> invoiceDTO.getInvoiceHeader().getIsStatementFlag().equals(false) && invoiceDTO.getInvoiceHeader().getDownpaymentFlag().equals(false))
                .map(invoiceDTO -> invoiceDTO.getInvoiceHeader().getBillingAmount().getExcludingTaxNetTotalAmount())
                .collect(Collectors.toList());
    }

    private static List<Double> getCaTtcHorsRelevesAndAcomptes(List<InvoiceDTO> invoiceDtos) {
        return invoiceDtos.stream()
                .filter(invoiceDTO -> invoiceDTO.getInvoiceHeader().getIsStatementFlag().equals(false) && invoiceDTO.getInvoiceHeader().getDownpaymentFlag().equals(false))
                .map(invoiceDTO -> invoiceDTO.getInvoiceHeader().getBillingAmount().getTotalAmount())
                .collect(Collectors.toList());
    }

    private void logInvoicesKibana(List<InvoiceExportDto> validInvoices, List<InvoiceExportDto> excludedInvoices, List<InvoiceExportDto> failedInvoices, ExportHistoryEntity exportHistoryEntity, FileType fileType) {
        for (InvoiceExportDto invoice : validInvoices) {
            if (exportHistoryEntity != null) {
                var exportKibanaDto = new ExportKibanaDto();
                exportKibanaDto.setExportTreatment(fileType.toString());
                exportKibanaDto.setExportInvoiceNumber(invoice.getInvoiceNumber());
                exportKibanaDto.setExportId(exportHistoryEntity.getIdExport());
                exportKibanaDto.setExportStatus(ExportStatus.SUCCESS.toString());
                exportKibanaDto.setExportMessage("Export " + fileType + " en succès pour la facture " + invoice.getInvoiceNumber());
                exportKibanaDto.setErrorMessage(null);
                exportKibanaDto.setErrorCode(null);
                JsonNode node = this.objectMapper.convertValue(exportKibanaDto, JsonNode.class);
                log.info(Markers.append(ExportKibanaCst.TREATMENT, exportKibanaDto.getExportTreatment())
                                .and(Markers.append(ExportKibanaCst.INVOICE_NUMBER, exportKibanaDto.getExportInvoiceNumber()))
                                .and(Markers.append(ExportKibanaCst.EXPORT_ID, exportKibanaDto.getExportId()))
                                .and(Markers.append(ExportKibanaCst.STATUS, exportKibanaDto.getExportStatus()))
                                .and(Markers.append(ExportKibanaCst.MESSAGE, exportKibanaDto.getExportMessage()))
                                .and(Markers.append(ExportKibanaCst.CLEFS, node))
                        , "Export " + fileType + " en succès pour la facture {}, traitement: {}, invoiceNumber: {}, exportId: {}, status: {}, clefs: {}", invoice.getInvoiceNumber(), fileType, invoice.getInvoiceNumber(), exportHistoryEntity.getIdExport(), ExportStatus.SUCCESS, node);
            }
        }
        for (InvoiceExportDto invoiceNumber : excludedInvoices) {
            if (exportHistoryEntity != null) {
                var exportKibanaDto = new ExportKibanaDto();
                exportKibanaDto.setExportTreatment(fileType.toString());
                exportKibanaDto.setExportInvoiceNumber(invoiceNumber.getInvoiceNumber());
                exportKibanaDto.setExportId(exportHistoryEntity.getIdExport());
                exportKibanaDto.setExportStatus(ExportStatus.EXCLUDED.toString());
                exportKibanaDto.setExportMessage("Export " + fileType + " ignoré pour la facture " + invoiceNumber.getInvoiceNumber());
                exportKibanaDto.setErrorMessage(invoiceNumber.getErrorMessage());
                exportKibanaDto.setErrorCode(null);
                JsonNode node = this.objectMapper.convertValue(exportKibanaDto, JsonNode.class);
                log.info(Markers.append(ExportKibanaCst.TREATMENT, exportKibanaDto.getExportTreatment())
                                .and(Markers.append(ExportKibanaCst.INVOICE_NUMBER, exportKibanaDto.getExportInvoiceNumber()))
                                .and(Markers.append(ExportKibanaCst.EXPORT_ID, exportKibanaDto.getExportId()))
                                .and(Markers.append(ExportKibanaCst.STATUS, exportKibanaDto.getExportStatus()))
                                .and(Markers.append(ExportKibanaCst.MESSAGE, exportKibanaDto.getExportMessage()))
                                .and(Markers.append(ExportKibanaCst.CLEFS, node))
                        , "Export " + fileType + " ignoré pour la facture {}, traitement: {}, invoiceNumber: {}, exportId: {}, status: {}, clefs: {}", invoiceNumber.getInvoiceNumber(), fileType, invoiceNumber.getInvoiceNumber(), exportHistoryEntity.getIdExport(), ExportStatus.EXCLUDED, node);
            }
        }

        for (InvoiceExportDto invoiceNumber : failedInvoices) {
            if (exportHistoryEntity != null) {
                var exportKibanaDto = new ExportKibanaDto();
                exportKibanaDto.setExportTreatment(fileType.toString());
                exportKibanaDto.setExportInvoiceNumber(invoiceNumber.getInvoiceNumber());
                exportKibanaDto.setExportId(exportHistoryEntity.getIdExport());
                exportKibanaDto.setExportStatus(ExportStatus.FAILED.toString());
                exportKibanaDto.setExportMessage("Export " + fileType + " en erreur pour la facture " + invoiceNumber.getInvoiceNumber());
                exportKibanaDto.setErrorMessage(invoiceNumber.getErrorMessage());
                exportKibanaDto.setErrorCode(invoiceNumber.getErrorCode());
                JsonNode node = this.objectMapper.convertValue(exportKibanaDto, JsonNode.class);
                log.info(Markers.append(ExportKibanaCst.TREATMENT, exportKibanaDto.getExportTreatment())
                                .and(Markers.append(ExportKibanaCst.INVOICE_NUMBER, exportKibanaDto.getExportInvoiceNumber()))
                                .and(Markers.append(ExportKibanaCst.EXPORT_ID, exportKibanaDto.getExportId()))
                                .and(Markers.append(ExportKibanaCst.STATUS, exportKibanaDto.getExportStatus()))
                                .and(Markers.append(ExportKibanaCst.MESSAGE, exportKibanaDto.getExportMessage()))
                                .and(Markers.append(ExportKibanaCst.CLEFS, node))
                        , "Export " + fileType + " en erreur pour la facture {}, traitement: {}, invoiceNumber: {}, exportId: {}, status: {}, clefs: {}", invoiceNumber.getInvoiceNumber(), fileType, invoiceNumber.getInvoiceNumber(), exportHistoryEntity.getIdExport(), ExportStatus.FAILED, node);
            }
        }
    }

    public Mono<ExportHistoryEntity> generateHistory(Instant startTime, List<InvoiceDTO> validInvoicesDto, List<InvoiceExportDto> validInvoices, List<InvoiceExportDto> failedInvoices, List<InvoiceExportDto> excludedInvoices, FileType fileType, String name) {
        var endTime = Instant.now();
        Long durationInMs = Duration.between(startTime, endTime).toMillis();
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setStartDate(startTime);
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setExportDuration(durationInMs);
        exportHistoryEntity.setFileType(fileType);
        exportHistoryEntity.setFileName(name);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        if (!failedInvoices.isEmpty()) {
            exportHistoryEntity.setExportStatus(ExportStatus.WARNING);
        }
        if (validInvoices.isEmpty()) {
            exportHistoryEntity.setIsFileEmpty(true);
            if (fileType.equals(FileType.DOCAPOSTE) || fileType.equals(FileType.DOCAPOSTE_AVIS_PAIEMENT)) {
                exportHistoryEntity.setTransferStatus(TransferStatus.NO_FILE);
            }
        }
        NotificationStatus notificationStatus = resolveNotificationStatus(fileType);

        // Si l'export est en échec, on désactive systématiquement les notifications
        if (exportHistoryEntity.getExportStatus() == ExportStatus.FAILED) {
            log.info("Export en statut FAILED, désactivation des notifications pour le traitement (fileType={})", fileType);
            notificationStatus = NotificationStatus.DISABLED;
        }

        exportHistoryEntity.setNotificationStatus(notificationStatus);
        if (notificationStatus == NotificationStatus.ERROR) {
            exportHistoryEntity.setNotificationErrorCode("U171000");
            exportHistoryEntity.setNotificationErrorMessage("Erreur lors de la récupération des paramètres de notification");
        }
        setCompteursAttributs(exportHistoryEntity, validInvoicesDto, validInvoices, failedInvoices, excludedInvoices);
        ExportHistoryEntity entitySaved = exportHistoryRepository.save(exportHistoryEntity).block();
        updateInvoicesStatus(fileType, validInvoices, failedInvoices, excludedInvoices, Objects.requireNonNull(entitySaved).getIdExport());
        logInvoicesKibana(validInvoices, excludedInvoices, failedInvoices, exportHistoryEntity, fileType);
        log.info("Fin de l'export " + fileType + " après {} ms", durationInMs);
        log.info("Nombre de factures traitées : {}", validInvoices.size() + failedInvoices.size() + excludedInvoices.size());
        log.info("Nombre de factures valides dans le fichier : {}", validInvoices.size());
        log.info("Nombre de factures exclues : {}", excludedInvoices.size());
        log.info("Nombre de factures en erreur : {}", failedInvoices.size());
        return Mono.just(entitySaved);
    }

    private NotificationStatus resolveNotificationStatus(FileType fileType) {
        try {
            SchedulerParamsEntity params = schedulerParamsRepository.findAllBySchedulerName("scheduler_notification").block();
            if (params == null) {
                log.warn("Paramètres scheduler 'scheduler_notification' introuvables");
                return NotificationStatus.DISABLED;
            }

            String customParams = params.getCustomParams();
            if (customParams == null || customParams.isBlank()) {
                log.warn("customParams vide ou null pour 'scheduler_notification'");
                return NotificationStatus.DISABLED;
            }

            JsonNode root = objectMapper.readTree(customParams);
            log.debug("customParams pour scheduler_notification : {}", root);
            String key = switch (fileType) {
                case DOCAPOSTE -> "docaposte";
                case INFOCA -> "infoca";
                case COEURFINANCE -> "coeurfinance";
                case DOCAPOSTE_AVIS_PAIEMENT -> "docaposte_avis_paiement";
                default -> fileType.toString().toLowerCase();
            };

            JsonNode valueNode = root.get(key);
            if (valueNode == null || valueNode.isNull()) {
                log.warn("Clé '{}' absente du customParams ou null : {}", key, root);
                return NotificationStatus.ERROR;
            }

            if (!valueNode.isNumber()) {
                log.warn("Valeur de la clé '{}' n'est pas numérique (attendu 0 ou 1) : {}", key, valueNode);
                return NotificationStatus.ERROR;
            }

            int v = valueNode.intValue();
            if (v == 1) {
                return NotificationStatus.NEW;
            } else if (v == 0) {
                return NotificationStatus.DISABLED;
            } else {
                log.warn("Valeur numérique de la clé '{}' non attendue (seulement 0 ou 1 acceptés) : {}", key, v);
                return NotificationStatus.ERROR;
            }

        } catch (Exception e) {
            log.warn("Erreur lors de la résolution du notificationStatus pour {}: {}", fileType, e.getMessage(), e);
            return NotificationStatus.ERROR;
        }
    }

    private void updateInvoicesStatus(FileType fileType, List<InvoiceExportDto> validInvoices, List<InvoiceExportDto> failedInvoices, List<InvoiceExportDto> excludedInvoices, Long exportId) {
        try {
            if (fileType.equals(FileType.DOCAPOSTE)) {
                Flux.fromIterable(validInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateDocaposteExportStatusById(InvoiceStatusEnum.SUCCESS, invoice.getInvoiceId())
                                .then(invoiceRepository.updateDocaposteExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(excludedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateDocaposteExportStatusById(InvoiceStatusEnum.EXCLUDED, invoice.getInvoiceId())
                                .then(invoiceRepository.updateDocaposteExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(failedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateDocaposteExportStatusById(InvoiceStatusEnum.FAILED, invoice.getInvoiceId())
                                .then(this.invoiceRepository.updateDocaposteErrorMessageById(invoice.getErrorMessage(), invoice.getInvoiceId()))
                                .then(this.invoiceRepository.updateDocaposteErrorCodeById(invoice.getErrorCode(), invoice.getInvoiceId()))
                                .then(invoiceRepository.updateDocaposteExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
            } else if(fileType.equals(FileType.DOCAPOSTE_AVIS_PAIEMENT)){
                Flux.fromIterable(validInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateDocaposteAvispaiementExportStatusById(InvoiceStatusEnum.SUCCESS, invoice.getInvoiceId())
                                .then(invoiceRepository.updateDocaposteAvisPaiementExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(excludedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateDocaposteAvispaiementExportStatusById(InvoiceStatusEnum.EXCLUDED, invoice.getInvoiceId())
                                .then(invoiceRepository.updateDocaposteAvisPaiementExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(failedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateDocaposteAvispaiementExportStatusById(InvoiceStatusEnum.FAILED, invoice.getInvoiceId())
                                .then(this.invoiceRepository.updateDocaposteAvisPaiementErrorMessageById(invoice.getErrorMessage(), invoice.getInvoiceId()))
                                .then(this.invoiceRepository.updateDocaposteAvisPaiementErrorCodeById(invoice.getErrorCode(), invoice.getInvoiceId()))
                                .then(invoiceRepository.updateDocaposteAvisPaiementExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
            }
            else if (fileType.equals(FileType.INFOCA)) {
                Flux.fromIterable(validInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateInfocaExportStatusById(InvoiceStatusEnum.SUCCESS, invoice.getInvoiceId())
                                .then(invoiceRepository.updateInfocaExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(excludedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateInfocaExportStatusById(InvoiceStatusEnum.EXCLUDED, invoice.getInvoiceId())
                                .then(invoiceRepository.updateInfocaExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(failedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateInfocaExportStatusById(InvoiceStatusEnum.FAILED, invoice.getInvoiceId())
                                .then(this.invoiceRepository.updateInfocaErrorMessageById(invoice.getErrorMessage(), invoice.getInvoiceId()))
                                .then(this.invoiceRepository.updateInfocaErrorCodeById(invoice.getErrorCode(), invoice.getInvoiceId()))
                                .then(invoiceRepository.updateInfocaExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
            } else if (fileType.equals(FileType.COEURFINANCE)) {
                Flux.fromIterable(validInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateCoeurfinanceExportStatusById(InvoiceStatusEnum.SUCCESS, invoice.getInvoiceId())
                                .then(invoiceRepository.updateCoeurfinanceExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(excludedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateCoeurfinanceExportStatusById(InvoiceStatusEnum.EXCLUDED, invoice.getInvoiceId())
                                .then(invoiceRepository.updateCoeurfinanceExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
                Flux.fromIterable(failedInvoices)
                        .concatMap(invoice -> this.invoiceRepository.updateCoeurfinanceExportStatusById(InvoiceStatusEnum.FAILED, invoice.getInvoiceId())
                                .then(this.invoiceRepository.updateCoeurfinanceErrorMessageById(invoice.getErrorMessage(), invoice.getInvoiceId()))
                                .then(this.invoiceRepository.updateCoeurfinanceErrorCodeById(invoice.getErrorCode(), invoice.getInvoiceId()))
                                .then(invoiceRepository.updateCoeurfinanceExportIdById(exportId, invoice.getInvoiceId())))
                        .subscribe();
            }
        } catch (RuntimeException e) {
            log.info("Couldn't save invoice status for " + fileType + " export");
        }

    }
}
