CREATE OR REPLACE VIEW customer_details_supervision AS
    SELECT
        `lp`.`cust_acc_number` AS `cust_acc_number`,
        `lp`.`id_legal_person` AS `id_legal_person`,
        `lp`.`siret_code` AS `siret_code`,
        `lp`.`legal_nature_code` AS `legal_nature_code`,
        `lp`.`legal_nature_name` AS `legal_nature_name`,
        `lp`.`establish_zone_code` AS `implantation_zone`,
        `lp`.`vat_number` AS `vat_number`,
        `el`.`error_message` AS `error_message`
    FROM
        (`legal_person` `lp`
        LEFT JOIN `error_log` `el` ON (((`lp`.`id_legal_person` = `el`.`id_legal_person`)
            AND (`el`.`date_error` = (SELECT
                MAX(`e2`.`date_error`)
            FROM
                `error_log` `e2`
            WHERE
                (`e2`.`id_legal_person` = `lp`.`id_legal_person`))))))