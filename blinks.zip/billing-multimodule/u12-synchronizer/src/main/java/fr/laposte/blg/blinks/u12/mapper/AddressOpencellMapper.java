package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.bscc.billing.avro.billing.AddressOpencell;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface AddressOpencellMapper {

    @Mapping(source = "addressIdRefPM", target = "addressId")
    @Mapping(source = "name1", target = "name1")
    @Mapping(source = "add2", target = "add2")
    @Mapping(source = "add3", target = "add3")
    @Mapping(source = "add4", target = "add4")
    @Mapping(source = "add5", target = "add5")
    @Mapping(source = "add6", target = "add6")
    @Mapping(source = "add7", target = "add7")
    AddressOpencell addressEntityToCustomerAddress(AddressEntity addressEntity);

}
