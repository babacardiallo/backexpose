package fr.laposte.blg.blinks.u12.okapi;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.DefaultUriBuilderFactory;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;
import reactor.util.retry.Retry;

import javax.net.ssl.SSLException;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

@Service
@Data
@ConfigurationProperties(prefix = "fr.laposte.okapi")
@Slf4j
public class OkapiServiceImpl {
    private final OkapiProperties okapiProperties;
    private final WebClient.Builder webClientBuilder;

    @Value("${proxy.username}")
    private String username;

    @Value("${proxy.password}")
    private String password;

    @Value("${proxy.server}")
    private String server;

    @Value("${proxy.port}")
    private int port;


    public Mono<String> get(String path, String graphqlQuery, Map<String, Object> variables) {
        Retry retrySpec500 = Retry.fixedDelay(3, Duration.ofSeconds(5)).transientErrors(true)
                .filter(throwable -> throwable.getClass() == HttpServerErrorException.InternalServerError.class);
        Retry retrySpec429 = Retry.fixedDelay(5, Duration.ofSeconds(1)).transientErrors(true)
                .filter(throwable -> throwable.getClass() == HttpClientErrorException.TooManyRequests.class);

        log.debug("host {}", okapiProperties.getHost());
        log.debug("key : {}", okapiProperties.getKey());
        log.debug("PATH ON POST {}", path);
        log.debug("QUERY PARAMS  GET {}", graphqlQuery);
        DefaultUriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory(okapiProperties.getHost());
        uriBuilderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY);
        Function<? super String, ? extends String> pwd = username -> password;
        HttpClient httpClient =
                HttpClient.create()
                            .secure(sslContextSpec -> {
                                try {
                                    sslContextSpec.sslContext(
                                        SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build()
                                );
                                } catch (SSLException e) {
                                    throw new RuntimeException(e);
                                }
                            })
                        .proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP)
                                .host(server)
                                .port(port)
                                .username(username)
                                .password(pwd));
        ReactorClientHttpConnector connectorProxy = new ReactorClientHttpConnector(httpClient);
        // encapsulation graphql query en json
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("query", graphqlQuery);
        requestMap.put("variables", variables);

        String jsonRequestBody;
        try {
            jsonRequestBody = objectMapper.writeValueAsString(requestMap);
        } catch (JsonProcessingException e) {
            return Mono.error(new RuntimeException("Failed to serialize GraphQL request body", e));
        }

        return webClientBuilder
                .uriBuilderFactory(uriBuilderFactory)
                .clientConnector(connectorProxy)
                .build()
                .post()
                .uri(path)
                .header("X-Okapi-Key", okapiProperties.getKey())
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(jsonRequestBody))
                .exchangeToMono(this::traiterRepOkapi)
                .retryWhen(retrySpec500)
                .retryWhen(retrySpec429)
                .doOnError(err -> {
                    log.error("Service Okapi, Erreur après retry", err);
                    throw OkapiException.builder()
                            .messageOkapi(err.getMessage())
                            .build();
                });
    }

    Mono<String> traiterRepOkapi(ClientResponse response) {
        return Mono.just(response)
                .flatMap(rep -> rep.bodyToMono(String.class))
                .doOnNext(s -> log.debug(Markers.appendFields(response), "RETOUR OKAPI COMPLET : {}// STATUS CODE : {}", s, response.statusCode()))
                .switchIfEmpty(Mono.error(() -> {
                            HttpStatusCode status = response.statusCode();
                            String message = String.format("Service Okapi, Reponse inattendue code (%s) avec corps reponse vide", status);
                            log.error(message, status);
                            return OkapiException.builder()
                                    .messageOkapi(message)
                                    .build();
                        })
                )
                .mapNotNull(body -> {
                    Optional.of(response)
                            .filter(rep -> !rep.statusCode().equals(HttpStatus.OK))
                            .filter(rep -> !rep.statusCode().equals(HttpStatus.FOUND))
                            .map(rep -> body)
                            .ifPresent(okapiMessage -> {
                                try {
                                    ObjectMapper objectMapper = new ObjectMapper();
                                    TypeReference<Map<String, Object>> typeRef = new TypeReference<>() {
                                    };
                                    Map<String, Object> errorResponse = objectMapper.readValue(okapiMessage, typeRef);
                                    if (errorResponse.containsKey("errors")) {
                                        Object errorsObject = errorResponse.get("errors");
                                        if (errorsObject instanceof List<?> errorsList) {
                                            if (!errorsList.isEmpty() && errorsList.get(0) instanceof Map) {
                                                List<Map<String, Object>> errors = (List<Map<String, Object>>) errorsList;
                                                throw OkapiException.fromGraphqlError(errors.get(0));
                                            }
                                        }
                                    }
                                } catch (IOException e) {
                                    throw new RuntimeException("Failed to parse error response", e);
                                }
                            });

                    Optional.of(response)
                            .filter(rep -> rep.statusCode().is4xxClientError())
                            .filter(rep -> rep.headers()
                                    .contentType()
                                    .filter(type -> type.includes(MediaType.APPLICATION_JSON))
                                    .isPresent())
                            .map(rep -> body)
                            .map(JSONValue::parse)
                            .filter(JSONObject.class::isInstance)
                            .map(JSONObject.class::cast)
                            .ifPresent(json -> {
                                OkapiException.OkapiExceptionBuilder exception = OkapiException.builder();
                                Optional.of(response)
                                        .map(ClientResponse::statusCode);
                                Optional.ofNullable(json.getAsString("error"))
                                        .ifPresent(exception::messageOkapi);
                                log.error("Response error {}", json);
                                throw exception.build();
                            });
                    return body;
                });
    }
}