ALTER TABLE invoice
ADD docaposte_avis_paiement_export_id int UNSIGNED,
ADD docaposte_avis_paiement_export_status VARCHAR(32) default 'NEW',
ADD docaposte_avis_paiement_error_message TEXT default NULL,
ADD docaposte_avis_paiement_error_code VARCHAR(32) default NULL,
ADD CONSTRAINT fk_docaposte_avis_paiement_export_id FOREIGN KEY
 (docaposte_avis_paiement_export_id) REFERENCES export_history (id) ON DELETE CASCADE ON UPDATE RESTRICT;
