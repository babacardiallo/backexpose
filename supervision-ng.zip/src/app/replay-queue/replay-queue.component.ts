import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/internal/operators/filter';
import { environment } from '../../environments/environment';

@Component({
    selector: 'app-replay-queue',
    templateUrl: './replay-queue.component.html',
    styleUrls: ['./replay-queue.component.scss'],
    standalone: false
})

export class ReplayQueueComponent {
  appName = environment.appName;

  constructor(
    private router: Router,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.updateTitle();

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateTitle();
      });
  }

  private updateTitle() {
    this.titleService.setTitle("Factura : Queue de rejeu");
  }

}
