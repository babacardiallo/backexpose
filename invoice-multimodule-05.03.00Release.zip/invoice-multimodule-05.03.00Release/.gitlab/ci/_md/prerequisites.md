# Prerequisites
## 1- AgentK
We need an AgentK for each  Kube cluster

>JIRA for BUILD MAR PAAS here: https://jira.net.extra.laposte.fr/jira/browse/APPUI-93373  \
>AgentK link: https://git.net-courrier.extra.laposte.fr/groupe_blg/agentk/-/clusters  \

>JIRA for RUN MAR PAAS here: todo \
>todo 

---
## 2- Gitlab Envs 
We need to environement under gitlab and link them to Openshift Kube-space


---
## 3- Variables


---

## 4- Repository deploy token
To be able to use the Registry gitlab: 
registry.bscc.net.intra.laposte.fr/groupe_blg/invoice-multimodule/
  
We need to create a deploy token in gitlab:

>Goto Gitlab Gui -> Group repo -> Menu Settings -> Repository -> Deploy keys 

Used values:
> name: factura-gitlab-registry-read-token \
> user: factura-gitlab-registry-reader \
> token: ${DOCKER_REGISTRY_PWD}  \
> desc: Utilisé dans le paas pour pull les images du registry gitlab \
> link: https://git.net-courrier.extra.laposte.fr/groupe_blg/-/settings/repository#js-deploy-tokens

> Il faut créer le deploy token au niveau groupe et non au niveau projet pour n'en avoir qu'une commune aux différents projets.


**Warning: This  token should be added as a secret in each PAAS namespace!**

>La commande kubectl .. crée un secret Kubernetes de type docker-registry pour enregistrer les identifiants du registre Docker afin que Kube puisse s’authentifier et récupérer les images de conteneur depuis le registre privé (registry.bscc.net.intra.laposte.fr).
>Ce secret doit être ajouté dans chaque namespace PAAS pour permettre le pull des images depuis le registry Gitlab.

Use the following command to add the secret:
```
kubectl create secret docker-registry factura-gitlab-registry-secret 
--docker-server=registry.bscc.net.intra.laposte.fr 
--docker-username=factura-gitlab-registry-reader 
--docker-password=${DOCKER_REGISTRY_PWD}
--docker-email=unused
```

---

