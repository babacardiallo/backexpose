package fr.laposte.blg.blinks.u17.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcessStatus;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.u17.dto.ExportProcessKibanaCst;
import fr.laposte.blg.blinks.u17.dto.ExportProcessKibanaDto;
import fr.laposte.blg.blinks.u17.service.DocaposteService;
import fr.laposte.blg.blinks.u17.service.CoeurfinanceService;
import fr.laposte.blg.blinks.u17.service.ExportBaseService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Instant;
import java.util.Arrays;
import java.util.Date;
import java.util.Objects;

@Slf4j
@EnableScheduling
public class ExportOnceScheduler implements Runnable {

    private final DocaposteService docaposteService;
    private final CoeurfinanceService coeurfinanceService;
    private final InfocaInvoiceExportService infocaInvoiceExportService;
    private final ExportProcessRepository exportProcessRepository;
    private final SchedulerParamsEntity schedulerParams;
    private final TaskScheduler scheduler;

    public ExportOnceScheduler(DocaposteService docaposteService,
                           CoeurfinanceService coeurfinanceService,
                           InfocaInvoiceExportService infocaInvoiceExportService,
                           ExportProcessRepository exportProcessRepository,
                           SchedulerParamsEntity schedulerParams,
                               TaskScheduler scheduler){
        this.docaposteService = docaposteService;
        this.coeurfinanceService = coeurfinanceService;
        this.infocaInvoiceExportService = infocaInvoiceExportService;
        this.exportProcessRepository = exportProcessRepository;
        this.schedulerParams = schedulerParams;
        this.scheduler = scheduler;
    }

    @Override
    public void run() {
        this.exportProcessRepository.findTopByExportProcessStatusOrderByExecutionSequenceAsc(ExportProcessStatus.FAILED)
                .switchIfEmpty(this.exportProcessRepository.findTopByExportProcessStatusOrderByExecutionSequenceAsc(ExportProcessStatus.NEW))
                .doOnNext(this::runProcess)
                .subscribe();
    }



    private void runProcess(ExportProcess exportProcess){
        log.info("Starting export: {} Order: {} from process scheduler: {}", exportProcess.getFileType(), exportProcess.getExecutionSequence(), schedulerParams.getSchedulerName());
        ExportBaseService exportBaseService;
        switch (Objects.requireNonNull(exportProcess).getFileType()) {
            case DOCAPOSTE, DOCAPOSTE_AVIS_PAIEMENT -> exportBaseService = docaposteService;
            case COEURFINANCE -> exportBaseService = coeurfinanceService;
            case INFOCA -> exportBaseService = infocaInvoiceExportService;
            default -> {
                String errMsg = "Unsupported file type:" + exportProcess.getFileType();
                updateProcess(exportProcess.getId(), errMsg, "U170016", ExportProcessStatus.FAILED);
                return;
            }
        }
        Mono.fromCallable(() -> start(exportBaseService, exportProcess, schedulerParams.getExportPath()))
                .subscribeOn(Schedulers.boundedElastic())
                .doOnError(throwable -> this.updateProcess(exportProcess.getId(), throwable.getMessage(), "U170017", ExportProcessStatus.FAILED))
                .doOnSuccess(exportProcess1 -> this.updateProcess(exportProcess.getId(), null, null, ExportProcessStatus.SUCCESS))
                .flatMap(r -> this.exportProcessRepository.existsExportProcessByExportProcessStatusIn(Arrays.asList(ExportProcessStatus.FAILED, ExportProcessStatus.NEW)))
                .doOnNext(result -> {
                    if(result){
                        Runnable task = new ExportOnceScheduler(this.docaposteService, this.coeurfinanceService, this.infocaInvoiceExportService, this.exportProcessRepository, this.schedulerParams, this.scheduler);
                        scheduler.schedule(task, new Date(System.currentTimeMillis() + (schedulerParams.getWaitingDelay()* 1000L)));
                    } else {
                        this.finishProcess();
                    }
                })
                .subscribe();
    }

    private Mono<ExportHistoryEntity> start(ExportBaseService exportBaseService, ExportProcess process, String path){
        ExportProcess exportProcess1 = this.exportProcessRepository.findById(process.getId())
                .map(exportProcess -> {
                    exportProcess.setExportProcessStatus(ExportProcessStatus.RUNNING);
                    exportProcess.setExecutionDate(Instant.now());
                    return exportProcess;
                })
                .flatMap(exportProcessRepository::save)
                .block();
        this.logExportProcessKibana(exportProcess1);
        return exportBaseService.process(exportProcess1, path);
    }


    private void updateProcess(Long id, String errorMessage, String errorCode, ExportProcessStatus exportProcessStatus) {
        this.exportProcessRepository.findById(id)
                .map(exportProcess -> {
                    exportProcess.setExportProcessStatus(exportProcessStatus);
                    exportProcess.setErrorMessage(errorMessage);
                    exportProcess.setErrorCode(errorCode);
                    exportProcess.setExecutionDate(exportProcess.getExecutionDate()!=null ? exportProcess.getExecutionDate():Instant.now());
                    return exportProcess;
                })
                .flatMap(exportProcessRepository::save)
                .subscribe(this::logExportProcessKibana);
    }

    private void logExportProcessKibana(ExportProcess exportProcess) {
        if (exportProcess != null) {
            var exportProcessKibanaDto = new ExportProcessKibanaDto();
            exportProcessKibanaDto.setProcessId(exportProcess.getId());
            exportProcessKibanaDto.setMinId(exportProcess.getMinId());
            exportProcessKibanaDto.setMaxId(exportProcess.getMaxId());
            exportProcessKibanaDto.setExecutionDate(exportProcess.getExecutionDate());
            exportProcessKibanaDto.setFileType(exportProcess.getFileType());
            exportProcessKibanaDto.setExportProcessStatus(exportProcess.getExportProcessStatus());
            exportProcessKibanaDto.setErrorCode(exportProcess.getErrorCode());
            exportProcessKibanaDto.setErrorMessage(exportProcess.getErrorMessage());
            if(exportProcess.getExportProcessStatus().equals(ExportProcessStatus.FAILED)){
                log.error(Markers.append(ExportProcessKibanaCst.EXPORT_PROCESS_KEYS, exportProcessKibanaDto), "Export process status for {} {}: {}", exportProcessKibanaDto.getFileType(), exportProcessKibanaDto.getExportProcessStatus(), exportProcessKibanaDto);
            } else {
                log.info(Markers.append(ExportProcessKibanaCst.EXPORT_PROCESS_KEYS, exportProcessKibanaDto), "Export process status for {} {}: {}", exportProcessKibanaDto.getFileType(), exportProcessKibanaDto.getExportProcessStatus(), exportProcessKibanaDto);
            }
        }
    }

    private void finishProcess(){

    }
}
