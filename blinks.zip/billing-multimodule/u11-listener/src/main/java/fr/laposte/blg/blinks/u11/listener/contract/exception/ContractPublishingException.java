package fr.laposte.blg.blinks.u11.listener.contract.exception;

import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;

public class ContractPublishingException extends ContractListenerException {

    /**
     * Constructs a new runtime exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this runtime exception's detail message.
     *
     * @param cause the cause (which is saved for later retrieval by the
     *              {@link #getCause()} method).  (A {@code null} value is
     *              permitted, and indicates that the cause is nonexistent or
     *              unknown.)
     * @since 1.4
     */
    public ContractPublishingException(Throwable cause, ContractVersionEntity contractVersionEntityConcerned) {
        super("Error while we publish in the private topic : " + cause.getMessage()
            , cause
            , ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_POST_LISTENING_PUBLISHING
            , contractVersionEntityConcerned.getContract().getContractNumber()
            , contractVersionEntityConcerned.getAmendmentNumber()
            , contractVersionEntityConcerned.getRevisionNumber()
            , contractVersionEntityConcerned
            , contractVersionEntityConcerned.getValuedOffer().getOpsCode());
    }
}
