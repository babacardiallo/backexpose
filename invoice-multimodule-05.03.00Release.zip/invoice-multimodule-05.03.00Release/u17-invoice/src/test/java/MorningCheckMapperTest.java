import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportStatus;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import fr.laposte.blg.blinks.u17.dto.MorningCheckDto;
import fr.laposte.blg.blinks.u17.mapper.MorningCheckMapper;
import fr.laposte.blg.blinks.u17.mapper.MorningCheckMapperImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Instant;
import java.util.List;

@SpringBootTest(classes = {MorningCheckMapper.class, MorningCheckMapperImpl.class})
class MorningCheckMapperTest {

    @Autowired
    private MorningCheckMapper morningCheckMapper;

    @Test
    void exportHistoryEntityToMorningCheckDtoTest(){
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setMessageCount(10);
        exportHistoryEntity.setNbAvoirs(2);
        exportHistoryEntity.setNbReleves(1);
        exportHistoryEntity.setNbAcomptes(1);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        MorningCheckDto morningCheckDto = this.morningCheckMapper.exportHistoryEntityToMorningCheckDto(exportHistoryEntity);
        Assertions.assertNotNull(morningCheckDto);
        Assertions.assertEquals(1L, morningCheckDto.getIdExport());
        Assertions.assertEquals("file_123", morningCheckDto.getFileName());
        Assertions.assertEquals(false, morningCheckDto.getIsFileEmpty());
        Assertions.assertEquals(FileType.DOCAPOSTE.toString(), morningCheckDto.getType());
        Assertions.assertEquals(ExportStatus.SUCCESS, morningCheckDto.getStatus());
        Assertions.assertEquals(TransferStatus.NEW, morningCheckDto.getTransferStatus());
        Assertions.assertEquals(10, morningCheckDto.getNbTreatedInvoices());
        Assertions.assertEquals(2, morningCheckDto.getNbAvoirs());
        Assertions.assertEquals(1, morningCheckDto.getNbReleves());
        Assertions.assertEquals(1, morningCheckDto.getNbAcomptes());
    }

    @Test
    void exportHistoryEntityListToMorningCheckDtoListTest(){
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setMessageCount(10);
        exportHistoryEntity.setNbAvoirs(2);
        exportHistoryEntity.setNbReleves(1);
        exportHistoryEntity.setNbAcomptes(1);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        List<MorningCheckDto> morningCheckDtos = this.morningCheckMapper.exportHistoryEntityToMorningCheckDto(List.of(exportHistoryEntity));
        MorningCheckDto morningCheckDto = morningCheckDtos.get(0);
        Assertions.assertNotNull(morningCheckDto);
        Assertions.assertEquals(1L, morningCheckDto.getIdExport());
        Assertions.assertEquals("file_123", morningCheckDto.getFileName());
        Assertions.assertEquals(false, morningCheckDto.getIsFileEmpty());
        Assertions.assertEquals(FileType.DOCAPOSTE.toString(), morningCheckDto.getType());
        Assertions.assertEquals(ExportStatus.SUCCESS, morningCheckDto.getStatus());
        Assertions.assertEquals(TransferStatus.NEW, morningCheckDto.getTransferStatus());
        Assertions.assertEquals(10, morningCheckDto.getNbTreatedInvoices());
        Assertions.assertEquals(2, morningCheckDto.getNbAvoirs());
        Assertions.assertEquals(1, morningCheckDto.getNbReleves());
        Assertions.assertEquals(1, morningCheckDto.getNbAcomptes());
    }
}
