package service;

import fr.laposte.blg.blinks.lib.common.entities.SeresReplaySupervision;
import fr.laposte.blg.blinks.lib.common.repositories.SeresReplayEntityRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SeresReplaySupervisionRepository;
import fr.laposte.blg.blinks.u17.dto.SeresReplayDto;
import fr.laposte.blg.blinks.u17.mapper.SeresReplayMapper;
import fr.laposte.blg.blinks.u17.service.SeresReplayRestService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class SeresReplayRestServiceTest {
    @InjectMocks
    private SeresReplayRestService seresReplayRestService;
    @Mock
    private SeresReplayEntityRepository seresReplayEntityRepository;
    @Mock
    private SeresReplaySupervisionRepository seresReplaySupervisionRepository;
    @Mock
    private SeresReplayMapper seresReplayMapper;

    @Test
    void filterTest(){
        SeresReplaySupervision seresReplayEntity = new SeresReplaySupervision();
        seresReplayEntity.setId(1L);
        seresReplayEntity.setInvoiceNumber("PF01");
        seresReplayEntity.setErrorCode(1);
        seresReplayEntity.setErrorMessage("error");
        seresReplayEntity.setErrorDate(Instant.now());
        seresReplayEntity.setInvoiceUrl("url");

        SeresReplaySupervision seresReplayEntity2 = new SeresReplaySupervision();
        seresReplayEntity.setId(2L);
        seresReplayEntity.setInvoiceNumber("PF02");
        seresReplayEntity.setErrorCode(1);
        seresReplayEntity.setErrorMessage("error");
        seresReplayEntity.setErrorDate(Instant.now());
        seresReplayEntity.setInvoiceUrl("url");

        Mockito.when(seresReplayMapper.seresReplayEntityToSeresReplayDto(Mockito.any(SeresReplaySupervision.class))).thenReturn(new SeresReplayDto());

        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetween(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetween(Mockito.any(Instant.class), Mockito.any(Instant.class))).thenReturn(Mono.just(2L));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEquals(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndPrintFlagEquals(Mockito.any(Instant.class), Mockito.any(Instant.class),  Mockito.anyString())).thenReturn(Mono.just(2L));


        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeIn(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeIn(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList())).thenReturn(Mono.just(2L));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEquals(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEquals(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString())).thenReturn(Mono.just(2L));


        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString())).thenReturn(Mono.just(2L));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.anyString(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(2L));


        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString())).thenReturn(Mono.just(2L));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.any(PageRequest.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.countAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLike(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(2L));

        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "", false, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));
        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "", false, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));
        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "filter", false, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));
        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "filter", false, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));

        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "",true, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));
        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "",true, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));
        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "filter",true, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));
        seresReplayRestService.getAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "filter",true, PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "id")));

    }

    @Test
    void exportTest(){
        SeresReplaySupervision seresReplayEntity = new SeresReplaySupervision();
        seresReplayEntity.setId(1L);
        seresReplayEntity.setInvoiceNumber("PF01");
        seresReplayEntity.setErrorCode(1);
        seresReplayEntity.setErrorMessage("error");
        seresReplayEntity.setErrorDate(Instant.now());
        seresReplayEntity.setInvoiceUrl("url");

        SeresReplaySupervision seresReplayEntity2 = new SeresReplaySupervision();
        seresReplayEntity.setId(2L);
        seresReplayEntity.setInvoiceNumber("PF02");
        seresReplayEntity.setErrorCode(1);
        seresReplayEntity.setErrorMessage("error");
        seresReplayEntity.setErrorDate(Instant.now());
        seresReplayEntity.setInvoiceUrl("url");
        Mockito.when(seresReplayMapper.seresReplayEntityToSeresReplayDto(Mockito.any(SeresReplaySupervision.class))).thenReturn(new SeresReplayDto());

        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class)))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEqualsOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));


        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));


        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLikeOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLikeOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));

        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLikeOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));
        Mockito.when(seresReplaySupervisionRepository.findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLikeOrderByErrorDateDesc(Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Instant.class), Mockito.any(Instant.class), Mockito.anyList(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Flux.fromIterable(List.of(seresReplayEntity, seresReplayEntity2)));

        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "", false);
        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "", false);
        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "filter", false);
        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "filter", false);

        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "", true);
        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "", true);
        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), new ArrayList<>(), "filter", true);
        seresReplayRestService.exportAllSeresReplay(Instant.now(), Instant.now(), List.of("e1"), "filter", true);

    }
}
