export class EdrDetails {
    id?: string;
    offset?: string;
    partition?: string;
    serviceCode?: string;
    chargeCode?: string;
    analysis?: string;
    solution?: string;
    kafkaMessage?: JSON;
}
