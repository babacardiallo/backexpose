
import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { map, mergeAll, mergeMap, toArray } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Invoice } from '../../models/invoice';
import { InvoicePage } from '../../models/invoice.page';
import { LancementExportService } from '../../services/Lancement-export.service';

@Component({
    selector: 'invoice-rejeu',
    templateUrl: './invoice-rejeu.component.html',
    styleUrls: ['./invoice-rejeu.component.scss'],
    standalone: false
})

export class InvoiceRejeuComponent implements OnInit, AfterViewInit {


    appName = environment.appName;

    @ViewChild(DatatableComponent) invoices: DatatableComponent;

    listInvoices: Array<Invoice> = [];

    initialList: Array<Invoice> = [];

    @Output() emitSelectedInvoices: EventEmitter<Array<Invoice>> = new EventEmitter<Array<Invoice>>();

    listPrintFlags = ['Docaposte','Seres'];

    public searchText = '';

    isSeres: boolean = true;
  
    isDocaposte: boolean = true;

    public isLoading = false;

    constructor(private _cdr: ChangeDetectorRef, private lancementExportService: LancementExportService){}

    invoicePage: InvoicePage = new InvoicePage();

    ngAfterViewInit(): void {
    }

    ngOnInit(): void {
        this.getAllInvoices(0, 5, "invoiceNumber", "desc", "", this.isDocaposte, this.isSeres);
    }

    onSelect(event: any) {
       this.emitSelectedInvoices.emit(event.selected);
    }


    selectedDoca(){
        this.getAllInvoices(0, 5, "invoiceNumber", "desc", this.searchText, this.isDocaposte, this.isSeres);      
        
    }
    
    selectedSeres(){
        this.getAllInvoices(0, 5, "invoiceNumber", "desc", this.searchText, this.isDocaposte, this.isSeres);
    }

    fetchAllInvoices(){
        this.isDocaposte = true;
        this.isSeres = true;
        this.getAllInvoices(0, 5, "invoiceNumber", "desc", "", this.isDocaposte, this.isSeres);
    }



    updateFilter(event: KeyboardEvent) {
        if (!event.target) {
            return null;
        }
        const val = (event.target as HTMLInputElement).value;        
        if (event.key === 'Enter') {
            this.getAllInvoices(0, 5, "invoiceNumber", "desc", val, this.isDocaposte, this.isSeres);
        }
    }



    getAllInvoices(page: number, itemPerPage: number, sort: string, order: string, filter: string, doca: boolean, seres: boolean): void {
        this.lancementExportService.getAllInvoices(page, itemPerPage,sort,order,filter,doca,seres).subscribe({
            next: (response: any) => {                    
                this.listInvoices = response.content.map((data: any) => {
                    const message = data.message ? JSON.parse(data.message) : '';
                    return <Invoice>{
                        id: data.id,
                        invoiceNumber : data.invoiceNumber,
                        message : data.message,
                        billRunId : data.billRunId,
                        docapostExportId : data.docapostExportId,
                        infocaExportId : data.infocaExportId,
                        equinoxExportId : data.equinoxExportId,
                        custAccNumber:  message != '' ? message.billingAccount.custAccNumber  + "-" + message.billingAccount.extension : '',
                        printFlag: message != '' ? message.invoiceHeader.printFlag ? "Docaposte" : "Seres" : "Docaposte",
                    };
                })
                this.invoicePage = {
                    currentPage: response.pageable.pageNumber,
                    itemsOnPage: response.pageable.pageSize,
                    currentOffset: response.pageable.offset,
                    totalPages: response.totalPages,
                    totalItems: response.totalElements
                }
            },
            complete: () => {
                
            },
        });

    }

    onPageChange(event: any) {
        this.getAllInvoices(event.offset, 5, this.invoices.sorts[0].prop, this.invoices.sorts[0].dir, this.searchText, this.isDocaposte, this.isSeres);  
    }

    onSort(event: any) {
        this.getAllInvoices(this.invoicePage.currentPage!, 5, event.sorts[0].prop, event.sorts[0].dir, this.searchText, this.isDocaposte, this.isSeres);
        this.invoices.offset = this.invoicePage.currentPage!;
    }

    
}