package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.relational.core.mapping.Column;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MonthlyTreatment {
    @Column("file_date")
    private Instant date;
    @Column("is_file_empty")
    private Boolean isFileEmpty;
    @Column("export_status")
    private ExportStatus exportStatus;
    @Column("file_type")
    private String fileType;
    @Column("transfer_status")
    private String transferStatus;
}
