package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Setter
@Getter
@Slf4j
@JsonPropertyOrder({
        "excludingTaxTotalAmount",
        "excludingTaxNetTotalAmount",
        "totalAmount",
        "VATTotalAmount",
        "discountLineExcludingTaxAmount",
        "VATAmountPaid",
        "paymentCashAmount",
        "amountDue"
})
public class BillingAmountDTO {
    Double excludingTaxTotalAmount;
    Double excludingTaxNetTotalAmount;
    Double totalAmount;
    @JsonProperty("VATTotalAmount")
    Double vatTotalAmount;
    Double discountLineExcludingTaxAmount;
    @JsonProperty("VATAmountPaid")
    Double vatAmountPaid;
    Double paymentCashAmount;
    Double amountDue;

}
