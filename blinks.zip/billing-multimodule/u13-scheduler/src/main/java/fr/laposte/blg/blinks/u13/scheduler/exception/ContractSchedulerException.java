package fr.laposte.blg.blinks.u13.scheduler.exception;

import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ContractSchedulerException extends RuntimeException {

    private final String contractNumber;
    private final ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum;

    public ContractSchedulerException(String errorMessage, Throwable cause, @NotBlank String contractNumber) {
        super(errorMessage, cause);
        this.contractNumber = contractNumber;
        workflowStepEnum = ErrorLogEntity.ErrorWorkflowStepEnum.SCHEDULER;
    }
}
