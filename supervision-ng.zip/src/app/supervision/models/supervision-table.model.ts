export class SupervisionTable {
  idExport?: number;
  type?: string;
  fileName?: string;
  comment?: string;
  startDate?: number | string | Date;
  endDate?: number | string | Date;
  fileSendDate?: number | string | Date;
  dateError?: number | string | Date;
  nbNormalInvoices?: string;
  nbInvoiceExportedInFile?: string;
  nbTreatedInvoices?: string;
  nbAcomptes?: string;
  nbAvoirs?: string;
  nbReleves?: string;
  caHtHorsRelevesAndAcomptes?: string;
  caTtcHorsRelevesAndAcomptes?: string;
  status: string;
  isFileEmpty: boolean;
  isFileSent: boolean;
  nbExcludedInvoices: number;
  nbFailedInvoices: number;
  transferStatus: string;
}
