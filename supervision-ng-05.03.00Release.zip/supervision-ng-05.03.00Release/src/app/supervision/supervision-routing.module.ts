import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';

import { SupervisionComponent } from './supervision.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: SupervisionComponent }
        ])],
    exports: [RouterModule]
})
export class SupervisionRoutingModule { }
