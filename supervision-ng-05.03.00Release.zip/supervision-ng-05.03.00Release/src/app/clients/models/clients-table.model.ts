import { ClientTableDetail } from "./client-table-detail.model";
import { ClientDetailContracts } from "./client-table-detail-contracts.model";
import { ClientAddress } from "./client-detail-adress.model";

export class ClientsTable {
    custAccNumber?: number;
    type?: string;
    marketType?: string;
    name?: string;
    brand?: string;
    isSynchronized?: boolean;
    dateSynchronization?: number | string | Date | null;
    dateError?: number | string | Date | null;
    clientDetail?: ClientTableDetail;
    clientDetailContrat?: ClientDetailContracts
    clientAddress?: ClientAddress;
    idLegalPerson?: number;
    nbInvoices?: number;
    nbAddresses?: number;

}
