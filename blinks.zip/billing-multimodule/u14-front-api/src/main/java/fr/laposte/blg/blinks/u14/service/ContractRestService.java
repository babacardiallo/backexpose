package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.*;
import fr.laposte.blg.blinks.u14.controller.dto.ContractSupervisionDetailsDto;
import fr.laposte.blg.blinks.u14.controller.dto.ContractSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.ErrorLogSupRevDto;
import fr.laposte.blg.blinks.u14.controller.dto.SuperiorRevErrorDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.relational.core.query.Criteria;
import org.springframework.data.relational.core.query.Query;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.*;

@Service
@RequiredArgsConstructor
@Data
public class ContractRestService {

    private final ContractSupervisionAllRepository contractSupervisionAllRepository;
    private final ContractSupervisionActivesRepository contractSupervisionActivesRepository;
    private final CustomerSupervisionRepository customerSupervisionRepository;
    private final ContractSupervisionDetailsRepository contractSupervisionDetailsRepository;
    private final ErrorLogRepository errorLogRepository;
    private final ContractMessageRepository contractMessageRepository;
    private final ContractVersionMessageRepository contractVersionMessageRepository;
    private final ContractRepository contractRepository;
    private final ContractVersionRepository contractVersionRepository;
    private final R2dbcEntityTemplate template;

    public Mono<Page<ContractSupervisionDto>> getContractsActiveOffers(boolean errors, boolean isNotSynchronized,  Pageable pageable) {
        if(errors){
            if(isNotSynchronized){
                return contractSupervisionActivesRepository.findAllByFirstErrorDateIsNotNullAndIsSynchronizedFalse(pageable)
                        .map(this::mapToContractSupervisionDto)
                        .collectList()
                        .zipWith(contractSupervisionActivesRepository.countAllByFirstErrorDateIsNotNullAndIsSynchronizedFalse())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            } else {
                return contractSupervisionActivesRepository.findAllByFirstErrorDateIsNotNull(pageable)
                        .map(this::mapToContractSupervisionDto)
                        .collectList()
                        .zipWith(contractSupervisionActivesRepository.countAllByFirstErrorDateIsNotNull())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            }


        } else {
            if(isNotSynchronized){
                return contractSupervisionActivesRepository.findAllByIsSynchronizedFalse(pageable)
                        .map(this::mapToContractSupervisionDto)
                        .collectList()
                        .zipWith(contractSupervisionActivesRepository.countAllByIsSynchronizedFalse())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            } else {
                return contractSupervisionActivesRepository.findAllBy(pageable)
                        .map(this::mapToContractSupervisionDto)
                        .collectList()
                        .zipWith(contractSupervisionActivesRepository.count())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            }

        }

    }

    public  Mono<Page<ContractSupervisionDto>> getAllContracts(boolean errors, Pageable pageable) {
        if(errors) {
            return contractSupervisionAllRepository.findAllByFirstErrorDateIsNotNull(pageable)
                    .map(this::mapToContractSupervisionDto)
                    .collectList()
                    .zipWith(contractSupervisionAllRepository.countAllByFirstErrorDateIsNotNull())
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        } else {
            return contractSupervisionAllRepository.findAllBy(pageable)
                    .map(this::mapToContractSupervisionDto)
                    .collectList()
                    .zipWith(contractSupervisionActivesRepository.count())
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        }

    }

    public Mono<Page<SuperiorRevErrorDto>> getSuperiorRevErrors(Pageable pageable, String contractNumber, String custAccNumber, List<String> offers, boolean showAll) {
        if (contractNumber == null && custAccNumber == null && offers == null && Boolean.FALSE.equals(showAll)){
            return Mono.just(new PageImpl<>(Collections.emptyList(), pageable, 0));
        }
        else {
            Mono<List<SuperiorRevErrorDto>> data = contractSupervisionActivesRepository.contractSuperiorRevError(contractNumber, custAccNumber, offers, pageable)
                    .map(this::mapToContractSuperiorRevErrorDto)
                    .collectList();
            Mono<Long> count = contractSupervisionActivesRepository.countContractSuperiorRevError(contractNumber, custAccNumber, offers);

            return data.zipWith(count)
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        }
    }

    public Mono<ErrorLogSupRevDto> getSuperiorRevErrorContract(String contractNumber, Integer amendmentNumber, Integer revisionNumber){
        return errorLogRepository.oneContractSuperiorRevError(contractNumber, amendmentNumber, revisionNumber)
                .map(this::mapToErrorLogSupRevDto)
                .switchIfEmpty(Mono.just(new ErrorLogSupRevDto()));
    }

    public Mono<ContractSupervisionDetailsDto> getContractDetails(String contractNumber, Integer amendementNumber) {
        return  contractVersionRepository.findByContractNumberAndByAmendmentNumber(contractNumber, amendementNumber)
                .flatMap(contractVersionEntity ->
                Mono.zip(
                        contractSupervisionDetailsRepository.findFirstByContractNumberAndAmendmentNumber(contractNumber, amendementNumber),
                        contractVersionMessageRepository.findByIdContractVersion(contractVersionEntity.getIdContractVersion())
                )).map(this::mapToContractSupervisionDetailsDto);

    }


    private ContractSupervisionDto mapToContractSupervisionDto(ContractSupervisionEntity contractSupervisionEntity) {
        return new ContractSupervisionDto(
                contractSupervisionEntity.getId(),
                contractSupervisionEntity.getContractNumber(),
                contractSupervisionEntity.getAmendmentNumber(),
                contractSupervisionEntity.getRevisionNumber(),
                contractSupervisionEntity.getStatus(),
                contractSupervisionEntity.getSubstatus(),
                contractSupervisionEntity.getType(),
                contractSupervisionEntity.getSubtype(),
                contractSupervisionEntity.getOpsCode(),
                contractSupervisionEntity.getOpsLabel(),
                contractSupervisionEntity.getIsSynchronized(),
                contractSupervisionEntity.getLastDateSynchronization(),
                contractSupervisionEntity.getDateError(),
                contractSupervisionEntity.getFirstErrorDate(),
                contractSupervisionEntity.getCustAccNumber(),
                contractSupervisionEntity.getCustAccNumberBeforeSynchronisation()
        );
    }

    private ContractSupervisionDetailsDto mapToContractSupervisionDetailsDto(Tuple2<ContractSupervisionDetailsEntity, ContractVersionMessage> tuple2) {
        ContractSupervisionDetailsEntity contractSupervisionDetailsEntity =  tuple2.getT1();
        return new ContractSupervisionDetailsDto(
                contractSupervisionDetailsEntity.getDateError(),
                contractSupervisionDetailsEntity.getFirstErrorDate(),
                contractSupervisionDetailsEntity.getErrorMessage(),
                contractSupervisionDetailsEntity.getInvoiceAddressNumber(),
                contractSupervisionDetailsEntity.getDedicatedInvoiceFlag(),
                contractSupervisionDetailsEntity.getInvoicePeriodicityLabel(),
                contractSupervisionDetailsEntity.getSendingSupportLabel(),
                contractSupervisionDetailsEntity.getPaymentMeans(),
                contractSupervisionDetailsEntity.getRum(),
                contractSupervisionDetailsEntity.getCustPurchaseOrderNumber(),
                contractSupervisionDetailsEntity.getContractingCustRef(),
                contractSupervisionDetailsEntity.getMarketNumber(),
                tuple2.getT2().getContractConsolidated(),
                contractSupervisionDetailsEntity.getOffsetConsolidated(),
                contractSupervisionDetailsEntity.getPartitionConsolidated(),
                tuple2.getT2().getOdcContract(),
                contractSupervisionDetailsEntity.getOffsetOdc(),
                contractSupervisionDetailsEntity.getPartitionOdc(),
                contractSupervisionDetailsEntity.getCategory()
        );
    }

    private SuperiorRevErrorDto mapToContractSuperiorRevErrorDto(ContractSuperiorRevError contractSuperiorRevError) {
        return new SuperiorRevErrorDto(
                contractSuperiorRevError.getId(),
                contractSuperiorRevError.getContractNumber(),
                contractSuperiorRevError.getAmendmentNumber(),
                contractSuperiorRevError.getRevisionNumber(),
                contractSuperiorRevError.getStatus(),
                contractSuperiorRevError.getSubstatus(),
                contractSuperiorRevError.getType(),
                contractSuperiorRevError.getSubtype(),
                contractSuperiorRevError.getOpsCode(),
                contractSuperiorRevError.getOpsLabel(),
                contractSuperiorRevError.getIsSynchronized(),
                contractSuperiorRevError.getLastDateSynchronization(),
                contractSuperiorRevError.getDateError(),
                contractSuperiorRevError.getFirstErrorDate(),
                contractSuperiorRevError.getCustAccNumber(),
                contractSuperiorRevError.getCustAccNumberBeforeSynchronisation(),
                contractSuperiorRevError.getSuperiorRevisionNumber(),
                contractSuperiorRevError.getErrorMessage(),
                contractSuperiorRevError.getOffsetError(),
                contractSuperiorRevError.getPartitionError(),
                true
        );
    }

    private ErrorLogSupRevDto mapToErrorLogSupRevDto(ErrorLogEntity errorLogEntity) {
        return new ErrorLogSupRevDto(
                errorLogEntity.getContractNumber(),
                errorLogEntity.getAmendmentNumber(),
                errorLogEntity.getRevisionNumber(),
                errorLogEntity.getContractOdcJson(),
                errorLogEntity.getErrorMessage(),
                errorLogEntity.getOffset(),
                errorLogEntity.getPartition()
        );
    }



    public Mono<Page<ContractSupervisionDto>> getFilteredContracts(boolean errors, boolean isNotSynchronized, boolean showAll, String contractNumber, String custAccNumber, List<String> offers, Pageable pageable) {
        List<Criteria> criteriaList = new ArrayList<>();
        if (contractNumber == null && custAccNumber == null && offers == null && Boolean.FALSE.equals(showAll)){
            return Mono.just(new PageImpl<>(Collections.emptyList(), pageable, 0));
        }
        if (errors) {
            criteriaList.add(Criteria.where("first_error_date").isNotNull());
        }
        if (isNotSynchronized) {
            criteriaList.add(Criteria.where("is_synchronized").isFalse());
        }
        if (contractNumber != null && !contractNumber.isEmpty()) {
            criteriaList.add(Criteria.where("contract_number")
                    .is(contractNumber));
        }
        if (custAccNumber != null && !custAccNumber.isEmpty()) {
            criteriaList.add(Criteria.where("cust_acc_number")
                    .is(custAccNumber));
        }
        if (offers != null && !offers.isEmpty()) {
            criteriaList.add(Criteria.where("ops_code")
                    .in(offers));
        }

        Optional<Criteria> combined = criteriaList.stream()
                .reduce(Criteria::and);
        Query baseQuery = combined.map(Query::query).orElseGet(Query::empty);

        Query pagedQuery = baseQuery.sort(pageable.getSort()).with(pageable);

        Mono<List<ContractSupervisionDto>> pageFlux = template.select(pagedQuery, ContractSupervisionActivesEntity.class)
                .map(this::mapToContractSupervisionDto)
                .collectList();

        Mono<Long> countFlux = combined.map(c ->  template.count(Query.query(c), ContractSupervisionActivesEntity.class))
                .orElseGet(() -> template.count(Query.empty(), ContractSupervisionActivesEntity.class));


        return  pageFlux.zipWith(countFlux)
                .map(tuple -> new PageImpl<>(
                        tuple.getT1(), pageable, tuple.getT2()
                ));
    }

    public Flux<ContractSupervisionDto> getSynchedContractsExport() {
        return contractSupervisionActivesRepository.findAllContractsSynchronized()
                .map(this::mapToContractSupervisionDto);
    }


    public Flux<ReplayDto> getAllContractsForReplay() {
        return contractSupervisionActivesRepository.getByCriteria();
    }

}
