import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthGuard } from '../auth/auth-guard.service';
import { EdrComponent } from './edr.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: 'edr', component: EdrComponent, canActivate: [AuthGuard], data: { permissions: { only: ['ADMIN', 'CONS'], } } }
        ])],
    exports: [RouterModule]
})
export class EdrRoutingModule { }
