package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ElectionFileSequence;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface ElectionFileSequenceRepository extends ReactiveCrudRepository<ElectionFileSequence, Long> {

    Mono<Boolean> existsElectionFileSequenceByFileSequence(Integer fileSequence);

}
