import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/internal/operators/filter';
import { environment } from '../../environments/environment';

@Component({
    selector: 'app-offres',
    templateUrl: './offres.component.html',
    styleUrls: ['./offres.component.scss'],
    standalone: false
})

export class OffresComponent {
  appName = environment.appName;

  constructor(
    private router: Router,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.updateTitle();

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateTitle();
      });
  }

  private updateTitle() {
    this.titleService.setTitle("Factura : Supervision Offres");
  }

}
