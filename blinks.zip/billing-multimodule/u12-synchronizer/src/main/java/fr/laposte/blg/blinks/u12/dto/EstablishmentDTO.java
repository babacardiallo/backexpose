package fr.laposte.blg.blinks.u12.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EstablishmentDTO {

    @JsonProperty("CODE_SOURCE")
    private String codeSource;

    @JsonProperty("CODE_REGATE")
    private String codeRegate;

    @JsonProperty("LIBELLE")
    private String libelle;

    @JsonProperty("LIBELLE_COURT_TYPE")
    private String libelleCourtType;

    @JsonProperty("DATE_CREATION")
    private String dateCreation;

    @JsonProperty("DATE_MODIFICATION")
    private String dateModification;

    @JsonProperty("DATE_FERMETURE")
    private String dateFermeture;

    @JsonProperty("DATE_DESACTIVATION")
    private String dateDesactivation;

    @JsonProperty("LIGNE3_ADR_GEO")
    private String ligne3AdrGeo;

    @JsonProperty("LIGNE4_ADR_GEO")
    private String ligne4AdrGeo;

    @JsonProperty("LIGNE5_ADR_GEO")
    private String ligne5AdrGeo;

    @JsonProperty("LIGNE6_ADR_GEO")
    private String ligne6AdrGeo;

    @JsonProperty("LIGNE7_ADR_GEO")
    private String ligne7AdrGeo;

    @JsonProperty("CODE_ENTITE_RATTACHEMENT")
    private String codeEntiteRattachement;

    @JsonProperty("CODE_REGATE_ENTITE_RATTACHEMENT")
    private String codeRegateEntiteRattachement;

    @JsonProperty("LIBELLE_ENTITE_RATTACHEMENT")
    private String libelleEntiteRattachement;

    @JsonProperty("LIBELLE_COURT_TYPE_ENTITE_RATTACHEMENT")
    private String libelleCourtTypeEntiteRattachement;
}
