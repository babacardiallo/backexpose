import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';
import { environment } from '../../environments/environment';

@Component({
    selector: 'app-contrats',
    templateUrl: './contrats.component.html',
    styleUrls: ['./contrats.component.scss'],
    standalone: false
})

export class ContratsComponent {
    appName = environment.appName;

    constructor(
        private router: Router,
        private titleService: Title,
    ) { }

    ngOnInit() {
        this.updateTitle();

        this.router.events
            .pipe(filter(event => event instanceof NavigationEnd))
            .subscribe(() => {
                this.updateTitle();
            });
    }

    private updateTitle() {
        this.titleService.setTitle("Factura : Supervision Contrats");
    }
}
