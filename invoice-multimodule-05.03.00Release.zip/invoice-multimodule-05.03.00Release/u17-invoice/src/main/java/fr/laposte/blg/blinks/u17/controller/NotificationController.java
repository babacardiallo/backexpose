package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.u17.service.NotificationService;
import fr.laposte.blg.blinks.u17.service.NotificationService.EmailsResponse;
import fr.laposte.blg.blinks.u17.service.NotificationService.UpdateEmailsRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping(path = "/api/notifications", produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping("/custom-params/emails")
    public Mono<EmailsResponse> getEmails() {
        return notificationService.getEmails();
    }

    @PostMapping("/custom-params/emails")
    @ResponseStatus(HttpStatus.OK)
    public Mono<EmailsResponse> updateEmails(@RequestBody UpdateEmailsRequest request) {
        return notificationService.updateEmails(request);
    }
}
