export class ContractPage {
    currentPage?: number;
    itemsOnPage?: number;
    currentOffset?: number;
    totalPages?: number;
    totalItems?: number;
}