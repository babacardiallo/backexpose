package fr.laposte.blg.blinks.u17.util;

public final class Constant {
    private Constant() {}
    public static final String LINE_BREAK = "\n";

    public static final String BLANK = "";
    public static final String SEPARATOR = "¤";
    public static final String HEADER1 = "HHH001¤SOCFCT¤i7aa¤epaa¤blg1aaaa.ep%s¤/EP/ECC/import/SOCFCT/treat¤ep.sd¤¤blg1aaaa.ep%s¤";
    public static final String HEADER2 = "BBB001¤SOCFCT¤%010d¤%s¤%s";
    public static final String HEADER3 = "MET001¤%020.2f¤%06d¤%s                              ";
    public static final String HEADER4 = "HEAD00¤Z001¤";
    public static final String TECH_FIELD1="LINE00¤Z0001";
    public static final String INVOICE_TYPE="Z0001";

    public static final String RECORD_TYPE_ACPT00 = "ACPT00";
    public static final String RECORD_TYPE_ECHE00 = "ECHE00";

    //same is used in cql initializer script as well
    public static final String COEURFINANCE_FLOW_SEQ= "COEURFINANCE_FLOW_SEQ";

    public static final String CASH_PAYMENT = "10";
    public static final String TRANSFER = "40";
    public static final String DIRECT_PAYMENT = "20";
    public static final String BANK_DIRECT_DEBIT = "30";
    public static final String CREDIT_CARD = "90";

    public static final String CASH_PAYMENT_FRENCH = "Paiement comptant";
    public static final String TRANSFER_FRENCH = "Prélèvement bancaire";
    public static final String DIRECT_PAYMENT_FRENCH = "Paiement direct";
    public static final String BANK_DIRECT_DEBIT_FRENCH = "Prélèvement bancaire";
    public static final String TRANSFER_VALUE_C = "C";
    public static final String TRANSFER_VALUE_Z = "Z";
    public static final String TRANSFER_VALUE_Q = "Q";
    public static final String TRANSFER_VALUE_V = "V";
    public static final String TRANSFER_VALUE_P = "P";
    public static final String TRANSFER_VALUE_A = "A";
    public static final String TRANSFER_VALUE_B = "B";
    public static final String EMPTY = "";
    public static final String PC = "PC";

    public static final String ID_CONTRAT_CB = "0195359";

    public static final String BASE_QUERY =
            """
               WITH input_ids AS (
                   SELECT jt.id COLLATE utf8mb4_general_ci AS id_param
                   FROM JSON_TABLE(:ids, "$[*]" COLUMNS(id VARCHAR(255) PATH "$")) jt
               ),
               combined AS (
                   SELECT invoice.id_invoice, invoice.invoice_number, invoice.created, invoice.client,
                   invoice.billrun_id, invoice.docaposte_export_status, invoice.coeurfinance_export_status,
                   invoice.infoca_export_status, invoice.docaposte_export_date, invoice.coeurfinance_export_date,
                   invoice.infoca_export_date, invoice.docaposte_export_id, invoice.coeurfinance_export_id,
                   invoice.infoca_export_id, TRUE AS present
                   FROM invoice_supervision invoice
                   JOIN input_ids i ON invoice.invoice_number = i.id_param
                   UNION
                   SELECT NULL AS id_invoice, i.id_param AS invoice_number, NULL AS created, NULL AS client,
                   NULL AS billrun_id, NULL AS docaposte_export_status, NULL AS coeurfinance_export_status,
                   NULL AS infoca_export_status, NULL AS docaposte_export_date, NULL AS coeurfinance_export_date,
                   NULL AS infoca_export_date, NULL AS docaposte_export_id, NULL AS coeurfinance_export_id,
                   NULL AS infoca_export_id, FALSE AS present
                   FROM input_ids i
                   WHERE NOT EXISTS (SELECT 1 FROM invoice invoice WHERE invoice.invoice_number = i.id_param)
               )
             """;

    public static final String OUT_OF_BLINKS_BASE_QUERY =
            """
               WITH input_ids AS (
                   SELECT jt.id COLLATE utf8mb4_general_ci AS id_param
                   FROM JSON_TABLE(:ids, "$[*]" COLUMNS(id VARCHAR(255) PATH "$")) jt
               ),
               combined AS (
                   SELECT NULL AS id_invoice, i.id_param AS invoice_number, NULL AS created, NULL AS client,
                   NULL AS billrun_id, NULL AS docaposte_export_status, NULL AS coeurfinance_export_status,
                   NULL AS infoca_export_status, NULL AS docaposte_export_date, NULL AS coeurfinance_export_date,
                   NULL AS infoca_export_date, NULL AS docaposte_export_id, NULL AS coeurfinance_export_id,
                   NULL AS infoca_export_id, FALSE AS present
                   FROM input_ids i
                   WHERE NOT EXISTS (SELECT 1 FROM invoice invoice WHERE invoice.invoice_number = i.id_param)
               )
             """;
    public static final String YES = "Oui";
    public static final String NO = "Non";

}
