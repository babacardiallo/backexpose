package fr.laposte.blg.blinks.u17.util;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.stereotype.Component;

@Component("XmlMapper")
public class XmlMapperWithJavaTimeModule extends XmlMapper {
    public XmlMapperWithJavaTimeModule() {
        super();
        this.registerModule(new JavaTimeModule());
    }
}
