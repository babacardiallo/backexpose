package fr.laposte.blg.blinks.u14.service.producer;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u14.controller.dto.MandateDto;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;
import reactor.kafka.sender.KafkaSender;


import java.util.*;

@Slf4j
@Service
@Profile("mar-srec|mar-sdev|sloc")
public class KafkaMandateInjectorProducer {

    @Value("${fr.laposte.topic.mandate_injector}")
    String topic;
    @Resource(name = "kafkaMandateSenderConfig")
    Properties kafkaConfig;
    private KafkaSender<String, String> mandateKafkaSender;

    public KafkaMandateInjectorProducer(KafkaSender<String, String> mandateKafkaSender) {
        this.mandateKafkaSender = mandateKafkaSender;
    }

    @PostConstruct
    void init() {
        SenderOptions<String, String> senderOptions = SenderOptions.create(kafkaConfig);
        mandateKafkaSender = KafkaSender.create(senderOptions);
    }

    public Mono<Void> sendMandateToTopic(String mandate) {
        MandateDto mandateDto = transformToDto(mandate);
        return mandateKafkaSender.send(Mono.just(mandateDto)
                        .map(message -> SenderRecord.create(new ProducerRecord<>(topic, message.getRum(), mandate), mandate)))
                .doOnError(error -> error.printStackTrace())
                .doOnTerminate(() -> log.info("mandate {} published on topic {}", mandateDto.getRum(), topic))
                .then();
    }

    private MandateDto transformToDto(String mandate){
        MandateDto mandateDto = new MandateDto();
        try {
            var objectMapper = new ObjectMapper();
            objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            mandateDto =  objectMapper.readValue(mandate, MandateDto.class);
        } catch (Exception e) {
            log.error("Error while converting string to mandateDto");
        }
        return mandateDto;
    }
}
