package fr.laposte.blg.blinks.u14.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.web.reactive.config.WebFluxConfigurer;

@Configuration
public class WebFluxConfiguration implements WebFluxConfigurer {

    @Override
    public void configureHttpMessageCodecs(ServerCodecConfigurer configurer) {
        final int size = 32 * 1024 * 1024;
        configurer.defaultCodecs().maxInMemorySize(size);
    }
}