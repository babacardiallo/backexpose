package fr.laposte.blg.blinks.u10.controller;


import fr.laposte.blg.blinks.u10.entities.Event;
import fr.laposte.blg.blinks.u10.repositories.EventBaseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/edr")
public class EventController {

    private final EventBaseRepository eventBaseRepository;

    @GetMapping("/all-code-errors")
    List<String> getAllCodeErrors() {
        return eventBaseRepository.getAllCodeErrors();
    }


    @PostMapping("/updateFilteredEvent")
    int updateFilteredEvent(@RequestParam Instant startDate,
                            @RequestParam Instant endDate) {
        return eventBaseRepository.updateFilteredEvent(startDate, endDate);
    }

    @GetMapping("/exportEvent")
    List<Event> exportEvent(@RequestParam Instant startDate,
                            @RequestParam Instant endDate){

        return eventBaseRepository.exportEvents(startDate, endDate);
    }
}
