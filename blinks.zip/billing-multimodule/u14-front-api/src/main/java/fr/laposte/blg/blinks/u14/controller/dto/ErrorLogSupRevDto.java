package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ErrorLogSupRevDto {
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionSupNumber;
    private String odcSupMessage;
    private String errorSupMessage;
    private String offset;
    private String partition;
}



