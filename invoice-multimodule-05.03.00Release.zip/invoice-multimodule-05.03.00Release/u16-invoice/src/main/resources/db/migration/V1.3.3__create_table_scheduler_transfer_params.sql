CREATE table scheduler_params
(
id  int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
scheduler_name VARCHAR(255) default NULL,
cron_expression VARCHAR(32) default NULL,
export_path TEXT default NULL,
cft_path TEXT default NULL,
archive_path TEXT default NULL,
is_enabled TINYINT default 0
);

insert into scheduler_params VALUES(
1,
'scheduler_transfer',
'* * 23 * * *',
'/opt/app-root/src/donnees/export/',
'/opt/app-root/src/donnees/transfert/',
'/opt/app-root/src/donnees/archive/',
1
);