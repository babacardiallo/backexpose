package fr.laposte.blg.blinks.u14.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ErrorLogRepository;
import fr.laposte.blg.blinks.u14.service.producer.KafkaContractIntegrationReplayProducer;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class ReplayerIntegrationService {

    private final ErrorLogRepository errorLogRepository;
    private final KafkaContractIntegrationReplayProducer producer;
    private final ObjectMapper objectMapper;

    public Mono<String> replayContractIntegrationInError(List<String> contractNumbers){
        return run(errorLogRepository.getAllIntegrationErrorsByContractNumber(contractNumbers));
    }

    public Mono<String> replayAllContractIntegrationInError(){
        return run(errorLogRepository.getAllIntegrationErrors());

    }

    public Mono<String> run(Flux<ErrorLogEntity> errorLogEntityFlux){
        return errorLogEntityFlux
                .flatMap(errorLogEntity -> {
                    gkContractFullOutV1 contract = new gkContractFullOutV1();
                    objectMapper.registerModule(new JavaTimeModule());
                    try {
                        contract = objectMapper.readValue(errorLogEntity.getContractOdcJson(), gkContractFullOutV1.class);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    return Mono.zip(Mono.just(contract), Mono.just(errorLogEntity));
                })
                .flatMap(tuple2 -> producer.sendContractToTopic(tuple2.getT1()).thenReturn(tuple2.getT2())
                        .onErrorResume(t -> {
                            log.error("Error during the replay of the contract {}", t.getMessage());
                            return Mono.empty();
                        }))
                .count()
                .flatMap(value -> Mono.just("Démarrage du rejeu en intégration, nombre de contrats rejoués: " + value));

    }

}
