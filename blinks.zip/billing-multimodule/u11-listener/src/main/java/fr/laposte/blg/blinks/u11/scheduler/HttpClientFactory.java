package fr.laposte.blg.blinks.u11.scheduler;

import org.springframework.stereotype.Service;

import java.net.http.HttpClient;

@Service
public class HttpClientFactory {

    public HttpClient create(){
        return HttpClient.newHttpClient();
    }
}

