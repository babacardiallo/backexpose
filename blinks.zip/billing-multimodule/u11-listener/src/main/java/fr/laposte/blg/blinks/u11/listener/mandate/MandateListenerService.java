package fr.laposte.blg.blinks.u11.listener.mandate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.MandateEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.MandateRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.u11.listener.contract.ContractFullService;
import fr.laposte.blg.blinks.u11.listener.contract.dto.MandateDTO;
import fr.laposte.blg.blinks.u11.mapper.MandateMapper;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.EventOrigin;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.TypeEnum;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Data
@Slf4j
@RequiredArgsConstructor
public class MandateListenerService {

    private final MandateRepository mandateRepository;
    private final OfferFilterRepository offerFilterRepository;
    private final MandateMapper mandateMapper;
    private final ObjectMapper mapper;
    private final ContractFullService contractService;
    private final SynchronizationSender synchronizationSender;
    private final ErrorLogService errorLogService;
    private ConsumerRecord<String, String> receiverRecordFromKafka;

    public Mono<Void> updateMandateIfExist(ConsumerRecord<String, String> receiverRecord) {
        MandateDTO mandateIn;
        this.receiverRecordFromKafka = receiverRecord;
        try {
            var objectMapper = new ObjectMapper();
            objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            mandateIn = objectMapper.readValue(receiverRecord.value(), MandateDTO.class);
        } catch (Exception e) {
            return Mono.error(e);
        }

        return Mono.justOrEmpty(mandateIn.getRum())
            .flatMap(mandateRepository::findByRum)
            .filter(mandateFromDb -> isMandateDifferent(mandateFromDb, mandateIn))
            .doOnNext(mandateEntity -> log.info("Found mandate with RUM: {} in database, triggering update", mandateEntity.getRum()))
            .map(updatedMandateEntity -> this.mandateMapper.mandateToMandateEntity(mandateIn, updatedMandateEntity))
            .flatMap(mandateRepository::save)
            .flatMap(this::propagateMandateUpdateToContract)
            .then();
    }

    private boolean isMandateDifferent(MandateEntity mandateFromDb, MandateDTO mandateIn) {
        return !mandateFromDb.getBic().equals(mandateIn.getBic()) ||
            !mandateFromDb.getRum().equals(mandateIn.getRum()) ||
            !mandateFromDb.getStatus().equals(mandateIn.getStatus()) ||
                !mandateFromDb.getIban().equals(mandateIn.getIban());
    }

    private Mono<Void> propagateMandateUpdateToContract(MandateEntity entity) {
        return contractService.getContractVersionByRum(entity.getRum())
                .filterWhen(contractVersionEntity -> contractService.isOfferOfContractEligibleUpdate(contractVersionEntity))
                .flatMap(contractVersion -> {
                    contractVersion.setSynchronized(false);
                    return contractService.save(contractVersion);
                })
                .map(ContractVersionEntity::getIdContract)
                .distinct()
                .flatMap(idContract -> publishContractSyncCommand(idContract, receiverRecordFromKafka.topic(), receiverRecordFromKafka.key()))
                .then();
    }

    private Mono<Void> publishContractSyncCommand(long idContract, String topic, String key) {
        return Mono.just(idContract)
            .map(id ->
                Synchronization.newBuilder()
                    .setAction(ActionEnum.update)
                    .setType(TypeEnum.contract)
                    .setInternalId(id.intValue())
                    .setEventOrigin(EventOrigin.newBuilder()
                        .setKey(key)
                        .setTopic(topic).build())
                    .build()
            )
            .flatMap(this.synchronizationSender::send);
    }
}
