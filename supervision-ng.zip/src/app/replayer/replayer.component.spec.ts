import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplayerComponent } from './replayer.component';

describe('ReplayerComponent', () => {
  let component: ReplayerComponent;
  let fixture: ComponentFixture<ReplayerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReplayerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
