import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { SharedService } from "../../../shared/services/shared.service";
import { LancementExportService } from "../../services/Lancement-export.service";



@Component({
    selector: 'send-file',
    templateUrl: './send-file.component.html',
    styleUrls: ['./send-file.component.scss'],
    standalone: false
})
  
export class SendFileComponent  {

    env: any;
    email: string = '';
    name = 'SendFileComponent';

    constructor(private exportService: LancementExportService, private snackBar: MatSnackBar, private sharedService: SharedService, private modalService: ModalService){
      this.email = this.sharedService.connectedUserData.email;
    }

    send() {
        this.exportService.send(this.env, this.email)
        .subscribe(response =>{
          this.close();
          if(response==1){
            this.snackBar.open("Le fichier est envoyé au mail: " + this.email, 'Fermer', { duration: 8000 });
          } else {
            this.snackBar.open("Une erreur est survenue lors de la tentive d'envoie du mail", 'Fermer', { duration: 8000 });
          }
        })
    }

    close(){
      this.modalService.close(this.name);
    }

  }