ALTER TABLE blg_invoice.file_sequence
    MODIFY COLUMN sequence_name enum ('DOCAPOST','INFOCA','EQUINOX', 'COPILOTMD');

INSERT INTO blg_invoice.file_sequence(sequence_name, current_sequence)
VALUES ('COPILOTMD', 0);