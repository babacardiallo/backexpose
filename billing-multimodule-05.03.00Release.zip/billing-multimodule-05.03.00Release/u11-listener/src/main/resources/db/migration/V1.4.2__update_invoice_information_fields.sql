ALTER TABLE invoice_information
    ADD COLUMN framework_contract_number varchar(255),
    ADD COLUMN cust_business_unit_ref varchar(255),
    ADD COLUMN contracting_cust_ref2 varchar(255);