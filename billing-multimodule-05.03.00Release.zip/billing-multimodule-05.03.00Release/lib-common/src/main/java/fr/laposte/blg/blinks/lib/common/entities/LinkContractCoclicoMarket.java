package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Table("link_coclico_market_contract")
public class LinkContractCoclicoMarket {

    @Id
    @Column("id")
    private Long id;

    @Column("cust_acc_number")
    private Integer custAccNumber;

    @Column("market_number")
    private String marketNumber;

    @Column("contract_number")
    private String contractNumber;
}
