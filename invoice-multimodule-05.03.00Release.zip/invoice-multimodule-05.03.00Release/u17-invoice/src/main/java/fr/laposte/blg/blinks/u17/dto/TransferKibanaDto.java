package fr.laposte.blg.blinks.u17.dto;


import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransferKibanaDto {
    private Long exportId;
    private FileType fileType;
    private String fileName;
    private Instant fileDate;
    private Instant transferDate;
    private TransferStatus transferStatus;
    private String transferErrorMessage;
    private String transferErrorCode;

}
