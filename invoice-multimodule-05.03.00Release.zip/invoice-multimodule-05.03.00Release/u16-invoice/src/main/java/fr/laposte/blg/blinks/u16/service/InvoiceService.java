package fr.laposte.blg.blinks.u16.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.lib.common.dto.RejectedInvoiceToLog;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceMessageEntity;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoice;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoiceStatus;
import fr.laposte.blg.blinks.lib.common.exceptions.CodeError;
import fr.laposte.blg.blinks.lib.common.exceptions.InvoiceListenerException;
import fr.laposte.blg.blinks.lib.common.exceptions.WorkFlowStep;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.RejectedInvoiceRepository;
import fr.laposte.blg.blinks.u16.mapper.InvoiceAvroToDtoMapper;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Service
@Slf4j
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;

    private final InvoiceMessageRepository invoiceMessageRepository;

    private final InvoiceAvroToDtoMapper invoiceAvroToDtoMapper;

    private final ObjectMapper objectMapper;

    private final RejectedInvoiceRepository rejectedInvoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository, InvoiceMessageRepository invoiceMessageRepository, InvoiceAvroToDtoMapper invoiceAvroToDtoMapper, RejectedInvoiceRepository rejectedInvoiceRepository) {
        this.invoiceRepository = invoiceRepository;
        this.invoiceMessageRepository = invoiceMessageRepository;
        this.invoiceAvroToDtoMapper = invoiceAvroToDtoMapper;
        this.objectMapper = new ObjectMapper();
        this.rejectedInvoiceRepository = rejectedInvoiceRepository;
    }

    public Mono<InvoiceEntity> saveInvoice(Invoice invoice) {
         return Mono.just(invoice)
                 .map(this::invoiceToInvoiceEntity)
                 .flatMap(this::saveOn)
                 .onErrorResume(InvoiceListenerException.class, e -> {
                    RejectedInvoice rejectedInvoice =
                            RejectedInvoice.builder()
                                    .invoiceNumber(String.valueOf(invoice.getInvoiceHeader().getInvoiceNumber()))
                                    .invoiceJson(String.valueOf(invoice))
                                    .errorCode(e.getCode())
                                    .errorMessage(e.getMessage())
                                    .errorDate(Instant.now())
                                    .status(RejectedInvoiceStatus.REJECTED)
                                    .workFlowStep(e.getWorkFlowStep()).build();
                    RejectedInvoiceToLog rejectedInvoiceToLog = convertToLogEntity(rejectedInvoice);
                    objectMapper.registerModule(new JavaTimeModule());
                    JsonNode node = objectMapper.convertValue(rejectedInvoiceToLog, JsonNode.class);
                    log.error(Markers.append("invoiceListeningError", node), "[INVOICE NUMBER:" + invoice.getInvoiceHeader().getInvoiceNumber() + "] Invoice Listening error: {}", node);
                    return rejectedInvoiceRepository.save(rejectedInvoice).then(Mono.empty());
                })
                .onErrorResume(throwable -> {
                    RejectedInvoice rejectedInvoice =
                            RejectedInvoice.builder()
                                    .invoiceNumber(String.valueOf(invoice.getInvoiceHeader().getInvoiceNumber()))
                                    .invoiceJson(String.valueOf(invoice))
                                    .errorCode(CodeError.U16999)
                                    .errorMessage("UNHANDLED EXCEPTION " + throwable.getMessage())
                                    .errorDate(Instant.now())
                                    .status(RejectedInvoiceStatus.REJECTED)
                                    .workFlowStep(WorkFlowStep.INVOICE_LISTENING).build();
                    RejectedInvoiceToLog rejectedInvoiceToLog = convertToLogEntity(rejectedInvoice);
                    objectMapper.registerModule(new JavaTimeModule());
                    JsonNode node = objectMapper.convertValue(rejectedInvoiceToLog, JsonNode.class);
                    log.error(Markers.append("invoiceListeningError", node), "[INVOICE NUMBER:" + invoice.getInvoiceHeader().getInvoiceNumber() + "] Invoice Listening error: {}", node);
                    return rejectedInvoiceRepository.save(rejectedInvoice).then(Mono.empty());
                });
    }


    public Tuple2<InvoiceEntity, InvoiceMessageEntity> invoiceToInvoiceEntity(Invoice invoice) {
        InvoiceDTO invoiceDto;
        InvoiceEntity invoiceEntity = new InvoiceEntity();
        InvoiceMessageEntity invoiceMessageEntity= new InvoiceMessageEntity();

        try{
            invoiceEntity.setCreated(Instant.now());
            invoiceEntity.setUpdated(Instant.now());
            invoiceEntity.setBillrunId(invoice.getHeader().getBillrunCode().toString());
            invoiceEntity.setInvoiceNumber(invoice.getInvoiceHeader().getInvoiceNumber().toString());
            invoiceEntity.setReference(invoice.getInvoiceHeader().getInvoiceNumber().toString());
            invoiceEntity.setBillrunDate(LocalDateTime.parse(invoice.getInvoiceHeader().getBillingDate().getCalculationDate().toString(), DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant());
            invoiceEntity.setReference(invoice.getInvoiceHeader().getInvoiceNumber().toString());
            invoiceEntity.setClient(Integer.parseInt(invoice.getBillingAccount().getCustAccNumber().toString()));
            // flag columns
            invoiceEntity.setCreditFlag(invoice.getInvoiceHeader().getCreditFlag());
            invoiceEntity.setDownPaymentFlag(invoice.getInvoiceHeader().getDownpaymentFlag());
            invoiceEntity.setStatementFlag(invoice.getInvoiceHeader().getIsStatementFlag());
            invoiceEntity.setAvisPaymentFlag(invoice.getInvoiceHeader().getAvisPaiementFlag());
        } catch (NumberFormatException exception) {
            throw new InvoiceListenerException(exception.getMessage(), exception.getCause(), WorkFlowStep.INVOICE_LISTENING_NUMBER_FORMAT, CodeError.U16003);
        }  catch (DateTimeParseException exception){
            throw new InvoiceListenerException(exception.getMessage(), exception.getCause(), WorkFlowStep.INVOICE_LISTENING_MAPPING_AVRO, CodeError.U16001);
        }

        try{
            invoiceDto = invoiceAvroToDtoMapper.avroToDto(invoice);
        } catch (Exception exception){
            throw new InvoiceListenerException(exception.getMessage(), exception.getCause(), WorkFlowStep.INVOICE_LISTENING_MAPPING_AVRO, CodeError.U16001);
        }
        try {
            objectMapper.registerModule(new JavaTimeModule());
            invoiceMessageEntity.setMessage(this.objectMapper.writeValueAsString(invoiceDto));
            invoiceMessageEntity.setIdInvoice(invoiceEntity.getIdInvoice());
        } catch (JsonProcessingException exception) {
            throw new InvoiceListenerException(exception.getMessage(), exception.getCause(), WorkFlowStep.INVOICE_LISTENING_CONVERTING_MESSAGE_TO_JSON, CodeError.U16002);
        }
        return Tuples.of(invoiceEntity, invoiceMessageEntity);
    }

    private Mono<InvoiceEntity> saveOn(Tuple2<InvoiceEntity, InvoiceMessageEntity> tuple2){
        InvoiceEntity invoiceEntity = tuple2.getT1();
        InvoiceMessageEntity invoiceMessageEntity = tuple2.getT2();
        return this.invoiceRepository.save(invoiceEntity)
                .onErrorMap(throwable -> {
                    if(throwable instanceof DataIntegrityViolationException){
                        return new InvoiceListenerException(throwable.getMessage(), throwable.getCause(), WorkFlowStep.INVOICE_LISTENING_SAVING_INVOICE_THAT_ALREADY_EXISTS, CodeError.U16004);
                    } else {
                        return throwable;
                    }
                })
                .flatMap(invoiceEntity1 -> {
                    invoiceMessageEntity.setIdInvoice(invoiceEntity1.getIdInvoice());
                    return invoiceMessageRepository.save(invoiceMessageEntity).thenReturn(invoiceEntity1);
                });
    }

    private RejectedInvoiceToLog convertToLogEntity(RejectedInvoice rejectedInvoice) {
        RejectedInvoiceToLog rejectedInvoiceToLog = new RejectedInvoiceToLog();
        rejectedInvoiceToLog.setInvoiceNumber(rejectedInvoice.getInvoiceNumber());
        rejectedInvoiceToLog.setErrorCode(rejectedInvoice.getErrorCode());
        rejectedInvoiceToLog.setErrorMessage(rejectedInvoice.getErrorMessage());
        rejectedInvoiceToLog.setErrorDate(rejectedInvoice.getErrorDate());
        rejectedInvoiceToLog.setReplayedDate(rejectedInvoice.getReplayedDate());
        rejectedInvoiceToLog.setStatus(rejectedInvoice.getStatus());
        rejectedInvoiceToLog.setWorkFlowStep(rejectedInvoice.getWorkFlowStep());
        return rejectedInvoiceToLog;
    }


}
