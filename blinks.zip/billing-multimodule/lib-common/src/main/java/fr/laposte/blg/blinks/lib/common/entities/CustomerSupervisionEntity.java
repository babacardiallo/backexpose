package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;


@Data
@Table("customer_supervision")
@AllArgsConstructor
@NoArgsConstructor
public class CustomerSupervisionEntity {
    @Id
    @Column("id")
    protected String id;
    @Column("id_legal_person")
    protected int idLegalPerson;
    @Column("cust_acc_number")
    protected int custAccNumber;
    @Column("type")
    protected String type;
    @Column("market_type")
    protected String marketType;
    @Column("name")
    protected String name;
    @Column("brand")
    protected String brand;
    @Column("is_synchro")
    protected boolean isSynchro;
    @Column("date_last_synchronization")
    protected Instant dateLastSynchro;
    @Column("max_date_error")
    protected Instant dateError;
    @Column("cust_acc_number_text")
    protected String custAccNumberText;
}
