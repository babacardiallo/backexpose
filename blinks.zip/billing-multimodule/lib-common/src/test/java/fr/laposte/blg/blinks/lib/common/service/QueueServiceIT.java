package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.an.testcontainers.mysql.MySQLContainer;
import fr.laposte.blg.blinks.lib.common.entities.ContractEntity;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LegalPersonRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.QueueSynchronizationRepository;
import fr.laposte.bscc.billing.avro.ActionEnum;
import io.r2dbc.spi.ConnectionFactory;
import org.junit.jupiter.api.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.r2dbc.DataR2dbcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.r2dbc.connection.init.CompositeDatabasePopulator;
import org.springframework.r2dbc.connection.init.ConnectionFactoryInitializer;
import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Testcontainers;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

@Testcontainers
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DataR2dbcTest
class QueueServiceIT {

    @Autowired
    private QueueSynchronizationRepository queueSynchronizationRepository;

    ContractEntity contractEntitySaved1;

    LegalPersonEntity legalPersonEntitySaved;

    @Autowired
    private ContractRepository contractRepository;

    @Autowired
    private LegalPersonRepository legalPersonRepository;

    @Mock
    private ContractService contractService;

    @Mock
    private LegalPersonService legalPersonService;

    private QueueService queueServiceToTest;

    private static final MySQLContainer sqlContainer = new MySQLContainer()
        .withDatabaseName("blg_contract_importer");

    static {
        sqlContainer.start();
    }

    @DynamicPropertySource
    static void registerDynamicProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.r2dbc.url", QueueServiceIT::r2dbcUrl);
        registry.add("spring.r2dbc.username", sqlContainer::getUsername);
        registry.add("spring.r2dbc.password", sqlContainer::getPassword);
    }

    private static String r2dbcUrl() {
        return String.format("r2dbc:mysql://%s:%s/%s?sslMode=DISABLED",
            sqlContainer.getContainerIpAddress(),
            sqlContainer.getFirstMappedPort(),
            sqlContainer.getDatabaseName());
    }

    @TestConfiguration
    static class TestConfig {
        @Bean
        public ConnectionFactoryInitializer initializer(ConnectionFactory connectionFactory) {

            ConnectionFactoryInitializer initializer = new ConnectionFactoryInitializer();
            initializer.setConnectionFactory(connectionFactory);

            CompositeDatabasePopulator populator = new CompositeDatabasePopulator();
            populator.addPopulators(new ResourceDatabasePopulator(new ClassPathResource("V1.0.0__init_blling_tables.sql")));
            initializer.setDatabasePopulator(populator);

            return initializer;
        }
    }

    @BeforeAll
    void setUp() {

        queueServiceToTest = new QueueService(
            queueSynchronizationRepository, contractService, legalPersonService
        );
    }

    @AfterEach
    void tearDown() {
        queueSynchronizationRepository.deleteAll().block();
        contractRepository.deleteAll().block();
        legalPersonRepository.deleteAll().block();
    }

    @BeforeEach
    void beforeEach() {
        ContractEntity.ContractEntityBuilder contractEntityBuilder = ContractEntity.builder();
        contractEntitySaved1 = contractRepository.save(contractEntityBuilder.contractNumber("TEST-123")
            .type("Simple")
            .subtype("bof")
            .custAccNumber(12346)
            .build()).block();
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setCustAccNumber(1);
        legalPersonEntity.setCompName("GG");
        legalPersonEntitySaved = legalPersonRepository.save(legalPersonEntity).block();
    }

    @Test
    void enQueueContract() {
        Mono<QueueSynchronizationEntity> monoToVerify = queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create);

        StepVerifier.create(monoToVerify)
            .expectNextMatches(queueSynchronizationEntity ->
                queueSynchronizationEntity.getDateSynchronizationExpected().equals(ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                    .withHour(0)
                    .withMinute(0)
                    .withMinute(0)
                    .toInstant())
                    &&
                    queueSynchronizationEntity.getIdContract().equals(1L)

            )
            .expectComplete()
        ;
    }

    @Test
    void enQueueExsitingContract() {


        queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create).block();

        Mono<QueueSynchronizationEntity> monoToVerify = queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create);
        //We try to enqueue existing contract
        StepVerifier.create(monoToVerify)
            .expectError()
        ;
    }

    @Test
    void isContractAlreadyQueued() {
        //PRECONDITION
        queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create).block();

        ContractVersionEntity contractVersionEntity = Mockito.spy(ContractVersionEntity.class);
        contractVersionEntity.setIdContract(contractEntitySaved1.getIdContract());

        StepVerifier.create(queueServiceToTest.isContractAlreadyQueued(contractVersionEntity.getIdContract()))
            .expectNext(true)
            .verifyComplete();


    }

    @Test
    void findQueueSynchronization() {
        //PRECONDITION
        queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create).block();
        ContractVersionEntity contractVersionEntity = Mockito.spy(ContractVersionEntity.class);
        contractVersionEntity.setIdContract(contractEntitySaved1.getIdContract());

        StepVerifier.create(queueServiceToTest.findQueueSynchronizationByIdContract(contractVersionEntity.getIdContract()))
            .expectNextMatches(queueSynchronizationEntity -> queueSynchronizationEntity.getIdContract().equals(contractVersionEntity.getIdContract()) &&
                queueSynchronizationEntity.getDateSynchronizationExpected().equals(ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                    .withHour(0)
                    .withMinute(0)
                    .withMinute(0)
                    .toInstant()))
            .expectComplete();

    }

    @Test
    void findContractsToSynchronizeImmediately() {
        ContractEntity.ContractEntityBuilder contractEntityBuilder = ContractEntity.builder();

        //Preconditions
        var contractEntitySaved2 = contractRepository.save(contractEntityBuilder.contractNumber("TEST-1234")
            .type("Simple")
            .subtype("bof")
            .custAccNumber(12346)
            .build()).block();
        var contractEntitySaved3 = contractRepository.save(contractEntityBuilder.contractNumber("TEST-1235")
            .type("Simple")
            .subtype("bof")
            .custAccNumber(12346)
            .build()).block();

        var queueEntity1 = queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create).block();
        //In the future +2days
        var queueEntity2 = queueServiceToTest.enQueueContract(contractEntitySaved2.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .plusDays(2)
                .toInstant(), ActionEnum.create).block();
        var queueEntity3 = queueServiceToTest.enQueueContract(contractEntitySaved3.getIdContract()
            , ZonedDateTime.now(ZoneId.of("Europe/Paris"))
                .withHour(0)
                .withMinute(0)
                .withMinute(0)
                .toInstant(), ActionEnum.create).block();

        //Only queueEntity1 and queueEntity3 should be selected as queueEntity2 is planned in the future
        StepVerifier.create(queueServiceToTest.findEntitiesToSynchronizeImmediately())
            .expectNextSequence(List.of(queueEntity1, queueEntity3))
            .expectComplete();


    }

    @Test
    void enQueueContractAction() {
        Mono<QueueSynchronizationEntity> monoToVerify = queueServiceToTest.enQueueContract(contractEntitySaved1.getIdContract(),ActionEnum.create);

        StepVerifier.create(monoToVerify)
                .expectNextMatches(queueSynchronizationEntity ->
                                queueSynchronizationEntity.getIdContract().equals(1L)

                )
                .expectComplete()
        ;
    }

    @Test
    void enQueueLegalPerson() {
        Mono<QueueSynchronizationEntity> monoToVerify = queueServiceToTest.enQueueCustomerByIdLegalPerson(1L, Instant.now(), ActionEnum.create, true);

        StepVerifier.create(monoToVerify)
                .expectNextMatches(queueSynchronizationEntity ->
                                queueSynchronizationEntity.getIdLegalPerson().equals(1L)

                )
                .expectComplete()
        ;
    }

    @Test
    void enQueueCoclico() {
        Mockito.when(legalPersonService.findLegalPersonByCoclico(Mockito.anyInt(), Mockito.anyBoolean())).thenReturn(Mono.just(legalPersonEntitySaved));
        Mono<QueueSynchronizationEntity> monoToVerify = queueServiceToTest.enQueueCustomerByCoclico(1, Instant.now(), ActionEnum.create);

        StepVerifier.create(monoToVerify)
                .expectNextMatches(queueSynchronizationEntity ->
                                queueSynchronizationEntity.getIdLegalPerson().equals(1L)

                )
                .expectComplete()
        ;
    }
}
