package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerSupervisionDto {
    private String siret;
    private String legalNatureCode;
    private String legalNatureName;
    private String implantationCode;
    private String vatNumber;
    private String message;
    private String errorMessage;

}
