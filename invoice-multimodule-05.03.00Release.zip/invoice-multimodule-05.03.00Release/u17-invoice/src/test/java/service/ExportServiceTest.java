package service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.dto.ExportKibanaDto;
import fr.laposte.blg.blinks.u17.dto.InvoiceExportDto;
import fr.laposte.blg.blinks.u17.service.ExportService;
import fr.laposte.blg.blinks.u17.util.ObjectMapperWithModules;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import static org.mockito.Mockito.doAnswer;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExportServiceTest {
    @InjectMocks
    private ExportService exportService;
    @Mock
    private ExportHistoryRepository exportHistoryRepository;
    @Mock
    private InvoiceRepository invoiceRepository;
    @Mock
    private ObjectMapper objectMapper;

    @Test
    void setCompteursAttributsTest() throws IOException {
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        String json1 = "src/test/resources/remise_type_v9.json";
        String json2 = "src/test/resources/remise2_type_v9.json";
        String mes1 = Files.readString(Path.of(json1));
        String mes2 = Files.readString(Path.of(json2));
        ObjectMapperWithModules objectMapperWithModules = new ObjectMapperWithModules();
        InvoiceDTO invoiceDTO = objectMapperWithModules.readValue(mes1, InvoiceDTO.class);
        InvoiceDTO invoiceDTO1 = objectMapperWithModules.readValue(mes1, InvoiceDTO.class);
        List<InvoiceDTO> validInvoicesDto = List.of(invoiceDTO,invoiceDTO1);
        List<InvoiceExportDto> validInvoices = List.of(new InvoiceExportDto(), new InvoiceExportDto());
        List<InvoiceExportDto> failedInvoices = List.of(new InvoiceExportDto(), new InvoiceExportDto());
        List<InvoiceExportDto> excludedInvoices = List.of(new InvoiceExportDto(), new InvoiceExportDto());
        exportService.setCompteursAttributs(exportHistoryEntity, validInvoicesDto, validInvoices, failedInvoices, excludedInvoices);
    }


    @Test
    void generateHistoryTest() throws IOException {
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        String json1 = "src/test/resources/remise_type_v9.json";
        String json2 = "src/test/resources/remise2_type_v9.json";
        String mes1 = Files.readString(Path.of(json1));
        String mes2 = Files.readString(Path.of(json2));
        ObjectMapperWithModules objectMapperWithModules = new ObjectMapperWithModules();
        InvoiceDTO invoiceDTO = objectMapperWithModules.readValue(mes1, InvoiceDTO.class);
        InvoiceDTO invoiceDTO1 = objectMapperWithModules.readValue(mes1, InvoiceDTO.class);
        List<InvoiceDTO> validInvoicesDto = List.of(invoiceDTO,invoiceDTO1);
        List<InvoiceExportDto> validInvoices = List.of(new InvoiceExportDto(1L, "P1", null,null), new InvoiceExportDto(2L, "P2", null,null));
        List<InvoiceExportDto> failedInvoices = List.of(new InvoiceExportDto(3L, "P3", "error","U17001"), new InvoiceExportDto(4L, "P4", "error","U17001"));
        List<InvoiceExportDto> excludedInvoices = List.of(new InvoiceExportDto(5L, "P5", null,null), new InvoiceExportDto(6L, "P6", null,null));
        Mockito.when(exportHistoryRepository.save(Mockito.any(ExportHistoryEntity.class))).thenReturn(Mono.just(exportHistoryEntity));
        Mockito.when(this.invoiceRepository.updateDocaposteExportIdById(Mockito.anyLong(), Mockito.anyLong())).thenReturn(Mono.just(new InvoiceEntity()));
        Mockito.when(this.invoiceRepository.updateInfocaExportIdById(Mockito.anyLong(), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateCoeurfinanceExportIdById(Mockito.anyLong(), Mockito.anyLong())).thenReturn(Mono.just(1));

        Mockito.when(this.invoiceRepository.updateDocaposteExportStatusById(Mockito.any(InvoiceStatusEnum.class), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateDocaposteErrorMessageById(Mockito.anyString(), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateDocaposteErrorCodeById(Mockito.anyString(), Mockito.anyLong())).thenReturn(Mono.just(1));

        Mockito.when(this.invoiceRepository.updateInfocaExportStatusById(Mockito.any(InvoiceStatusEnum.class), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateInfocaErrorMessageById(Mockito.anyString(), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateInfocaErrorCodeById(Mockito.anyString(), Mockito.anyLong())).thenReturn(Mono.just(1));

        Mockito.when(this.invoiceRepository.updateCoeurfinanceExportStatusById(Mockito.any(InvoiceStatusEnum.class), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateCoeurfinanceErrorMessageById(Mockito.anyString(), Mockito.anyLong())).thenReturn(Mono.just(1));
        Mockito.when(this.invoiceRepository.updateCoeurfinanceErrorCodeById(Mockito.anyString(), Mockito.anyLong())).thenReturn(Mono.just(1));

        doAnswer(invocation -> new ObjectMapper().convertValue(invocation.getArgument(0), JsonNode.class))
                .when(objectMapper).convertValue(Mockito.any(ExportKibanaDto.class), (Class<Object>)Mockito.any());
        exportService.generateHistory(Instant.now(), validInvoicesDto,  validInvoices, failedInvoices,  excludedInvoices,  FileType.DOCAPOSTE, "name");
        exportService.generateHistory(Instant.now(), validInvoicesDto,  validInvoices, failedInvoices,  excludedInvoices,  FileType.INFOCA, "name");
        exportService.generateHistory(Instant.now(), validInvoicesDto,  validInvoices, failedInvoices,  excludedInvoices,  FileType.COEURFINANCE, "name");
    }
}
