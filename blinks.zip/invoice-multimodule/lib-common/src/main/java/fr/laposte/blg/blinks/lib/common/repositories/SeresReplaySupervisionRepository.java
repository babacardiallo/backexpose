package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.SeresReplaySupervision;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

public interface SeresReplaySupervisionRepository extends ReactiveCrudRepository<SeresReplaySupervision, Long> {

    // methodes pour l'affichage

    Flux<SeresReplaySupervision> findAllByErrorDateBetween(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetween(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeIn(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndErrorCodeIn(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("errors") String errors, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("errors") String errors);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, @Param("errors") String errors, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, @Param("errors") String errors);


    // methodes pour l'export

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenOrderByErrorDateDesc(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInOrderByErrorDateDesc(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLikeOrderByErrorDateDesc(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("errors") String errors);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLikeOrderByErrorDateDesc(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, @Param("errors") String errors);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndPrintFlagEquals(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, String printFlag, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndPrintFlagEquals(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, String printFlag);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEquals(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes, String printFlag, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEquals(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes, String printFlag);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, String printFlag1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, String printFlag2, @Param("errors") String errors, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1,String printFlag1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, String printFlag2, @Param("errors") String errors);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, String printFlag1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, String printFlag2, @Param("errors") String errors, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, String printFlag1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, String printFlag2, @Param("errors") String errors);

    // methodes pour l'export

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndPrintFlagEqualsOrderByErrorDateDesc(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, String printFlag);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsOrderByErrorDateDesc(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes, String printFlag);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndPrintFlagEqualsAndErrorMessageLikeOrderByErrorDateDesc(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, String printFlag1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, String printFlag2, @Param("errors") String errors);

    Flux<SeresReplaySupervision> findAllByErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndPrintFlagEqualsAndErrorMessageLikeOrderByErrorDateDesc(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, String printFlag1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, String printFlag2, @Param("errors") String errors);


}
