package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Setter
@Getter
@JsonPropertyOrder({
        "accountInvoiceNumber",
        "accountInvoiceCalculationDate",
        "excludingTaxNetTotalAmount",
        "amountDue"
})
public class AccountDetailsDTO {
    String accountInvoiceNumber;
    Instant accountInvoiceCalculationDate;
    Double excludingTaxNetTotalAmount;
    Double amountDue;
}
