package fr.laposte.blg.blinks.u11.mapper;

import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class InstantMapper {
    public String asString(Instant instant) {
        return instant != null ? ZonedDateTime.ofInstant(instant, ZoneId.of("Europe/Paris")).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) : null;
    }

    public Instant asInstant(String date) {
        return date != null && !date.isBlank() ? ZonedDateTime.parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toInstant() : null;
    }
}
