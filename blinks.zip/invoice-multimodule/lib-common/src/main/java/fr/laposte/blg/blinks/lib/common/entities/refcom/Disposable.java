package fr.laposte.blg.blinks.lib.common.entities.refcom;

public interface Disposable {

    boolean isActive();
}
