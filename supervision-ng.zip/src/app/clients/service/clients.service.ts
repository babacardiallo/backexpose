import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, Subject, throwError } from 'rxjs';
import { catchError, map, takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ClientsTable } from '../models/clients-table.model';
import { ClientTableDetail } from "../models/client-table-detail.model";
import { ClientAddress } from "../models/client-detail-adress.model";
import { ReplayReport } from '../../replayer/models/replay-report.model';

@Injectable({
  providedIn: 'root',
})
export class ClientsService {
  ngUnsubscribe$ = new Subject<void>();

  constructor(private http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }

  getAllClients(errors: boolean, page: number, size: number, sort: string, order: string, filter: string): Observable<any> {
    let queryParams = new HttpParams()
        .set("page", page)
        .set("errors", errors)
        .set("size", size)
        .set("sort", sort)
        .set("order", order)
        .set("filter", filter);
    return this.http.get<any>(environment.API_CUSTOMER_SUPERVISION_PARTIAL+queryParams, this.httpOptions)
    .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getOneClient(coclico: number): Observable<ClientsTable> {
    let queryParams = new HttpParams().append("coclico", coclico);
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    return this.http.get<ClientsTable>(environment.API_CUSTOMER_SUPERVISION_ONE_PARTIAL, { headers: head, params: queryParams })
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getClientDetail(coclico: number): Observable<ClientTableDetail> {
    let queryParams = new HttpParams().append("coclico", coclico);
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    return this.http.get<ClientTableDetail>(environment.API_CUSTOMER_SUPERVISION_DETAILS, { headers: head, params: queryParams })
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getClientContracts(coclico: number): Observable<ClientTableDetail> {
    let queryParams = new HttpParams().append("coclico", coclico);
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    return this.http.get<ClientTableDetail>(environment.API_CUSTOMER_SUPERVISION_DETAILS_CONTRACTS, { headers: head, params: queryParams })
      .pipe(takeUntil(this.ngUnsubscribe$));
  }
  getClientAddress(idLegalPerson: number): Observable<ClientAddress[]> {
    let queryParams = new HttpParams().append("idLegalPerson", idLegalPerson);
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    return this.http.get<ClientAddress[]>(environment.API_CUSTOMER_SUPERVISION_DETAILS_ADDRESS, { headers: head, params: queryParams })
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  replayClientUnit(coclicos: number[], refcomReplay: string, date?: string): Observable<ReplayReport> {
    let queryParams = new HttpParams();
    if (date) {
      queryParams = queryParams.set("date-synchronization-expected", date);
    }
    queryParams = queryParams.set("refcom-replay", refcomReplay);
    let head = new HttpHeaders({ 'Content-Type': 'application/json',  });
    return this.http.post<ReplayReport>(environment.API_CLIENT_REPLAY_UNIT, coclicos, { headers: head, params: queryParams })
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

   getCustomerNbInvoices(client: any): Observable<any> {
    return this.http.get<number>(environment.API_CUSTOMER_INVOICES+"/"+client.custAccNumber, this.httpOptions)
    .pipe(
      map((value) =>{
        client.nbInvoices = value;
        return client;
      }),
      catchError(error => {
        return of(client);
      }),
      takeUntil(this.ngUnsubscribe$)
      );
  }


  /* getCustomerNbInvoices(client: any): Observable<any> {
    return this.http.get<number>(environment.API_CUSTOMER_INVOICES+"/"+client.custAccNumber, this.httpOptions)
    .pipe(
      takeUntil(this.ngUnsubscribe$)
      );
  } */


 /*  getCustomerNbAddresses(client: any): Observable<any> {    
    let queryParams = new HttpParams()
        .set("legalPersonId", client.idLegalPerson)
    return this.http.get<ClientsTable[]>(environment.API_CUSTOMER_COUNT_ADDRESS+queryParams, this.httpOptions)
    .pipe(
      map((value) =>{
        client.nbAddresses = value;
        return client;
      }),
      catchError(error => {
        return of(client);
      }),
      takeUntil(this.ngUnsubscribe$)
      );
  } */
  /* getCustomerNbAddresses(client: any): Observable<any> {    
    let queryParams = new HttpParams()
        .set("legalPersonId", client)
    return this.http.get<ClientsTable[]>(environment.API_CUSTOMER_COUNT_ADDRESS+queryParams, this.httpOptions)
    .pipe(takeUntil(this.ngUnsubscribe$));
  } */

  getCustomerInvoices(content:any,clientIds: any): Observable<any> {
    return this.http.post<number>(environment.API_CUSTOMER_INVOICES, clientIds, this.httpOptions)
    .pipe(
      map((value: any) =>{
        content.forEach((element:any, key: any) => {  
          content[key].nbInvoices =  value[element.custAccNumber+""]?value[element.custAccNumber+""]:0;
        });
        return content;
      }),
      catchError(error => {
        return of(content);
      }),
      takeUntil(this.ngUnsubscribe$)
      );
  }

  getAllExportedClients(errors: boolean, filter: string): Observable<any> {
    let queryParams = new HttpParams()
        .set("errors", errors)
        .set("filter", filter);
    return this.http.get<any>(environment.API_CUSTOMER_EXPORT+queryParams, this.httpOptions)
    .pipe(takeUntil(this.ngUnsubscribe$));
  }


}
