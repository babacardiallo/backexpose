package fr.laposte.blg.blinks.u12.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogSynchro {
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionNumber;
    private String custAccNumber;
    private String message;
}
