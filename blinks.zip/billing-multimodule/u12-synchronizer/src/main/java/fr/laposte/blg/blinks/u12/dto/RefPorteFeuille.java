package fr.laposte.blg.blinks.u12.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "portefeuillerefcomlienposition"
})
public class RefPorteFeuille {
    private List<RefPortefeuilleRefcomLienPosition> portefeuillerefcomlienposition;
}
