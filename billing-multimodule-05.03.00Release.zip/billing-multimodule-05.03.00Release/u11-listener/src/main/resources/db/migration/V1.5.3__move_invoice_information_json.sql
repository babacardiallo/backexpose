CREATE TABLE invoice_information_message (
    id_invoice_information_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_invoice_information INT UNSIGNED default null,
    invoicing_comments_jsonarray JSON,
    invoice_information_json JSON,
    CONSTRAINT fk_invoice_information_invoice_invoice_information_message FOREIGN KEY (id_invoice_information) REFERENCES blg_contract_importer.invoice_information (id_invoice_information) ON DELETE CASCADE ON UPDATE RESTRICT
);