package fr.laposte.blg.blinks.u11.listener;

import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonMessage;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u11.listener.legalperson.LegalPersonListenerService;
import fr.laposte.blg.blinks.u11.mapper.LegalPersonListenerMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Mono;
import reactor.kafka.receiver.ReceiverRecord;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.*;


class LegalPersonListenerServiceTest {

    @InjectMocks
    private LegalPersonListenerService legalPersonListenerService;

    @Mock
    private LegalPersonService legalPersonService;

    @Mock
    private LegalPersonListenerMapper legalPersonListenerMapper;

    @Mock
    private SynchronizationSender synchronizationSender;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Mock
    private ErrorLogService errorLogService;

    @Mock
    private TransactionalOperator transactionalOperator;

    @Test
    void legalPersonNotFoundTest() {
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("28481");

        ConsumerRecord<String, LegalPerson> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", legalPerson);
        ReceiverRecord<String, LegalPerson> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        when(this.legalPersonService.findLegalPersonByCoclico(anyInt(), anyBoolean())).thenReturn(Mono.empty());

        StepVerifier.create(this.legalPersonListenerService.legalPersonUpdate(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.legalPersonService, times(1)).findLegalPersonByCoclico(anyInt(), anyBoolean());
        verify(this.legalPersonService, times(0)).save(any(LegalPersonEntity.class), anyBoolean());
    }

    @Test
    void legalPersonFoundTest() {
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("28481");
        legalPerson.setRefpmAdressId("50");

        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(2L);
        legalPersonEntity.setCustAccNumber(28481);

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setIdAddress(1L);
        addressEntity.setIdLegalPerson(2L);

        ConsumerRecord<String, LegalPerson> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", legalPerson);
        ReceiverRecord<String, LegalPerson> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        when(this.legalPersonService.findLegalPersonByCoclico(anyInt(), anyBoolean())).thenReturn(Mono.just(legalPersonEntity));
        when(this.legalPersonService.save(any(LegalPersonEntity.class), anyBoolean())).thenAnswer(i -> Mono.just(i.getArgument(0)));
        when(this.legalPersonService.saveLegalPersonMessage(any(LegalPersonEntity.class), any(LegalPersonMessage.class))).thenAnswer(i -> Mono.just(i.getArgument(0)));
        when(this.legalPersonListenerMapper.legalPersonToLegalPersonEntity(any())).thenReturn(legalPersonEntity);
        when(this.legalPersonService.findMainAddress(anyString())).thenReturn(Mono.just(addressEntity));
        when(this.legalPersonListenerMapper.legalPersonToAddressEntity(any(LegalPerson.class))).thenReturn(addressEntity);
        when(this.legalPersonService.saveMainAddress(any(AddressEntity.class))).thenReturn(Mono.just(addressEntity));
        when(this.transactionalOperator.transactional(any(Mono.class))).thenAnswer(i -> i.getArgument(0));
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        when(this.errorLogService.logError(any(ErrorLogEntity.class))).thenReturn(Mono.empty());

        StepVerifier.create(this.legalPersonListenerService.legalPersonUpdate(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.legalPersonService, times(1)).findLegalPersonByCoclico(anyInt(), anyBoolean());
        verify(this.legalPersonService, times(1)).save(any(LegalPersonEntity.class), anyBoolean());
        verify(this.legalPersonService, times(1)).saveLegalPersonMessage(any(LegalPersonEntity.class), any(LegalPersonMessage.class));
    }


    @Test
    void updateMainAddress(){
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("28481");
        legalPerson.setRefpmAdressId("50");

        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(2L);
        legalPersonEntity.setCustAccNumber(28481);

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setIdAddress(1L);
        addressEntity.setIdLegalPerson(2L);

        when(this.legalPersonService.findMainAddress(anyString())).thenReturn(Mono.just(addressEntity));
        when(this.legalPersonListenerMapper.legalPersonToAddressEntity(any(LegalPerson.class))).thenReturn(addressEntity);
        when(this.legalPersonService.saveMainAddress(any(AddressEntity.class))).thenReturn(Mono.just(addressEntity));
        Mono<LegalPersonEntity> legalPersonEntity1 = this.legalPersonListenerService.updateMainAddress(legalPerson, legalPersonEntity);
        Assertions.assertNotNull(legalPersonEntity1);
    }

    @Test
    void publishLegalPersonSyncCommandTest(){
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(2L);
        legalPersonEntity.setCustAccNumber(28481);
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        StepVerifier.create(this.legalPersonListenerService.publishLegalPersonSyncCommand(legalPersonEntity, "test_customer_topic", "cust-1"))
                .expectSubscription()
                .verifyComplete();
        verify(this.synchronizationSender, times(1)).send(any());
    }
}
