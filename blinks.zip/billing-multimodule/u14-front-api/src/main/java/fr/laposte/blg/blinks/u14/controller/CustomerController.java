package fr.laposte.blg.blinks.u14.controller;


import fr.laposte.blg.blinks.u14.controller.dto.AddressDTO;
import fr.laposte.blg.blinks.u14.controller.dto.ContractVersionSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.CustomerPartialSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.CustomerSupervisionDto;
import fr.laposte.blg.blinks.u14.service.AddressService;
import fr.laposte.blg.blinks.u14.service.CustomerService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@RestController
@CrossOrigin
@RequestMapping("/api/customer")
public class CustomerController {

    private final CustomerService service;
    private final AddressService addressService;

    public CustomerController(CustomerService service, AddressService addressService) {
        this.service = service;
        this.addressService = addressService;
    }

    @GetMapping("/all")
    @ResponseBody
    @Operation(
        summary = "Liste les clients",
        description = "Permet de récupérer tous les clients")
    Mono<Page<CustomerPartialSupervisionDto>> getAllCustomers(
            @RequestParam(defaultValue = "0") boolean errors,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "custAccNumber") String sort,
            @RequestParam(defaultValue = "desc") String order,
            @RequestParam(defaultValue = "default") String filter
    ) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "id"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        if(filter.equals("default")){
            return service.getAllCustomer(errors,pageable);
        } else {
            return service.filterCustomer(errors,pageable, filter);

        }
    }

    @GetMapping("/get-customer-partial")
    @ResponseBody
    @Operation(
        summary = "Retourne les infos principales du client identifié par son coclico",
        description = "Permet de récupérer par coclico les informations de base d'un client")
    Mono<CustomerPartialSupervisionDto> getOnePartialCustomer(@RequestParam int coclico) {
        return service.getOnePartialCustomer(coclico);
    }

    @GetMapping("/get-customer-details")
    @ResponseBody
    @Operation(
        summary = "Retourne le client identifié par son coclico",
        description = "Permet de récupérer un client et ses détails")
    Mono<CustomerSupervisionDto> getCustomerByCoclico(@RequestParam int coclico) {
        return service.getCustomerWithDetails(coclico);
    }

    @GetMapping("/address")
    @ResponseBody
    @Operation(
        summary = "Retourne les adresses d'un client identifié par son idLegalPerson",
        description = "Permet de récupérer les adresses d'un client"
    )
    Flux<AddressDTO> getAddressByCustomer(@RequestParam Long idLegalPerson) {
        return addressService.getAddress(idLegalPerson);
    }

    @GetMapping("/contract-versions")
    @ResponseBody
    @Operation(
        summary = "Retourne les contracts version d'un client identifié par son coclico",
        description = "Permet de récupérer les contract versions d'un client"
    )
    Flux<ContractVersionSupervisionDto> getContractVersionByCustomer(@RequestParam int coclico) {
        return service.getContractVersionByCustAccNumber(coclico);
    }

    @GetMapping("/export")
    @ResponseBody
    @Operation(
            summary = "export Liste des clients",
            description = "Permet d'exporter tous les clients")
    Flux<CustomerPartialSupervisionDto> export( @RequestParam(defaultValue = "0") boolean errors,
                                                @RequestParam(defaultValue = "default") String filter) {
        if(filter.equals("default")){
            return service.getAllExportedCustomer(errors);
        } else {
            return service.getAllFilteredExportedCustomers(errors, filter);

        }
    }


    @GetMapping("/list-coclico")
    @Operation(
            summary = "Récupère la liste des coclico selon une date",
            description = "Permet de récupèrer la liste des coclico selon une date")
    Flux<Integer> getListCoclicoByLastExecutionDate(@RequestParam(required = false) Instant lastExecutionDate) {
       return service.getListCoclicoByLastExecutionDate(lastExecutionDate);
    }
}
