package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.FileSequenceEntity;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface FileSequenceRepository extends ReactiveCrudRepository<FileSequenceEntity, String> {

    @Query("SELECT current_sequence FROM file_sequence WHERE sequence_name = 'EQUINOX' ")
    Mono<Long> getCurrentSequenceForEquinoxExport();

    @Modifying
    @Query("UPDATE file_sequence SET current_sequence = current_sequence + 1 WHERE sequence_name = 'EQUINOX'")
    Mono<Integer> incrementSequenceForEquinox();

    @Modifying
    @Query("UPDATE file_sequence SET current_sequence = current_sequence + 1 WHERE sequence_name = 'INFOCA'")
    Mono<Integer> incrementSequenceForInfoCA();

    @Query("SELECT current_sequence FROM file_sequence WHERE sequence_name = 'INFOCA' ")
    Mono<Long> getCurrentSequenceForInfoCAExport();

    @Query("SELECT current_sequence FROM file_sequence WHERE sequence_name = 'COPILOTMD' ")
    Mono<Long> getCurrentSequenceForCopilotMdExport();

    @Modifying
    @Query("UPDATE file_sequence SET current_sequence = :actualSequence WHERE sequence_name = 'COPILOTMD'")
    Mono<Integer> incrementSequenceForCopilotMdExport(Integer actualSequence);

}
