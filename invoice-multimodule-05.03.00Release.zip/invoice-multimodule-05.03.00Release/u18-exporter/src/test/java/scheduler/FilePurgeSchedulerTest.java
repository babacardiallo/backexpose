package scheduler;



import fr.laposte.blg.blinks.u18.scheduler.FilePurgeScheduler;
import fr.laposte.blg.blinks.u18.service.impl.FilePurgeServiceImpl;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FilePurgeSchedulerTest {

    @Mock
    private FilePurgeServiceImpl filePurgeService;

    @Test
    void purgeRunTest(){
        SchedulerParamsEntity updatedParams = new SchedulerParamsEntity();
        updatedParams.setIsEnabled(true);
        updatedParams.setSchedulerName("scheduler_file_purge");
        updatedParams.setRetentionDays(1);
        FilePurgeScheduler filePurgeScheduler = new FilePurgeScheduler(filePurgeService, updatedParams);
        when(filePurgeService.purgeFilesOlderThan(anyString(),any(Instant.class))).thenReturn(1);
        filePurgeScheduler.run();
    }
}
