package fr.laposte.blg.blinks.u12.config.kafka;

import io.confluent.kafka.streams.serdes.avro.SpecificAvroDeserializer;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.specific.SpecificRecord;
import org.apache.kafka.common.errors.SerializationException;

@Slf4j
public class KafkaDeserializer extends SpecificAvroDeserializer {
    @Override
    public SpecificRecord deserialize(String topic, byte[] bytes) {
        try {
            return super.deserialize(topic, bytes);
        } catch (SerializationException e) {
            log.error("Error during deserialization.", e);
            return null;
        }
    }
}
