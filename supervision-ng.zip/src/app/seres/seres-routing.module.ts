import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { SeresComponent } from './seres.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: SeresComponent }
        ])],
    exports: [RouterModule]
})
export class SeresRoutingModule { }
