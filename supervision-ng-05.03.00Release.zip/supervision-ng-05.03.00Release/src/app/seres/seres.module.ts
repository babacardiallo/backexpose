import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CdkStepperModule } from "@angular/cdk/stepper";
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { NgxPermissionsModule } from 'ngx-permissions';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { SeresRoutingModule } from './seres-routing.module';
import { SeresComponent } from './seres.component';
import { SeresTableComponent } from './components/seres-table.component';
import { SeresDetailsPopUpComponent } from './components/seres-details-pop-up/seres-details-pop-up.component';
import { ModalService } from 'ngx-modal-ease';

@NgModule({
    imports: [
        SharedModule,
        NgxDatatableModule,
        MatStepperModule,
        CdkStepperModule,
        MatSnackBarModule,
        MatGridListModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        NgxPermissionsModule.forChild(),
        SeresRoutingModule,
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        FormsModule,
        ReactiveFormsModule,
        MatSelectModule,
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [SeresComponent, SeresTableComponent, SeresDetailsPopUpComponent],
    exports: [SeresComponent]
})
export class SeresModule { }
