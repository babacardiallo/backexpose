package fr.laposte.blg.blinks.lib.common.service;


import fr.laposte.blg.blinks.lib.common.entities.QueueMigrationEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.QueueMigrationRepository;
import fr.laposte.bscc.billing.avro.ActionEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class QueuMigrationServiceTest {

    @InjectMocks
    private QueueMigrationService queueMigrationService;

    @Mock
    private QueueMigrationRepository queueMigrationRepository;

    @Test
    void findQueueMigrationToMigrateByOfferTest(){
        Mockito.when(queueMigrationRepository.findQueueMigrationEligible())
                .thenReturn(Flux.just(QueueMigrationEntity.builder().idQueue(1L).action(ActionEnum.create).offerOpsCode("3263").idContract(19928L).build()));
        StepVerifier.create(queueMigrationService.findQueueMigrationToMigrateByOffer())
                .assertNext(queueMigrationEntity -> {
                    assertEquals(1L, queueMigrationEntity.getIdQueue());
                    assertEquals("3263", queueMigrationEntity.getOfferOpsCode());
                })
                .verifyComplete();

    }

    @Test
    void findQueueMigrationByIdContract(){
        Mockito.when(queueMigrationRepository.findQueueMigrationEntityByIdContract(Mockito.anyLong()))
                .thenReturn(Mono.just(QueueMigrationEntity.builder().idQueue(1L).action(ActionEnum.create).offerOpsCode("3263").idContract(19928L).build()));
        StepVerifier.create(queueMigrationService.findQueueMigrationByIdContract(1L))
                .assertNext(queueMigrationEntity -> {
                    assertEquals(1L, queueMigrationEntity.getIdQueue());
                    assertEquals("3263", queueMigrationEntity.getOfferOpsCode());
                })
                .verifyComplete();
    }

    @Test
    void enQueueContractTest(){
        Mockito.when(queueMigrationRepository.findQueueMigrationEntityByIdContract(Mockito.anyLong()))
                .thenReturn(Mono.just(QueueMigrationEntity.builder().idQueue(1L).action(ActionEnum.create).offerOpsCode("3263").idContract(19928L).build()));
        Mockito.when(queueMigrationRepository.save(any(QueueMigrationEntity.class)))
                .thenAnswer(args -> Mono.just(args.getArgument(0)));
        StepVerifier.create(queueMigrationService.enQueueContract(1L, ActionEnum.update, "0001"))
                .assertNext(queueMigrationEntity -> {
                    assertEquals(1L, queueMigrationEntity.getIdQueue());
                    assertEquals("0001", queueMigrationEntity.getOfferOpsCode());
                    assertEquals(ActionEnum.update, queueMigrationEntity.getAction());
                })
                .verifyComplete();
    }

}
