export class EdrPage{
    currentPage?: number;
    itemsOnPage?: number;
    currentOffset?: number;
    totalPages?: number;
    totalItems?: number;
}