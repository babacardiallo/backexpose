package fr.laposte.blg.blinks.u10.repositories;

import fr.laposte.blg.blinks.u10.entities.Event;
import fr.laposte.blg.blinks.u10.entities.EventWithId;
import jakarta.annotation.Nullable;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@CrossOrigin
@RepositoryRestResource(collectionResourceRel = "events", path = "events")
@Primary
public interface EventRepository extends JpaRepository<Event, UUID> {
    // Désactivation des méthodes de création et suppression
    @Override
    @RestResource(exported = false)
    void deleteById(@Nullable UUID id);
    @Override
    @RestResource(exported = false)
    void delete(Event entity);
    @Override
    @RestResource(exported = false)
    void deleteAll(Iterable<? extends Event> entities);
    @RestResource()
    EventWithId findAllById(UUID id);
    @RestResource(path = "findByErrorDateBetween", rel = "findByErrorDateBetween")
    List<Event> findByErrorDateBetween(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate);

    @Query("""
            SELECT evt FROM Event evt WHERE
             (evt.errorDate BETWEEN :startDate AND :endDate)
             AND (evt.replayStatus IN ('PENDING','FAILED'))
             AND (evt.replayStatus = :status OR :status IS NULL OR :status='')
             AND evt.errorCode <> 'U2007'
             AND (evt.errorCode IN :errors OR :errors IS NULL)
             AND (evt.errorCode LIKE CONCAT('%',:filter,'%')
             OR evt.errorMessage LIKE CONCAT('%',:filter,'%')
             OR CAST(evt.id AS text) LIKE CONCAT('%',:filter,'%')
             OR evt.contractCode LIKE CONCAT('%',:filter,'%')
             OR evt.custAccNumber LIKE CONCAT('%',:filter,'%')
             OR evt.offerCode LIKE CONCAT('%',:filter,'%')
             OR evt.productCode LIKE CONCAT('%',:filter,'%')
             OR :filter IS NULL
             OR :filter='')""")
    Page<Event> getAllByDateAndStatus(@Param("startDate") Instant startDate, @Param("endDate")Instant endDate, @Param("filter")String filter, @Param("status") String status, @Param("errors") String[] errors, @Param("pageable") Pageable pageable);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("UPDATE Event evt set evt.replayStatus='PENDING' where evt.id = :id")
    int updateEventStatusById (@Param("id") UUID id);

    @Query("SELECT evt FROM Event evt WHERE (CAST(evt.id AS text)) IN (SELECT MIN(CAST(evtS.id AS text)) FROM Event evtS GROUP BY evtS.errorCode) AND evt.errorCode <>'U2007'")
    List<Event> getAllCodeError();


    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("""
            UPDATE Event evt SET evt.replayStatus='PENDING' WHERE
            (evt.errorDate BETWEEN :startDate AND :endDate)
             AND (evt.replayStatus = :status OR :status IS NULL OR :status='')
             AND (evt.errorCode IN :errors OR :errors IS NULL)
             AND (evt.errorCode LIKE CONCAT('%',:filter,'%') OR evt.errorMessage LIKE CONCAT('%',:filter,'%') OR CAST(evt.id AS text) LIKE CONCAT('%',:filter,'%') OR :filter IS NULL OR :filter='')""")
    int updateFilteredEvent (@Param("startDate") Instant startDate, @Param("endDate")Instant endDate, @Param("filter") String filter, @Param("status") String status, @Param("errors") String[] errors);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("UPDATE Event evt set evt.replayStatus='PENDING' where evt.id IN :ids")
    int updateSelectedEvents (@Param("ids") String[] ids);


    @Query("""
            SELECT evt FROM Event evt WHERE
             (evt.errorDate BETWEEN :startDate AND :endDate)
             AND (evt.replayStatus IN ('PENDING','FAILED'))
             AND (evt.replayStatus = :status OR :status IS NULL OR :status='')
             AND (evt.errorCode IN :errors OR :errors IS NULL)
             AND (evt.errorCode LIKE CONCAT('%',:filter,'%') OR evt.errorMessage LIKE CONCAT('%',:filter,'%') OR CAST(evt.id AS text) LIKE CONCAT('%',:filter,'%') OR :filter IS NULL OR :filter='')
             ORDER BY evt.errorDate desc""")
    List<Event> getExportedEvents (@Param("startDate") Instant startDate, @Param("endDate")Instant endDate, @Param("filter") String filter, @Param("status") String status, @Param("errors") String[] errors);
}
