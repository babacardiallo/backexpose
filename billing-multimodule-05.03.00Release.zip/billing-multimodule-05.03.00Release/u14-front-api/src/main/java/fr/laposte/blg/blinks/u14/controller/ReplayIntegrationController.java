package fr.laposte.blg.blinks.u14.controller;

import fr.laposte.blg.blinks.u14.service.ReplayerIntegrationService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/replayer-integration")
@Validated
@Slf4j
@OpenAPIDefinition(tags = {@Tag(name = "Replayer Integration Controller")}, info = @Info(description = "Permet de forcer la resynchronisation d'un contrat"))
public class ReplayIntegrationController {

    private final ReplayerIntegrationService replayerIntegrationService;

    @PostMapping(value = "/by-contracts")
    @Operation(
            summary = "Rejeu d'intégration d'un ou plusieurs contrat",
            description = "Service de rejeu d'intégration de contrats")
    public Mono<String> replayByContracts(@RequestBody List<String> contractNumbers) {
        return replayerIntegrationService.replayContractIntegrationInError(contractNumbers);
    }

    @PostMapping(value = "/all")
    @Operation(
            summary = "Rejeu d'intégration de tous les contrats en rejets d'intégration",
            description = "Service de rejeu d'intégration de contrats")
    public Mono<String> replayAll() {
        return replayerIntegrationService.replayAllContractIntegrationInError();
    }


}
