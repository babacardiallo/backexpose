# Scripts use to initialize databases by Docker
# create databases
CREATE DATABASE IF NOT EXISTS `blg_invoice`;

# create root user and grant rights

CREATE USER 'blg'@'localhost' IDENTIFIED BY 'root';
CREATE USER 'blg'@'%' IDENTIFIED BY 'root';
GRANT ALL ON `blg_invoice`.* TO 'blg'@'localhost';
GRANT ALL ON `blg_invoice`.* TO 'blg'@'%';


