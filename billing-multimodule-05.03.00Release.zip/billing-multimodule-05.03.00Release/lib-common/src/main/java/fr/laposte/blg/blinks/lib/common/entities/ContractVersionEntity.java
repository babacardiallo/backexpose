package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("contract_version")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Accessors(chain = true)
public class ContractVersionEntity {
    @Id
    @Column("id_contract_version")
    private Long idContractVersion;
    @Column("amendment_number")
    @NotNull
    @PositiveOrZero
    private Integer amendmentNumber;
    @Column("revision_number")
    @NotNull
    private Integer revisionNumber;
    @Column("validity_start_datetime")
    @NotNull
    @Past
    private Instant validityStartDatetime;
    @Column("validity_end_datetime")
    private Instant validityEndDatetime;
    @Column("status")
    @NotNull
    private ContractStatusEnum status;
    @Column("substatus")
    @NotNull
    private ContractSubStatusEnum substatus;
    @Column("termination_datetime")
    private Instant terminationDatetime;
    @Column("termination_reason")
    private String terminationReason;
    @Column("term")
    private String term;
    @Column("category")
    @NotNull
    private String category;
    @Column("parent_contract_number")
    private String parentContractNumber;
    @Column("parent_amendment_number")
    private Integer parentAmendmentNumber;
    @Column("is_synchronized")
    private boolean isSynchronized = false;
    @Column("date_synchronization")
    private Instant dateSynchronization;
    @Column("is_purged")
    private Boolean isPurged;

    @Column("id_contract")
    private Long idContract;
    @Transient
    @Valid
    private ContractEntity contract;

    @Column("id_invoice_information")
    private Long idInvoiceInformation;
    @Transient
    private InvoiceInformationEntity invoiceInformationEntity;

    @Column("id_valued_offer")
    private Long idValuedOffer;
    @Transient
    private ValuedOfferEntity valuedOffer;
    @Column("offset_num")
    private String offset;
    @Column("partition_num")
    private String partition;
    @Column("previous_date_synchronization")
    private Instant previousDateSynchronization;
    @Column("offset_num_consolidated")
    private Long offsetNumConsolidated;
    @Column("partition_num_consolidated")
    private Integer partitionNumConsolidated;

}
