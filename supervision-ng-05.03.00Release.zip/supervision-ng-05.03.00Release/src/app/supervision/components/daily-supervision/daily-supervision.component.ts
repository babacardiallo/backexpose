import { AfterViewInit, ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { formatDate } from "@angular/common";
import { CalendarView } from 'angular-calendar';
import { NguCarousel, NguCarouselConfig } from '@ngu/carousel';
import { Subject } from 'rxjs';
import { SupervisionTable } from '../../models/supervision-table.model';
import { Treatment } from '../../models/supervision.enum';
import { SupervisionService } from '../../service/supervision.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'daily-supervision',
  templateUrl: './daily-supervision.component.html',
  styleUrls: ['./daily-supervision.component.scss',],
  standalone: false
})
export class DailySupervisionComponent implements OnInit, AfterViewInit {

  @Input() selected!: Date;
  exportList: SupervisionTable[] = [];
  treatment = Treatment;
  expandedIndex = 0;
  kibana = "#";
  color = 'yellow';
  public carouselConfig: NguCarouselConfig = {
    grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
    slide: 3,
    speed: 250,
    point: {
      visible: true
    },
    touch: true,
    interval: { timing: 4000, initialDelay: 1000 },
  };

  currentCoeurfinanceIndex = 0;
  currentEquinoxIndex = 0;
  currentInfocaIndex = 0;
  currentDocaposteindex = 0;
  coeurfinanceList: SupervisionTable[] = [];
  equinoxList: SupervisionTable[] = [];
  infocaList: SupervisionTable[] = [];
  docaposteList: SupervisionTable[] = [];
  expandedAccordionCoeurfinance: boolean = false;
  expandedAccordionEquinox: boolean = false;
  expandedAccordionInfoca: boolean = false;
  expandedAccordionDocaposte: boolean = false;
  refresh = new Subject<void>();

  @ViewChild('myCarouselCoeurfinance') myCarouselCoeurfinance: NguCarousel<any>;

  @ViewChild('myCarouselEquinox') myCarouselEquinox: NguCarousel<any>;

  @ViewChild('myCarouselInfoca') myCarouselInfoca: NguCarousel<any>;

  @ViewChild('myCarouselDoca') myCarouselDoca: NguCarousel<any>;

  constructor(private supervisionService: SupervisionService, private cdr: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    this.getDalilyListTreatment();
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  formatDate(date: Date): string {
    const format = 'dd/MM/yyyy';
    const locale = "fr-FR";
    return formatDate(date, format, locale);
  }

  formatDatetoApi(date: Date): string {
    const format = 'yyyy-MM-dd';
    const locale = "fr-FR";
    return formatDate(date, format, locale);
  }

  buildKibanaLinks(event: any, exportId: number) {
    event.preventDefault();
    const url: string = environment.URL_KIBANA;
    const query = 'exportId%20:%20' + exportId;
    const finalUrl = url.replace('exportId%20:%201508', query);
    window.open(finalUrl, '_blank');
  }


  refreshView(): void {
    this.refresh.next();
  }


  moveToNextCoeurfinanceExport() {
    if (this.currentCoeurfinanceIndex != this.coeurfinanceList.length - 1) {
      this.myCarouselCoeurfinance.moveTo(this.currentCoeurfinanceIndex + 1);
      this.currentCoeurfinanceIndex++;
    }
  }

  moveToPreviousCoeurfinanceExport() {
    if (this.currentCoeurfinanceIndex != 0) {
      this.myCarouselCoeurfinance.moveTo(this.currentCoeurfinanceIndex - 1);
      this.currentCoeurfinanceIndex--;
    }
  }

  moveToNextEquinoxExport() {
    if (this.currentEquinoxIndex != this.equinoxList.length - 1) {
      this.myCarouselEquinox.moveTo(this.currentEquinoxIndex + 1);
      this.currentEquinoxIndex++;
    }
  }

  moveToPreviousEquinoxExport() {
    if (this.currentEquinoxIndex != 0) {
      this.myCarouselEquinox.moveTo(this.currentEquinoxIndex - 1);
      this.currentEquinoxIndex--;
    }
  }


  moveToNextInfocaExport() {
    if (this.currentInfocaIndex != this.infocaList.length - 1) {
      this.myCarouselInfoca.moveTo(this.currentInfocaIndex + 1);
      this.currentInfocaIndex++;
    }
  }

  moveToPreviousInfocaExport() {
    if (this.currentInfocaIndex != 0) {
      this.myCarouselInfoca.moveTo(this.currentInfocaIndex - 1);
      this.currentInfocaIndex--;
    }
  }

  moveToNextDocaExport() {
    if (this.currentDocaposteindex != this.docaposteList.length - 1) {
      this.myCarouselDoca.moveTo(this.currentDocaposteindex + 1);
      this.currentDocaposteindex++;
    }
  }

  moveToPreviousDocaExport() {
    if (this.currentDocaposteindex != 0) {
      this.myCarouselDoca.moveTo(this.currentDocaposteindex - 1);
      this.currentDocaposteindex--;
    }
  }

  getDalilyListTreatment(date?: Date) {
    if (date) {
      this.selected = date;
    }
    this.coeurfinanceList = [];
    this.equinoxList = [];
    this.infocaList = [];
    this.docaposteList = [];
    this.currentCoeurfinanceIndex = 0;
    this.currentEquinoxIndex = 0;
    this.currentInfocaIndex = 0;
    this.currentDocaposteindex = 0;
    this.supervisionService.getDailyListTreatment(this.formatDatetoApi(this.selected))
      .pipe().subscribe(response => {
        this.coeurfinanceList = response.COEURFINANCE;
        this.equinoxList = response.EQUINOX;
        this.infocaList = response.INFOCA;
        const docaWithOutAvispaiement = response.DOCAPOSTE;
        const docaWithAvisPaiement = response.DOCAPOSTE_AVIS_PAIEMENT
        this.docaposteList = [...docaWithOutAvispaiement, ...docaWithAvisPaiement];
      });
  }

  openCoeurfinanceAcccordion() {
    this.expandedAccordionCoeurfinance = true;
  }

  closeCoeurfinanceAcccordion() {
    this.expandedAccordionCoeurfinance = false;
  }

  openEquinoxAcccordion() {
    this.expandedAccordionEquinox = true;
  }

  closeEquinoxAcccordion() {
    this.expandedAccordionEquinox = false;
  }

  openInfocaAcccordion() {
    this.expandedAccordionInfoca = true;
  }

  closeInfocaAcccordion() {
    this.expandedAccordionInfoca = false;
  }

  openDocaposteAcccordion() {
    this.expandedAccordionDocaposte = true;
  }

  closeDocaposteAcccordion() {
    this.expandedAccordionDocaposte = false;
  }

  getDocapoteExcludedInvoicesTooltip(value: any) {
    if (value.type == 'DOCAPOSTE_AVIS_PAIEMENT') {
      return "Objets exclus du fichier pour raison fonctionnelle : objets sans édition papier ou du périmètre efact ou dont le pdf a été généré directement par Opencell (exemple : Elections) ou ne sont pas des avis de paiement";
    }
    return "Objets exclus du fichier pour raison fonctionnelle : objets sans édition papier ou du périmètre efact ou dont le pdf a été généré directement par Opencell (exemple : Elections) ou sont des avis de paiement";
  }



}
