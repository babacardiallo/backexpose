package fr.laposte.blg.blinks.u16.service;

import fr.laposte.bscc.avro.invoicing.Invoice;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@Profile("mar-sdev|mar-srec|sloc")
public class KafkaTestInvoiceProducer {

    @Value("${fr.laposte.invoice.listener.test.canal-suez.kafka-topic}")
    String topic;
    @Autowired
    private KafkaTemplate<String, Invoice> kafkaTemplate;

    public void sendInvoiceToTopic(Invoice invoice) {
        this.kafkaTemplate.send(topic, invoice.getInvoiceHeader().getInvoiceNumber().toString(), invoice);
    }
}
