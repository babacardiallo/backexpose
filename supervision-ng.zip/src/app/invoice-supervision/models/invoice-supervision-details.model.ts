export class InvoiceSupervisionDetailsModel {
    isCredit?: boolean;
    isRefundable?: boolean;
    isDownpayment?: boolean;
    isStatement?: boolean;
    isOpencellPdf?: boolean;
    isDedicated?: boolean;
    support?: string;
    printFlag?: boolean;
    htAmount?: number;
    amount?: number;
    equinoxFileName?: string;
    docaposteFileName?: string;
    infocaFileName?: string;
    equinoxTransferDate?: string;
    docaposteTransferDate?: string;
    infocaTransferDate?: string;
    equinoxTransferStatus?: string;
    docaposteTransferStatus?: string;
    infocaTransferStatus?: string;
    invoiceJson?: JSON;
    mappingError?: string | null;
    type?: string;
}
