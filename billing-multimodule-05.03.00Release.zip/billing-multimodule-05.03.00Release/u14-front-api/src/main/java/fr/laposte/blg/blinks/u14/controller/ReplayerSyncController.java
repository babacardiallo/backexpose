package fr.laposte.blg.blinks.u14.controller;

import fr.laposte.blg.blinks.u14.controller.dto.ReplayOfferReportDto;
import fr.laposte.blg.blinks.u14.controller.dto.ReplayReportDto;
import fr.laposte.blg.blinks.u14.controller.dto.ReplayTotalDto;
import fr.laposte.blg.blinks.u14.service.ReplayerSyncService;
import fr.laposte.bscc.billing.avro.ActionEnum;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.checkerframework.common.value.qual.EnumVal;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;


/**
 * Exemple de controller.
 */
@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/replayer")
@Validated
@Slf4j
@OpenAPIDefinition(tags = {@Tag(name = "Replayer Controller")}, info = @Info(description = "Permet de forcer la resynchronisation d'un contrat"))
public class ReplayerSyncController {

    private final ReplayerSyncService service;

    private final AtomicBoolean isRunningReplayAll = new AtomicBoolean(false);

    @PostMapping(value = "/replay-contract")
//    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Rejeu de synchro d'un contrat",
            description = "Service de rejeu de contrat")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ResponseEntity<String>> replaySyncForOneContract(
            @RequestParam("contract-number") String contractNumber
            , @RequestParam(value = "date-synchronization-expected", required = false)
            //Si nulle, now
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected
            , @EnumVal({"create", "update"}) @RequestParam(value = "action") ActionEnum actionEnum) {
        Instant dateMigrationInstant = Instant.now();
        if (Objects.nonNull(dateSynchronizationExpected)) {
            dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
        }
        return service.replayContractSynchronization(contractNumber, dateMigrationInstant, actionEnum)

                .map(s -> new ResponseEntity<>(s + "versions was successfully replayed", HttpStatus.OK));
    }

    @PostMapping(value = "/replay-contracts")
//    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Rejeu de synchro d'un ou plusieurs contrat",
            description = "Service de rejeu de contrats")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ReplayReportDto> replaySyncForContracts(
            @RequestBody List<String> contractNumbers
            , @RequestParam(value = "date-synchronization-expected", required = false)
            //Si nulle, now
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected
            , @EnumVal({"create", "update"}) @RequestParam(value = "action") ActionEnum actionEnum) {
        Instant dateMigrationInstant = Instant.now();
        if (Objects.nonNull(dateSynchronizationExpected)) {
            dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
        }
        Instant finalDateMigrationInstant = dateMigrationInstant;
        ReplayReportDto reportDto = new ReplayReportDto();
        reportDto.setNbTotal(contractNumbers.size());
        log.debug("Liste des contrats {}", contractNumbers);
        if (contractNumbers.size() <= 100) {
            reportDto.setWaitingResponse(true);
            return service.replayListOfContracts(contractNumbers, finalDateMigrationInstant, actionEnum, reportDto);
        } else {
            isRunningReplayAll.set(true);
            reportDto.setWaitingResponse(false);
            reportDto.setShortMessage("Démarrage du rejeu des contrats");
            return Mono.just(reportDto)
                    .doOnNext(process -> service.replayListOfContracts(contractNumbers, finalDateMigrationInstant, actionEnum, reportDto)
                            .subscribeOn(Schedulers.boundedElastic())
                            .elapsed()
                            .doOnNext(replayReportDto -> {
                                log.info("[Fin de relance des contrats], temps écoulé : {} ms, rapport : {}"
                                        , replayReportDto.getT1()
                                        , replayReportDto.getT2());
                                isRunningReplayAll.set(false);
                            })
                            .subscribe());
        }
    }

    @PostMapping(value = "/replay-all-contracts-synchronized")
    @Operation(
            summary = "Rejeu de synchro dde tous les contrats déjà synchronisés",
            description = "Service de rejeu de contrats synchronisés")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ReplayTotalDto> replaySyncForAllContractsAlreadySynced(
            @RequestParam(value = "date-synchronization-expected", required = false)
            //Si nulle, now
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected
            , @EnumVal({"create", "update"}) @RequestParam(value = "action") ActionEnum actionEnum) {
        if (!isRunningReplayAll.get()) {
            log.info("[Début de relance total des contrats déjà synchronisés]");
            isRunningReplayAll.set(true);
            Instant dateMigrationInstant = Instant.now();
            if (Objects.nonNull(dateSynchronizationExpected)) {
                dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
            }
            Instant finalDate = dateMigrationInstant;

            return Mono.just(new ReplayTotalDto("Démarrage du rejeu total des contrats déjà synchronisés"))
                    .doOnNext(process -> service.replayAllContractSynchronization(finalDate, actionEnum)
                            .subscribeOn(Schedulers.boundedElastic())
                            .elapsed()
                            .doOnNext(replayReportDto -> {
                                log.info("[Fin de relance total des contrats déjà synchronisés], temps écoulé : {} ms, rapport : {}"
                                        , replayReportDto.getT1()
                                        , replayReportDto.getT2());
                                isRunningReplayAll.set(false);
                            })
                            .subscribe());

        } else {
            log.info("A replay task is currently running. Please wait for process to finish");
            return Mono.empty();
        }
    }

    @PostMapping(value = "/replay-legal-persons")
//    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Rejeu de synchro d'un ou plusieurs clients",
            description = "Service de rejeu de clients")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ReplayReportDto> replaySyncForLegalPersons(
            @RequestBody List<Integer> coclicos
            , @RequestParam(value = "date-synchronization-expected", required = false)
            //Si nulle, now
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected,
            @RequestParam(value = "refcom-replay", required = false, defaultValue = "false")
            boolean refcomReplay
    ) {
        Instant dateMigrationInstant = Instant.now();
        if (Objects.nonNull(dateSynchronizationExpected)) {
            dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
        }
        Instant finalDateMigrationInstant = dateMigrationInstant;
        ReplayReportDto reportDto = new ReplayReportDto();
        reportDto.setNbTotal(coclicos.size());
        log.debug("Liste des coclicos {}", coclicos);
        if (coclicos.size() <= 100) {
            reportDto.setWaitingResponse(true);
            return service.replayListOfCustomer(coclicos, finalDateMigrationInstant, refcomReplay, reportDto);
        } else {
            isRunningReplayAll.set(true);
            reportDto.setWaitingResponse(false);
            reportDto.setShortMessage("Démarrage du rejeu des clients");
            return Mono.just(reportDto)
                    .doOnNext(process -> service.replayListOfCustomer(coclicos, finalDateMigrationInstant, refcomReplay, reportDto)
                            .subscribeOn(Schedulers.boundedElastic())
                            .elapsed()
                            .doOnNext(replayReportDto -> {
                                log.info("[Fin de relance des clients], temps écoulé : {} ms, rapport : {}"
                                        , replayReportDto.getT1()
                                        , replayReportDto.getT2());
                                isRunningReplayAll.set(false);
                            })
                            .subscribe());
        }

    }

    @PostMapping(value = "/replay-legal-persons-all")
    @Operation(
            summary = "Rejeu de tous les clients déjà synchronisés",
            description = "Service de rejeu des clients")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ReplayTotalDto> replaySyncAllLegalPersons(
            @RequestParam(value = "date-synchronization-expected", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected,
            @RequestParam(value = "refcom-replay", required = false, defaultValue = "false")
            boolean refcomReplay
    ) {
        if (!isRunningReplayAll.get()) {
            log.info("[Début de relance total des clients]");
            isRunningReplayAll.set(true);
            Instant dateMigrationInstant = Instant.now();
            if (Objects.nonNull(dateSynchronizationExpected)) {
                dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
            }
            Instant finalDateMigrationInstant = dateMigrationInstant;
            return Mono.just(new ReplayTotalDto("Démarrage du rejeu total des clients"))
                    .doOnNext(process -> service.replayAllClientsSynchronization(finalDateMigrationInstant, refcomReplay)
                            .subscribeOn(Schedulers.boundedElastic())
                            .elapsed()
                            .doOnNext(replayReportDto -> {
                                log.info("[Fin de relance total des clients], temps écoulé : {} ms, rapport : {}"
                                        , replayReportDto.getT1()
                                        , replayReportDto.getT2());
                                isRunningReplayAll.set(false);
                            })
                            .subscribe());


        } else {
            log.info("A replay task is currently running. Please wait for process to finish");
            return Mono.just(new ReplayTotalDto("Un rejeu est déjà encours d'execution"));
        }
    }

    @PostMapping(value = "/replay-all-contracts-by-offer")
    @Operation(
            summary = "Rejeu de synchro de tous les contrats par offre",
            description = "Service de rejeu de contrats synchronisés")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ReplayOfferReportDto> replaySyncForAllContractsAlreadySyncedByOffer(
            @RequestBody List<String> listOffers,
            @RequestParam(value = "date-synchronization-expected", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected
            , @EnumVal({"create", "update"}) @RequestParam(value = "action") ActionEnum actionEnum) {
        if (!isRunningReplayAll.get()) {
            isRunningReplayAll.set(true);
            Instant dateMigrationInstant = Instant.now();
            if (Objects.nonNull(dateSynchronizationExpected)) {
                dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
            }
            ReplayOfferReportDto report = new ReplayOfferReportDto();
            report.setWaitingResponse(false);
            report.setShortMessage("Démarrage du rejeu par offre");
            Instant finalDate = dateMigrationInstant;
            return Mono.just(report)
                    .doOnNext(process -> service.replayContractSynchronizationByOffer(actionEnum, finalDate, listOffers, report)
                            .subscribeOn(Schedulers.boundedElastic())
                            .elapsed()
                            .doOnNext(replayReportDto -> {
                                log.info("[Fin de relance de la synchronisation par offre], temps écoulé : {} ms, rapport : {}"
                                        , replayReportDto.getT1()
                                        , replayReportDto.getT2());
                                isRunningReplayAll.set(false);
                            })
                            .subscribe());
        } else {
            log.info("A replay task is currently running. Please wait for process to finish");
            return Mono.empty();
        }
    }


    @PostMapping(value = "/replay-all-contracts")
    @Operation(
            summary = "Rejeu de synchro de tous les contrats",
            description = "Service de rejeu de tous les contrats")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Succès"),
            @ApiResponse(responseCode = "500", description = "Erreur", content = @Content)
    })
    public Mono<ReplayTotalDto> replaySyncForAllContracts(
            @RequestParam(value = "date-synchronization-expected", required = false)
            //Si nulle, now
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime dateSynchronizationExpected
            , @EnumVal({"create", "update"}) @RequestParam(value = "action") ActionEnum actionEnum) {
        if (!isRunningReplayAll.get()) {
            log.info("[Début de relance total des contrats]");
            isRunningReplayAll.set(true);
            Instant dateMigrationInstant = Instant.now();
            if (Objects.nonNull(dateSynchronizationExpected)) {
                dateMigrationInstant = dateSynchronizationExpected.toInstant(ZoneId.of("Europe/Paris").getRules().getOffset(dateSynchronizationExpected));
            }
            Instant finalDate = dateMigrationInstant;

            return Mono.just(new ReplayTotalDto("Démarrage du rejeu total des contrats"))
                    .doOnNext(process -> service.replayAllContracts(finalDate, actionEnum)
                            .subscribeOn(Schedulers.boundedElastic())
                            .elapsed()
                            .doOnNext(replayReportDto -> {
                                log.info("[Fin de relance total des contrats], temps écoulé : {} ms, rapport : {}"
                                        , replayReportDto.getT1()
                                        , replayReportDto.getT2());
                                isRunningReplayAll.set(false);
                            })
                            .subscribe());

        } else {
            log.info("A replay task is currently running. Please wait for process to finish");
            return Mono.empty();
        }
    }

}
