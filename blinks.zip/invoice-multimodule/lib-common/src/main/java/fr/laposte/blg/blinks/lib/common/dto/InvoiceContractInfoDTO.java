package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Setter
@Getter
@JsonPropertyOrder({
        "contractNumber",
        "contractVersionValidityStartDateTime",
        "contractVersionValidityEndDateTime",
        "contractParentContractNumber",
        "contractType",
        "contractSubType",
        "OpsCode",
        "custContractualAgreementReference",
        "creationChannel",
        "sellerSector",
        "comment",
        "stampingDeviceNumber",
        "categoryLabel",
        "categoryCode",
        "repaymentTypeCode",
        "repaymentTypeLabel",
        "inactivationDate",
        "invoiceModeCode",
        "invoiceModeLabel",
        "custInvoiceTermId",
        "excludingDiscountAndTaxAmount",
        "excludingTaxTotalAmount",
        "totalAmount",
        "contract1108FormInfo"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class InvoiceContractInfoDTO {
    String contractNumber;
    Instant contractVersionValidityStartDateTime;
    Instant contractVersionValidityEndDateTime;
    String contractParentContractNumber;
    String contractType;
    String contractSubType;
    @JsonProperty("OpsCode")
    String opsCode;
    String custContractualAgreementReference;
    String creationChannel;
    String sellerSector;
    String comment;
    String stampingDeviceNumber;
    String categoryLabel;
    String categoryCode;
    String repaymentTypeCode;
    String repaymentTypeLabel;
    Instant inactivationDate;
    String invoiceModeCode;
    String invoiceModeLabel;
    String custInvoiceTermId;
    Double excludingTaxTotalAmount;
    Double totalAmount;
    Double excludingDiscountAndTaxAmount;
    Contract1108FormInfoDTO contract1108FormInfo;
}
