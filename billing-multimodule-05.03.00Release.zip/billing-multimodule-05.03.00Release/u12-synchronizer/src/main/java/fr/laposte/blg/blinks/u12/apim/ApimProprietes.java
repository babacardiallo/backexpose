package fr.laposte.blg.blinks.u12.apim;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Data
@ConfigurationProperties(prefix = "fr.laposte.apim")
public class ApimProprietes {
    private String host;
    private String hostVente;
    private String clientId;
    private String clientSecret;
}
