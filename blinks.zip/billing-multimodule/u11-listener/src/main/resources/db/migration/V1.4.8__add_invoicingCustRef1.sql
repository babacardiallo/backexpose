ALTER TABLE invoice_information
    ADD COLUMN invoicing_cust_ref1 varchar(255);