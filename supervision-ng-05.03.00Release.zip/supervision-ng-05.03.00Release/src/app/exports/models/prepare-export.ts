export class PrepareExport {
    invoices : Array<string> =[];
    exportChoices : Array<string>=[]
}
  