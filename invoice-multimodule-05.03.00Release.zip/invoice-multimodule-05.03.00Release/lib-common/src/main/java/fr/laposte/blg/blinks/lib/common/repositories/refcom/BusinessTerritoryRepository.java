package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessTerritoryHierarchy;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessTerritoryRepository extends ReactiveCrudRepository<BusinessTerritoryHierarchy, Long> {

    Mono<BusinessTerritoryHierarchy> findByBusinessTerritoryId(Long businessTerritoryId);

}
