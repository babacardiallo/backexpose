ALTER TABLE export_history
    MODIFY COLUMN message_count INT NOT NULL DEFAULT 0,
    MODIFY COLUMN nb_invoices_exported_in_file INT NOT NULL DEFAULT 0,
    MODIFY COLUMN nb_normal_invoices INT NOT NULL DEFAULT 0,
    MODIFY COLUMN nb_acomptes INT NOT NULL DEFAULT 0,
    MODIFY COLUMN nb_avoirs INT NOT NULL DEFAULT 0,
    MODIFY COLUMN nb_releves INT NOT NULL DEFAULT 0,
    MODIFY COLUMN ca_ht_hors_releves_and_acomptes DOUBLE NOT NULL DEFAULT 0,
    MODIFY COLUMN ca_ttc_hors_releves_and_acomptes DOUBLE NOT NULL DEFAULT 0;