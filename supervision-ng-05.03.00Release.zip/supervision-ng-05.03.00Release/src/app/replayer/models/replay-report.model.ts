export class ReplayReport{

  nbSuccess : string;
  nbErrors : string;
  mapErrors : string;

}
