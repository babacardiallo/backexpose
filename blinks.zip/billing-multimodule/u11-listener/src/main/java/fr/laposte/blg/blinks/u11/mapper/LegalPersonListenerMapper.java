package fr.laposte.blg.blinks.u11.mapper;

import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ContractListenerException;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import reactor.core.Exceptions;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Mapper
@DecoratedWith(LegalPersonListenerDecorator.class)
public interface LegalPersonListenerMapper {

    @Mapping(target = "idLegalPerson", ignore = true)
    @Mapping(source = "id", target = "custAccNumber")
    @Mapping(source = "compName", target = "compName")
    @Mapping(source = "brandName", target = "brandName")
    @Mapping(source = "custTypeCode", target = "typeCode")
    @Mapping(source = "custTypeCode", target = "typeLabel", qualifiedByName = "custTypeCodeToTypeLabel")
    @Mapping(source = "CVATNO", target = "vatNumber")
    @Mapping(source = "siretCode", target = "siretCode")
    @Mapping(source = "establishZoneCode", target = "establishZoneCode")
    @Mapping(source = "marketingTypeCode", target = "marketingTypeCode")
    @Mapping(source = "active", target = "status")
    @Mapping(source = "email", target = "email")
    @Mapping(source = "legalPersonBillingTypology", target = "billingTypology")
    @Mapping(target = "legalNatureCode", ignore = true) //Does not exist in topic
    @Mapping(target = "legalNatureName", ignore = true) //Does not exist in topic
    @Mapping(target = "synchronized", ignore = true)
    @Mapping(target = "dateSynchronization", ignore = true)
    @Mapping(target = "addressEntityList", ignore = true)
    LegalPersonEntity legalPersonToLegalPersonEntity(LegalPerson legalPerson);

    @Mapping(source = "refpmAdressId", target = "addressIdRefPM")
    @Mapping(source = "MDateTime", target = "modificationDatetime")
    @Mapping(source = "CDateTime", target = "creationDatetime")
    @Mapping(ignore = true, target = "legalPersonEntity")
    @Mapping(ignore = true, target = "idAddress")
    @Mapping(ignore = true, target = "idLegalPerson")
    @Mapping(ignore = true, target = "addressJson")
    @Mapping(ignore = true, target = "custAccNumber")
    AddressEntity legalPersonToAddressEntity(LegalPerson legalPerson);

    default String toString(CharSequence charSequence) {
        return (charSequence != null) ? charSequence.toString() : null;
    }

    default Instant asInstant(String date) {
        return date != null && !date.isBlank() ? LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant() : null;
    }

    @Named("custTypeCodeToTypeLabel")
    default String custTypeCodeToTypeLabel(CharSequence csCustTypeCode) {
        if (csCustTypeCode.length() != 1) {
            throw new ContractListenerException("custTypeCode length does not equal to 1");
        }
        int iCustTypeCode;
        try {
            iCustTypeCode = Integer.parseUnsignedInt(csCustTypeCode, 0, 1, 10);
        } catch (Exception e) {
            throw Exceptions.propagate(e);
        }

        return switch (iCustTypeCode) {
            case 0 -> "privé";
            case 1 -> "public";
            default -> throw Exceptions.propagate(new ContractListenerException("The custTypeCode " + iCustTypeCode + " is not allowed (only 0=privé or 1=public are allowed)"));
        };
    }
}
