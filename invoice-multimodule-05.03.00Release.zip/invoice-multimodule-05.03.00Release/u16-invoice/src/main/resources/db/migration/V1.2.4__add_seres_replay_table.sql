CREATE TABLE blg_invoice.seres_replay
(
    id              int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    invoice_number  varchar(20)  NOT NULL,
    error_date     datetime     NOT NULL,
    error_code            int,
    error_message          text,
    invoice_url             text
);