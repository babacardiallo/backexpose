package fr.laposte.blg.blinks.lib.common.entities;

public enum FileType {
    DOCAPOSTE, INFOCA, REFCOM_BATCH, DOCAPOSTE_AVIS_PAIEMENT, COEURFINANCE, EQUINOX
}
