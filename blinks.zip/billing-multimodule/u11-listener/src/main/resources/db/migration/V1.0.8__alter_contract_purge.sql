ALTER TABLE blg_contract_importer.contract_version ADD is_purged TINYINT NOT NULL DEFAULT(0);
