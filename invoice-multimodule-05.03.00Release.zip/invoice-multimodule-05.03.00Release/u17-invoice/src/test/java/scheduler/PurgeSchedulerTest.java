package scheduler;

import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.scheduler.PurgeScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PurgeSchedulerTest {

    @Mock
    private InvoiceRepository invoiceRepository;

    @Mock
    private ExportHistoryRepository exportHistoryRepository;

    @TempDir
    Path tempDir;

    private PurgeScheduler purgeScheduler;
    private SchedulerParamsEntity schedulerParams;

    @BeforeEach
    void setUp() {
        schedulerParams = new SchedulerParamsEntity();
        schedulerParams.setId(1L);
        schedulerParams.setSchedulerName("scheduler_purge");
        schedulerParams.setArchivePath(tempDir.toString());
        schedulerParams.setIsEnabled(true);

        purgeScheduler = new PurgeScheduler(schedulerParams, invoiceRepository, exportHistoryRepository);
    }

    @Test
    void testPurgeOldArchiveFilesSuccess() throws IOException {
        Path docaArchiv = tempDir.resolve(FileType.DOCAPOSTE.toString());
        Files.createDirectories(docaArchiv);
        Files.createDirectories(tempDir.resolve(FileType.COEURFINANCE.toString()));
        Files.createDirectories(tempDir.resolve(FileType.INFOCA.toString()));
        Path oldFile = docaArchiv.resolve("old_file.txt");
        Path recentFile = docaArchiv.resolve("recent_file.txt");

        Files.write(oldFile, "old content".getBytes());
        Files.write(recentFile, "recent content".getBytes());

        Instant oldTime = Instant.now().minus(400, ChronoUnit.DAYS);
        Files.setLastModifiedTime(oldFile, FileTime.from(oldTime));

        Instant recentTime = Instant.now().minus(30, ChronoUnit.DAYS);
        Files.setLastModifiedTime(recentFile, FileTime.from(recentTime));

        when(invoiceRepository.deleteByUpdatedBefore(any(Instant.class))).thenReturn(Mono.just(5L));
        when(exportHistoryRepository.deleteOrphanedDocaposteExportHistory(any(Instant.class))).thenReturn(Mono.just(2L));
        when(exportHistoryRepository.deleteOrphanedCoeurfinanceExportHistory(any(Instant.class))).thenReturn(Mono.just(1L));
        when(exportHistoryRepository.deleteOrphanedInfocaExportHistory(any(Instant.class))).thenReturn(Mono.just(3L));

        purgeScheduler.run();

        assertFalse(Files.exists(oldFile), "Old file should be deleted");
        assertTrue(Files.exists(recentFile), "Recent file should remain");

        verify(invoiceRepository, times(1)).deleteByUpdatedBefore(any(Instant.class));
        verify(exportHistoryRepository, times(1)).deleteOrphanedDocaposteExportHistory(any(Instant.class));
        verify(exportHistoryRepository, times(1)).deleteOrphanedCoeurfinanceExportHistory(any(Instant.class));
        verify(exportHistoryRepository, times(1)).deleteOrphanedInfocaExportHistory(any(Instant.class));
    }



    @Test
    void testPurgeArchivePathDoesNotExist() {
        schedulerParams.setArchivePath("/path/that/does/not/exist");
        PurgeScheduler purgeSchedulerBadPath = new PurgeScheduler(schedulerParams, invoiceRepository, exportHistoryRepository);

        when(invoiceRepository.deleteByUpdatedBefore(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedDocaposteExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedCoeurfinanceExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedInfocaExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));

        assertDoesNotThrow(purgeSchedulerBadPath::run);

        verify(invoiceRepository, times(1)).deleteByUpdatedBefore(any(Instant.class));
        verify(exportHistoryRepository, times(1)).deleteOrphanedDocaposteExportHistory(any(Instant.class));
        verify(exportHistoryRepository, times(1)).deleteOrphanedCoeurfinanceExportHistory(any(Instant.class));
        verify(exportHistoryRepository, times(1)).deleteOrphanedInfocaExportHistory(any(Instant.class));
    }

    @Test
    void testPurgeOnlyFilesOlderThanOneYear() throws IOException {
        Path docaArchiv = tempDir.resolve(FileType.DOCAPOSTE.toString());
        Files.createDirectories(docaArchiv);
        Files.createDirectories(tempDir.resolve(FileType.COEURFINANCE.toString()));
        Files.createDirectories(tempDir.resolve(FileType.INFOCA.toString()));
        Path file364Days = docaArchiv.resolve("file_364_days.txt");
        Path file365Days = docaArchiv.resolve("file_365_days.txt");
        Path file366Days = docaArchiv.resolve("file_366_days.txt");

        Files.write(file364Days, "364 days old".getBytes());
        Files.write(file365Days, "365 days old".getBytes());
        Files.write(file366Days, "366 days old".getBytes());

        // Calcul des dates avec une marge pour éviter les problèmes de timing
        Instant baseTime = Instant.now();
        Files.setLastModifiedTime(file364Days, FileTime.from(baseTime.minus(364, ChronoUnit.DAYS).minus(1, ChronoUnit.HOURS)));
        Files.setLastModifiedTime(file365Days, FileTime.from(baseTime.minus(365, ChronoUnit.DAYS).plus(1, ChronoUnit.HOURS)));
        Files.setLastModifiedTime(file366Days, FileTime.from(baseTime.minus(366, ChronoUnit.DAYS)));

        when(invoiceRepository.deleteByUpdatedBefore(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedDocaposteExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedCoeurfinanceExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedInfocaExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));

        purgeScheduler.run();

        assertTrue(Files.exists(file364Days), "File 364 days old should remain");
        assertTrue(Files.exists(file365Days), "File exactly 365 days old should remain");
        assertFalse(Files.exists(file366Days), "File 366 days old should be deleted");
    }

    @Test
    void testPurgeUsesCorrectTimezone() throws IOException {
        Path docaArchiv = tempDir.resolve(FileType.DOCAPOSTE.toString());
        Files.createDirectories(docaArchiv);
        Files.createDirectories(tempDir.resolve(FileType.COEURFINANCE.toString()));
        Files.createDirectories(tempDir.resolve(FileType.INFOCA.toString()));
        Path oldFile = docaArchiv.resolve("old_file.txt");
        Files.write(oldFile, "old content".getBytes());

        Instant cutoffTime = ZonedDateTime.now(ZoneId.systemDefault())
                .minusDays(365)
                .toInstant();
        Instant fileTime = cutoffTime.minus(1, ChronoUnit.HOURS); // 1h plus vieux que la limite

        Files.setLastModifiedTime(oldFile, FileTime.from(fileTime));

        when(invoiceRepository.deleteByUpdatedBefore(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedDocaposteExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedCoeurfinanceExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));
        when(exportHistoryRepository.deleteOrphanedInfocaExportHistory(any(Instant.class))).thenReturn(Mono.just(0L));

        purgeScheduler.run();

        assertFalse(Files.exists(oldFile), "File should be deleted");
    }
}
