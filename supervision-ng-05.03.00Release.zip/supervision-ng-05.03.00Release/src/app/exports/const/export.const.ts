export const CHOIX_EXPORTS: Choix[] = [
    {value: 'docaposte',label: 'Docaposte'},
    {value: 'infoca',label: 'Infoca'},
    {value: 'coeurfinance',label: 'Coeur Finance'}
]

export class Choix{
     value: string='';
     label: string='';
}
