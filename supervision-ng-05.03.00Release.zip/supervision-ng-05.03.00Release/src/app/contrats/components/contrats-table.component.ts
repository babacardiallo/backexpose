import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ContratsTable } from '../models/contrats-table.model';
import { ContratsTableService } from '../service/contrats-table.service';
import * as XLSX from 'xlsx';
import { ContratsDetailsPopUpComponent } from './contrats-details-pop-up/contrats-details-pop-up.component';
import { ContratsRevisionError } from '../models/contrats-revision-error';
import { firstValueFrom, takeUntil } from 'rxjs';
import { ClientsService } from '../../clients/service/clients.service';
import { ClientsDetailsPopUpComponent } from '../../clients/components/clients-details-pop-up/clients-details-pop-up.component';
import { ContractPage } from '../models/contract.page';
import { ClientsTable } from '../../clients/models/clients-table.model';
import { ModalService } from 'ngx-modal-ease';

@Component({
    selector: 'contrats-table-component',
    templateUrl: './contrats-table.component.html',
    styleUrls: ['./contrats-table.component.scss'],
    standalone: false
})

export class ContratsTableComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild(DatatableComponent) contractsTable: DatatableComponent;
    listContracts: ContratsTable[];
    dataToExport: ContratsTable[];
    listSuperiorRevErrors?: ContratsRevisionError[];
    filtered: ContratsTable[];
    isActiveOffers: boolean = true;
    showOnlySyncErrors: boolean = false;
    showOnlySupRevErrors: boolean = false;
    contractPage: ContractPage = new ContractPage();
    searchText = '';
    client: ClientsTable;
    showContractNotSynch: boolean = false;
    isNotSynchronized: boolean = false;
    contractNumberSearch = '';
    custAccNumberSearch = '';
    offersSelected: string[] = [];
    offersList: string[] = [];
    showAll: boolean = false;

    M1_MODAL_PROPERTIES = {
        animation: 'enter-going-down',
        duration: '0.1s',
        easing: 'ease-out',
        padding: '1rem',
        width: '1900px',
        height: '100%'
    };

    constructor(private contratsTableService: ContratsTableService, private datePipe: DatePipe, private clientService: ClientsService, private modalService: ModalService) { }

    ngOnInit(): void {
    }

    async ngAfterViewInit(): Promise<void> {
        this.getOffersList();
    }


    ngOnDestroy(): void {
        this.contratsTableService.ngUnsubscribe$.next();
        this.contratsTableService.ngUnsubscribe$.complete();
    }

    getOffersList() {
        this.contratsTableService.getOffersList()
            .pipe(takeUntil(this.contratsTableService.ngUnsubscribe$))
            .subscribe((response: any) => {
                this.offersList = response.map((r: { opsCode: string; }) => r.opsCode);
            });
    }

    getSupRevErrors(showAll: boolean, page: number, itemPerPage: number, sort: string, order: string, contractNumber: string, custAccNumber: string, offers: string[]): Promise<any> {
        return new Promise((resolve) => {
            this.contratsTableService.getSuperiorRevErrors(showAll, page, itemPerPage, sort, order, contractNumber, custAccNumber, offers).subscribe({
                next: (response: any) => {
                    this.listContracts = response.content.map((data: any) => {
                        return <ContratsTable>{
                            contractId: data.id,
                            contractNumber: data.contractNumber,
                            amendmentNumber: data.amendmentNumber,
                            revisionNumber: data.revisionNumber,
                            status: data.status,
                            substatus: data.subStatus,
                            type: data.type,
                            subtype: data.subtype,
                            opsCode: data.opsCode,
                            opsLabel: data.opsLabel,
                            isSynchronized: data.isSynchronized,
                            lastDateSynchronization: data.lastDateSynchronization ? new Date(data.lastDateSynchronization * 1000) : null,
                            firstErrorDate: data.firstErrorDate ? new Date(data.firstErrorDate * 1000) : null,
                            custAccNumber: data.custAccNumber,
                            custAccNumberBeforeSynchronisation: data.custAccNumberBeforeSynchronisation,
                            hasSuperiorRevError: true,
                            superiorRevError: data.superiorRevError,
                            superiorRevErrMessage: data.superiorRevErrMessage,
                            supOffsetError: data.supOffsetError,
                            supPartitionError: data.supPartitionError
                        };
                    })
                    this.contractPage = {
                        currentPage: response.pageable.pageNumber,
                        itemsOnPage: response.pageable.pageSize,
                        currentOffset: response.pageable.offset,
                        totalPages: response.totalPages,
                        totalItems: response.totalElements
                    }
                },
                complete: () => {
                    resolve(true);
                },
            });
        });
    }

    getContractsExport(): Promise<any> {
        return new Promise((resolve) => {
            this.contratsTableService.getContractsExport().subscribe({
                next: (response: any) => {
                    this.dataToExport = response.map((data: any) => {
                        return <ContratsTable>{
                            contractId: data.id,
                            contractNumber: data.contractNumber,
                            amendmentNumber: data.amendmentNumber,
                            revisionNumber: data.revisionNumber,
                            status: data.status,
                            substatus: data.subStatus,
                            type: data.type,
                            subtype: data.subtype,
                            opsCode: data.opsCode,
                            opsLabel: data.opsLabel,
                            isSynchronized: data.isSynchronized,
                            lastDateSynchronization: data.lastDateSynchronization ? new Date(data.lastDateSynchronization * 1000) : null,
                            dateError: data.dateError ? new Date(data.dateError * 1000) : null,
                            firstErrorDate: data.firstErrorDate ? new Date(data.firstErrorDate * 1000) : null,
                            custAccNumber: data.custAccNumber,
                            custAccNumberBeforeSynchronisation: data.custAccNumberBeforeSynchronisation,
                        };
                    })
                },
                complete: () => {
                    resolve(true);
                },
            });
        });
    }

    /*
    * Function to check if a contract that is integrated has a superior revision with an integration error.
    * If previous revision is synchronized, we color the row in orange. If not, in red.
    */


    getRowClass = (row: ContratsTable) => {
        let className = "";
        if (row.firstErrorDate !== null) {
            className = "error_synch";
        } else if (this.listSuperiorRevErrors) {
            const commonContract = this.listSuperiorRevErrors.find((errorOnRev: ContratsRevisionError) => {
                return row.contractNumber === errorOnRev.contractNumber && row.amendmentNumber === errorOnRev.amendmentNumber;
            });

            if (commonContract) {
                row.hasSuperiorRevError = true;
                className = "error_superior_rev";
            }
        }
        return className;
    };

    async showSyncErrors() {
        this.isNotSynchronized = false;
        this.showOnlySupRevErrors = false;
        this.checkFilters();
        if (this.showOnlySyncErrors) {
            await this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, this.showAll, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
        else {
            await this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, false, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
    }

    async showSupRevErrors() {
        this.showOnlySyncErrors = false;
        this.isNotSynchronized = false;
        this.checkFilters();
        if (this.showOnlySupRevErrors) {
            await this.getSupRevErrors(this.showAll, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
        else {
            await this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, false, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
    }


    async exportSynchContracts() {
        await this.getContractsExport();
        this.dataToExport.forEach((contract: ContratsTable) => {
            delete contract.contractId,
                delete contract.isSynchronized,
                delete contract.lastDateSynchronization,
                delete contract.dateError,
                delete contract.firstErrorDate,
                delete contract.superiorRevErrMessage,
                delete contract.hasSuperiorRevError,
                delete contract.superiorRevError,
                delete contract.superiorRevOdcMessage,
                contract.refClient = contract.custAccNumberBeforeSynchronisation,
                delete contract.custAccNumberBeforeSynchronisation,
                delete contract.custAccNumber,
                delete contract.supOffsetError,
                delete contract.supPartitionError

        });

        this.dataToExport.sort((a: ContratsTable, b: ContratsTable) =>
            (a.contractNumber! > b.contractNumber!) ? 1
                : (b.contractNumber! > a.contractNumber!) ? -1
                    : (a.amendmentNumber! > b.amendmentNumber!) ? 1
                        : (b.amendmentNumber! > a.amendmentNumber!) ? -1
                            : 0
        );

        // group data by "opsCode"
        const groupedData: { [opsCode: string]: any[] } = {};
        this.dataToExport.forEach((row: ContratsTable) => {
            if (!groupedData[row.opsCode!]) {
                groupedData[row.opsCode!] = []
            }
            groupedData[row.opsCode!].push(row);
        });
        const opsCodeKeys = Object.keys(groupedData).sort();
        const fileName = 'ExportContratsSynchronisés_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["N° Contrat", "N° Avenant", "N° Révision", "Statut", "Sous statut",
            "Type", "Sous type", "Code OPS", "Libellé", "Ref client"]];
        const wb: XLSX.WorkBook = XLSX.utils.book_new();

        // add a sheet for each group of data
        opsCodeKeys.forEach((opsCode) => {
            const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(groupedData[opsCode]);
            XLSX.utils.sheet_add_aoa(ws, headers);
            XLSX.utils.book_append_sheet(wb, ws, opsCode);
            ws['!cols'] = [
                { wch: 15 },
                { wch: 10 },
                { wch: 10 },
                { wch: 15 },
                { wch: 20 },
                { wch: 30 },
                { wch: 30 },
                { wch: 10 },
                { wch: 30 },
            ];
        });
        XLSX.writeFile(wb, fileName);
        this.contractsTable.selected.splice(0, this.contractsTable.selected.length);
        this.contractsTable.recalculate();
    }


    updateFilter() {
        this.checkFilters();
        if (this.showOnlySupRevErrors) {
            this.getSupRevErrors(this.showAll, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        } else {
            this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, this.showAll, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
    }

    showPopup(row: ContratsTable, event: Event) {
        this.modalService
            .open(ContratsDetailsPopUpComponent, {
                modal: {
                    enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
                },
                overlay: {
                    leave: 'fade-out 0.3s',
                },
                size: {
                    padding: this.M1_MODAL_PROPERTIES.padding,
                    width: this.M1_MODAL_PROPERTIES.width,
                    height: this.M1_MODAL_PROPERTIES.height
                },
                data: {
                    contrat: row,
                }
            })
            .then((response) => console.log(response));
        event.stopPropagation()
    }

    formatDateTable(date: number) {
        return date ? this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
    }

    formatDateExport(date: number) {
        return this.datePipe.transform(date, 'yyyyMMdd_HHmmss', 'fr');
    }

    showPopupClient(row: any, event: Event) {
        this.clientService.getOneClient(row.custAccNumber).
            subscribe({
                next: (response: any) => {
                    this.client = response;
                    this.client.isSynchronized = response.synchro;
                    this.client.type = response.type ? "Public" : "Privé";
                    this.client.dateSynchronization = response.dateLastSynchro ? new Date(response.dateLastSynchro * 1000) : null;
                    this.client.dateError = response.dateError ? new Date(response.dateError * 1000) : null;
                    this.modalService
                        .open(ClientsDetailsPopUpComponent, {
                            modal: {
                                enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
                            },
                            overlay: {
                                leave: 'fade-out 0.3s',
                            },
                            size: {
                                padding: this.M1_MODAL_PROPERTIES.padding,
                                width: this.M1_MODAL_PROPERTIES.width,
                                height: this.M1_MODAL_PROPERTIES.height
                            },
                            data: {
                                client: this.client,
                            }
                        })
                        .then((response) => console.log(response));
                    event.stopPropagation();
                },
            })
    }

    onPageChange(event: any) {
        this.checkFilters();
        if (this.showOnlySupRevErrors) {
            this.getSupRevErrors(this.showAll, event.offset, 10, this.contractsTable.sorts[0].prop, this.contractsTable.sorts[0].dir, this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        } else {
            this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, this.showAll, event.offset, 10, this.contractsTable.sorts[0].prop, this.contractsTable.sorts[0].dir, this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
    }

    onSort(event: any) {
        this.checkFilters();
        if (this.showOnlySupRevErrors) {
            this.getSupRevErrors(this.showAll, this.contractPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        } else {
            this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, this.showAll, this.contractPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
        // On remet la page de la table manuellement a chaque sort car par défaut ngx-datatable revient page 1 ce qui n'a pas de sens sur un sort.
        this.contractsTable.offset = this.contractPage.currentPage!;
    }


    filterContracts(errors: boolean, isSynchronized: boolean, showAll: boolean, page: number, itemPerPage: number, sort: string, order: string, contractNumber: string, custAccNumber: string, offers: string[]): Promise<any> {
        return new Promise((resolve) => {
            this.contratsTableService.getFilteredContracts(errors, isSynchronized, showAll, page, itemPerPage, sort, order, contractNumber, custAccNumber, offers).subscribe({
                next: (response: any) => {
                    this.listContracts = response.content.map((data: any) => {
                        return <ContratsTable>{
                            contractId: data.id,
                            contractNumber: data.contractNumber,
                            amendmentNumber: data.amendmentNumber,
                            revisionNumber: data.revisionNumber,
                            status: data.status,
                            substatus: data.subStatus,
                            type: data.type,
                            subtype: data.subtype,
                            opsCode: data.opsCode,
                            opsLabel: data.opsLabel,
                            isSynchronized: data.isSynchronized,
                            lastDateSynchronization: data.lastDateSynchronization ? new Date(data.lastDateSynchronization * 1000) : null,
                            dateError: data.dateError ? new Date(data.dateError * 1000) : null,
                            firstErrorDate: data.firstErrorDate ? new Date(data.firstErrorDate * 1000) : null,
                            custAccNumber: data.custAccNumber,
                            custAccNumberBeforeSynchronisation: data.custAccNumberBeforeSynchronisation,
                        };
                    })
                    this.contractPage = {
                        currentPage: response.pageable.pageNumber,
                        itemsOnPage: response.pageable.pageSize,
                        currentOffset: response.pageable.offset,
                        totalPages: response.totalPages,
                        totalItems: response.totalElements
                    };

                },
                complete: () => {
                    resolve(true);
                },
            });
        });
    }

    async switchToNotSynch() {
        this.showOnlySyncErrors = false;
        this.showOnlySupRevErrors = false;
        this.checkFilters();
        if (this.isNotSynchronized) {
            await this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, this.showAll, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
        else {
            await this.filterContracts(this.showOnlySyncErrors, this.isNotSynchronized, false, 0, 10, "id", "desc", this.contractNumberSearch, this.custAccNumberSearch, this.offersSelected);
        }
    }

    checkFilters() {
        if (this.contractNumberSearch == '' && this.custAccNumberSearch == '' && this.offersSelected.length == 0) {
            if (this.isNotSynchronized == true || this.showOnlySupRevErrors == true || this.showOnlySyncErrors == true) {
                this.showAll = true;
            }
            else {
                this.showAll = false;
            }
        }
        else {
            this.showAll = false;
        }
    }

}
