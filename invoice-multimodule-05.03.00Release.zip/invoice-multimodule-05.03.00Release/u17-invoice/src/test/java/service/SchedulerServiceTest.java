package service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.Instant;
import java.util.concurrent.ScheduledFuture;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import fr.laposte.blg.blinks.u17.service.*;
import fr.laposte.blg.blinks.u17.util.SchedulerUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class SchedulerServiceTest {

    @Mock
    private TaskScheduler taskScheduler;

    @Mock
    private SchedulerParamsRepository schedulerParamsRepository;

    @Mock
    private ExportHistoryRepository exportHistoryRepository;
    @Mock
    private DocaposteService docaposteService;
    @Mock
    private CoeurfinanceService coeurfinanceService;
    @Mock
    private InfocaInvoiceExportService infocaInvoiceExportService;
    @Mock
    private ExportProcessRepository exportProcessRepository;
    @Mock
    private InvoiceRepository invoiceRepository;
    @Mock
    private SchedulerUtils schedulerUtils;
    @Mock
    private NotificationService notificationService;

    @Mock
    private ScheduledFuture<?> scheduledFuture;
    private SchedulerService schedulerService;

    private SchedulerParamsEntity schedulerParams;

    @BeforeEach
    void setup() {
        when(schedulerParamsRepository.findAllByIsEnabledAndModule(anyBoolean(), anyString())).thenReturn(Flux.empty());

        lenient().doReturn(scheduledFuture)
                .when(taskScheduler)
                .schedule(any(Runnable.class), any(CronTrigger.class));

        schedulerParams = new SchedulerParamsEntity();
        schedulerParams.setId(1L);
        schedulerParams.setSchedulerName("scheduler_transfer");
        schedulerParams.setCronExpression("0 * * * * *");
        schedulerParams.setExportPath("/export");
        schedulerParams.setCftPath("/cft");
        schedulerParams.setArchivePath("/archive");
        schedulerParams.setIsEnabled(true);
        schedulerParams.setModule("u17");

        schedulerService = new SchedulerService(
                taskScheduler,
                schedulerParamsRepository,
                exportHistoryRepository,
                docaposteService,
                coeurfinanceService,
                infocaInvoiceExportService,
                exportProcessRepository,
                invoiceRepository,
                schedulerUtils,
                notificationService,
                "/tmp/key.pem"
        );
    }

    @Test
    void testUpdateSchedulerParams() {
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParams));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(schedulerParamsRepository).save(any(SchedulerParamsEntity.class));

        SchedulerParamsEntity updatedParams = new SchedulerParamsEntity();
        updatedParams.setCronExpression("0 0 * * * *");
        updatedParams.setExportPath("/newExport");
        updatedParams.setCftPath("/newCft");
        updatedParams.setArchivePath("/newArchive");
        updatedParams.setIsEnabled(true);
        updatedParams.setSchedulerName("scheduler_transfer");
        updatedParams.setModule("u17");

        Mono<SchedulerParamsEntity> updateMono = schedulerService.updateTask(1L, updatedParams);
        StepVerifier.create(updateMono)
                .assertNext(updatedEntity -> {
                    assertEquals("0 0 * * * *", updatedEntity.getCronExpression());
                    assertEquals("/newExport", updatedEntity.getExportPath());
                    verify(taskScheduler).schedule(any(Runnable.class), any(CronTrigger.class));
                }).verifyComplete();

        Mono<SchedulerParamsEntity> disableMono = schedulerService.cancelTask(1L);
        StepVerifier.create(disableMono)
                .assertNext(disabledEntity -> {
                    assertFalse(disabledEntity.getIsEnabled());
                    verify(scheduledFuture).cancel(false);
                })
                .verifyComplete();

        schedulerParams.setIsEnabled(false);
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParams));
        Mono<SchedulerParamsEntity> enableMono = schedulerService.enableTask(1L);
        StepVerifier.create(enableMono)
                .assertNext(enabledEntity -> {
                    assertTrue(enabledEntity.getIsEnabled());
                    verify(taskScheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
                })
                .verifyComplete();
    }

    @Test
    void testRunOnceSuccess() {
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParams));
        doReturn(scheduledFuture)
                .when(taskScheduler)
                .schedule(any(Runnable.class), any(Instant.class));

        Mono<Void> runOnceMono = schedulerService.runOnce(1L);
        StepVerifier.create(runOnceMono)
                .verifyComplete();

        verify(taskScheduler, times(1)).schedule(any(Runnable.class), any(Instant.class));
    }

    @Test
    void testRunOnceNotFound() {
        when(schedulerParamsRepository.findById(2L)).thenReturn(Mono.empty());

        Mono<Void> runOnceMono = schedulerService.runOnce(2L);
        StepVerifier.create(runOnceMono)
                .verifyComplete();

        verify(taskScheduler, never()).schedule(any(Runnable.class), any(Instant.class));
    }

    @Test
    void testOrganizeExistingArchivesSchedulerNotFound() {
        when(schedulerParamsRepository.findById(999L)).thenReturn(Mono.empty());
        Mono<Integer> organizeMono = schedulerService.organizeExistingArchives(999L);
        StepVerifier.create(organizeMono)
                .expectError(IllegalArgumentException.class)
                .verify();
    }

    @Test
    void testOrganizeExistingArchivesWrongSchedulerType() {
        SchedulerParamsEntity exportScheduler = new SchedulerParamsEntity();
        exportScheduler.setId(2L);
        exportScheduler.setSchedulerName("scheduler_export");
        exportScheduler.setArchivePath("/archive");

        when(schedulerParamsRepository.findById(2L)).thenReturn(Mono.just(exportScheduler));

        Mono<Integer> organizeMono = schedulerService.organizeExistingArchives(2L);

        StepVerifier.create(organizeMono)
                .expectErrorMatches(throwable ->
                        throwable instanceof IllegalArgumentException &&
                                throwable.getMessage().contains("not a transfer scheduler"))
                .verify();
    }

    @Test
    void testOrganizeExistingArchivesNonExistentArchivePath() {
        SchedulerParamsEntity transferScheduler = new SchedulerParamsEntity();
        transferScheduler.setId(3L);
        transferScheduler.setSchedulerName("scheduler_transfer");
        transferScheduler.setArchivePath("/non/existent/path");

        when(schedulerParamsRepository.findById(3L)).thenReturn(Mono.just(transferScheduler));

        Mono<Integer> organizeMono = schedulerService.organizeExistingArchives(3L);

        StepVerifier.create(organizeMono)
                .assertNext(count -> assertEquals(0, count, "Should return 0 when archive path doesn't exist"))
                .verifyComplete();
    }

    @Test
    void testOrganizeExistingArchivesWithRealFiles(@TempDir Path tempDir) throws IOException {
        Path archiveDir = tempDir.resolve("archive");
        Files.createDirectories(archiveDir);

        Files.write(archiveDir.resolve("blg3aaaa_20250130.ws"), "docaposte content".getBytes());
        Files.write(archiveDir.resolve("blg1aaaa_20250228.ep"), "coeurfinance content".getBytes());
        Files.write(archiveDir.resolve("blg2aaaa_20250315.is"), "infoca content".getBytes());
        Files.write(archiveDir.resolve("blg2aaaa_20250315.etz"), "infoca etz content".getBytes());
        Files.write(archiveDir.resolve("unknown_file.txt"), "unknown content".getBytes()); // Fichier non reconnu

        SchedulerParamsEntity transferScheduler = new SchedulerParamsEntity();
        transferScheduler.setId(4L);
        transferScheduler.setSchedulerName("scheduler_transfer");
        transferScheduler.setArchivePath(archiveDir.toString());

        when(schedulerParamsRepository.findById(4L)).thenReturn(Mono.just(transferScheduler));

        Mono<Integer> organizeMono = schedulerService.organizeExistingArchives(4L);

        StepVerifier.create(organizeMono)
                .assertNext(count -> {
                    assertEquals(4, count, "Should organize 4 files (excluding unknown file)");

                    assertTrue(Files.exists(archiveDir.resolve("DOCAPOSTE/2025/01/blg3aaaa_20250130.ws")),
                            "DOCAPOSTE file should be organized");
                    assertTrue(Files.exists(archiveDir.resolve("COEURFINANCE/2025/02/blg1aaaa_20250228.ep")),
                            "COEURFINANCE file should be organized");
                    assertTrue(Files.exists(archiveDir.resolve("INFOCA/2025/03/blg2aaaa_20250315.is")),
                            "INFOCA .is file should be organized");
                    assertTrue(Files.exists(archiveDir.resolve("INFOCA/2025/03/blg2aaaa_20250315.etz")),
                            "INFOCA .etz file should be organized");

                    assertTrue(Files.exists(archiveDir.resolve("unknown_file.txt")),
                            "Unknown file should remain in original location");

                    assertFalse(Files.exists(archiveDir.resolve("blg3aaaa_20250130.ws")),
                            "Original DOCAPOSTE file should be moved");
                    assertFalse(Files.exists(archiveDir.resolve("blg1aaaa_20250228.ep")),
                            "Original COEURFINANCE file should be moved");
                })
                .verifyComplete();
    }

    @Test
    void testOrganizeExistingArchivesWithInvalidDateFiles(@TempDir Path tempDir) throws IOException {
        Path archiveDir = tempDir.resolve("archive");
        Files.createDirectories(archiveDir);

        Files.write(archiveDir.resolve("blg3aaaa_invalid.ws"), "docaposte content".getBytes());
        Files.write(archiveDir.resolve("some_file.ep"), "coeurfinance content".getBytes());

        SchedulerParamsEntity transferScheduler = new SchedulerParamsEntity();
        transferScheduler.setId(5L);
        transferScheduler.setSchedulerName("scheduler_transfer");
        transferScheduler.setArchivePath(archiveDir.toString());

        when(schedulerParamsRepository.findById(5L)).thenReturn(Mono.just(transferScheduler));

        Mono<Integer> organizeMono = schedulerService.organizeExistingArchives(5L);

        StepVerifier.create(organizeMono)
                .assertNext(count -> {
                    assertEquals(0, count, "Should organize 0 files due to invalid dates");

                    assertTrue(Files.exists(archiveDir.resolve("blg3aaaa_invalid.ws")),
                            "File with invalid date should remain");
                    assertTrue(Files.exists(archiveDir.resolve("some_file.ep")),
                            "File with invalid date should remain");
                })
                .verifyComplete();
    }

    @Test
    void testOrganizeExistingArchivesWithExistingTargetFiles(@TempDir Path tempDir) throws IOException {
        Path archiveDir = tempDir.resolve("archive");
        Files.createDirectories(archiveDir);

        String sourceContent = "source content";
        Files.write(archiveDir.resolve("blg3aaaa_20250130.ws"), sourceContent.getBytes());

        Path targetDir = archiveDir.resolve("DOCAPOSTE/2025/01");
        Files.createDirectories(targetDir);
        String existingTargetContent = "existing target content";
        Files.write(targetDir.resolve("blg3aaaa_20250130.ws"), existingTargetContent.getBytes());

        SchedulerParamsEntity transferScheduler = new SchedulerParamsEntity();
        transferScheduler.setId(6L);
        transferScheduler.setSchedulerName("scheduler_transfer");
        transferScheduler.setArchivePath(archiveDir.toString());

        when(schedulerParamsRepository.findById(6L)).thenReturn(Mono.just(transferScheduler));

        Mono<Integer> organizeMono = schedulerService.organizeExistingArchives(6L);

        StepVerifier.create(organizeMono)
                .assertNext(count -> {
                    assertEquals(0, count, "Should organize 0 files when target already exists");

                    assertTrue(Files.exists(archiveDir.resolve("blg3aaaa_20250130.ws")),
                            "Source file should remain when target exists");

                    try {
                        String actualSourceContent = Files.readString(archiveDir.resolve("blg3aaaa_20250130.ws"));
                        assertEquals(sourceContent, actualSourceContent,
                                "Source file content should remain unchanged");
                    } catch (IOException e) {
                        fail("Failed to read source file content: " + e.getMessage());
                    }

                    assertTrue(Files.exists(targetDir.resolve("blg3aaaa_20250130.ws")),
                            "Target file should still exist");

                    try {
                        String actualTargetContent = Files.readString(targetDir.resolve("blg3aaaa_20250130.ws"));
                        assertEquals(existingTargetContent, actualTargetContent,
                                "Target file content should remain unchanged");
                    } catch (IOException e) {
                        fail("Failed to read target file content: " + e.getMessage());
                    }
                })
                .verifyComplete();
    }
}
