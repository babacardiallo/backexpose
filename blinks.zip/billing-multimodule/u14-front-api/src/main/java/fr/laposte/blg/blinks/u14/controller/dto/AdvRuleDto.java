package fr.laposte.blg.blinks.u14.controller.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class AdvRuleDto {
    private Integer index;
    private String column;
    private String rule;
}
