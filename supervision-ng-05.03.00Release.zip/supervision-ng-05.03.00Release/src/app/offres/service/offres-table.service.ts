import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {environment} from '../../../environments/environment';
import {ErrorOfferBean} from '../models/error-offer.model';
import {OffresRefops} from '../models/offres-refops.model';
import {OffresTable} from '../models/offres-table.model';

@Injectable({
  providedIn: 'root',
})
export class OffresTableService {
  ngUnsubscribe$ = new Subject<void>();

  constructor(private http: HttpClient) {
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }
  httpOptionsTextResponse = {
    headers: new HttpHeaders({
      'Accept': 'text/plain, */*',
      'Content-Type': 'application/json'
    }),
    responseType: 'text' as 'json'
  }

  getOffres(page: number, size: number, sort: string, order: string, filter: string): Observable<any> {
    let queryParams = new HttpParams()
    .set("page", page)
    .set("size", size)
    .set("sort", sort)
    .set("order", order)
    .set("filter", filter);
    return this.http.get<OffresTable[]>(environment.API_OFFER_SUPERVISION+"?"+queryParams, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getActivesOffres(page: number, size: number, sort: string, order: string, filter: string): Observable<any> {
    let queryParams = new HttpParams()
    .set("page", page)
    .set("size", size)
    .set("sort", sort)
    .set("order", order)
    .set("filter", filter);
    return this.http.get<OffresTable[]>(environment.API_ACTIVE_OFFER_SUPERVISION+"?"+queryParams, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getErrorsbyOfferAndTypeError(opsCode: string, workflowStep: string): Observable<ErrorOfferBean[]> {
    let queryParams = new HttpParams().append("opsCode", opsCode).append("workflowStep", workflowStep);
    let head = new HttpHeaders({'Content-Type': 'application/json', });
    return this.http.get<ErrorOfferBean[]>(environment.API_ERRORS_OFFER, {headers: head, params: queryParams})
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  addOffreHttp(opsCode: string, date: string): Observable<unknown> {
    let queryParams = new HttpParams()
      .set("offer-ops-code", opsCode)
      .set("date-migration-expected", date);
    return this.http.post(environment.API_ADD_OFFER + queryParams, null, this.httpOptionsTextResponse)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getAllRefops(): Observable<OffresRefops[]> {
    return this.http.get<OffresRefops[]>(environment.API_OFFER_REFOPS, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getErrors(): Observable<ErrorOfferBean[]> {
    return this.http.get<ErrorOfferBean[]>(environment.API_ALL_ERRORS, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  deleteOffer(opsCode: string): Observable<unknown> {
    let queryParams = new HttpParams()
      .set("opsCode", opsCode);

    return this.http.post(environment.API_DELETE_OFFER + queryParams, null, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  exportOffres(filter: string): Observable<any> {
    let queryParams = new HttpParams()
    .set("filter", filter);
    return this.http.get<OffresTable[]>(environment.API_EXPORT_OFFER+"?"+queryParams, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  exportActivesOffres(filter: string): Observable<any> {
    let queryParams = new HttpParams()
    .set("filter", filter);
    return this.http.get<OffresTable[]>(environment.API_EXPORT_ACTIVE_OFFER+"?"+queryParams, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

}
