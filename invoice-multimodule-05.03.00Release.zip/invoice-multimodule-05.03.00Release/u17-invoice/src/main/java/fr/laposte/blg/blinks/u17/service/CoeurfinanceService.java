package fr.laposte.blg.blinks.u17.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.opencsv.CSVWriter;
import com.opencsv.ICSVWriter;
import fr.laposte.blg.blinks.lib.common.dto.*;
import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.repositories.*;
import fr.laposte.blg.blinks.lib.common.repositories.organization.CustomerProfitCenterRepository;
import fr.laposte.blg.blinks.lib.common.repositories.refcom.*;
import fr.laposte.blg.blinks.lib.common.utils.TrackExecutionTime;
import fr.laposte.blg.blinks.u17.dto.InvoiceExportDto;
import fr.laposte.blg.blinks.u17.dto.ScheduledPaymentTreatment;
import fr.laposte.blg.blinks.u17.dto.coeurfinance.InvoiceCoeurfinanceDto;
import fr.laposte.blg.blinks.u17.util.Constant;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import fr.laposte.blg.blinks.u17.util.ObjectMapperWithModules;
import fr.laposte.blg.blinks.u17.util.StringExportUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;

import java.io.FileWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.stream.Stream;

@Service
@Data
@Slf4j
@JsonIgnoreProperties(ignoreUnknown = true)
public class CoeurfinanceService implements ExportBaseService {

    public static final String PROFIT_CENTER_CODE_REGATE = "profitCenterCodeRegate";
    public static final String POSITION_ID = "positionId";
    public static final String POSITION_TYPE_ID = "positionTypeId";
    public static final String TERRITORY_ID = "territoryId";
    public static final String TERRITORY_TYPE_ID = "territoryTypeId";
    public static final String TEAM_ID = "teamId";
    public static final String TEAM_TYPE_ID = "teamTypeId";
    public static final String Z003 = "Z003";
    public static final String Z005 = "Z005";
    public static final String Z001 = "Z001";
    private static final DecimalFormat df = new DecimalFormat("0.00", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
    private static final DecimalFormat dfUnitPrice = new DecimalFormat("0.00000", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
    private static final String DEFAULT_PROFIT_CENTER = "750854";
    private static final String DEFAULT_ZONE_DISTRIB = "750774";
    private static final ZoneId ZONE_ID = ZoneId.of("Europe/Paris");
    private final InvoiceRepository invoiceRepository;
    private final InvoiceMessageRepository invoiceMessageRepository;
    private final ObjectMapperWithModules objectMapper;
    private final FileSequenceRepository fileSequenceRepository;
    private final ExportHistoryRepository exportHistoryRepository;
    private final BusinessAssignmentNomenclatureRepository businessAssignmentNomenclatureRepository;
    private final BusinessPortfolioPositionLinkRepository businessPortfolioPositionLinkRepository;
    private final BusinessPortfolioTeamLinkRepository businessPortfolioTeamLinkRepository;
    private final BusinessPortfolioComChangesRepository businessPortfolioComChangesRepository;
    private final BusinessPositionHierarchyRepository businessPositionHierarchyRepository;
    private final BusinessTeamRepository businessTeamRepository;
    private final ExportProcessRepository exportProcessRepository;

    private final ExportService exportService;
    private final TeamAssignmentLinkRepository teamAssignmentLinkRepository;
    private final BusinessPositionLinkTerritoryRepository businessPositionLinkTerritoryRepository;
    private final BusinessTerritoryRepository businessTerritoryRepository;
    private final CustomerProfitCenterRepository customerProfitCenterRepository;
    private final OrganizationService organizationService;
    private final DateUtil dateUtil;
    private final List<Double> totalBillingAmount;

    private final RefcomCommunicationService refcomCommunicationService;
    private double finalAmount;
    @Value("${fr.laposte.coeurfinance.file.name}")
    private String baseName;
    @Value("${fr.laposte.coeurfinance.file.location}")
    private String location;
    private String fileName;
    private HashMap<String, String> linkCustAccNumberProfitCenter = new HashMap<>();


    private static String getCommandeType(InvoiceHeaderDTO invoiceHeader) {
        if (Boolean.TRUE.equals(invoiceHeader.getCreditFlag())) {
            return Z003;
        } else if (Boolean.TRUE.equals(invoiceHeader.getDownpaymentFlag())) {
            return Z005;
        } else return Z001;
    }

    @TrackExecutionTime
    public Mono<ExportHistoryEntity> process(ExportProcess exportProcess, String exportPath) {
        log.info("Début de l'export Coeurfinance");
        if (exportProcess.getMaxId().equals(Long.MAX_VALUE)){
            exportProcess.setMaxId(invoiceRepository.getMaxIdForProcess().block());
        }
        String finalLocation = exportPath != null ? exportPath:location;
        finalAmount = 0;
        Instant startTime = Instant.now();
        List<InvoiceExportDto> failedInvoices = new ArrayList<>();
        List<InvoiceExportDto> excludedInvoices = new ArrayList<>();
        List<InvoiceExportDto> validInvoices = new ArrayList<>();
        List<InvoiceDTO> validInvoicesDto = new ArrayList<>();
        List<String[]> headersFile;
        List<Pair<InvoiceCoeurfinanceDto,Long>> invoicesToWrite = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        this.fileName = baseName + "_" + LocalDateTime.now().format(formatter) + ".a3p";
        try (CSVWriter csvWriter = new CSVWriter(new FileWriter(finalLocation + fileName)
                , '¤'
                , ICSVWriter.NO_QUOTE_CHARACTER
                , ICSVWriter.NO_ESCAPE_CHARACTER
                , ICSVWriter.DEFAULT_LINE_END
        )) {
            List<Pair<InvoiceEntity, InvoiceDTO>> validInvoicePairs =
                    this.invoiceRepository.findByCoeurfinanceExportIdIsNullAndIdBetweenOrderByReferenceAsc(exportProcess.getMinId(), exportProcess.getMaxId())
                            .flatMap(invoiceEntity -> this.invoiceMessageRepository.getMessage(invoiceEntity.getIdInvoice())
                                    .flatMap(message -> {
                                        try {
                                            InvoiceDTO invoiceDTO = this.objectMapper.readValue(message, InvoiceDTO.class);
                                            return Mono.just(Pair.of(invoiceEntity, invoiceDTO));
                                        } catch (JsonProcessingException e) {
                                            log.info("Failure for invoice {} : error when parsing invoice JSON : {}",
                                                    invoiceEntity.getInvoiceNumber(), e.getMessage());
                                            failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Error when parsing invoice JSON: " + e.getMessage(), "U170001"));
                                            return Mono.empty();
                                        }
                                    })
                            )
                            .concatMap(pair -> {
                                InvoiceEntity invoiceEntity = pair.getFirst();
                                InvoiceDTO invoiceDTO = pair.getSecond();
                                List<ContractDTO> contracts = invoiceDTO.getContracts();
                                boolean isTotalBillingNotNull = invoiceDTO.getInvoiceHeader().getBillingAmount().getExcludingTaxTotalAmount() != 0;
                                AtomicBoolean isBillingsNotNull = new AtomicBoolean(false);
                                if (Boolean.TRUE.equals(invoiceDTO.getInvoiceHeader().getIsStatementFlag())) {
                                    log.info("Skipping invoice {} : isStatementFlag from invoice is true",
                                            invoiceEntity.getInvoiceNumber());
                                    excludedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Skipping invoice : isStatementFlag from invoice is true", null));
                                    return Mono.empty();
                                }
                                if (Boolean.TRUE.equals(invoiceDTO.getInvoiceHeader().getAvisPaiementFlag())
                                        && (invoiceDTO.getInvoiceHeader().getInvoiceAttachmentNumber()==null || StringUtils.isBlank(invoiceDTO.getInvoiceHeader().getInvoiceAttachmentNumber()))) {
                                    invoiceDTO.getInvoiceHeader().setInvoiceAttachmentNumber(invoiceDTO.getInvoiceHeader().getInvoiceNumber());
                                }
                                contracts.forEach(contractDto -> {
                                        contractDto.getLinkedAccounts()
                                                .forEach(linkedAccount -> {
                                                    if (isBillingsNotNull.get()) {
                                                        return; // Dès qu'on trouve une excludingTax != 0, on veut écrire le header.
                                                    }
                                                    isBillingsNotNull.set(
                                                            linkedAccount.getInvoiceLines()
                                                                    .stream()
                                                                    .anyMatch(line -> line.getExcludingTaxAmount() != 0)
                                                    );
                                                });
                                        if (isBillingsNotNull.get()) {
                                            return;
                                        }
                                        contractDto.getContractInvoiceLines()
                                                .forEach(contractInvoiceLine -> {
                                                    if (isBillingsNotNull.get()) {
                                                        return;
                                                    }
                                                    isBillingsNotNull.set(
                                                            contractInvoiceLine.getExcludingTaxAmount() != 0 || isBillingsNotNull.get()
                                                    );
                                                });
                                    });
                                if (!isTotalBillingNotNull && !isBillingsNotNull.get()) {
                                    log.info("Skipping invoice {} : total amount and all line amounts equals 0",
                                            invoiceEntity.getInvoiceNumber());
                                    excludedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Skipping invoice: total amount and all line amounts equals 0", null));
                                    return Mono.empty();
                                }
                                return Mono.just(pair);
                            })
                            .collectList()
                            .block();
            String firstInvoice = "";
            String lastInvoice = "";
            if (!ObjectUtils.isEmpty(validInvoicePairs)) {
                invoicesToWrite =  transformToInvoiceCoeurfinanceDto(
                        validInvoicePairs
                                .stream()
                                .map(this::getTotalAmountByCommandType)
                                .toList(), validInvoicesDto, validInvoices, failedInvoices);
            }
            if(ObjectUtils.isEmpty(invoicesToWrite)) {
                headersFile = generateHeadersFile(finalAmount, 0, firstInvoice, lastInvoice);
                csvWriter.writeAll(headersFile);
                csvWriter.flush();
            }
            else {
                firstInvoice = invoicesToWrite.get(0).getFirst().getInvoiceNo();
                lastInvoice = invoicesToWrite.size() > 1 ? invoicesToWrite.get(invoicesToWrite.size() - 1).getFirst().getInvoiceNo() : firstInvoice;
                headersFile = generateHeadersFile(finalAmount, invoicesToWrite.size(), firstInvoice, lastInvoice);
                csvWriter.writeAll(headersFile);
                csvWriter.flush();
                invoicesToWrite.forEach(pair -> {
                            var invoiceCoeurfinanceDto = pair.getFirst();
                            if (invoiceCoeurfinanceDto.getHeader().length != 0) {
                                csvWriter.writeNext(invoiceCoeurfinanceDto.getHeader());
                            }
                            csvWriter.writeAll(invoiceCoeurfinanceDto.getInvoiceContent());
                        }
                );
            }
        } catch (Exception e) {
            log.error("Couldn't export Coeur Finance file : {}", e.getMessage(), e);
        }
        return this.exportService.generateHistory(startTime, validInvoicesDto, validInvoices, failedInvoices, excludedInvoices, FileType.COEURFINANCE, this.fileName);
    }

    // Evolution liée a https://jira.net.extra.laposte.fr/jira/browse/BILLING-1177
    private Pair<InvoiceEntity,InvoiceDTO> getTotalAmountByCommandType(Pair<InvoiceEntity, InvoiceDTO> invoice) {
        double totalAmount = invoice.getSecond().getInvoiceHeader().getBillingAmount().getTotalAmount();
        switch (getCommandeType(invoice.getSecond().getInvoiceHeader())) {
            case Z001:
                finalAmount += totalAmount;
                break;
            case Z003:
                finalAmount -= Math.abs(totalAmount);
                break;
            default:
                break;
        }
        return invoice;
    }

    private void markInvoiceAsFailed(Exception e, String errorCode, String errorPlace, List<InvoiceExportDto> failedInvoices, InvoiceEntity invoiceEntity) {
        failedInvoices.add(new InvoiceExportDto(invoiceEntity.getIdInvoice(), invoiceEntity.getInvoiceNumber(), "Error when processing " + errorPlace + ": " + e.getMessage(), errorCode));
    }

    private List<String[]> generateHeadersFile(double finalAmount, int size, String firstInvoice, String lastInvoice) {
        List<String[]> headers = new ArrayList<>();

        String[] headerRoutage = {
                "HHH001",
                "SOCFCT",
                "i7aa",
                "epaa",
                "blg1aaaa.a3p" + dateUtil.yyyyMMddHHmm(), //index = 4
                "/EP/ECC/import/SOCFCT/treat",
                "ep.sd",
                Constant.EMPTY,
                "blg1aaaa.a3p" + dateUtil.yyyyMMddHHmm(), //index = 8
                Constant.EMPTY
        };

        Long sequenceNumber = fileSequenceRepository.incrementSequenceForCoeurfinance()
                .then(fileSequenceRepository.getCurrentSequenceForCoeurfinanceExport())
                .switchIfEmpty(Mono.error(new RuntimeException("No sequence number for Coeurfinance")))
                .block();
        String[] headerBordereau = {
                "BBB001",
                "SOCFCT",
                String.format("%010d", sequenceNumber),
                dateUtil.yyyyMMddHHmm(),
                dateUtil.yyyyMMddHHmm(),
                "    "
        };

        String invoiceRange = "";
        if (!("".equals(firstInvoice) && "".equals(lastInvoice))) {
            invoiceRange = firstInvoice + "-" + lastInvoice;
        }

        String[] headerMetier = {
                "MET001",
                df.format(finalAmount),
                String.format("%06d", size),
                invoiceRange
        };

        Collections.addAll(headers, headerRoutage, headerBordereau, headerMetier);
        return headers;

    }

    private List<Pair<InvoiceCoeurfinanceDto,Long>> transformToInvoiceCoeurfinanceDto(List<Pair<InvoiceEntity, InvoiceDTO>> validInvoicePairs, List<InvoiceDTO> validInvoicesDto, List<InvoiceExportDto> validInvoices, List<InvoiceExportDto> failedInvoices) {

        return validInvoicePairs.stream()
                .map(
                        pair -> {
                            var invoiceDto = pair.getSecond();
                            try {
                                String[] header = StringExportUtils.replaceNewLineChar(generateInvoiceHeader(invoiceDto, failedInvoices, pair.getFirst()));
                                List<String[]> lines = StringExportUtils.replaceNewLineChar(generateInvoiceLinesFromOneInvoice(invoiceDto, failedInvoices, pair.getFirst()));
                                double amount;
                                amount = Optional.ofNullable(invoiceDto.getInvoiceHeader().getBillingAmount().getTotalAmount()).orElse(0d);
                                validInvoicesDto.add(pair.getSecond());
                                validInvoices.add(new InvoiceExportDto(pair.getFirst().getIdInvoice(), pair.getFirst().getInvoiceNumber(), null, null));
                                return Optional.of(Pair.of(InvoiceCoeurfinanceDto.builder()
                                        .isExport(invoiceDto.isExport())
                                        .amount(amount)
                                        .header(header)
                                        .invoiceContent(lines)
                                        .invoiceNo(invoiceDto.getInvoiceHeader().getInvoiceNumber())
                                        .build(), pair.getFirst().getIdInvoice()));
                            } catch (Exception e) {
                                log.info("Failure for invoice {} : error while processing invoice: {}", pair.getFirst().getInvoiceNumber(), e.getMessage());
                                return Optional.<Pair<InvoiceCoeurfinanceDto, Long>>empty();
                            }
                        })
                .filter(Optional::isPresent)
                .map(Optional::get)
                .toList();
    }

    private List<String[]> generateInvoiceLinesFromOneInvoice(InvoiceDTO invoiceDto, List<InvoiceExportDto> failedInvoices, InvoiceEntity invoiceEntity) {
        try {
            final List<ContractDTO> contractsInvoice = invoiceDto.getContracts();
            List<String[]> linesFromInvoice = new ArrayList<>();
            contractsInvoice.forEach(contractDto ->
                    linesFromInvoice.addAll(generateInvoiceLinesFromOneContract(invoiceDto, contractDto))
            );
            if (invoiceDto.getAccountDetails() != null && (!invoiceDto.getAccountDetails().isEmpty())) {
                linesFromInvoice.addAll(fillAccountLines(invoiceDto, invoiceDto.getInvoiceHeader()));
            }
            if (!contractsInvoice.isEmpty()) {
                linesFromInvoice.addAll(fillContract1108FormInfo(contractsInvoice, invoiceDto.getInvoiceHeader()));
            }
            if (invoiceDto.getInvoiceHeader().getScheduledPayment() != null && !invoiceDto.getInvoiceHeader().getScheduledPayment().isEmpty()) {
                linesFromInvoice.addAll(fillScheduledPayment(invoiceDto.getInvoiceHeader()));

            }

            return linesFromInvoice;
        }catch (Exception e) {
            log.info("Failure for invoice {} : error when processing invoice lines: {}",
                    invoiceDto.getInvoiceHeader().getInvoiceNumber(), e.getMessage());
            markInvoiceAsFailed(e, "U170010", "invoice line", failedInvoices, invoiceEntity);
            throw e;
        }
    }

    private List<String[]> generateInvoiceLinesFromOneContract(InvoiceDTO invoiceDto, ContractDTO contractDto) {
        final var invoiceHeader = invoiceDto.getInvoiceHeader();
        String[] firstColumnsOfTheLine = {
                "LINE00",
                getCommandeType(invoiceHeader),
                Constant.EMPTY,
                invoiceDto.getInvoiceHeader().getInvoiceNumber(),
                resolveRefOrigine(invoiceHeader),
                invoiceDto.getCustomer().getCustomerInformation().getCustAccNumber(),

        };
        Predicate<InvoiceLineDTO> excludingTaxAmountLineIsNotNull = invoiceLineDto -> invoiceLineDto.getExcludingTaxAmount() != 0;

        List<String[]> invoiceLineslist =
                contractDto.getLinkedAccounts().stream()
                        .flatMap(linkedAccountDto -> linkedAccountDto.getInvoiceLines().stream())
                        .filter(excludingTaxAmountLineIsNotNull)
                        .map(invoiceLineDto -> ArrayUtils.addAll(firstColumnsOfTheLine, generateInvoiceLine(invoiceDto, contractDto, invoiceLineDto)))
                        .toList();

        List<String[]> contractInvoiceLineslist =
                contractDto.getContractInvoiceLines().stream()
                        .filter(contractInvoiceLineDto -> contractInvoiceLineDto.getExcludingTaxAmount() != 0)
                        .map(contractInvoiceLineDto -> ArrayUtils.addAll(firstColumnsOfTheLine, generateContractInvoiceLine(invoiceDto, contractDto, contractInvoiceLineDto)))
                        .toList();
        return Stream.of(invoiceLineslist, contractInvoiceLineslist)
                .flatMap(Collection::stream)
                .toList();
    }

    private List<String[]> fillAccountLines(InvoiceDTO invoiceDto, InvoiceHeaderDTO invoiceHeader) {
        return invoiceDto.getAccountDetails().stream()
                .map(accountDetailsDTO -> generateAccountLine(invoiceHeader, accountDetailsDTO))
                .toList();
    }

    private String[] generateInvoiceLine(InvoiceDTO invoiceDto, ContractDTO contractDto, InvoiceLineDTO invoiceLineDto) {
        return new String[]{
                invoiceLineDto.getType(),
                invoiceLineDto.getAccountingCode(),
                contractDto.getInvoiceContractInfo().getOpsCode(),
                String.valueOf(Math.abs(invoiceLineDto.getQuantity())),
                Constant.PC,//item unit pc
                // For the moment if we receive TYPE "R" for remise we put blank + by default type A if null
                Optional.ofNullable(invoiceLineDto.getDiscountedAccountingCode()).orElse(Constant.EMPTY),
                dfUnitPrice.format(invoiceLineDto.getUnitPrice()),
                df.format(invoiceLineDto.getExcludingTaxAmount()),
                formatVATRate(invoiceLineDto.getVatRate()),
                df.format(invoiceLineDto.getVatAmount()),
                invoiceLineDto.getVatCode(),
                Boolean.TRUE.equals(invoiceDto.getBillingAccount().getVatliabilityFlag()) ? "1" : "0",
                Constant.EMPTY,
                Optional.ofNullable(invoiceLineDto.getRegateCode()).orElse(DEFAULT_ZONE_DISTRIB),
                Optional.ofNullable(invoiceLineDto.getCoclicoEmitterCode())
                        .filter(coclicoEmitterCode -> !coclicoEmitterCode.equals(invoiceDto.getCustomer().getCustomerInformation().getCustAccNumber()))
                        .orElse(Constant.EMPTY),
                Constant.EMPTY,
                contractDto.getInvoiceContractInfo().getCreationChannel(),
                Constant.EMPTY,
                Optional.ofNullable(invoiceLineDto.getStampingCode()).orElse(Constant.EMPTY),
                Optional.ofNullable(contractDto.getInvoiceContractInfo().getStampingDeviceNumber())
                        .map(stampingDeviceNumber -> stampingDeviceNumber.replaceAll("\\s+", ""))
                        .orElse(Constant.EMPTY)

        };
    }

    private String[] generateContractInvoiceLine(InvoiceDTO invoiceDto, ContractDTO contractDto, ContractInvoiceLineDto contractInvoiceLineDto) {

        return new String[]{
                contractInvoiceLineDto.getType(),
                contractInvoiceLineDto.getAccountingCode(),
                contractDto.getInvoiceContractInfo().getOpsCode(),
                String.valueOf(Math.abs(contractInvoiceLineDto.getQuantity())),
                Constant.PC,//item unit pc
                // For the moment if we receive TYPE "R" for remise we put blank + by default type A if null
                Optional.ofNullable(contractInvoiceLineDto.getDiscountedAccountingCode()).orElse(Constant.EMPTY),
                dfUnitPrice.format(contractInvoiceLineDto.getUnitPrice()),
                df.format(contractInvoiceLineDto.getExcludingTaxAmount()),
                formatVATRate(contractInvoiceLineDto.getVatRate()),
                df.format(contractInvoiceLineDto.getVatAmount()),
                contractInvoiceLineDto.getVatCode(),
                Boolean.TRUE.equals(invoiceDto.getBillingAccount().getVatliabilityFlag()) ? "1" : "0",
                Constant.EMPTY,
                Optional.ofNullable(contractInvoiceLineDto.getRegateCode()).orElse(DEFAULT_ZONE_DISTRIB),
                Optional.ofNullable(contractInvoiceLineDto.getCoclicoEmitterCode())
                        .filter(coclicoEmitterCode -> !coclicoEmitterCode.equals(invoiceDto.getCustomer().getCustomerInformation().getCustAccNumber()))
                        .orElse(Constant.EMPTY),
                Constant.EMPTY,
                contractDto.getInvoiceContractInfo().getCreationChannel(),
                Constant.EMPTY,
                Optional.ofNullable(contractInvoiceLineDto.getStampingCode()).orElse(Constant.EMPTY),
                Optional.ofNullable(contractDto.getInvoiceContractInfo().getStampingDeviceNumber())
                        .map(stampingDeviceNumber -> stampingDeviceNumber.replaceAll("\\s+", ""))
                        .orElse(Constant.EMPTY)

        };
    }

    private String[] generateInvoiceHeader(InvoiceDTO invoiceDto, List<InvoiceExportDto> failedInvoices, InvoiceEntity invoiceEntity) {

        try{
        InvoiceHeaderDTO invoiceHeader = invoiceDto.getInvoiceHeader();

        boolean isDirectDebit = Optional.ofNullable(invoiceDto.getBillingAccount().getPaymentMeanCode()).orElse(Constant.EMPTY).equals(Constant.BANK_DIRECT_DEBIT);
        boolean isCreditCard = Optional.ofNullable(invoiceDto.getBillingAccount().getPaymentMeanCode()).orElse(Constant.EMPTY).equals(Constant.CREDIT_CARD);
        boolean isrefundableFlag = invoiceHeader.getRefundableFlag();
        List<ContractDTO> contracts = invoiceDto.getContracts();
            return new String[]{
                    "HEAD00",
                    getCommandeType(invoiceHeader),
                    Constant.EMPTY,
                    invoiceHeader.getInvoiceNumber(),
                    resolveRefOrigine(invoiceHeader),
                    invoiceDto.getCustomer().getCustomerInformation().getCustAccNumber(),
                    Constant.EMPTY,
                    dateUtil.yyyyMMdd(invoiceHeader.getBillingDate().getCalculationDate()),
                    dateUtil.yyyyMMdd(invoiceHeader.getBillingDate().getCalculationDate()),
                    dateUtil.yyyyMMdd(invoiceHeader.getBillingDate().getExpiryDate()),
                    getPaymentMode(isrefundableFlag,getCommandeType(invoiceHeader) ,invoiceDto),
                    dateUtil.yyyyMMdd((Boolean.TRUE.equals(invoiceHeader.getCreditFlag()) || Boolean.TRUE.equals(invoiceHeader.getDownpaymentFlag())) ? invoiceHeader.getBillingDate().getCalculationDate() : invoiceHeader.getBillingDate().getConsumptionRefDate()),
                    dateUtil.yyyyMMdd(invoiceHeader.getBillingDate().getStartDate()),
                    isDirectDebit ? getIBAN10Char(invoiceDto) : Constant.EMPTY,
                    isDirectDebit ? getIBAN2ndPart(invoiceDto) : Constant.EMPTY,
                    isDirectDebit ? getRibKey(invoiceDto) : Constant.EMPTY,
                    isDirectDebit ? invoiceDto.getBillingAccount().getUniqueMandateReference().getBic() : Constant.EMPTY,
                    isDirectDebit ? invoiceDto.getBillingAccount().getUniqueMandateReference().getIban() : Constant.EMPTY,
                    isDirectDebit ? invoiceDto.getBillingAccount().getUniqueMandateReference().getSignatoryLastName() : Constant.EMPTY,
                    Constant.EMPTY,
                    df.format(invoiceDto.getInvoiceHeader().getBillingAmount().getExcludingTaxNetTotalAmount()),
                    df.format(invoiceHeader.getBillingAmount().getTotalAmount()),
                    df.format(invoiceHeader.getBillingAmount().getVatTotalAmount()),
                    df.format(invoiceHeader.getBillingAmount().getAmountDue()),
                    Optional.ofNullable(invoiceDto.getCustomer().getCustomerInformation().getTypeCode()).orElse(Constant.EMPTY).equals("a") ? "0" : "1",
                    Constant.EMPTY,
                    Constant.EMPTY,
                    Constant.EMPTY,
                    Constant.EMPTY,
                    Constant.EMPTY,
                    Constant.EMPTY,
                    Constant.EMPTY,
                    isDirectDebit ? invoiceDto.getBillingAccount().getUniqueMandateReference().getRum() : Constant.EMPTY,
                    isCreditCard ? dateUtil.yyyyMMdd(invoiceDto.getInvoiceHeader().getPaymentCc().getPaymentCcDateTime()) : Constant.EMPTY,
                    isCreditCard ? Constant.ID_CONTRAT_CB : Constant.EMPTY,
                    isCreditCard ? invoiceDto.getInvoiceHeader().getPaymentCc().getPaymentCcId() : Constant.EMPTY,
                    Constant.EMPTY,
                    invoiceDto.getBillingAccount().getSectorCode(),
                    contracts.get(0).getInvoiceContractInfo().getSellerSector(),
                    Constant.EMPTY, //Groupe de vendeurs
                    Constant.EMPTY, //Centre de profit facturé
                    Constant.EMPTY, //Canal de distribution
                    Constant.EMPTY, //Position Données REFCOM
                    Constant.EMPTY, //Type de Position Données REFCOM
                    Constant.EMPTY, //Territoire Données REFCOM
                    Constant.EMPTY, //Type de Territoire Données REFCOM
                    Constant.EMPTY, //Equipe Données REFCOM
                    Constant.EMPTY, //Type Equipe Données REFCOM
                    Constant.EMPTY //Numéro de relevé Données REFCOM
            };
        }catch (Exception e) {
            log.info("Failure for invoice {} : error when processing invoice header: {}",
                    invoiceDto.getInvoiceHeader().getInvoiceNumber(), e.getMessage());
            markInvoiceAsFailed(e, "U170009", "invoice header", failedInvoices, invoiceEntity);
            throw e;
        }
        }

    private String[] generateAccountLine(InvoiceHeaderDTO invoiceHeader, AccountDetailsDTO detail) {
        return new String[]{
                "ACPT00",
                Optional.ofNullable(invoiceHeader.getInvoiceNumber()).orElse(Constant.EMPTY),
                Optional.ofNullable(detail.getAccountInvoiceNumber()).orElse(Constant.EMPTY),
                Optional.of(dateUtil.yyyyMMdd(detail.getAccountInvoiceCalculationDate())).orElse(Constant.EMPTY),
                Optional.of(df.format(detail.getAmountDue())).orElse(Constant.EMPTY)
        };
    }

    private String getPaymentMode(boolean isRefundableFlag, String commandeType, InvoiceDTO invoice) {
        String payMeanCode = invoice.getBillingAccount().getPaymentMeanCode();
        if (payMeanCode == null) {
            return Constant.EMPTY;
        }
        if (StringUtils.equals(commandeType, Z003)) {
            if (isRefundableFlag) {
                return switch (payMeanCode) {
                    case Constant.CASH_PAYMENT, Constant.DIRECT_PAYMENT, Constant.TRANSFER -> Constant.TRANSFER_VALUE_C;
                    case Constant.BANK_DIRECT_DEBIT -> Constant.TRANSFER_VALUE_V;
                    case Constant.CREDIT_CARD -> Constant.TRANSFER_VALUE_A;
                    default -> Constant.EMPTY;
                };
            } else {
                return Constant.TRANSFER_VALUE_P;
            }
        } else if (StringUtils.equals(commandeType, Z001) || StringUtils.equals(commandeType, Z005)) {
            // Si la commande a un bordereau 1108, on force paiement Z --> billing 3789
            boolean have1108 = haveInvoice1108(invoice);
            if (have1108) {
                return Constant.TRANSFER_VALUE_Z;
            }
            return switch (payMeanCode) {
                case Constant.CASH_PAYMENT, Constant.DIRECT_PAYMENT, Constant.TRANSFER -> Constant.TRANSFER_VALUE_Z;
                case Constant.BANK_DIRECT_DEBIT -> Constant.TRANSFER_VALUE_Q;
                case Constant.CREDIT_CARD -> Constant.TRANSFER_VALUE_B;
                default -> Constant.EMPTY;
            };
        }
        return Constant.EMPTY;
    }

    private Boolean haveInvoice1108 (InvoiceDTO invoice) {
        List <ContractDTO> contractsList = invoice.getContracts();
        return contractsList.stream().anyMatch(contractDTO ->
                contractDTO.getInvoiceContractInfo() != null &&
                        contractDTO.getInvoiceContractInfo().getContract1108FormInfo() != null);
    }

    private String formatVATRate(double vatNo) {
        return df.format(vatNo).replace(".", "");
    }

    private String getIBAN10Char(InvoiceDTO entity) {
        String iban = entity.getBillingAccount().getUniqueMandateReference().getIban();
        String rib = iban.substring(4);

        return iban.length() < 10 ? "" : rib.substring(0, 10);
    }

    private String getIBAN2ndPart(InvoiceDTO entity) {
        String iban = entity.getBillingAccount().getUniqueMandateReference().getIban();
        String rib = iban.substring(4);
        return iban.length() < 10 ? "" : rib.substring(10);
    }

    private String getRibKey(InvoiceDTO entity) {
        String iban = entity.getBillingAccount().getUniqueMandateReference().getIban();
        String rib = iban.substring(4);

        return iban.length() < 10 ? "" : rib.substring(rib.length() - 2);
    }

    private List<String[]> fillContract1108FormInfo(List<ContractDTO> contractsInvoice, InvoiceHeaderDTO invoiceHeader) {
        return contractsInvoice.stream()
                .filter(contractDTO -> contractDTO.getInvoiceContractInfo() != null
                        && contractDTO.getInvoiceContractInfo().getContract1108FormInfo() != null)
                .map(contractDTO -> generateContract1108Lines(contractDTO.getInvoiceContractInfo().getContract1108FormInfo(), invoiceHeader))
                .toList();
    }

    private String[] generateContract1108Lines(Contract1108FormInfoDTO contract1108FormInfoDTO, InvoiceHeaderDTO invoiceHeader) {
        return new String[]{
                "110800",
                Optional.ofNullable(invoiceHeader.getInvoiceNumber()).orElse(Constant.EMPTY),
                Optional.ofNullable(contract1108FormInfoDTO.getFormNumber()).orElse(Constant.EMPTY),
                contract1108FormInfoDTO.getPaymentDate() != null ? dateUtil.yyyyMMdd(contract1108FormInfoDTO.getPaymentDate().atStartOfDay(ZONE_ID).toInstant()) : Constant.EMPTY,
                contract1108FormInfoDTO.getPaidCashAmount() != null ? df.format(contract1108FormInfoDTO.getPaidCashAmount()) : Constant.EMPTY,
                Optional.ofNullable(contract1108FormInfoDTO.getRegateCode()).orElse(Constant.EMPTY),
        };
    }

    private List<String[]> fillScheduledPayment(InvoiceHeaderDTO invoiceHeader) {
        return invoiceHeader.getScheduledPayment()
                .stream()
                .map(scheduledPaymentDTO -> {
                    ScheduledPaymentTreatment scheduledPaymentTreatment = new ScheduledPaymentTreatment();
                    scheduledPaymentTreatment.setScheduledPaymentDate(scheduledPaymentDTO.getScheduledPaymentDate());
                    scheduledPaymentTreatment.setScheduledPaymentAmountIncludingVAT(scheduledPaymentDTO.getScheduledPaymentAmountIncludingVAT());
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE);
                    try {
                        scheduledPaymentTreatment.setDate(formatter.parse(scheduledPaymentDTO.getScheduledPaymentDate()).toInstant());
                    } catch (ParseException e) {
                        log.error("Error parsing scheduled payment date: {}", e.getMessage());
                    }
                    return scheduledPaymentTreatment;
                })
                .sorted(Comparator.comparing(ScheduledPaymentTreatment::getDate))
                .map(scheduledPayment -> generateScheduledPaymentLine(invoiceHeader, scheduledPayment))
                .toList();
    }

    private String[] generateScheduledPaymentLine(InvoiceHeaderDTO invoiceHeader, ScheduledPaymentTreatment scheduledPaymentTreatment) {
        DateTimeFormatter localFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return new String[]{
                "ECHE00",
                Optional.ofNullable(invoiceHeader.getInvoiceNumber()).orElse(Constant.EMPTY),
                Optional.ofNullable(dateUtil.yyyyMMddLocal(LocalDate.parse(scheduledPaymentTreatment.getScheduledPaymentDate(), localFormat))).orElse(Constant.EMPTY),
                Optional.of(df.format(scheduledPaymentTreatment.getScheduledPaymentAmountIncludingVAT())).orElse(Constant.EMPTY)
        };
    }

    private String resolveRefOrigine(InvoiceHeaderDTO invoiceHeader) {
        boolean isCredit = Boolean.TRUE.equals(invoiceHeader.getCreditFlag());
        double totalAmount = invoiceHeader.getBillingAmount() != null ? invoiceHeader.getBillingAmount().getTotalAmount() : 0d;
        if (isCredit || totalAmount < 0) {
            return invoiceHeader.getInvoiceAttachmentNumber();
        }
        return invoiceHeader.getInvoiceNumber();
    }
}
