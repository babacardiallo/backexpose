CREATE OR REPLACE
VIEW `contract_supervision_details` AS
    SELECT
        CONCAT(`co`.`contract_number`,
                `cv`.`amendment_number`,
                `cv`.`revision_number`) AS `id`,
        `co`.`contract_number` AS `contract_number`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `el`.`date_error` AS `first_error_date`,
        `el`.`error_message` AS `error_message`,
        `ii`.`invoice_address_number` AS `invoice_address_number`,
        `ii`.`dedicated_invoice_flag` AS `dedicated_invoice_flag`,
        `ii`.`invoice_periodicity_label` AS `invoice_periodicity_label`,
        `ii`.`sending_support_label` AS `sending_support_label`,
        `ii`.`payment_means` AS `payment_means`,
        `ii`.`rum` AS `rum`,
        `ii`.`cust_purchase_order_number` AS `cust_purchase_order_number`,
        `ii`.`contracting_cust_ref1` AS `contracting_cust_ref1`,
        `ii`.`market_number` AS `market_number`,
        `cv`.`contract_consolidated` AS `contract_consolidated`,
        `cv`.`offset_num_consolidated` AS `offset_num_consolidated`,
        `cv`.`partition_num_consolidated` AS `partition_num_consolidated`,
        `cv`.`contract_odc_json` AS `contract_odc_json`,
        `cv`.`offset_num` AS `offset`,
        `cv`.`partition_num` AS `partition`,
        `cv`.`category` AS `category`
    FROM
        ((((((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `invoice_information` `ii` ON ((`cv`.`id_invoice_information` = `ii`.`id_invoice_information`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        LEFT JOIN `legal_person` `lp` ON ((`lp`.`cust_acc_number` = `co`.`cust_acc_number`)))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`cv`.`amendment_number` = `el`.`amendment_number`)
            AND (`el`.`workflow_step` = 'SYNCHRONIZATION_CONTRACT'))))
    WHERE
        `vo`.`ops_code` IN (SELECT
                `offer_filter`.`ops_code`
            FROM
                `offer_filter`)