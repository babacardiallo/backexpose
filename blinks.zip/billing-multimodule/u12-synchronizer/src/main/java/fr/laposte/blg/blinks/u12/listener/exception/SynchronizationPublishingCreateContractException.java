package fr.laposte.blg.blinks.u12.listener.exception;

import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class SynchronizationPublishingCreateContractException extends SynchronizationContractException {

    /**
     * Constructs a new runtime exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this runtime exception's detail message.
     *
     * @param message               the detail message (which is saved for later retrieval
     *                              by the {@link #getMessage()} method).
     * @param cause                 the cause (which is saved for later retrieval by the
     *                              {@link #getCause()} method).  (A {@code null} value is
     *                              permitted, and indicates that the cause is nonexistent or
     *                              unknown.)
     * @param contractNumber
     * @param amendmentNumber
     * @param revisionNumber
     * @since 1.4
     */
    public SynchronizationPublishingCreateContractException(String message, Throwable cause, String contractNumber, Integer amendmentNumber, Integer revisionNumber, String opsCode, CodeErrorEnum codeError) {
        super(message, cause, ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_PUBLISHING_CREATE_CONTRACT, null, contractNumber, amendmentNumber, revisionNumber, null, opsCode, codeError);
    }
}
