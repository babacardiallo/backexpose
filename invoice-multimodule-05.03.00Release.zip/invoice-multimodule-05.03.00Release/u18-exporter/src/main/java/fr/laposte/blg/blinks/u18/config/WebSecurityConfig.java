package fr.laposte.blg.blinks.u18.config;

import fr.laposte.bscc.shared.jwt.filter.servlet.BypassBasicAuthIfAuthenticatedFilter;
import fr.laposte.bscc.shared.jwt.filter.servlet.JwtAuthorizationFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
import org.springframework.security.config.annotation.web.configurers.FormLoginConfigurer;
import org.springframework.security.config.annotation.web.configurers.HttpBasicConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    @Value("${fr.laposte.security.api.user}")
    String user;

    @Value("${fr.laposte.security.api.pwd}")
    String mdp;

    @Value("${fr.laposte.security.cors.allowed-origins}")
    List<String> allowedOrigins;

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring().requestMatchers(EndpointRequest.toAnyEndpoint());
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, JwtAuthorizationFilter jwtAuthorizationFilter, AuthenticationConfiguration authenticationConfiguration) throws Exception {
        BypassBasicAuthIfAuthenticatedFilter bypassBasicAuthFilter = new BypassBasicAuthIfAuthenticatedFilter(authenticationConfiguration.getAuthenticationManager());
        http.csrf(httpSecurityCsrfConfigurer -> {});
        http.httpBasic(HttpBasicConfigurer::disable);
        http.formLogin(FormLoginConfigurer::disable);
        http.cors(cors -> cors.configurationSource(request -> {
            CorsConfiguration configuration = new CorsConfiguration();
            configuration.setAllowedOrigins(allowedOrigins);
            configuration.setAllowedMethods(List.of("*"));
            configuration.setAllowedHeaders(List.of("*"));
            configuration.setAllowCredentials(true);
            return configuration;
        }));

        http.addFilterAt(bypassBasicAuthFilter, BasicAuthenticationFilter.class)
                .addFilterBefore(jwtAuthorizationFilter, BypassBasicAuthIfAuthenticatedFilter.class);
        http.authorizeHttpRequests(requests -> requests
                .requestMatchers("/v3/api-docs/**", "/configuration/ui", "/swagger-resources/**", "/configuration/**", "/swagger-ui.html", "/webjars/**", "/swagger-ui/**", "/actuator/**", "/heath/**", "/csrf/token").permitAll()
                .anyRequest().authenticated()
        );
        http.exceptionHandling(httpSecurityExceptionHandlingConfigurer ->
                httpSecurityExceptionHandlingConfigurer
                        .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))
        );
        return http.build();
    }

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(){

        UserDetails admin = User.builder()
                .username(user)
                .password(bCryptPasswordEncoder().encode(mdp))
                .authorities("ADMIN", "CONS")
                .build();

        return new InMemoryUserDetailsManager(admin);
    }


}
