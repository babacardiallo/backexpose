CREATE TABLE blg_invoice.rejected_invoice
(
    id_rejected_invoice              int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    invoice_number                   varchar(255),
    invoice_json                     json,
    error_code                       varchar(255),
    error_message                    text NOT NULL,
    status                           varchar(255),
    error_date                       datetime default CURRENT_TIMESTAMP NOT NULL,
    replayed_date                    datetime,
    work_flow_step                   varchar(255)
);