import fr.laposte.blg.blinks.lib.common.entities.organization.OrganizationEntity;
import fr.laposte.blg.blinks.u17.dto.organization.OrganizationDto;
import fr.laposte.blg.blinks.u17.mapper.OrganizationMapper;
import fr.laposte.blg.blinks.u17.mapper.OrganizationMapperImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;

@SpringBootTest(classes = {OrganizationMapper.class, OrganizationMapperImpl.class})
class OrganizationMapperTest {
    @Autowired
    private OrganizationMapper organizationMapper;

    @Test
    void organizationDtoToOrganizationEntityTest(){
        OrganizationDto organizationDto = OrganizationDto.builder()
                .code("201")
                .codeRegate("18510")
                .closingDate(LocalDate.now())
                .creationDate(LocalDate.now())
                .deactivationDate(LocalDate.now())
                .modificationDate(LocalDate.now()).build();
        OrganizationEntity organizationEntity = this.organizationMapper.organizationDtoToOrganizationEntity(organizationDto);
        Assertions.assertNotNull(organizationEntity);
        Assertions.assertEquals(organizationDto.getCode(), organizationEntity.getCode());
        Assertions.assertEquals(organizationDto.getCodeRegate(), organizationEntity.getCodeRegate());
        Assertions.assertEquals(organizationDto.getClosingDate(), organizationEntity.getClosingDate());
        Assertions.assertEquals(organizationDto.getCreationDate(), organizationEntity.getCreationDate());
        Assertions.assertEquals(organizationDto.getDeactivationDate(), organizationEntity.getDeactivationDate());
        Assertions.assertEquals(organizationDto.getModificationDate(), organizationEntity.getModificationDate());

    }
}
