package fr.laposte.blg.blinks.u14.utils;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class ExecutionTimeAdvice {

    @Around("@annotation(fr.laposte.blg.blinks.u14.utils.TrackExecutionTime)")
    public Object executionTime(ProceedingJoinPoint point) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object object = point.proceed();
        long endTime = System.currentTimeMillis();
        log.info("Class Name: " + point.getSignature().getDeclaringTypeName() +
                ". Method Name: " + point.getSignature().getName() +
                ". Time taken for execution is : " +
                (endTime - startTime) + "ms");
        return object;
    }
}
