package fr.laposte.blg.blinks.u12.apim;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper=false) //To avoid warning from maven
@Builder
@ToString
public class ApimException extends RuntimeException {
    String codeApim;
    String messageApim;
    String descriptionApim;

    @Override
    public String getMessage() {
        return messageApim;
    }
}
