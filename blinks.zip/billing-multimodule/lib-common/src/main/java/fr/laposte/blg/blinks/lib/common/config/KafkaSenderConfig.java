package fr.laposte.blg.blinks.lib.common.config;

import fr.laposte.bscc.billing.avro.Synchronization;
import jakarta.annotation.Resource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;

import java.util.Properties;

@Configuration
public class KafkaSenderConfig {

    @Resource(name = "kafkaConfig")
    Properties kafkaConfig;

    @Bean
    public KafkaSender<String, Synchronization> synchronizationKafkaSender() {
        SenderOptions<String, Synchronization> basicSenderOptions = SenderOptions.create(kafkaConfig);
        return KafkaSender.create(basicSenderOptions);
    }
}
