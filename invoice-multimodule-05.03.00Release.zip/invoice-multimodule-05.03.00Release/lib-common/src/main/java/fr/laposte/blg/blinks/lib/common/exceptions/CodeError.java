package fr.laposte.blg.blinks.lib.common.exceptions;

public enum CodeError {
    U16001,
    U16002,
    U16003,
    U16004,
    U16999
}
