package fr.laposte.blg.blinks.u10.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(name = "rejection_u2", schema = "rejection")
public class Event {
    @Id
    UUID id;
    @Column(name = "event_uuid")
    String eventUuid;
    @Column(name = "error_date")
    Instant errorDate;
    @Column(name = "error_code")
    String errorCode;
    @Column(name = "error_message")
    String errorMessage;
    @Column(name = "kafka_message")
    String kafkaMessage;
    @Column(name = "nb_retry")
    Integer nbRetry;
    @Column(name = "status")
    String replayStatus;
    @Column(name = "offset_message")
    Integer offset ;
    @Column(name = "partition")
    Integer partition;
    @Column(name = "contract_code")
    String contractCode;
    @Column(name = "cust_acc_number")
    String custAccNumber;
    @Column(name = "offer_code")
    String offerCode;
    @Column(name = "product_code")
    String productCode;
    @Column(name = "service_code")
    String serviceCode;
    @Column(name = "charge_code")
    String chargeCode;
    @Column(name = "analysis")
    String analysis;
    @Column(name = "solution")
    String solution;

}
