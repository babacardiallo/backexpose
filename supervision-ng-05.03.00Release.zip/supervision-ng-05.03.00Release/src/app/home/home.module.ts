import { NgModule } from '@angular/core';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { SharedModule } from '../shared/shared.module';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { DataTableComponentComponent } from './data-table-component/data-table-component.component';
import { TotauxComponent } from './totaux/totaux.component';
import { CardHoverDirective } from './totaux/directives/card-hover.directive';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { NgxPermissionsModule } from 'ngx-permissions';



@NgModule({
    imports: [
        SharedModule,
        HomeRoutingModule,
        NgxDatatableModule,
        NgxSkeletonLoaderModule,
        NgxPermissionsModule.forChild()
    ],
    declarations: [HomeComponent, DataTableComponentComponent, TotauxComponent, CardHoverDirective],
    exports: [HomeComponent]
})
export class HomeModule { }
