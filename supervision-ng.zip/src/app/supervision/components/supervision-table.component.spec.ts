import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupervisionTableComponent } from './supervision-table.component';

describe('SupervisionTableComponent', () => {
  let component: SupervisionTableComponent;
  let fixture: ComponentFixture<SupervisionTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupervisionTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupervisionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
