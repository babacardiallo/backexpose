package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractSequenceElection;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface ContractSequenceElectionRepository extends ReactiveCrudRepository<ContractSequenceElection, String> {

    @Query("SELECT current_sequence FROM contract_sequence_election limit 1")
    Mono<Long> getCurrentSequenceContract();

    @Modifying
    @Query("UPDATE contract_sequence_election SET current_sequence = current_sequence + 1")
    Mono<Integer> incrementSequenceContract();
}
