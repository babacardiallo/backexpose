package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
public class ExportProcessService {

    @Autowired
    private ExportProcessRepository exportProcessRepository;

    public Flux<ExportProcess> getAllProcesses(){
        return this.exportProcessRepository.findAll();
    }
}
