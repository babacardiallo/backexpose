package fr.laposte.blg.blinks.u14.service;


import fr.laposte.blg.blinks.lib.common.entities.repositories.*;
import fr.laposte.blg.blinks.u14.controller.dto.StatDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class StatService {

    private final OfferFilterRepository offerFilterRepository;
    private final ContractVersionRepository contractVersionRepository;
    private final LegalPersonRepository legalPersonRepository;
    private final ErrorLogRepository errorLogRepository;
    private final ContractRepository contractRepository;

    private static final String  OFFER_SUPERVISION_LABEL="Nombre d'offres ouvertes à la synchronisation";
    private static final String  CONTRACT_SUPERVISION_LABEL="Nombre de contrats synchronisés";
    private static final String  CONTRACT_VERSION_SUPERVISION_LABEL="Nombre de versions de contrats synchronisées";
    private static final String  CUSTOMER_SUPERVISION_LABEL="Nombre de clients en base";
    private static final String  ERROR_SUPERVISION_LABEL="Nombre d'erreurs de synchronisation en cours";
    private static final String  CONTRACT_INTEGRATED_SUPERVISION_LABEL="Nombre de contrats intégrés";
    private static final String  CONTRACT_VERSION_INTEGRATED_SUPERVISION_LABEL="Nombre de versions de contrats intégrées";


    public Mono<StatDto[]> getTotaux(){
        return Mono.zip(
            offerFilterRepository.countOffers(),
            contractRepository.countContractsSynchronized(),
            contractVersionRepository.countVersionsSynched(),
            errorLogRepository.countSynchronisationError(),
            legalPersonRepository.countLegalPerson(),
            contractRepository.countContractsIntegrated(),
            contractVersionRepository.countContractVersionIntegrated()
        ).flatMap(tuple7 -> Mono.just(
            new StatDto[]{
                new StatDto(0, OFFER_SUPERVISION_LABEL, tuple7.getT1()),
                new StatDto(1, CONTRACT_SUPERVISION_LABEL, tuple7.getT2()),
                new StatDto(2, CONTRACT_VERSION_SUPERVISION_LABEL, tuple7.getT3()),
                new StatDto(3, ERROR_SUPERVISION_LABEL, tuple7.getT4()),
                new StatDto(4, CUSTOMER_SUPERVISION_LABEL, tuple7.getT5()),
                new StatDto(5, CONTRACT_INTEGRATED_SUPERVISION_LABEL, tuple7.getT6()),
                new StatDto(6, CONTRACT_VERSION_INTEGRATED_SUPERVISION_LABEL, tuple7.getT7())
            }
        ));
    }

}
