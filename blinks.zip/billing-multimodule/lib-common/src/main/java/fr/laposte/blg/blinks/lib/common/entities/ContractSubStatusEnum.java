package fr.laposte.blg.blinks.lib.common.entities;

public enum ContractSubStatusEnum {

    //TODO A compléter ou pas car on peut refuser les contrats n'entrant pas dans cette liste
    //voir EnumSet
    EN_COURS_DE_CREATION,
    EDITE,
    A_VALIDER,
    SIGNE,
    VALIDE,
    DEMANDE_DE_RESILIATION,
    ECHU,
    EN_COURS_DE_RENOUVELLEMENT,
    RESILIE,
    TERMINE,
    RENOUVELE,
    ANNULE,
    AVENANT,
    //Sous-statuts obsolétes (Phare) mais avec lequel certains contrats sont encore présent
    EN_ATTENTE_SIGNATURE_CLIENT,
    EN_ATTENTE_SIGNATURE_POSTE


}
