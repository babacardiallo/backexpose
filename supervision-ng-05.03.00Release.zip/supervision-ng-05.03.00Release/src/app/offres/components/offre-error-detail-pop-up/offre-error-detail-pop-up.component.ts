import { Component, OnInit, ViewChild, ViewEncapsulation, OnDestroy } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ErrorOfferBean } from '../../models/error-offer.model';
import { OffresTable } from '../../models/offres-table.model';
import { OffresTableService } from '../../service/offres-table.service';
import { DatePipe } from "@angular/common";
import { ModalService } from 'ngx-modal-ease';

export class OffreErrorDetailPopUpModel {
  offre: OffresTable;
  typeError: string;
}

@Component({
    selector: 'app-offre-error-detail-pop-up',
    templateUrl: './offre-error-detail-pop-up.component.html',
    styleUrls: ['./offre-error-detail-pop-up.component.scss'],
    standalone: false
})
export class OffreErrorDetailPopUpComponent implements OnInit, OnDestroy {
  @ViewChild(DatatableComponent) table: DatatableComponent;

  offre: OffresTable;
  typeError: string;
  typeErrorHtml: string;
  listErrors: ErrorOfferBean[] = [];
  filtered: ErrorOfferBean[];
  name = 'OffreErrorDetailPopUpComponent';

  constructor(private offreService: OffresTableService, private datePipe: DatePipe, private modalService: ModalService) {
  }

  ngOnInit(): void {
    if (!(this.offre.codeOps == null || this.offre.codeOps == undefined)
    ) {
      this.getErrors(this.offre.codeOps.toString(), this.typeError);
    } else {
      console.log("code ops null ou undifined");
    }
  }

  ngOnDestroy(): void {
    this.offreService.ngUnsubscribe$.next();
    this.offreService.ngUnsubscribe$.complete();
  }

  getErrors(code: string, typeError: string) {
    this.offreService.getErrorsbyOfferAndTypeError(code, typeError)
      .subscribe({
        next: (response: any) => {
          this.listErrors = response.map((data: any) => {
            return <ErrorOfferBean>{
              contractNumber: data.contractNumber,
              revisionNumber: data.revisionNumber,
              amendmentNumber: data.amendmentNumber,
              dateError: new Date(data.dateError * 1000),
              firstErrorDate: new Date(data.firstErrorDate * 1000),
              isSynchronized: data.isSynchronized,
              previousDateSynchronization: data.previousDateSynchronization,
              workflowStep: data.workflowStep,
              errorMessage: data.errorMessage,
              codeOps: data.codeOps
            };
          })
          this.filtered = this.listErrors;
        },
        complete: () => {
          if (typeError === "SYNCHRONIZATION_%") {
            this.typeErrorHtml = "de synchronisation";
          } else {
            this.typeErrorHtml = "d'intégration";
          }
        }
      });
  }

  updateFilter(event: Event) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value.toLowerCase();
    this.listErrors = this.filtered.filter(function (item: any) {
      if (item.contractNumber.toLowerCase().indexOf(val) !== -1 ||
        (item.dateError + "").indexOf(val) !== -1 ||
        (item.errorCode + "").toLowerCase().indexOf(val) !== -1 ||
        !val) {
        return true;
      }
    });
    this.table.offset = 0;
  }

  formatDateErrors(date: number): string | null {

    return this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr');

  }

  close(){
    this.modalService.close(this.name);
  }
}
