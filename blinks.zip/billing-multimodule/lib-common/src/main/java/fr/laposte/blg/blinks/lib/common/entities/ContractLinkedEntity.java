package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table("contract_linked")
@Data
public class ContractLinkedEntity {
    @Id
    @Column("id_contract")
    private Long idContract;

    @Column("linked_contract_number")
    private String linkedContractNumber;
    @Column("linked_contract_id")
    private Long linkedContractId;
    @Column("link_type")
    private String linkType;

    @Transient
    private ContractEntity linkedContract;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContractLinkedEntity that = (ContractLinkedEntity) o;
        return Objects.equals(idContract, that.idContract) &&
            Objects.equals(linkedContractNumber, that.linkedContractNumber) &&
            Objects.equals(linkType, that.linkType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idContract, linkedContractNumber, linkType);
    }
}
