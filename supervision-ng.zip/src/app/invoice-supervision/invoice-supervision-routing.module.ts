import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { InvoiceSupervisionComponent } from './invoice-supervision.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: InvoiceSupervisionComponent}
        ])],
    exports: [RouterModule]
})
export class InvoiceSupervisionRoutingModule { }
