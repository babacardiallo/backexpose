package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.ContractEntity;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractVersionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.u14.controller.dto.ReplayOfferReportDto;
import fr.laposte.blg.blinks.u14.controller.dto.ReplayReportDto;
import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class ReplayerSyncService {

    private final QueueService queueService;
    private final ContractService contractService;
    private final LegalPersonService legalPersonService;

    private final ContractRepository contractRepository;

    private final OfferFilterRepository offerFilterRepository;

    private final ContractVersionRepository contractVersionRepository;

    public Mono<Long> replayContractSynchronization(String contractNumber, Instant dateSynchronizationExpected, ActionEnum action) {

        return contractService.findContractByContractNumberWithVersions(contractNumber, true)
            .switchIfEmpty(Mono.error(new RuntimeException("Contract " + contractNumber + " not found !")))
            .flatMap(contractEntity ->
                Mono.justOrEmpty(contractEntity.getContractVersionEntities())
                    .flatMapMany(Flux::fromIterable)
                    .filterWhen(contractVersionEntity -> contractVersionRepository.ifOfferContractIsOpenForSynchronisation(contractVersionEntity.getIdValuedOffer())
                        .map(countOpsCode -> countOpsCode > 0))
                    .flatMap(contractVersionEntity -> {
                        contractVersionEntity.setSynchronized(false);
                        return contractService.save(contractVersionEntity);
                    })
                    .count()
                    .zipWith(Mono.just(contractEntity))
            )
            .flatMap(nbVersionUnlockedAndContractEntity
                -> {
                if(nbVersionUnlockedAndContractEntity.getT1() >0){
                    return queueService.enQueueContract(nbVersionUnlockedAndContractEntity.getT2().getIdContract()
                            , dateSynchronizationExpected
                            , action)
                        .thenReturn(nbVersionUnlockedAndContractEntity.getT1());
                } else {
                    return Mono.just(0L);
                }
            });

    }

    public Mono<ReplayReportDto> replayAllContractSynchronization(Instant dateSynchronizationExpected, ActionEnum action) {
        var report = new ReplayReportDto();
        var totalCounter = new AtomicLong();
        return contractService.findAllContractVersionsAlreadySynced()
            .filterWhen(contractVersionEntity -> contractVersionRepository.ifOfferContractIsOpenForSynchronisation(contractVersionEntity.getIdValuedOffer())
                .map(countOpsCode -> countOpsCode > 0))
            .flatMap(contractVersionEntity -> {
                contractVersionEntity.setSynchronized(false);
                return contractService.save(contractVersionEntity)
                        .flatMap(this::loadContract)
                        .map(ContractVersionEntity::getContract)
                    .onErrorResume(throwable -> {
                        report.getMapErrors().put(contractVersionEntity.getIdContract().toString(), throwable.getMessage());
                        report.getNbErrors().incrementAndGet();
                        return Mono.empty();
                    })
                    ;
            })
            .distinct()
            .doOnNext(contractLoaded -> {
                report.getListSuccess().add(contractLoaded.getContractNumber());
                totalCounter.incrementAndGet();
            })
            .flatMap(contractLoaded1
                -> queueService.enQueueContract(contractLoaded1.getIdContract()
                , dateSynchronizationExpected
                , action)
                .onErrorResume(throwable -> {
                    report.getMapErrors().put(contractLoaded1.getIdContract().toString(), throwable.getMessage());
                    return Mono.empty();
                })
            )
            .count()
            .map(nbSuccess -> {
                report.getNbSuccess().set(nbSuccess);
                report.getNbErrors().set(report.getMapErrors().size());
                report.setNbTotal(totalCounter.get());
                return report;
            });

    }

    public Mono<LegalPersonEntity> replayLegalPersonSynchronization(Integer coclico, Instant dateSynchronizationExpected, Boolean refcomReplay) {
        return legalPersonService.findLegalPersonByCoclico(coclico, false)
            .switchIfEmpty(Mono.error(new RuntimeException("Legal person " + coclico + " not found !")))
            .map(legalPersonEntity -> legalPersonEntity.setSynchronized(false))
            .flatMap(legalPersonEntity -> legalPersonService.save(legalPersonEntity, false))
                .flatMap(legalPersonEntity ->
                        queueService.enQueueCustomerByIdLegalPerson(legalPersonEntity.getIdLegalPerson()
                                        , dateSynchronizationExpected
                                        , ActionEnum.update
                                        , refcomReplay)
                                .thenReturn(legalPersonEntity)
                );
    }

    public Mono<ReplayReportDto> replayAllClientsSynchronization(Instant dateSynchronizationExpected, Boolean refcomReplay) {
        var report = new ReplayReportDto();
        var totalCounter = new AtomicLong();
        return legalPersonService.findAllClients()
                .flatMap(legalPersonEntity -> {
                    legalPersonEntity.setSynchronized(false);
                    return legalPersonService.save(legalPersonEntity, false);
                })
                .distinct()
                .doOnNext(legalPersonEntity -> {
                    report.getListSuccess().add(legalPersonEntity.getCustAccNumber().toString());
                    totalCounter.incrementAndGet();
                })
                .flatMap(legalPersonEntity
                        -> queueService.enQueueCustomerByIdLegalPerson(legalPersonEntity.getIdLegalPerson()
                                , dateSynchronizationExpected
                                , ActionEnum.update
                                , refcomReplay)
                        .onErrorResume(throwable -> {
                            report.getMapErrors().put(legalPersonEntity.getIdLegalPerson().toString(), throwable.getMessage());
                            return Mono.empty();
                        })
                )
                .count()
                .map(nbSuccess -> {
                    report.getNbSuccess().set(nbSuccess);
                    report.getNbErrors().set(report.getMapErrors().size());
                    report.setNbTotal(totalCounter.get());
                    return report;
                });
    }

    public Mono<ReplayOfferReportDto> replayContractSynchronizationByOffer(ActionEnum action, Instant dateSynchronizationExpected, List<String> offers, ReplayOfferReportDto report) {
        var totalCounter = new AtomicLong();

        return
            Flux.fromIterable(offers)
                .filterWhen(x-> this.isOfferSynchronised(x, report))
                .concatMap(opsCode ->
                            contractRepository.getContractVersionByOpsCode(opsCode)
                                .flatMap(contractVersionEntity -> {
                                    contractVersionEntity.setSynchronized(false);
                                    return
                                        contractService.save(contractVersionEntity)
                                                .flatMap(contractVersion -> contractService.findContractByIdContract(contractVersion.getIdContract()))
                                                .map(ContractEntity::getContractNumber)
                                            .onErrorContinue((throwable, i)  -> {
                                                report.getMapErrors().put(Mono.just(0).toString(), throwable.getMessage());
                                                report.getNbErrors().incrementAndGet();
                                            });
                                })
                        )
            .distinct()
            .doOnNext(contractNumber -> {
                totalCounter.incrementAndGet();
                report.getListSuccess().add(contractNumber);
            })
            .flatMap(contractNumber
                -> queueService.enQueueContract(contractNumber
                    , dateSynchronizationExpected
                    , action)
                .onErrorResume(throwable -> {
                    report.getMapErrors().put(contractNumber, throwable.getMessage());
                    return Mono.empty();
                })
            )
            .count()
            .map(nbSuccess -> {
                report.getNbSuccess().set(nbSuccess);
                report.getNbErrors().set(report.getMapErrors().size());
                report.setNbTotal(totalCounter.get());
                return report;
            });
    }

    public Mono<Boolean> isOfferSynchronised(String opsCode, ReplayOfferReportDto report) {
        return this.offerFilterRepository.findFirstByOpsCode(opsCode).hasElement()
            .map(isSynchronised -> {
                if(isSynchronised) {
                    log.info("--> offer : "+ opsCode +" synchronized");
                    report.getNumberSuccessOffers().set(report.getNumberSuccessOffers().intValue() + 1);
                    report.getOffersSynch().add(opsCode.toString());
                    return true;
                }
                else{
                    log.info("--> offer : "+ opsCode +" not synchronized");
                    report.getNumberKoOffers().set(report.getNumberKoOffers().intValue() + 1);
                    report.getOffersNotSynch().add(opsCode.toString());
                    return false;
                }
                });
    }

    public Mono<ReplayReportDto> replayAllContracts(Instant dateSynchronizationExpected, ActionEnum action) {
        var report = new ReplayReportDto();
        var totalCounter = new AtomicLong();
        return contractVersionRepository.findContractsVersionEligibleForSynchronisation()
            .flatMap(contractVersionEntity -> {
                contractVersionEntity.setSynchronized(false);
                return contractService.save(contractVersionEntity)
                    .flatMap(this::loadContract)
                        .map(ContractVersionEntity::getContract)
                    .onErrorResume(throwable -> {
                        report.getMapErrors().put(contractVersionEntity.getIdContract().toString(), throwable.getMessage());
                        report.getNbErrors().incrementAndGet();
                        return Mono.empty();
                    })
                    ;
            })
            .distinct()
            .doOnNext(contractLoaded -> {
                report.getListSuccess().add(contractLoaded.getContractNumber());
                totalCounter.incrementAndGet();
            })
            .flatMap(contractLoaded1
                -> queueService.enQueueContract(contractLoaded1.getIdContract()
                    , dateSynchronizationExpected
                    , action)
                .onErrorResume(throwable -> {
                    report.getMapErrors().put(contractLoaded1.getIdContract().toString(), throwable.getMessage());
                    return Mono.empty();
                })
            )
            .count()
            .map(nbSuccess -> {
                report.getNbSuccess().set(nbSuccess);
                report.getNbErrors().set(report.getMapErrors().size());
                report.setNbTotal(totalCounter.get());
                return report;
            });

    }

    public Mono<ContractVersionEntity> loadContract(ContractVersionEntity contractVersionEntity) {

        Mono<ContractEntity> contractEntityMono = Mono.justOrEmpty(contractVersionEntity.getIdContract())
                .flatMap(contractRepository::findById);

        return contractEntityMono.map(
                contractVersionEntity::setContract
        );
    }

    public Mono<ReplayReportDto> replayListOfCustomer(List<Integer> coclicos, Instant replayDate, boolean refcomReplay, ReplayReportDto reportDto) {
        return Flux.fromIterable(coclicos)
                .flatMap(coclico -> replayLegalPersonSynchronization(coclico, replayDate, refcomReplay)
                        .onErrorResume(t -> {
                            log.error("Error during the replay of the customer {}", t.getMessage());
                            reportDto.getNbErrors().incrementAndGet();
                            reportDto.getMapErrors().put(coclico.toString(), t.getMessage());
                            return Mono.empty();
                        }))
                .doOnNext(s -> reportDto.getListSuccess().add(s.getCustAccNumber().toString()))
                .count()
                .map(legalPersonsReplayed -> {
                    reportDto.getNbSuccess().set(legalPersonsReplayed);
                    return reportDto;
                });
    }

    public Mono<ReplayReportDto> replayListOfContracts(List<String> contractNumbers, Instant replayDate, ActionEnum actionEnum,  ReplayReportDto reportDto){
        return Flux.fromIterable(contractNumbers)
                .flatMap(contractNumber -> replayContractSynchronization(contractNumber, replayDate, actionEnum)
                        .map(nbReturned -> {
                            if(nbReturned == 0L){
                                reportDto.getNbErrors().incrementAndGet();
                                reportDto.getMapErrors().put(contractNumber, "Contract on closed offer");
                                return "noContract";
                            } else {
                                return contractNumber;
                            }
                        })
                        .onErrorResume(t -> {
                            log.error("Error during the replay of the contract {}", t.getMessage());
                            reportDto.getNbErrors().incrementAndGet();
                            reportDto.getMapErrors().put(contractNumber, t.getMessage());
                            return Mono.empty();
                        }))
                .filter(contractNumber -> !contractNumber.equals("noContract"))
                .doOnNext(s -> reportDto.getListSuccess().add(String.valueOf(s)))
                .count()
                .map(contractsReplayed -> {
                    reportDto.getNbSuccess().set(contractsReplayed);
                    return reportDto;
                });
    }
}
