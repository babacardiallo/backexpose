package fr.laposte.blg.blinks.u16.controller.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.server.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
public class CsrfTokenController {
    @GetMapping("/csrf/token")
    public Mono<String> getCsrfToken(ServerWebExchange exchange) {
        Mono<CsrfToken> csrfToken = exchange.getAttribute(CsrfToken.class.getName());
        return Mono.zip(csrfToken, exchange.getSession())
                .map(tuple -> {
                    log.info("session ID: {}", tuple.getT2().getId());
                    log.info("token ID: {}", tuple.getT1().getToken());
                    return tuple.getT1().getToken();
                });
    }
}