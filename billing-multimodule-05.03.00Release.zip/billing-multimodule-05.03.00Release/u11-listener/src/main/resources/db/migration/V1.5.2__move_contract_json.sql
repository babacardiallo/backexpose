CREATE TABLE contract_message (
    id_contract_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract INT UNSIGNED default null,
    contract_information JSON,
    CONSTRAINT fk_contract_message_contract FOREIGN KEY (id_contract) REFERENCES blg_contract_importer.contract (id_contract) ON DELETE CASCADE ON UPDATE RESTRICT
);
