package fr.laposte.blg.blinks.u16.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u16.service.SeresReplayService;
import fr.seres.avro.laposte.paktole.invoicing.PaktoleResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Data
@Slf4j
@ConfigurationProperties(prefix = "fr.laposte.invoice.listener.seres-replay.canal-suez")
@ConditionalOnProperty(value = "fr.laposte.invoice.listener.seres-replay.activated", havingValue = "true")
public class SeresReplayListener {
    // Nom du topic à consommer
    String kafkaTopic;
    // Groupe de consommation
    String kafkaGroupId;

    private final SeresReplayService seresReplayService;
    private final ObjectMapper objectMapper;
    public SeresReplayListener( SeresReplayService seresReplayService, ObjectMapper objectMapper) {
        this.seresReplayService = seresReplayService;
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", kafkaTopic);
        log.info("Kafka groupId: {}", kafkaGroupId);
        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", kafkaTopic, kafkaGroupId);
    }


    @KafkaListener(groupId = "${fr.laposte.invoice.listener.seres-replay.canal-suez.kafka-group-id}", topics = "${fr.laposte.invoice.listener.seres-replay.canal-suez.kafka-topic}")
    public void onMessages(List<ConsumerRecord<String, PaktoleResponse>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} seres(s) from topic '{}'", total, kafkaTopic);
        AtomicInteger errorCount = new AtomicInteger(0);
        try {
            Flux.fromIterable(records)
                    .concatMap(message -> {
                        log.info("Record received: key={}, topic={}, partition={}, offset={}",
                                message.key(), message.topic(), message.partition(), message.offset());
                        return seresReplayService.saveSeresReplay(message.value())
                                .onErrorResume(exception -> {
                                    errorCount.incrementAndGet();
                                    var errorMessage = String.format("Error on Seres Listener on seres: %s", message.key());
                                    log.error(errorMessage, exception);
                                    return Mono.empty();
                                });
                    })
                    .then()
                    .block();
            if (errorCount.get() > 0) {
                log.warn("Batch processing failed with {} errors — retrying individually {} records ))",
                        errorCount.get(), total);
                retryIndividually(records, ack);
            } else {
                ack.acknowledge();
                log.info("Batch processed and acknowledged successfully");
            }
        } catch (Exception error) {
            log.error("Unexpected error during batch processing — retrying individually ({} record(s))", total, error);
            retryIndividually(records, ack);
        }
    }



    private void retryIndividually(List<ConsumerRecord<String, PaktoleResponse>> records, Acknowledgment ack) {
        Flux.fromIterable(records)
                .concatMap(message -> seresReplayService.saveSeresReplay(message.value())
                        .doOnSuccess(c -> {
                            log.info("Seres key: {} is acknowledged successfully", message.key());
                            ack.acknowledge();
                        })
                        .doOnError(e -> log.error("Error processing seres key={}", message.key(), e))
                        .onErrorResume(throwable -> Mono.empty())
                )
                .then()
                .block();
    }
}
