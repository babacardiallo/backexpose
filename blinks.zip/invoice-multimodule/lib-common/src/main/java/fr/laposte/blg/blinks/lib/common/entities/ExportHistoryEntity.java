package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("export_history")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ExportHistoryEntity {

    @Id
    @Column("id")
    private Long idExport;

    @Column("file_type")
    private FileType fileType;

    @Column("file_name")
    private String fileName;

    @Column("start_date")
    private Instant startDate;

    @Column("file_date")
    private Instant date;

    @Column("message_count")
    private Integer messageCount;

    @Column("nb_invoices_exported_in_file")
    private Integer nbInvoiceExportedInFile;

    @Column("nb_normal_invoices")
    private Integer nbNormalInvoices;

    @Column("nb_acomptes")
    private Integer nbAcomptes;

    @Column("nb_avoirs")
    private Integer nbAvoirs;

    @Column("nb_releves")
    private Integer nbReleves;

    @Column("ca_ht_hors_releves_and_acomptes")
    private Double caHtHorsRelevesAndAcomptes;

    @Column("ca_ttc_hors_releves_and_acomptes")
    private Double caTtcHorsRelevesAndAcomptes;

    /**
     * Duration in ms units
     */
    @Column("export_duration")
    private Long exportDuration;

    @Column("export_status")
    private ExportStatus ExportStatus;

    @Column("comment")
    private String comment;

    @Column("is_file_empty")
    private Boolean isFileEmpty;

    @Column("is_file_sent")
    private Boolean isFileSent;

    @Column("file_send_date")
    private Instant fileSendDate;

    @Column("nb_excluded_invoices")
    private Integer nbExcludedInvoices;

    @Column("nb_failed_invoices")
    private Integer nbFailedInvoices;

    @Column("transfer_status")
    private TransferStatus transferStatus;

    @Column("transfer_error_message")
    private String transferErrorMessage;

    @Column("transfer_error_code")
    private String transferErrorCode;
}
