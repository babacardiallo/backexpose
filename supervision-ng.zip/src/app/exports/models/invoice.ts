export class Invoice {
    id: number = 0;
    invoiceNumber : string='';
    message : string='';
    billRunId : string='';
    docapostExportId : number=0;
    infocaExportId : number=0;
    equinoxExportId : number=0;
    custAccNumber?: string='';
    printFlag: string='';
}
  