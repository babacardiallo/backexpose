package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonPropertyOrder({
        "consumerAccountCode",
        "clientAccountCode",
        "externalReference",
        "excludingTaxTotalAmount",
        "accountAddress",
        "serviceEstablishments",
        "deliveryAddresses",
        "invoiceLines"
})
public class LinkedAccountDTO {

    String consumerAccountCode;
    String clientAccountCode;
    String externalReference;
    Double excludingTaxTotalAmount;
    AccountAdressDto accountAddress;
    @JacksonXmlElementWrapper(localName = "serviceEstablishments")
    @JacksonXmlProperty(localName = "serviceEstablishment")
    List<ServiceEstablishmentDto> serviceEstablishments;
    @JacksonXmlElementWrapper(localName = "deliveryAddresses")
    @JacksonXmlProperty(localName = "deliveryAddress")
    List<DeliveryAddressDto> deliveryAddresses;
    @JacksonXmlElementWrapper(localName = "invoiceLines")
    @JacksonXmlProperty(localName = "invoiceLine")
    List<InvoiceLineDTO> invoiceLines;



}
