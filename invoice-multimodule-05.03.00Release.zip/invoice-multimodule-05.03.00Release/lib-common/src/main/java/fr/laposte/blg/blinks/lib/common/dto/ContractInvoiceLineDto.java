package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
@JsonPropertyOrder({
        "number",
        "toDisplay",
        "displayPriority",
        "attachedNumber",
        "consumerAccountCode",
        "coclicoEmitterCode",
        "depositCustAccNumber",
        "externalRef",
        "type",
        "discountLineType",
        "discountedAccountingCode",
        "discountRate",
        "discountedAmount",
        "fuelTax",
        "productCode",
        "serviceCode",
        "accountingCode",
        "label",
        "comment",
        "quantity",
        "unitPrice",
        "excludingTaxAmount",
        "VATCode",
        "VATRate",
        "VATAmount",
        "stampingCode",
        "serviceDate",
        "regateCode",
        "addressId",
        "criteria"
})
public class ContractInvoiceLineDto {
    Integer number;
    Boolean toDisplay;
    Integer displayPriority;
    Integer attachedNumber;
    String consumerAccountCode;
    String coclicoEmitterCode;
    String depositCustAccNumber;
    String externalRef;
    String type;
    String discountLineType;
    String discountedAccountingCode;
    Boolean fuelTax;
    String productCode;
    String serviceCode;
    String accountingCode;
    String label;
    String comment;
    Integer quantity;
    Double unitPrice;
    Double excludingTaxAmount;
    @JsonProperty("VATCode")
    String vatCode;
    @JsonProperty("VATRate")
    Double vatRate;
    @JsonProperty("VATAmount")
    Double vatAmount;
    String stampingCode;
    @JsonFormat(pattern = "dd/MM/yyyy")
    LocalDate serviceDate;
    String regateCode;
    Integer addressId;
    List<CriterionDto> criteria;
    Double discountRate;
    Double discountedAmount;

}
