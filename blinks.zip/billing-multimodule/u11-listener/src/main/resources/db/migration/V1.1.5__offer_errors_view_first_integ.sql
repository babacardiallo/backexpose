ALTER TABLE contract_version ADD COLUMN previous_date_synchronization datetime;
CREATE OR REPLACE VIEW `offer_errors_view` AS
    SELECT
        COALESCE(`c`.`contract_number`,
                `er`.`contract_number`) AS `contract_number`,
        COALESCE(`cv`.`revision_number`,
                `er`.`revision_number`) AS `revision_number`,
        COALESCE(`cv`.`amendment_number`,
                `er`.`amendment_number`) AS `amendment_number`,
        `er`.`date_error` AS `date_error`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        `cv`.`previous_date_synchronization` AS `previous_date_synchronization`,
        `er`.`workflow_step` AS `workflow_step`,
        `er`.`error_message` AS `error_message`,
        COALESCE(`fo`.`ops_code`, `er`.`ops_code`) AS `ops_code`
    FROM
        ((((`error_log` `er`
        LEFT JOIN `contract` `c` ON ((`c`.`id_contract` = `er`.`id_contract`)))
        LEFT JOIN `contract_version` `cv` ON ((`cv`.`id_contract` = `c`.`id_contract`)))
        LEFT JOIN `valued_offer` `vo` ON ((`vo`.`id_valued_offer` = `cv`.`id_valued_offer`)))
        LEFT JOIN `offer_filter` `fo` ON ((`fo`.`offer_ops_id` = `vo`.`ops_id`)))
    WHERE
        (((COALESCE(`fo`.`ops_code`, `er`.`ops_code`) IS NOT NULL)
            AND `fo`.`ops_code` IN (SELECT
                `offer_filter`.`ops_code`
            FROM
                `offer_filter`))
            OR `er`.`ops_code` IN (SELECT
                `offer_filter`.`ops_code`
            FROM
                `offer_filter`))