package fr.laposte.blg.blinks.u14.service;


import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.OfferFilterEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class StatServiceTest {



    @Mock
    private OfferFilterRepository offerFilterRepository;
    @Mock
    private ContractVersionRepository contractVersionRepository;
    @Mock
    private LegalPersonRepository legalPersonRepository;
    @Mock
    private ErrorLogRepository errorLogRepository;
    @Mock
    private ContractRepository contractRepository;


    @InjectMocks
    private StatService statService;
    private OfferFilterEntity offerFilterEntity;
    private ContractVersionEntity contractVersionEntity;
    private LegalPersonEntity legalPersonEntity;

    @BeforeEach
    void setUp() {
        offerFilterEntity =  new OfferFilterEntity(0002l,"","");
        contractVersionEntity = new ContractVersionEntity();
        legalPersonEntity = new LegalPersonEntity();
    }

    @Test
    void getTotauxTest(){
        Mockito.when(offerFilterRepository.countOffers()).thenReturn(Mono.just(21L));
        Mockito.when(contractVersionRepository.countVersionsSynched()).thenReturn(Mono.just(2L));
        Mockito.when(legalPersonRepository.countLegalPerson()).thenReturn(Mono.just(10L));
        Mockito.when(contractRepository.countContractsSynchronized()).thenReturn(Mono.just(2L));
        Mockito.when(errorLogRepository.countSynchronisationError()).thenReturn(Mono.just(2L));
        Mockito.when(contractRepository.countContractsIntegrated()).thenReturn(Mono.just(2L));
        Mockito.when( contractVersionRepository.countContractVersionIntegrated()).thenReturn(Mono.just(2L));
        StepVerifier.create(statService.getTotaux()).
                assertNext(statDto ->{
                    assertNotNull(statDto);
                    assertEquals(21L,  statDto[0].getValue());
                    assertEquals(2L,  statDto[1].getValue());
                    assertEquals(2L,  statDto[2].getValue());
                    assertEquals(2L,  statDto[3].getValue());
                    assertEquals(10L,  statDto[4].getValue());
                    assertEquals(2L,  statDto[5].getValue());
                    assertEquals(2L,  statDto[6].getValue());
                })
                .verifyComplete();
    }
}
