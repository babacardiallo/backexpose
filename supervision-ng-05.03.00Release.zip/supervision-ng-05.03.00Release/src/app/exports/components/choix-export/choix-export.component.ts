
import { Component, OnInit } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Choix, CHOIX_EXPORTS } from '../../const/export.const';

@Component({
    selector: 'choix-export',
    templateUrl: './choix-export.component.html',
    styleUrls: ['./choix-export.component.scss'],
    standalone: false
})

export class ChoixExportComponent implements OnInit {

    appName = environment.appName;

    public listChoix = CHOIX_EXPORTS;

    public perimtresChoisies: string[] = [];

    constructor(){}

    ngOnInit(): void {
    }

    switchIsActive(choix: Choix , event: any) {
        if(event.checked){
            this.perimtresChoisies.push(choix.value);
        } else {
            if(this.perimtresChoisies.indexOf(choix.value)!=-1){
                this.perimtresChoisies.splice(this.perimtresChoisies.indexOf(choix.value), 1);
            }
        }
    }
    
}