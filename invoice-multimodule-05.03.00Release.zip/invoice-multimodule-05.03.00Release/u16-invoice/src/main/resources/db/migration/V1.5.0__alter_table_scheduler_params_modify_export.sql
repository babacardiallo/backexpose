UPDATE scheduler_params SET custom_params = '{"equinox": 1, "docaposte": 2, "docaposte_avis_paiement": 3, "infoca": 4}'
WHERE scheduler_name = "scheduler_export" AND module = "u17";