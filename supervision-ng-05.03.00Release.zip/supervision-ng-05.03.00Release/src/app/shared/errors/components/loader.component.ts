import { Component } from '@angular/core';
import { LoaderService } from '../service/loader.service';

@Component({
    selector: 'loader-spinner',
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss'],
    standalone: false
})
export class LoaderComponent {
    constructor(public loader: LoaderService) { }
}