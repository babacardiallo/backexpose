package fr.laposte.blg.blinks.u18.entity;

public enum MessageStatus {
    PENDING,     // En attente d’export
    EXPORTED,    // Exporté avec succès
    INVALID,     // Invalide (champs obligatoires manquants)
    ERROR        // Erreur technique lors du traitement
}
