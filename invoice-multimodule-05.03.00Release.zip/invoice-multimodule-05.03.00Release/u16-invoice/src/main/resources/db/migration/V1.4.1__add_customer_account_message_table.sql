CREATE TABLE customer_account_message
(
    id              BINARY(16)   NOT NULL,
    contract_number VARCHAR(255) NOT NULL,
    offer_code      VARCHAR(255) NOT NULL,
    message_key     VARCHAR(255) NULL,
    message_value   JSON NULL,
    topic_name      VARCHAR(255) NULL,
    topic_offset    BIGINT NULL,
    topic_partition INT NULL,
    comment         VARCHAR(255) NULL,
    status          VARCHAR(255) NOT NULL,
    created         datetime     NOT NULL,
    updated         datetime     NOT NULL,
    CONSTRAINT pk_customer_account_message PRIMARY KEY (id)
);

CREATE INDEX idx_contract_number ON customer_account_message (contract_number);

CREATE INDEX idx_created ON customer_account_message (created);

CREATE INDEX idx_status ON customer_account_message (status);