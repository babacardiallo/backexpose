import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, throwError } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { StatModel } from './models/stat.model';


@Injectable({
  providedIn: 'root',
})
export class TotauxService {
  ngUnsubscribe$ = new Subject<void>();

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        
    }),
}

  getTotauxBilling(): Observable<StatModel[]> {
    return this.http.get<StatModel[]>(environment.API_STAT_TOTAUX_BILLING, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getTotauxInvoice(): Observable<StatModel[]> {
    return this.http.get<StatModel[]>(environment.API_STAT_TOTAUX_INVOICE, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }
 
}