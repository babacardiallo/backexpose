package fr.laposte.blg.blinks.u10.entities;

import org.springframework.data.rest.core.config.Projection;

@Projection(name = "errorCodeOnly", types = {RejetContract.class})
public interface RejetErrorCodeOnly {
    String getErrorCode();
}
