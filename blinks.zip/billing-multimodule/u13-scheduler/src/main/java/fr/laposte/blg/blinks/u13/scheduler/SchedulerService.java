package fr.laposte.blg.blinks.u13.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Slf4j
public class SchedulerService {

    private final OfferFilterRepository offerFilterRepository;
    private final ContractService contractService;

    /**
     * Check if the offer in the contract is eligible or synchronization
     *
     * @param queueSynchronizationEntity the queueSynchronizationEntity
     * @return Mono with true if offer eligible, false otherwise
     */
    public Mono<Boolean> isOfferOfContractEligibleForSynchronization(QueueSynchronizationEntity queueSynchronizationEntity) {

        return contractService.findAnyVersionOfTheContract(queueSynchronizationEntity.getIdContract())
            .flatMap(contractService::loadValuedOffer)
            .map(contractVersionEntity -> contractVersionEntity.getValuedOffer().getOpsId())
            .doOnNext(offerId-> log.debug("OfferIdAsString {}", offerId))
            .map(Long::parseLong)
            .doOnError(throwable -> log.error("Error while we check if the contract is eligible to be synchronized", throwable))
            .flatMap(offerFilterRepository::findFirstByOfferOpsId)
            .doOnNext(offerFilterEntity -> log.debug("The version of contract {} is eligible to be synchronized : offer {}", queueSynchronizationEntity.getIdContract(), offerFilterEntity.getOpsCode()))
            .map(offerFilterEntity -> true)
            //TODO La partie parsing via le jPATH n'est pas implémenté car jamais utilisé jusqu'à présent
            .defaultIfEmpty(false)
            .onErrorReturn(false);

    }
}
