package fr.laposte.blg.blinks.u11.mapper;

import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = {LegalPersonListenerMapper.class, LegalPersonListenerMapperImpl_.class, LegalPersonListenerMapperImpl.class})
class LegalPersonListenerMapperTest {

    @Autowired
    private LegalPersonListenerMapper legalPersonListenerMapper;

    @Test
    void legalPersonToLegalPersonEntityTestWithBadCustTypeCode() {
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("51184");
        legalPerson.setCompName("myComp");
        legalPerson.setBrandName("myBrand");
        legalPerson.setCustTypeCode("2");
        legalPerson.setCVATNO("2");
        legalPerson.setEstablishZoneCode("01");
        legalPerson.setMarketingTypeCode("B2B");
        legalPerson.setActive("1");

        assertThrows(RuntimeException.class, () -> {
            this.legalPersonListenerMapper.legalPersonToLegalPersonEntity(legalPerson);
        });
    }

    @Test
    void legalPersonToLegalPersonEntityWithTypeCode0Test() {
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("51184");
        legalPerson.setCompName("myComp");
        legalPerson.setBrandName("myBrand");
        legalPerson.setCustTypeCode("0");
        legalPerson.setCVATNO("2");
        legalPerson.setEstablishZoneCode("01");
        legalPerson.setMarketingTypeCode("B2B");
        legalPerson.setActive("1");

        LegalPersonEntity legalPersonEntity = this.legalPersonListenerMapper.legalPersonToLegalPersonEntity(legalPerson);

        assertAll(() -> {
            assertEquals(Integer.parseInt(legalPerson.getId().toString()), legalPersonEntity.getCustAccNumber());
            assertEquals(legalPerson.getCompName().toString(), legalPersonEntity.getCompName());
            assertEquals(legalPerson.getBrandName().toString(), legalPersonEntity.getBrandName());
            assertEquals(Integer.parseInt(legalPerson.getCustTypeCode().toString()), legalPersonEntity.getTypeCode());
            assertEquals(legalPerson.getCVATNO().toString(), legalPersonEntity.getVatNumber());
            assertEquals(legalPerson.getEstablishZoneCode().toString(), legalPersonEntity.getEstablishZoneCode());
            assertEquals(legalPerson.getMarketingTypeCode().toString(), legalPersonEntity.getMarketingTypeCode());
            assertEquals(legalPerson.getActive().toString(), legalPersonEntity.getStatus());
            assertEquals(legalPersonEntity.getTypeLabel(), "privé");
            assertNull(legalPersonEntity.getIdLegalPerson());
        });
    }

    @Test
    void legalPersonToLegalPersonEntityWithTypeCode1Test() {
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("51184");
        legalPerson.setCompName("myComp");
        legalPerson.setBrandName("myBrand");
        legalPerson.setCustTypeCode("1");
        legalPerson.setCVATNO("2");
        legalPerson.setEstablishZoneCode("01");
        legalPerson.setMarketingTypeCode("B2B");
        legalPerson.setActive("1");

        LegalPersonEntity legalPersonEntity = this.legalPersonListenerMapper.legalPersonToLegalPersonEntity(legalPerson);

        assertAll(() -> {
            assertEquals(Integer.parseInt(legalPerson.getId().toString()), legalPersonEntity.getCustAccNumber());
            assertEquals(legalPerson.getCompName().toString(), legalPersonEntity.getCompName());
            assertEquals(legalPerson.getBrandName().toString(), legalPersonEntity.getBrandName());
            assertEquals(Integer.parseInt(legalPerson.getCustTypeCode().toString()), legalPersonEntity.getTypeCode());
            assertEquals(legalPerson.getCVATNO().toString(), legalPersonEntity.getVatNumber());
            assertEquals(legalPerson.getEstablishZoneCode().toString(), legalPersonEntity.getEstablishZoneCode());
            assertEquals(legalPerson.getMarketingTypeCode().toString(), legalPersonEntity.getMarketingTypeCode());
            assertEquals(legalPerson.getActive().toString(), legalPersonEntity.getStatus());
            assertEquals(legalPersonEntity.getTypeLabel(), "public");
            assertNull(legalPersonEntity.getIdLegalPerson());
        });
    }

    @Test
    void legalPersonToAddressEntityTest() {
        LegalPerson legalPerson = new LegalPerson();
        legalPerson.setId("51184");
        legalPerson.setRefpmAdressId("12");
        legalPerson.setName1("name1");
        legalPerson.setAdd2("add2");
        legalPerson.setAdd3("add3");
        legalPerson.setAdd4("add4");
        legalPerson.setAdd5("add5");
        legalPerson.setAdd6("add6");
        legalPerson.setAdd7("add7");
        legalPerson.setCDateTime("1999-08-02T00:00:00");
        legalPerson.setMDateTime("2022-03-25T11:14:33.150Z");

        AddressEntity addressEntity = this.legalPersonListenerMapper.legalPersonToAddressEntity(legalPerson);

        assertAll(() -> {
            assertEquals(legalPerson.getRefpmAdressId().toString(), addressEntity.getAddressIdRefPM());
            assertEquals(legalPerson.getName1().toString(), addressEntity.getName1());
            assertEquals(legalPerson.getAdd2().toString(), addressEntity.getAdd2());
            assertEquals(legalPerson.getAdd3().toString(), addressEntity.getAdd3());
            assertEquals(legalPerson.getAdd4().toString(), addressEntity.getAdd4());
            assertEquals(legalPerson.getAdd5().toString(), addressEntity.getAdd5());
            assertEquals(legalPerson.getAdd6().toString(), addressEntity.getAdd6());
            assertEquals(legalPerson.getAdd7().toString(), addressEntity.getAdd7());
            assertEquals(AddressType.PRINCIPALE, addressEntity.getAddressType());
            assertEquals("1999-08-02T00:00:00", addressEntity.getCreationDatetime().atZone(ZoneId.of("Europe/Paris")).toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            assertEquals("2022-03-25T11:14:33", addressEntity.getModificationDatetime().atZone(ZoneId.of("Europe/Paris")).toLocalDateTime().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            assertNull(addressEntity.getIdAddress());
        });
    }

    @Test
    void asInstantTest(){
        String date = "2025-03-17T00:00:00+02:00";
        Instant instant = LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant();
        assertEquals(instant, legalPersonListenerMapper.asInstant(date));
    }
}
