#!/bin/sh

set -e
echo "✅ Check if target JAR is present:"
echo "MODULE=${MODULE}"
ls -lh ./${MODULE}*/target/${MODULE}.jar || echo "❌ JAR not found"


echo "🧾 Job environment info:"
echo " >> CI_JOB_NAME=$CI_JOB_NAME"
echo " >> CI_PIPELINE_ID=$CI_PIPELINE_ID"
echo " >> CI_PROJECT_PATH=$CI_PROJECT_PATH"
echo " >> CI_COMMIT_BRANCH=$CI_COMMIT_BRANCH"
echo " >> CI_COMMIT_SHA=$CI_COMMIT_SHA"
echo " >> CI_JOB_STAGE=$CI_JOB_STAGE"
echo " >> CI_SERVER_URL=$CI_SERVER_URL"

echo "🗂️ Creating docker-context directory..."
mkdir -p docker-context
cp .gitlab/ci/docker/Dockerfile docker-context/Dockerfile
cp ${MODULE}*/target/${MODULE}.jar docker-context/app.jar

echo "🧾 Build context content:"
find docker-context -type f -exec ls -lh {} \;
