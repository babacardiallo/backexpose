import { NgModule } from '@angular/core';
import { SupervisionComponent } from "./supervision.component";
import { SupervisionRoutingModule } from "./supervision-routing.module";
import { SharedModule } from "../shared/shared.module";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { CdkAccordionModule } from "@angular/cdk/accordion";
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import {
  NguCarousel,
  NguCarouselDefDirective,
  NguCarouselNextDirective,
  NguCarouselPrevDirective,
  NguItemComponent
} from '@ngu/carousel';
import { NgxPermissionsModule } from 'ngx-permissions';
import { DailySupervisionComponent } from './components/daily-supervision/daily-supervision.component';
import { CalendarViewComponent } from './components/calendar-view/calendar-view.component';
import { CalendarActionComponent } from './components/calendar-event/calendar-action.component';
import { FileTransferComponent } from './components/file-transfer/file-transfer.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MonthViewComponent } from './components/month-view/month-view.component';
 



@NgModule({
  declarations: [SupervisionComponent, DailySupervisionComponent, CalendarActionComponent, CalendarViewComponent, FileTransferComponent, MonthViewComponent],
  imports: [
    SharedModule,
    NgxDatatableModule,
    SupervisionRoutingModule,
    CdkAccordionModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    NguCarousel,
    NguCarouselDefDirective,
    NguCarouselNextDirective,
    NguCarouselPrevDirective,
    NguItemComponent,
    NgxPermissionsModule.forChild(),
    MatSlideToggleModule
    
  ],
  exports: [
    SupervisionComponent
  ]
})
export class SupervisionModule { }
