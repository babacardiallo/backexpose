import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.u17.dto.InvoiceRestDTO;
import fr.laposte.blg.blinks.u17.dto.MorningCheckDto;
import fr.laposte.blg.blinks.u17.mapper.MorningCheckMapper;
import fr.laposte.blg.blinks.u17.service.MorningCheckService;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.PageRequest;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class MorningCheckServiceTest {

    @InjectMocks
    private MorningCheckService morningCheckService;
    @Mock
    private ExportHistoryRepository exportHistoryRepository;
    @Mock
    private MorningCheckMapper morningCheckMapper;
    @Mock
    private DateUtil dateUtil;

    @Test
    void getExportHistoriesTest(){
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setMessageCount(10);
        exportHistoryEntity.setNbAvoirs(2);
        exportHistoryEntity.setNbReleves(1);
        exportHistoryEntity.setNbAcomptes(1);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        MorningCheckDto morningCheckDto = new MorningCheckDto();
        morningCheckDto.setIdExport(1L);
        morningCheckDto.setFileName("file_name");
        morningCheckDto.setTransferStatus(TransferStatus.NEW);
        morningCheckDto.setStatus(ExportStatus.SUCCESS);
        when(dateUtil.yyyyMMddDash(any(LocalDate.class))).thenReturn("2025-05-05");
        when(exportHistoryRepository.getLastExportedFileByType(any(FileType.class), anyString()))
                .thenReturn(Mono.just(exportHistoryEntity));
        when(morningCheckMapper.exportHistoryEntityToMorningCheckDto(any(ExportHistoryEntity.class))).thenReturn(morningCheckDto);
        morningCheckService.getExportHistories(LocalDate.now()).subscribe();
    }

    @Test
    void updateFileSendStatusTest(){
        when(exportHistoryRepository.updateFileSendStatus(any(FileType.class), any(LocalDateTime.class), any(LocalDateTime.class)))
                .thenReturn(Mono.just(1));
        StepVerifier.create(morningCheckService.updateFileSendStatus(FileType.DOCAPOSTE, LocalDateTime.now(), LocalDateTime.now()))
                .assertNext(result -> {
                    assertEquals(1, result);
                });
    }

    @Test
    void getMonthlyTreatmentYearMonthTest(){
        Flux<MonthlyTreatment> monthlyTreatmentFlux =
                Flux.fromIterable(List.of(
                        new MonthlyTreatment(Instant.now(), false, ExportStatus.SUCCESS, FileType.DOCAPOSTE.toString(), TransferStatus.NEW.toString()),
                        new MonthlyTreatment(Instant.now(), false, ExportStatus.WARNING, FileType.COEURFINANCE.toString(), TransferStatus.NEW.toString()),
                        new MonthlyTreatment(Instant.now(), false, ExportStatus.FAILED, FileType.INFOCA.toString(), TransferStatus.FAILED.toString())
                ));
        when(exportHistoryRepository.getMonthlyTreatmentByMonthAndYear(anyInt(), anyInt(), any(FileType.class))).thenReturn(monthlyTreatmentFlux);
        morningCheckService.getMonthlyTreatment(1, 1).subscribe();
    }

    @Test
    void getMonthlyTreatmentTest(){
        Flux<MonthlyTreatment> monthlyTreatmentFlux =
                Flux.fromIterable(List.of(
                        new MonthlyTreatment(Instant.now(), false, ExportStatus.SUCCESS, FileType.DOCAPOSTE.toString(), TransferStatus.NEW.toString()),
                        new MonthlyTreatment(Instant.now(), false, ExportStatus.WARNING, FileType.COEURFINANCE.toString(), TransferStatus.NEW.toString()),
                        new MonthlyTreatment(Instant.now(), false, ExportStatus.FAILED, FileType.INFOCA.toString(), TransferStatus.FAILED.toString())
                ));
        when(exportHistoryRepository.getMonthlyTreatment(any(FileType.class))).thenReturn(monthlyTreatmentFlux);
        morningCheckService.getMonthlyTreatment(null, null).subscribe();
    }

    @Test
    void getExportHistoriesDailyTest(){
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setMessageCount(10);
        exportHistoryEntity.setNbAvoirs(2);
        exportHistoryEntity.setNbReleves(1);
        exportHistoryEntity.setNbAcomptes(1);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        MorningCheckDto morningCheckDto = new MorningCheckDto();
        morningCheckDto.setIdExport(1L);
        morningCheckDto.setFileName("file_name");
        morningCheckDto.setTransferStatus(TransferStatus.NEW);
        morningCheckDto.setStatus(ExportStatus.SUCCESS);
        when(dateUtil.yyyyMMddDash(any(LocalDate.class))).thenReturn("2025-05-05");
        when(exportHistoryRepository.getDailyExportFileByType(any(FileType.class), anyString())).thenReturn(Flux.just(exportHistoryEntity));
        when(morningCheckMapper.exportHistoryEntityToMorningCheckDto(anyList())).thenReturn(List.of(morningCheckDto));
        morningCheckService.getExportHistoriesDaily(LocalDate.now()).subscribe();
    }

    @Test
    void getTransferStatusDuJourTest(){
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setMessageCount(10);
        exportHistoryEntity.setNbAvoirs(2);
        exportHistoryEntity.setNbReleves(1);
        exportHistoryEntity.setNbAcomptes(1);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        when(dateUtil.yyyyMMddDash(any(LocalDate.class))).thenReturn("2025-05-05");
        when(exportHistoryRepository.getDailyExportFile(anyString())).thenReturn(Flux.just(exportHistoryEntity));
        morningCheckService.getTransferStatusDuJour(LocalDate.now()).subscribe();

    }

    @Test
    void getMonthlyMorningCheck() {
        MorningCheckMonthly monthly = MorningCheckMonthly.builder()
                .size(1)
                .nbTotalTreatedInvoices(5)
                .nbTotalNormalInvoices(3)
                .nbTotalAvoirs(1)
                .nbTotalReleves(1).build();

        when(exportHistoryRepository.getMonthlyMorningCheck(anyInt(),anyInt(), any(FileType.class))).thenReturn(Mono.just(monthly));
        when(exportHistoryRepository.getMonthlyMorningCheckForDocaposte(anyInt(),anyInt())).thenReturn(Mono.just(monthly));
        StepVerifier.create(morningCheckService.getMonthlyMorningCheck(2025, 12))
                .assertNext(result -> {
                    assertNotNull(result);
                    assertEquals(1, result.get(FileType.COEURFINANCE).getSize());
                    assertEquals(5, result.get(FileType.COEURFINANCE).getNbTotalTreatedInvoices());
                    assertEquals(3, result.get(FileType.COEURFINANCE).getNbTotalNormalInvoices());
                    assertEquals(1, result.get(FileType.COEURFINANCE).getNbTotalAvoirs());
                    assertEquals(1, result.get(FileType.COEURFINANCE).getNbTotalReleves());
                })
                .verifyComplete();


    }

    @Test
    void getTransferStatusMonthlyTest(){
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(1L);
        exportHistoryEntity.setStartDate(Instant.now());
        exportHistoryEntity.setDate(Instant.now());
        exportHistoryEntity.setFileName("file_123");
        exportHistoryEntity.setNbInvoiceExportedInFile(10);
        exportHistoryEntity.setExportStatus(ExportStatus.SUCCESS);
        exportHistoryEntity.setIsFileEmpty(false);
        exportHistoryEntity.setMessageCount(10);
        exportHistoryEntity.setNbAvoirs(2);
        exportHistoryEntity.setNbReleves(1);
        exportHistoryEntity.setNbAcomptes(1);
        exportHistoryEntity.setFileType(FileType.DOCAPOSTE);
        exportHistoryEntity.setTransferStatus(TransferStatus.NEW);
        when(exportHistoryRepository.getMonthlyExportFile(anyInt(), anyInt())).thenReturn(Flux.just(exportHistoryEntity));
        StepVerifier.create(morningCheckService.getTransferStatusMonthly(2025, 12))
                .assertNext(result -> {
                    assertNotNull(result);
                    assertEquals(1, result.getId());
                    assertEquals("file_123", result.getName());
                    assertEquals(TransferStatus.NEW.toString(), result.getStatus());
                })
                .verifyComplete();

    }


}
