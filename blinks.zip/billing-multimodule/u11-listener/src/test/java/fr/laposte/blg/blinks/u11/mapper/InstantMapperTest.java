package fr.laposte.blg.blinks.u11.mapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(classes=InstantMapper.class)
class InstantMapperTest {
    @Autowired
    private InstantMapper instantMapper;

    @Test
    void asStringTest(){
        Instant instant = Instant.now();
        String instantString = instant != null ? ZonedDateTime.ofInstant(instant, ZoneId.of("Europe/Paris")).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) : null;
        assertEquals(instantString, instantMapper.asString(instant));
    }
    @Test
    void asInstantTest(){
        String date = "2025-03-17T00:00:00+02:00";
        Instant instant = ZonedDateTime.parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toInstant();
        assertEquals(instant, instantMapper.asInstant(date));
    }
}

