package fr.laposte.blg.blinks.u11.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.entities.RefopsEntity;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ContractListenerException;
import fr.laposte.r5.uk.kafka.avro.viewoscar.Oscar;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.io.JsonEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public abstract class RefopsListenerDecorator implements RefopsListenerMapper {

    @Autowired
    @Qualifier("delegate")
    private RefopsListenerMapper delegate;

    @Override
    public RefopsEntity refopsToRefopsEntity(Oscar refopsAvro) throws JsonProcessingException {
        RefopsEntity refopsEntity = delegate.refopsToRefopsEntity(refopsAvro);
        try {
            DatumWriter<Oscar> writer = new GenericDatumWriter<>(refopsAvro.getSchema());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            JsonEncoder encoder = EncoderFactory.get().jsonEncoder(refopsAvro.getSchema(), out);
            writer.write(refopsAvro, encoder);
            encoder.flush();
            refopsEntity.setData(out.toString());
        } catch (IOException e) {
            throw new ContractListenerException("Unable to json encode refops offer block");
        }
        return refopsEntity;
    }

}
