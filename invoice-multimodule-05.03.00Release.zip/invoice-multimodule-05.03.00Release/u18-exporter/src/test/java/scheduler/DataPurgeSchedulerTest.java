package scheduler;


import fr.laposte.blg.blinks.u18.scheduler.DataPurgeScheduler;
import fr.laposte.blg.blinks.u18.service.impl.MessagePurgeServiceImpl;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DataPurgeSchedulerTest {

    @Mock
    private MessagePurgeServiceImpl messagePurgeService;

    @Test
    void purgeRunTest(){
        SchedulerParamsEntity updatedParams = new SchedulerParamsEntity();
        updatedParams.setIsEnabled(true);
        updatedParams.setSchedulerName("scheduler_purge");
        updatedParams.setRetentionDays(1);
        DataPurgeScheduler dataPurgeScheduler = new DataPurgeScheduler(messagePurgeService, updatedParams);
        when(messagePurgeService.purgeMessagesOlderThan(any(Instant.class))).thenReturn(1);
        dataPurgeScheduler.run();
    }
}
