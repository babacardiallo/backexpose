import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { RejetContractService } from "../../service/rejet-contract.service";


@Component({
    selector: 'rejet-contract-saisie',
    templateUrl: './rejet-contract-saisie-pop-pup.component.html',
    styleUrls: ['./rejet-contract-saisie-pop-pup.component.scss'],
    standalone: false
})
  
export class RejetContractSaisiePopupComponent implements OnInit {

    content: any;

    public rjcSaisies = '';

    name = 'RejetContractSaisiePopupComponent';
  

    constructor(private rejetContractService: RejetContractService, private snackBar: MatSnackBar, private modalService: ModalService){
       
    }


    ngOnInit(): void {
       
    }

    updatePerimeter(){
        const rjcs = this.rjcSaisies.split("\n");
        if(rjcs[0]==''){
            return;
        } else {
            this.rejetContractService.updateRejetContractSelectedPending(rjcs).subscribe({        
                next: (response) => {
                },
                complete: () => {
                  this.snackBar.open("Les status des rejets sont passés à PENDING", 'Fermer', { duration: 8000 });
                  this.close();
                  this.rejetContractService.emitLoadRjc();
                },
            })
        }
    
   }

   close(){
    this.modalService.close(this.name);
   }


  }