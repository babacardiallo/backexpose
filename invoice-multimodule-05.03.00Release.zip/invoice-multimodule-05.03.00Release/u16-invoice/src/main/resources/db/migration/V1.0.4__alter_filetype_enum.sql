ALTER TABLE export_history CHANGE file_type
    file_type ENUM('DOCAPOST', 'DOCAPOSTE','INFOCA', 'EQUINOX');
UPDATE export_history SET file_type = 'DOCAPOSTE'
WHERE file_type = 'DOCAPOST';
ALTER TABLE export_history CHANGE file_type
    file_type ENUM ('DOCAPOSTE','INFOCA', 'EQUINOX');