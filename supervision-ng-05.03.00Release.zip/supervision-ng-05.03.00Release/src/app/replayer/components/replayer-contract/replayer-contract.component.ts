import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { ContratsTable } from "../../../contrats/models/contrats-table.model";
import { ReplayerService } from "../../service/replay.service";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { atLeastOne, atLeastOneChecked } from '../../../consts/consts';
import { of, takeUntil } from 'rxjs';
import { ReplayAllContractsParameters } from '../../models/replay-all-contracts.model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReplayReport } from "../../models/replay-report.model";
import { OffresTable } from '../../../offres/models/offres-table.model';
import { OffresTableService } from '../../../offres/service/offres-table.service';
import { ContractPage } from '../../../contrats/models/contract.page';
import { OfferPage } from '../../../offres/models/offer.page';

@Component({
    selector: 'app-replayer-contract',
    templateUrl: './replayer-contract.component.html',
    styleUrls: ['./replayer-contract.component.scss'],
    standalone: false
})
export class ReplayerContractComponent implements OnInit, OnDestroy {
  popupFormMass: UntypedFormGroup;
  popupFormAll: UntypedFormGroup;
  popupFormOffers: UntypedFormGroup;
  replayAllContractsParameters: ReplayAllContractsParameters = new ReplayAllContractsParameters();
  replayOffersContractsParameters: ReplayAllContractsParameters = new ReplayAllContractsParameters();
  @ViewChild(DatatableComponent) contracts: DatatableComponent;
  @ViewChild("offersDataTable") offersDataTable: DatatableComponent;
  listContracts: any[];
  listContractsToReplay: any[];
  listOffers: OffresTable[];
  listOffersToReplay: any[];
  filteredOffers: any[];
  filtered: any[];
  action: any;
  date: any;
  replayReport: any;
  offersFilled: any;
  offersFilledFormated: string;
  contractsFilled: any;
  contractsFilledinput: any;
  contractsFilledinputList: any[];
  offersFilledinputList: any[];
  listContractsNum: any[];
  contractsFilledFormatted: string;
  contractPage: ContractPage = new ContractPage();
  searchText = '';
  loadedIndex = 0;
  searchOffer = '';
  offerPage: OfferPage = new OfferPage();

  constructor(private replayerService: ReplayerService, private datePipe: DatePipe, private formBuilder: UntypedFormBuilder, private snackBar: MatSnackBar, private offersService: OffresTableService) {
  }

  ngOnInit(): void {
    this.getContracts(0, 5, "id", "desc");
    this.initFormMass();
    this.subscribeFormMass();
    this.initFormAll();
    this.subscribeFormAll();
    this.initFormOffers();
    this.subscribeFormOffers();
  }

  ngOnDestroy(): void {
    this.replayerService.ngUnsubscribe$.next();
    this.replayerService.ngUnsubscribe$.complete();
  }

  getContracts(page: number, itemPerPage: number, sort: string, order: string): Promise<any> {
    return new Promise((resolve) => {
      this.replayerService.getContracts(page, itemPerPage, sort, order).subscribe({
        next: (response: any) => {
          this.listContracts = response.content.map((data: any) => {
            return <ContratsTable>{
              contractNumber: data.contractNumber,
              subtype: data.subtype,
              opsCode: data.opsCode,
            };
          })
          this.contractPage = {
            currentPage: response.pageable.pageNumber,
            itemsOnPage: response.pageable.pageSize,
            currentOffset: response.pageable.offset,
            totalPages: response.totalPages,
            totalItems: response.totalElements
          }
        },
        complete: () => {
          resolve(true);
        },
      });
    });
  }

  getOffers(page: number, itemPerPage: number, sort: string, order: string, filter: string): void {
    this.offersService.getActivesOffres(page, itemPerPage, sort, order, filter).subscribe({
      next: (response: any) => {
        this.listOffers = response.content.map((data: any) => {
          return <OffresTable>{
            codeOps: data.opsCode,
            labelOps: data.opsLabel,
            offerActivationDate: data.offerActivationDate ? new Date(data.offerActivationDate * 1000) : null,
            contractsSynch: data.contractSynch,
            versionsSynch: data.contractVersionSynch
          };
        })
        this.offerPage = {
          currentPage: response.pageable.pageNumber,
          itemsOnPage: response.pageable.pageSize,
          currentOffset: response.pageable.offset,
          totalPages: response.totalPages,
          totalItems: response.totalElements
        };
      },
      complete: () => { },
    });
  }

  tabClick(tab: any) {
    if (tab.index == 2 && this.loadedIndex != 2) {
      this.getOffers(0, 5, 'opsCode', 'asc', '');
      this.loadedIndex = 2;
    }
    this.replayReport = null;

  }

  onSelect(event: any) {
    this.listContractsToReplay = event.selected;
    this.showContractsFromTable()
  }

  onSelectOffers(event: any) {
    this.listOffersToReplay = event.selected;
    this.showOffersFromTable()
  }

  initFormMass() {
    this.popupFormMass = this.formBuilder.group({
      checkCreateMass: new UntypedFormControl(false),
      checkUpdateMass: new UntypedFormControl(true),
      dateReplayMass: new UntypedFormControl(''),
      dateDisabledMass: new UntypedFormControl(),
    }, {
      validator: [atLeastOne(Validators.required,
        ['dateReplayMass', 'dateDisabledMass']),
      atLeastOneChecked(['checkCreateMass', 'checkUpdateMass'])],
    });
  }

  initFormAll() {
    this.popupFormAll = this.formBuilder.group({
      checkCreate: new UntypedFormControl(false),
      checkUpdate: new UntypedFormControl(true),
      dateReplayAll: new UntypedFormControl(''),
      dateDisabled: new UntypedFormControl(),
      typeSynchronisation: new UntypedFormControl("1", Validators.required)
    }, {
      validator: [atLeastOne(Validators.required,
        ['dateReplayAll', 'dateDisabled']),
      atLeastOneChecked(['checkCreate', 'checkUpdate'])],
    });
  }

  initFormOffers() {
    this.popupFormOffers = this.formBuilder.group({
      checkCreateOffers: new UntypedFormControl(false),
      checkUpdateOffers: new UntypedFormControl(true),
      dateReplayOffers: new UntypedFormControl(''),
      dateDisabledOffers: new UntypedFormControl(),
    }, {
      validator: [atLeastOne(Validators.required,
        ['dateReplayOffers', 'dateDisabledOffers']),
      atLeastOneChecked(['checkCreateOffers', 'checkUpdateOffers'])],
    });
  }

  showContractsFromTable() {
    this.contractsFilled = this.listContractsToReplay.map(value => value.contractNumber);
    this.formatListContracts();
  }

  showOffersFromTable() {
    this.offersFilled = this.listOffersToReplay.map(value => value.codeOps);
    this.formatListOffers();
  }

  formatListContracts() {
    this.contractsFilledFormatted = this.contractsFilled.toString().split(",").join("\n");
  }

  formatListOffers() {
    this.offersFilledFormated = this.offersFilled.toString().split(",").join("\n");
  }


  launchReplay() {
    this.replayReport = null;
    this.contractsFilledinputList = this.contractsFilledFormatted.split("\n");
    this.replayerService.launchReplay(this.action, this.contractsFilledinputList, this.date)
      .subscribe({
        next: (response: any) => {
          if(response.waitingResponse==true){
            this.replayReport = {
              nbSuccess: response.nbSuccess,
              nbErrors: response.nbErrors,
              nbTotal: response.nbTotal,
              mapErrors: response.mapErrors,
              listSuccess: response.listSuccess
            };
          } else {
            this.snackBar.open(response.shortMessage, 'Fermer', { duration: 8000 });
          }  
        },
        complete: () => {
        },
      });
  }

  replayOffers() {
    this.replayReport = null;
    this.offersFilledinputList = this.offersFilledFormated.split("\n");
    this.replayerService.replayContractPerOffers(this.action, this.offersFilledinputList, this.date)
      .subscribe({
        next: (response: any) => {
          if(response.waitingResponse==true){
            this.replayReport = {
              nbSuccess: response.nbSuccess,
              nbErrors: response.nbErrors,
              nbTotal: response.nbTotal,
              mapErrors: response.mapErrors,
              listSuccess: response.listSuccess
            };
          } else {
            this.snackBar.open(response.shortMessage, 'Fermer', { duration: 8000 });
          }  
        },
        complete: () => {
          this.offersDataTable.recalculate();
          this.offersFilledFormated = "";
          this.offersFilled = [];
          this.offersDataTable.selected = [];
        },
      });
  }

  subscribeFormMass() {
    this.popupFormMass.get('dateDisabledMass')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe({
      next: (disableBoolean) => {
        if (disableBoolean) {
          this.popupFormMass.controls['dateReplayMass'].setValue(null, { emitEvent: false });
          this.popupFormMass.get('dateReplayMass')?.disable();
        } else {
          this.popupFormMass.get('dateReplayMass')?.enable();
          this.popupFormMass.controls['dateDisabledMass'].setValue(null, { emitEvent: false });
        }
      }
    });
    this.popupFormMass.get('checkCreateMass')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormMass.controls['checkUpdateMass'].setValue(null, { emitEvent: false });
      }
    });

    this.popupFormMass.get('checkUpdateMass')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormMass.controls['checkCreateMass'].setValue(null, { emitEvent: false });
      }
    });
  }

  subscribeFormOffers() {
    this.popupFormOffers.get('dateDisabledOffers')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe({
      next: (disableBoolean) => {
        if (disableBoolean) {
          this.popupFormOffers.controls['dateReplayOffers'].setValue(null, { emitEvent: false });
          this.popupFormOffers.get('dateReplayOffers')?.disable();
        } else {
          this.popupFormOffers.get('dateReplayOffers')?.enable();
          this.popupFormOffers.controls['dateDisabledOffers'].setValue(null, { emitEvent: false });
        }
      }
    });
    this.popupFormOffers.get('checkCreateOffers')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormOffers.controls['checkUpdateOffers'].setValue(null, { emitEvent: false });
      }
    });

    this.popupFormOffers.get('checkUpdateOffers')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormOffers.controls['checkCreateOffers'].setValue(null, { emitEvent: false });
      }
    });
  }

  subscribeFormAll() {
    this.popupFormAll.get('dateDisabled')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe({
      next: (disableBoolean) => {
        if (disableBoolean) {
          this.popupFormAll.controls['dateReplayAll'].setValue(null, { emitEvent: false });
          this.popupFormAll.get('dateReplayAll')?.disable();
        }
        else {
          this.popupFormAll.get('dateReplayAll')?.enable();
          this.popupFormAll.controls['dateDisabled'].setValue(null, { emitEvent: false });
        }
      }
    });

    this.popupFormAll.get('checkCreate')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormAll.controls['checkUpdate'].setValue(null, { emitEvent: false });
      }
    });

    this.popupFormAll.get('checkUpdate')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormAll.controls['checkCreate'].setValue(null, { emitEvent: false });
      }
    });
  }


  submitFormMass(): void {
    this.date = this.formatDate(this.popupFormMass.get('dateReplayMass')?.value);
    this.action = this.popupFormMass.get('checkCreateMass')?.value == true ? "create" : "update";
    this.launchReplay();
    this.popupFormMass.get('dateReplayMass')?.enable();
    this.popupFormMass.controls['dateDisabledMass'].setValue(null, { emitEvent: false });
    this.popupFormMass.controls['checkCreateMass'].setValue(null, { emitEvent: false });
    this.popupFormMass.controls['checkUpdateMass'].setValue(true);
    this.popupFormMass.controls['dateReplayMass'].setValue(null);
  }

  submitFormOffers(): void {

    this.date = this.formatDate(this.popupFormOffers.get('dateReplayOffers')?.value);
    this.action = this.popupFormOffers.get('checkCreateOffers')?.value == true ? "create" : "update";
    this.replayOffers();
    this.popupFormOffers.get('dateReplayOffers')?.enable();
    this.popupFormOffers.controls['dateDisabledOffers'].setValue(null, { emitEvent: false });
    this.popupFormOffers.controls['checkCreateOffers'].setValue(null, { emitEvent: false });
    this.popupFormOffers.controls['checkUpdateOffers'].setValue(true);
    this.popupFormOffers.controls['dateReplayOffers'].setValue(null);;

  }

  confirmReplayAll(): void {
    this.replayAllContractsParameters.date = this.popupFormAll.get('dateReplayAll')?.value;
    this.replayAllContractsParameters.method = this.popupFormAll.get('checkCreate')?.value == true ? "create" : "update";
    this.replayAllContracts();
    this.popupFormAll.get('dateReplayAll')?.enable();
    this.popupFormAll.controls['dateDisabled'].setValue(null, { emitEvent: false });
    this.popupFormAll.controls['checkCreate'].setValue(null, { emitEvent: false });
    this.popupFormAll.controls['checkUpdate'].setValue(true);
    this.popupFormAll.controls['dateReplayAll'].setValue(null);
  }

  replayAllContracts() {
    this.replayReport = null;
    const typeSynchronisation = this.popupFormAll.get('typeSynchronisation')?.value
    if (typeSynchronisation == "1") {
      this.replayAllContractsSynchronizedOrNot();
    } else {
      if (typeSynchronisation == "2") {
        this.replayAllContractsSynchronized();
      }
    }
  }
  replayAllContractsSynchronizedOrNot() {
    if (this.replayAllContractsParameters.method) {
      if (!this.replayAllContractsParameters.date) {
        this.replayerService.replayAllContracts(this.replayAllContractsParameters.method)
          .subscribe({
            next: (response: any) => {
              this.snackBar.open(response.result, 'Fermer', { duration: 8000 });
            },
            error: (response: any) => {
              this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
            }
          });
      }
      else {
        this.replayerService.replayAllContracts(this.replayAllContractsParameters.method, this.formatDate(this.replayAllContractsParameters.date)!)
          .subscribe({
            next: (response: any) => {
              this.snackBar.open(response.result, 'Fermer', { duration: 8000 });
            },
            error: (response: any) => {
              this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
            }
          });
      }
    }
    else {
      console.error("Aucune méthode de rejeu choisie");
    }
  }

  replayAllContractsSynchronized() {
    if (this.replayAllContractsParameters.method) {
      if (!this.replayAllContractsParameters.date) {
        this.replayerService.replaySynchedContracts(this.replayAllContractsParameters.method)
          .subscribe({
            next: (response: any) => {
              this.snackBar.open(response.result, 'Fermer', { duration: 8000 });
            },
            error: (response: any) => {
              this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
            }
          });
      }
      else {
        this.replayerService.replaySynchedContracts(this.replayAllContractsParameters.method, this.formatDate(this.replayAllContractsParameters.date)!)
          .subscribe({
            next: (response: any) => {
              this.snackBar.open(response.result, 'Fermer', { duration: 8000 });
            },
            error: (response: any) => {
              this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
            }
          });
      }
    }
    else {
      console.error("Aucune méthode de rejeu choisie");
    }
  }

  updateFilter(event: KeyboardEvent) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value;
    if (event.key === 'Enter') {
      if (val == '') {
        this.getContracts(0, 5, "id", "desc");

      } else {
        this.filterContracts(0, 5, "id", "desc", val);
      }
    }
  }

  updateFilterOffers(event: KeyboardEvent) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value;
    if (event.key === 'Enter') {
      this.getOffers(0, 5, 'opsCode', 'asc', val);
    }
  }


  formatDate(date: Date | string) {
    return this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm:ss', 'fr');
  }


  onPageChangeContract(event: any) {
    if (this.searchText != '') {
      this.filterContracts(event.offset, 5, this.contracts.sorts[0].prop, this.contracts.sorts[0].dir, this.searchText);
    } else {
      this.getContracts(event.offset, 5, this.contracts.sorts[0].prop, this.contracts.sorts[0].dir);
    }

  }

  onSortContract(event: any) {
    if (this.searchText != '') {
      this.filterContracts(this.contractPage.currentPage!, 5, event.sorts[0].prop, event.sorts[0].dir, this.searchText);
    } else {
      this.getContracts(this.contractPage.currentPage!, 5, event.sorts[0].prop, event.sorts[0].dir);
    }
    // On remet la page de la table manuellement a chaque sort car par défaut ngx-datatable revient page 1 ce qui n'a pas de sens sur un sort.
    this.contracts.offset = this.contractPage.currentPage!;
  }


  filterContracts(page: number, itemPerPage: number, sort: string, order: string, filter: string): Promise<any> {
    return new Promise((resolve) => {
      this.replayerService.getFilteredContracts(true, page, itemPerPage, sort, order, "%" + filter + "%").subscribe({
        next: (response: any) => {
          this.listContracts = response.content.map((data: any) => {
            return <ContratsTable>{
              contractNumber: data.contractNumber,
              subtype: data.subtype,
              opsCode: data.opsCode,
            };
          })
          this.contractPage = {
            currentPage: response.pageable.pageNumber,
            itemsOnPage: response.pageable.pageSize,
            currentOffset: response.pageable.offset,
            totalPages: response.totalPages,
            totalItems: response.totalElements
          }
        },
        complete: () => {
          resolve(true);
        },
      });
    });
  }


  onPageChangeOffer(event: any) {
    this.getOffers(event.offset, 5, this.offersDataTable.sorts[0].prop, this.offersDataTable.sorts[0].dir, this.searchOffer);
  }

  onSortOffer(event: any) {
    this.getOffers(this.offerPage.currentPage!, 5, event.sorts[0].prop, event.sorts[0].dir, this.searchOffer);
    this.offersDataTable.offset = this.offerPage.currentPage!;
  }

}
