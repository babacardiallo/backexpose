package fr.laposte.blg.blinks.u11.listener;


import MD.LatestValue.Address;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.AddressRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractVersionRepository;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u11.listener.address.AddressListenerService;
import fr.laposte.blg.blinks.u11.listener.contract.ContractFullService;
import fr.laposte.blg.blinks.u11.mapper.AddressListenerMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.kafka.receiver.ReceiverRecord;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;


class AddressListenerServiceTest {

    @InjectMocks
    private AddressListenerService addressService;

    @Mock
    private AddressRepository addressRepository;

    @Mock
    private AddressListenerMapper addressListenerMapper;

    @Mock
    private ContractRepository contractRepository;

    @Mock
    private SynchronizationSender synchronizationSender;

    @Mock
    private ContractVersionRepository contractVersionRepository;

    @Mock
    private LegalPersonService legalPersonService;

    @Mock
    private ContractFullService contractFullService;

    @Mock
    private ErrorLogService errorLogService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addressNotFoundTest() {
        Address address = new Address();
        address.setRefpmAdressId("86845");
        ConsumerRecord<String, Address> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", address);
        ReceiverRecord<String, Address> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        when(this.addressRepository.findByAddressIdRefPM(anyString())).thenReturn(Mono.empty());

        StepVerifier.create(this.addressService.updateAddress(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.addressRepository, times(1)).findByAddressIdRefPM(anyString());
        verify(this.addressRepository, times(0)).save(any(AddressEntity.class));
    }

    @Test
    void addressFoundTest() {
        Address address = new Address();
        address.setRefpmAdressId("86845");

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setIdAddress(86845L);
        addressEntity.setCustAccNumber(1889);
        addressEntity.setIdLegalPerson(354L);
        addressEntity.setName1("firstName");
        addressEntity.setAddressIdRefPM("86845");
        addressEntity.setAddressType(AddressType.FACTURATION);

        AddressEntity updatedAddressEntity = new AddressEntity();
        updatedAddressEntity.setIdAddress(86845L);
        updatedAddressEntity.setCustAccNumber(1889);
        updatedAddressEntity.setIdLegalPerson(354L);
        updatedAddressEntity.setName1("anotherName");
        updatedAddressEntity.setAddressType(AddressType.FACTURATION);
        updatedAddressEntity.setAddressIdRefPM("86845");

        ConsumerRecord<String, Address> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", address);
        ReceiverRecord<String, Address> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdContract(1L);

        when(this.addressRepository.findByAddressIdRefPM(anyString())).thenReturn(Mono.just(addressEntity));
        when(this.addressRepository.save(any(AddressEntity.class))).thenAnswer(i -> Mono.just(i.getArgument(0)));
        when(this.addressListenerMapper.addressToAddressEntity(any())).thenReturn(updatedAddressEntity);
        when(this.contractVersionRepository.findContractVersionUsingRefPMAddressId(anyString())).thenReturn(Flux.just(contractVersionEntity));
        when(this.contractFullService.isOfferOfContractEligibleUpdate(any(ContractVersionEntity.class))).thenReturn(Mono.just(true));
        when(this.contractVersionRepository.save(any(ContractVersionEntity.class))).thenReturn(Mono.just(contractVersionEntity));
        when(this.errorLogService.logError(any())).thenReturn(Mono.empty());

        StepVerifier.create(this.addressService.updateAddress(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.addressRepository, times(1)).findByAddressIdRefPM(anyString());
        verify(this.addressRepository, times(1)).save(any(AddressEntity.class));
        verify(this.contractVersionRepository, times(1)).findContractVersionUsingRefPMAddressId(anyString());
    }


    @Test
    void addressFoundTestPrestation() {
        Address address = new Address();
        address.setRefpmAdressId("86845");

        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setIdAddress(86845L);
        addressEntity.setCustAccNumber(1889);
        addressEntity.setIdLegalPerson(354L);
        addressEntity.setName1("firstName");
        addressEntity.setAddressIdRefPM("86845");
        addressEntity.setAddressType(AddressType.PRESTATION);

        AddressEntity updatedAddressEntity = new AddressEntity();
        updatedAddressEntity.setIdAddress(86845L);
        updatedAddressEntity.setCustAccNumber(1889);
        updatedAddressEntity.setIdLegalPerson(354L);
        updatedAddressEntity.setName1("anotherName");
        updatedAddressEntity.setAddressType(AddressType.PRESTATION);
        updatedAddressEntity.setAddressIdRefPM("86845");

        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(1L);
        legalPersonEntity.setCustAccNumber(1);

        ConsumerRecord<String, Address> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", address);
        ReceiverRecord<String, Address> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        when(this.addressRepository.findByAddressIdRefPM(anyString())).thenReturn(Mono.just(addressEntity));
        when(this.addressRepository.save(any(AddressEntity.class))).thenAnswer(i -> Mono.just(i.getArgument(0)));
        when(this.addressListenerMapper.addressToAddressEntity(any())).thenReturn(updatedAddressEntity);
        when(this.contractVersionRepository.findContractVersionUsingRefPMAddressId(anyString())).thenReturn(Flux.empty());
        when(this.legalPersonService.findLegalPersonByIdLegalPerson(anyLong(), anyBoolean())).thenReturn(Mono.just(legalPersonEntity));
        when(this.legalPersonService.save(any(LegalPersonEntity.class), anyBoolean())).thenReturn(Mono.just(legalPersonEntity));
        when(this.errorLogService.logError(any())).thenReturn(Mono.empty());

        StepVerifier.create(this.addressService.updateAddress(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.addressRepository, times(1)).findByAddressIdRefPM(anyString());
        verify(this.addressRepository, times(1)).save(any(AddressEntity.class));
        verify(this.legalPersonService, times(1)).save(any(LegalPersonEntity.class), anyBoolean());
    }

    @Test
    void publishAddressSyncCommandTest(){
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        StepVerifier.create(this.addressService.publishAddressSyncCommand(1L, "test_contract_topic", "contractId-1"))
                .expectSubscription()
                .verifyComplete();
        verify(this.synchronizationSender, times(1)).send(any());
    }

    @Test
    void publishCustomerSyncCommandTest(){
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        StepVerifier.create(this.addressService.publishCustomerSyncCommand(1L, "test_customer_topic", "cust-1"))
                .expectSubscription()
                .verifyComplete();
        verify(this.synchronizationSender, times(1)).send(any());
    }
}
