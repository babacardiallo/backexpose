package fr.laposte.blg.blinks.u16.mapper;

import org.apache.commons.lang3.ObjectUtils;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

@Mapper
public interface GenericMapper {

    GenericMapper INSTANCE = Mappers.getMapper(GenericMapper.class);

    DateTimeFormatter DATE_TIME_FORMATTER_FR = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    default String toString(CharSequence charSequence) {
        return (charSequence != null) ? charSequence.toString() : null;
    }

    default Instant asInstant(CharSequence date) {
        return date != null && !date.toString().isBlank() ? LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant() : null;
    }

    default LocalDate asLocalDate(CharSequence date) {
        if (Objects.isNull(date) || ObjectUtils.isEmpty(date.toString())) {
            return null;
        }

        return LocalDate.parse(date, DATE_TIME_FORMATTER_FR);
    }
}
