package fr.laposte.blg.blinks.u17.repository;

import fr.laposte.blg.blinks.u17.entities.BatchConfig;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BatchConfigRepository extends ReactiveCrudRepository<BatchConfig, Integer> {
}
