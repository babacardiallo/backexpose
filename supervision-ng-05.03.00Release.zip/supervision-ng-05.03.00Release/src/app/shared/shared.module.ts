/** ***********************************************************
 *
 * SHARED : The aim of this class is to store all the modules that
 * are used/shared accross the entire application modules
 *
 *********************************************************** **/

/** Angular Common Imports */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Uit Imports */


/** Angular Forms Imports */
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

/** Ngx Imports */

import { NgxJsonViewerModule } from 'ngx-json-viewer';
import { NgSelectModule } from '@ng-select/ng-select';

/** Material Imports */
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatListModule } from '@angular/material/list';

/** FlexLayout Imports */

/** Error Management Imports */
import { ErrorDialogComponent } from './errors/components/error-dialog.component';
import { ErrorDialogService } from './errors/service/error-dialog.service';
import { LoaderComponent } from './errors/components/loader.component';
import { UitBannerActionsComponent, UitBannerComponent, UitBodyComponent, UitContentComponent, UitFooterComponent, UitHeaderComponent, UitSidebarComponent, UitSidebarExpandableComponent, UitSidebarItemComponent, UitViewComponent } from '@cddng/ui-theme';
import { ModalService } from 'ngx-modal-ease';
import { ConfirmComponent } from './widgets/components/confirm.component';
import { JsonWidgetComponent } from './widgets/components/json/json-widget.component';
import { MatDividerModule } from '@angular/material/divider';

import {
        NgxMatDatepickerActions,
        NgxMatDatepickerApply,
        NgxMatDatepickerCancel,
        NgxMatDatepickerClear,
        NgxMatDatepickerInput,
        NgxMatDatetimepicker,
} from '@ngxmc/datetime-picker';

import { provideNativeDateAdapter } from '@angular/material/core';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';




const sharedComponents = [ErrorDialogComponent, LoaderComponent, ConfirmComponent, JsonWidgetComponent];
@NgModule({
        declarations: [
                sharedComponents
        ],
        imports: [
                CommonModule,
                MatCardModule,
                MatIconModule,
                MatButtonModule,
                FormsModule,
                MatDatepickerModule,
                MatInputModule,
                MatNativeDateModule,
                MatCheckboxModule,
                NgxMatDatepickerActions,
                NgxMatDatepickerActions,
                NgxMatDatepickerApply,
                NgxMatDatepickerCancel,
                NgxMatDatepickerClear,
                NgxMatDatepickerInput,
                NgxMatDatetimepicker,
                ReactiveFormsModule,
                MatDialogModule,
                NgxJsonViewerModule,
                MatTooltipModule,
                UitViewComponent,
                UitHeaderComponent,
                UitBodyComponent,
                UitSidebarExpandableComponent,
                UitFooterComponent,
                UitSidebarComponent,
                UitSidebarComponent,
                UitSidebarItemComponent,
                UitContentComponent,
                UitBannerComponent,
                UitBannerActionsComponent,
                MatButtonModule,
                MatDividerModule,
                MatFormFieldModule,
                MatListModule,
                FlexLayoutModule,
                NgSelectModule
        ],
        exports: [
                CommonModule,
                MatCardModule,
                MatIconModule,
                MatButtonModule,
                FormsModule,
                MatDatepickerModule,
                MatInputModule,
                MatNativeDateModule,
                MatCheckboxModule,
                NgxMatDatepickerActions,
                NgxMatDatepickerActions,
                NgxMatDatepickerApply,
                NgxMatDatepickerCancel,
                NgxMatDatepickerClear,
                NgxMatDatepickerInput,
                NgxMatDatetimepicker,
                ReactiveFormsModule,
                MatDialogModule,
                MatRadioModule,
                MatTooltipModule,
                NgxJsonViewerModule,
                sharedComponents,
                UitViewComponent,
                UitHeaderComponent,
                UitBodyComponent,
                UitSidebarExpandableComponent,
                UitFooterComponent,
                UitSidebarComponent,
                UitSidebarComponent,
                UitSidebarItemComponent,
                UitContentComponent,
                UitBannerComponent,
                UitBannerActionsComponent,
                MatDividerModule,
                MatButtonModule,
                MatFormFieldModule,
                MatListModule,
                FlexLayoutModule,
                NgSelectModule
        ],
        providers: [
                ErrorDialogService,
                ModalService,
                provideNativeDateAdapter(),
        ]
})
export class SharedModule { }
