package fr.laposte.blg.blinks.u18.listener;


import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import fr.laposte.blg.blinks.u18.entity.MessageStatus;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Optional;


@Slf4j
@Component
@RequiredArgsConstructor
public class
CustomerAccountListener {
    @Value("${module-config.consumers.topic}")
    private String topic;

    @Value("${module-config.consumers.consumer-group-id}")
    private String consumerGroupId;

    @Value("#{'${module-config.consumers.offers}'.split(',')}")
    private List<String> eligibleOfferCodes;

    private final CustomerAccountService customerAccountService;

    public static final MessageStatus DEFAULT_STATUS = MessageStatus.PENDING;

    // ✅ expose les propriétés à SpEL
    public String getTopic() {
        return topic;
    }

    public String getConsumerGroupId() {
        return consumerGroupId;
    }

    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", topic);
        log.info("Kafka groupId: {}", consumerGroupId);
        log.info("Eligible offers: {}", eligibleOfferCodes);

        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", topic, consumerGroupId);
    }

    @KafkaListener(id = "${module-config.consumers.consumer-group-id}", topics = "${module-config.consumers.topic}", groupId = "${module-config.consumers.consumer-group-id}")
    public void onMessages(List<ConsumerRecord<String, fr.laposte.bscc.avro.compteconsommateur.Consommateur>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} record(s) from topic '{}'", total, topic);

        try {
            for (ConsumerRecord<String, fr.laposte.bscc.avro.compteconsommateur.Consommateur> record : records) {
                MDC.put("kafka.key", record.key());
                MDC.put("kafka.topic", record.topic());
                MDC.put("kafka.partition", String.valueOf(record.partition()));
                MDC.put("kafka.offset", String.valueOf(record.offset()));

                log.debug("Record received: key={}, topic={}, partition={}, offset={}",
                        record.key(), record.topic(), record.partition(), record.offset());

                var rawValue = Optional.ofNullable(record.value()).map(Object::toString).orElse("null");
                log.debug("Raw value: {}", rawValue);

                CustomerAccountMessage message = map(record);

                if (message == null) {
                    log.warn("Mapping failed for key={}, skipping record", record.key());
                    continue;
                }

                log.info("Mapped message: contract={}, offerCode={}", message.getContractNumber(), message.getOfferCode());

                if (!isEligible(message)) {
                    log.info("Message not eligible: offerCode={} (contract={})", message.getOfferCode(), message.getContractNumber());
                    continue;
                }

                customerAccountService.save(message);
                log.info("Message saved: contract={}, offset={}, partition={}",
                        message.getContractNumber(), record.offset(), record.partition());

                MDC.clear();
            }

            ack.acknowledge();
            log.info("Batch processing complete: {} record(s) acknowledged", total);

        } catch (Exception batchException) {
            log.warn("Batch processing failed — retrying individually ({} record(s))", total, batchException);
            retryIndividually(records, ack);
        }
    }


    private void retryIndividually(List<ConsumerRecord<String, fr.laposte.bscc.avro.compteconsommateur.Consommateur>> records, Acknowledgment ack) {
        boolean allSucceeded = true;

        for (ConsumerRecord<String, fr.laposte.bscc.avro.compteconsommateur.Consommateur> record : records) {
            try {
                CustomerAccountMessage message = map(record);
                if (message == null || isEligible(message)) continue;

                customerAccountService.save(message);
                log.info("Successfully retried record: key={}, offset={}", record.key(), record.offset());
            } catch (Exception e) {
                log.error("Failed to process record individually: key={}, offset={}", record.key(), record.offset(), e);
                allSucceeded = false;
            }
        }

        if (allSucceeded) {
            ack.acknowledge(); // ✅ tous les retries ont réussi
        } else {
            log.warn("Some individual retries failed — skipping acknowledgment to allow Kafka retry.");
        }
    }


    private CustomerAccountMessage map(ConsumerRecord<String, fr.laposte.bscc.avro.compteconsommateur.Consommateur> record) {
        MDC.put("kafka.key", record.key());
        MDC.put("kafka.topic", record.topic());
        MDC.put("kafka.partition", String.valueOf(record.partition()));
        MDC.put("kafka.offset", String.valueOf(record.offset()));

        var consommateur = record.value();

        if (consommateur == null) {
            log.warn("Received null value for Kafka record");
            MDC.clear();
            return null;
        }

        try {
            var contractInfo = consommateur.getContract().getContractInfo();
            String contractNumber = contractInfo.getContractNumber().toString();
            String offerCode = contractInfo.getOfferCode() !=null ?contractInfo.getOfferCode().toString(): "";

            log.debug("Mapping successful: contractNumber={}, offerCode={}", contractNumber, offerCode);

            return CustomerAccountMessage.builder()
                    .contractNumber(contractNumber)
                    .offerCode(offerCode)
                    .messageKey(record.key())
                    .messageValue(record.value().toString())
                    .topicName(record.topic())
                    .topicPartition(record.partition())
                    .topicOffset(record.offset())
                    .status(DEFAULT_STATUS)
                    .created(Instant.now())
                    .updated(Instant.now())
                    .build();

        } catch (Exception e) {
            log.error("Failed to map Kafka record to CustomerAccountMessage: {}", e.getMessage(), e);
            return null;
        } finally {
            MDC.clear();
        }
    }

    public boolean isEligible(CustomerAccountMessage message) {
        String offerCode = message.getOfferCode();
        return eligibleOfferCodes != null &&
                !eligibleOfferCodes.isEmpty() &&
                eligibleOfferCodes.contains(offerCode);
    }


}
