package fr.laposte.blg.blinks.lib.common.entities;


import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table("invoice_supervision")
public class InvoiceSupervision {
    @Id
    @Column("id_invoice")
    private Long idInvoice;
    @Column("invoice_number")
    private String invoiceNumber;
    @Column("created")
    private Instant created;
    @Column("client")
    private Integer client;
    @Column("billrun_id")
    private String billrunId;
    @Column("docaposte_export_status")
    private InvoiceStatusEnum docaposteExportStatus;
    @Column("infoca_export_status")
    private InvoiceStatusEnum infocaExportStatus;
    @Column("coeurfinance_export_status")
    private InvoiceStatusEnum coeurfinanceExportStatus;
    @Column("docaposte_export_date")
    private Instant docaposteExportDate;
    @Column("docaposte_export_id")
    private Long docaposteExportId;
    @Column("infoca_export_date")
    private Instant infocaExportDate;
    @Column("infoca_export_id")
    private Long infocaExportId;
    @Column("coeurfinance_export_date")
    private Instant coeurfinanceExportDate;
    @Column("coeurfinance_export_id")
    private Long coeurfinanceExportId;
}
