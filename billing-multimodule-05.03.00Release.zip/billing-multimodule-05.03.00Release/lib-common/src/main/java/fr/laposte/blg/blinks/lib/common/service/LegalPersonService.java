package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonMessage;
import fr.laposte.blg.blinks.lib.common.entities.repositories.AddressRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LegalPersonMessageRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LegalPersonRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Service
@Data
@RequiredArgsConstructor

public class LegalPersonService {

    private final LegalPersonRepository legalPersonRepository;
    private final AddressRepository addressRepository;
    private final LegalPersonMessageRepository legalPersonMessageRepository;

    public Mono<LegalPersonEntity> findLegalPersonByIdLegalPerson(Long idLegalPerson, boolean loadAddresses) {

        Mono<LegalPersonEntity> legalPersonToReturn = legalPersonRepository.findById(idLegalPerson);

        if (loadAddresses) {
            legalPersonToReturn =
                legalPersonToReturn
                    .flatMap(legalPersonEntity ->
                        addressRepository.findByIdLegalPerson(legalPersonEntity.getIdLegalPerson())
                            .map(addressEntity -> addressEntity
                                .setIdLegalPerson(legalPersonEntity.getIdLegalPerson())
                                .setLegalPersonEntity(legalPersonEntity))
                            .collectList()
                            .map(legalPersonEntity::setAddressEntityList)
                    );
        }
        return legalPersonToReturn;

    }

    public Mono<LegalPersonEntity> findLegalPersonByCoclico(int coclico, boolean loadAddresses) {

        Mono<LegalPersonEntity> legalPersonToReturn = legalPersonRepository.findByCustAccNumber(coclico);

        if (loadAddresses) {
            legalPersonToReturn =
                legalPersonToReturn
                    .flatMap(legalPersonEntity ->
                        addressRepository.findByIdLegalPerson(legalPersonEntity.getIdLegalPerson())
                            .map(addressEntity -> addressEntity
                                .setIdLegalPerson(legalPersonEntity.getIdLegalPerson())
                                .setLegalPersonEntity(legalPersonEntity))
                            .collectList()
                            .map(legalPersonEntity::setAddressEntityList)
                    );
        }
        return legalPersonToReturn;

    }

    /**
     * Method allowing to save the legalPerson and the addresses if saveAddresses is true.
     *
     * @param legalPersonEntity legalPerson to save
     * @param saveAddresses     save the addresses in addition to the legalPerson
     * @return the legalPerson entity saved
     */
    public Mono<LegalPersonEntity> save(LegalPersonEntity legalPersonEntity, boolean saveAddresses) {

        Mono<LegalPersonEntity> legalPersonEntityMono = legalPersonRepository.save(legalPersonEntity);

        if (saveAddresses) {
            assert (ObjectUtils.isNotEmpty(legalPersonEntity.getAddressEntityList()));
            Flux<AddressEntity> addressEntityFlux = Flux.fromIterable(legalPersonEntity.getAddressEntityList()
            );
            return legalPersonEntityMono
                .flatMap(legalPersonEntity1 ->
                    addressEntityFlux
                        .concatMap(addressEntity -> addressRepository.findByAddressIdRefPM(addressEntity.getAddressIdRefPM())
                            .switchIfEmpty(Mono.just(addressEntity))
                        )
                        .map(addressEntity ->
                            addressEntity
                                .setIdLegalPerson(legalPersonEntity1.getIdLegalPerson())
                                .setLegalPersonEntity(legalPersonEntity1))
                        .filter(addressEntity -> addressEntity.getAddressType().equals(AddressType.FACTURATION)
                            || addressEntity.getAddressType().equals(AddressType.PRINCIPALE)
                            || addressEntity.getAddressType().equals(AddressType.PRESTATION)
                        )
                        .concatMap(addressRepository::save)
                        .collectList()
                        .map(legalPersonEntity::setAddressEntityList)
                );
        } else {
            return legalPersonEntityMono;
        }

    }

    public Mono<LegalPersonEntity> saveLegalPersonMessage(LegalPersonEntity legalPersonEntity, LegalPersonMessage legalPersonMessage){
        legalPersonMessage.setIdLegalPerson(legalPersonEntity.getIdLegalPerson());
        return legalPersonMessageRepository.findByIdLegalPerson(legalPersonEntity.getIdLegalPerson())
                .map(legalPersonMessage1 -> {
                    legalPersonMessage.setIdLegalPersonMessage(legalPersonMessage1.getIdLegalPersonMessage());
                    return legalPersonMessage;
                })
                .switchIfEmpty(Mono.defer(() -> Mono.just(legalPersonMessage)))
                .flatMap(legalPersonMessageRepository::save)
                .thenReturn(legalPersonEntity);
    }

    public Mono<LegalPersonEntity> markLegalPersonSynchronized(String custAccNumber) {
        return this.legalPersonRepository.findByCustAccNumber(Integer.parseInt(custAccNumber))
            .map(legalPersonEntity -> {
                legalPersonEntity.setSynchronized(true);
                legalPersonEntity.setDateSynchronization(Instant.now());
                return legalPersonEntity;
            })
            .flatMap(this.legalPersonRepository::save);
    }

    public Mono<AddressEntity> findMainAddress(String addressId) {
        return this.addressRepository.findByAddressIdRefPM(addressId);
    }

    public Mono<AddressEntity> saveMainAddress(AddressEntity addressEntity) {
        return this.addressRepository.save(addressEntity);
    }

    public Flux<LegalPersonEntity> findAllClientsAlreadySynchronized() {
        return this.legalPersonRepository.findAllByIsSynchronizedTrue();
    }

    public Flux<LegalPersonEntity> findAllClients(){
        return this.legalPersonRepository.findAllBy();
    }
}
