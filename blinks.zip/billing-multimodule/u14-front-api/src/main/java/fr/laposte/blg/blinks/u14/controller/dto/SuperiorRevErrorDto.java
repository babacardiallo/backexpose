package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class SuperiorRevErrorDto {
    private String id;
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionNumber;
    private String status;
    private String subStatus;
    private String type;
    private String subtype;
    private String opsCode;
    private String opsLabel;
    private Boolean isSynchronized;
    private Instant dateError;
    private Instant lastDateSynchronization;
    private Instant firstErrorDate;
    private Integer custAccNumber;
    private Integer custAccNumberBeforeSynchronisation;
    private Integer superiorRevError;
    private String superiorRevErrMessage;
    private String supOffsetError;
    private String supPartitionError;
    private boolean hasSuperiorRevError;

}
