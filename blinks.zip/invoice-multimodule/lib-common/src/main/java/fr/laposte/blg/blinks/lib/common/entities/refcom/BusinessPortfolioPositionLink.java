package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_portfolio_position_link")
@Data
@Accessors(chain = true)
public class BusinessPortfolioPositionLink implements Disposable, Persistable<Long> {
    @Id
    @Column("business_portfolio_link_position_id")
    private Long businessPortfolioLinkPositionId;
    @Column("business_position_id")
    private Long businessPositionId;
    @Column("business_portfolio_id")
    private int businessPortfolioId;
    @Column("business_portfolio_link_type_id")
    private Integer businessPortfolioLinkTypeId;
    @Column("business_portfolio_link_position_start_date")
    private Instant businessPortfolioLinkPositionStartDate;
    @Column("business_portfolio_link_position_end_date")
    private Instant businessPortfolioLinkPositionEndDate;

    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessPortfolioLinkPositionStartDate) &&
                        businessPortfolioLinkPositionStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessPortfolioLinkPositionEndDate)
                                || businessPortfolioLinkPositionEndDate.isAfter(Instant.now())
                )
                        &&
                        businessPortfolioLinkTypeId == 1;//On ne prend que les liens de portefeuille PILOTE soit d'id 1 ;
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessPortfolioLinkPositionId;
    }


    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
