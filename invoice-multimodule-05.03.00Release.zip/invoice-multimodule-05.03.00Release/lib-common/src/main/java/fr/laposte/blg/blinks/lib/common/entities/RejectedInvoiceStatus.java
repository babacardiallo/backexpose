package fr.laposte.blg.blinks.lib.common.entities;

public enum RejectedInvoiceStatus {
    REJECTED,
    REPLAYED
}
