export class ClientPage {
    currentPage?: number;
    itemsOnPage?: number;
    currentOffset?: number;
    totalPages?: number;
    totalItems?: number;
}