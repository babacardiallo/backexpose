package fr.laposte.blg.blinks.u11;

import fr.laposte.blg.blinks.lib.common.config.EnableBillingLibrary;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe Application du module u11.
 */
 @SpringBootApplication(scanBasePackages = "fr.laposte.blg.blinks")
@EnableBillingLibrary
@Slf4j
public class U11 {

    public static void main(String[] args) {
        SpringApplication.run(U11.class, args);
    }

    @PostConstruct
    public void init(){
        log.info("USER DIR {} ", System.getProperty("user.dir"));

    }

}
