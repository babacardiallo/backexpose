import { Component, Input, OnInit } from '@angular/core';
import { formatDate } from "@angular/common";
import { SupervisionService } from '../../service/supervision.service';

@Component({
  selector: 'file-transfer',
  templateUrl: './file-transfer.component.html',
  styleUrl: './file-transfer.component.scss',
  standalone: false
})
export class FileTransferComponent implements OnInit {

  @Input() selected!: Date;
  exportFileList: any[] = [];


  constructor(private supervisionService: SupervisionService){

  }
  ngOnInit(): void {
    this.callFileTransferStatus(this.selected);
  }

  callFileTransferStatus(date: Date): void {
    this.exportFileList = [];
    this.selected = date;
    this.supervisionService.getDailyFileTransfer(this.formatDatetoApi(this.selected))
      .pipe().subscribe(response => {
        this.exportFileList = response;        
      });
  }

  callFileTransferStatusMonthly(date: Date): void {
    this.exportFileList = [];
    this.selected = date;
    this.supervisionService.getMontlyFileTransfer(date.getFullYear(), date.getMonth() + 1)
      .pipe().subscribe(response => {
        this.exportFileList = response;        
      });

  }


  
  formatDate(date: Date): string {
    const format = 'dd/MM/yyyy';
    const locale = "fr-FR";
    return formatDate(date, format, locale);
  }

  formatDatetoApi(date: Date): string {
    const format = 'yyyy-MM-dd';
    const locale = "fr-FR";
    return formatDate(date, format, locale);
  }

}
