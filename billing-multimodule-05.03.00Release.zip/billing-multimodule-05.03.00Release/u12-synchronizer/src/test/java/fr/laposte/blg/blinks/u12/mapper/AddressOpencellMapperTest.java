package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.bscc.billing.avro.billing.AddressOpencell;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@Slf4j
@ActiveProfiles("test")
class AddressOpencellMapperTest {

    @Autowired
    AddressOpencellMapper addressOpencellMapper;

    @Test
    void testAddressEntityToCustomerAddress() {
        AddressEntity source = new AddressEntity();
        source.setAddressIdRefPM("12345");
        source.setName1("John Doe");
        source.setAdd2("Street 123");
        source.setAdd3("Extra line 1");
        source.setAdd4("Extra line 2");
        source.setAdd5("City");
        source.setAdd6("State");
        source.setAdd7("Zipcode");

        AddressOpencell result = addressOpencellMapper.addressEntityToCustomerAddress(source);

        assertEquals(source.getAddressIdRefPM(), String.valueOf(result.getAddressId()));
        assertEquals(source.getName1(),          result.getName1());
        assertEquals(source.getAdd2(),          result.getAdd2());
        assertEquals(source.getAdd3(),          result.getAdd3());
        assertEquals(source.getAdd4(),          result.getAdd4());
        assertEquals(source.getAdd5(),          result.getAdd5());
        assertEquals(source.getAdd6(),          result.getAdd6());
        assertEquals(source.getAdd7(),          result.getAdd7());
    }
}
