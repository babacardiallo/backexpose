package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.TeamAssignmentLink;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface TeamAssignmentLinkRepository extends ReactiveCrudRepository<TeamAssignmentLink, Long> {

    Mono<TeamAssignmentLink> findByBusinessTeamLinkPositionId(Long businessTeamLinkPositionId);


    @Query("SELECT * from refcom_team_assignment_link WHERE business_position_id = :businessPositionId AND business_team_link_position_start_date <= NOW() AND (business_team_link_position_end_date IS NULL OR business_team_link_position_end_date > NOW()) LIMIT 1")
    Mono<TeamAssignmentLink> findActiveTeamAssignmentByBusinessPositionId(Long businessPositionId);




    @Query("SELECT * from refcom_team_assignment_link WHERE business_team_id = :businessTeamId AND business_team_link_position_start_date <= NOW() AND (business_team_link_position_end_date IS NULL OR business_team_link_position_end_date > NOW()) LIMIT 1")
    Mono<TeamAssignmentLink> findFirstPositionAssignmentByBusinessTeamId(int businessTeamId);

}
