package fr.laposte.blg.blinks.lib.common.entities.organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDate;

@Table("source_orga_organization")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class OrganizationEntity {

    @Id
    @Column("id")
    private Long id;

    /**
     * Code ROC - peut être inutile
     */
    @Column("code")
    private String code;
    /**
     * Code Régate - peut être inutile
     */
    @Column("code_regate")
    private String codeRegate;

    /**
     * Date de création
     */
    @Column("date_creation")
    private LocalDate creationDate;

    /**
     * Date de modification
     */
    @Column("date_modification")
    private LocalDate modificationDate;
    /**
     * Date de désactivation
     */
    @Column("date_desactivation")
    private LocalDate deactivationDate;
    /**
     * Date de fermeture
     */
    @Column("date_fermeture")
    private LocalDate closingDate;

}
