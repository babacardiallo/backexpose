import { UntypedFormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";

// permet de ne valider le form seulement si au moins un des champs choisis dans le validator est valide.
export const atLeastOne = (validator: ValidatorFn, controls: string[]) => (
    group: UntypedFormGroup,
): ValidationErrors | null => {
    if (!controls) {
        controls = Object.keys(group.controls)
    }

    const hasAtLeastOne = group && group.controls && controls
        .some(k => !validator(group.controls[k]));

    return hasAtLeastOne ? null : {
        atLeastOne: true,
    };
};

// permet de valider le form seulement si une des checkbox est cochée
export const atLeastOneChecked = (controls: string[]) => (
    group: UntypedFormGroup,
): ValidationErrors | null => {
    if (!controls) {
        controls = Object.keys(group.controls)
    }

    const hasAtLeastOneChecked = group && group.controls && controls
        .some(k => group.controls[k].value);

    return hasAtLeastOneChecked ? null : {
        atLeastOneChecked: true,
    };
};
