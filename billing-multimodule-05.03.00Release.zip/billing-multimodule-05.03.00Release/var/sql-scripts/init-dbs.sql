CREATE DATABASE IF NOT EXISTS `blg_contract_importer`;
CREATE USER 'blg'@'localhost' IDENTIFIED BY 'root';
CREATE USER 'blg'@'%' IDENTIFIED BY 'root';
GRANT ALL ON `blg_contract_importer`.* TO 'blg'@'localhost';
GRANT ALL ON `blg_contract_importer`.* TO 'blg'@'%';