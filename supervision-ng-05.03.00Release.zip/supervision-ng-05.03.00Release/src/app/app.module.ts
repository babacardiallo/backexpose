import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID, DEFAULT_CURRENCY_CODE } from '@angular/core';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

/* App Root */
import { AppComponent } from './app.component';

/* Feature Modules */
import { CoreModule } from './core/core.module';
import { AppRoutingModule } from './app-routing.module';

/** Locale Imports */
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { NgxPermissionsModule } from 'ngx-permissions';
import { environment } from '../environments/environment';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthOidcApimModule } from '@cddng/auth-oidc-apim';
import { JwtInterceptor } from './auth/jwt-interceptor.service';
import { UitBodyComponent, UitContentComponent, UitFooterComponent, UitHeaderComponent, UitSidebarComponent, UitSidebarExpandableComponent, UitSidebarHeaderComponent, UitSidebarItemComponent, UitViewComponent } from '@cddng/ui-theme';
import { provideNativeDateAdapter, MatNativeDateModule } from '@angular/material/core';



/** Registering Locale */
registerLocaleData(localeFr);

@NgModule({ 
    
    declarations: [
        AppComponent,
    ],
    bootstrap: [AppComponent],
    
    imports: [BrowserModule,
        UitViewComponent,
        UitHeaderComponent,
        UitBodyComponent,
        UitSidebarExpandableComponent,
        UitFooterComponent,
        UitSidebarComponent,
        UitSidebarComponent,
        UitSidebarItemComponent,
        UitContentComponent,
        UitSidebarHeaderComponent,
        BrowserAnimationsModule,
        CoreModule,
        AppRoutingModule,
        AuthOidcApimModule.forRoot(environment.authentification),
        NgxPermissionsModule.forRoot(),
        MatNativeDateModule
    ],
        
        providers: [
        { provide: LOCALE_ID, useValue: 'fr' },
        { provide: DEFAULT_CURRENCY_CODE, useValue: 'EUR' },
        {
            provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideNativeDateAdapter(),
    ] })
export class AppModule { }
