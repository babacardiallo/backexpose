package listener;


import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import fr.laposte.blg.blinks.u18.listener.CustomerAccountService;
import fr.laposte.blg.blinks.u18.repository.CustomerAccountRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CustomerMessageServiceTest {

    @InjectMocks
    private CustomerAccountService customerAccountService;

    @Mock
    private CustomerAccountRepository customerAccountRepository;

    @Test
    void saveTest(){
        when(customerAccountRepository.save(any(CustomerAccountMessage.class))).thenReturn(new CustomerAccountMessage());
        customerAccountService.save(new CustomerAccountMessage());
        verify(customerAccountRepository, atLeastOnce()).save(any(CustomerAccountMessage.class));
    }
}
