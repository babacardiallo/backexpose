package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
@JsonPropertyOrder({
        "RUM",
        "IBAN",
        "BIC",
        "signatoryLastName"
})
public class UniqueMandateReferenceDto {
    @JsonProperty("RUM")
    String rum;
    @JsonProperty("IBAN")
    String iban;
    @JsonProperty("BIC")
    String bic;
    String signatoryLastName;
}
