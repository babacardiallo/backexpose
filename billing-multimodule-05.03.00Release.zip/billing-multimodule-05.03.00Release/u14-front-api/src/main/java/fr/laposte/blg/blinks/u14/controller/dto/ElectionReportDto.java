package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElectionReportDto {
    private String sequence;
    private String coclico;
    private String marketNumber;
    private String contractNumber;
    private String action;
    private List<String> errors = new ArrayList<>();
}
