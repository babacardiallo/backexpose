package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.InvoiceMessageEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface InvoiceMessageRepository extends ReactiveCrudRepository<InvoiceMessageEntity, Long> {

    @Query("SELECT message from invoice_message where id_invoice = :id")
    Mono<String> getMessage(long id);

}