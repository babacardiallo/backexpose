package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessTeam;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessTeamRepository extends ReactiveCrudRepository<BusinessTeam, Integer> {

    Mono<BusinessTeam> findByBusinessTeamId(int businessTeamId);

}
