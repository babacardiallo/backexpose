Starter Kit
===========

> **Attention ! Si vous démarrez un nouveau projet, vous devez utiliser le "StarterKit Installer" pour initialiser votre application: https://git.net-courrier.extra.laposte.fr/GROUPE_ANGULAR_SHARED/starterkit-installer**


## Installation et configuration

> *Version details*
> * This project is based on **Angular 12.0**
> * This project was generated with **[Angular CLI](https://github.com/angular/angular-cli)**  ^12.0.0.

Récupération des dépendances

```
npm install
```

Lancement des services

```
ng serve
```

## Utilisation

L'application est lancée et prête à être utilisée : http://localhost:4200


## Ce qui est inclus

* Structure applicative fonctionnelle
* Base de tests unitaire de base : Karma/Jasmine
* Intégration du theme UI Laposte : UI Theme
* Sous module GIT docker permettant la configuration et l'utilisation du projet dans docker.

## Pour aller plus loin

Si vous souhaitez ajouter des services : https://wiki.net.extra.laposte.fr/confluence/display/ANGULAR/Cadre+de+Dev+Angular


Starter Kit
===========

## Development server

Run `ng serve --aot` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Gitlabci Angular template

https://git.net-courrier.extra.laposte.fr/groupe_cdd/gitlab-ci/templates/-/tree/main/Angular
