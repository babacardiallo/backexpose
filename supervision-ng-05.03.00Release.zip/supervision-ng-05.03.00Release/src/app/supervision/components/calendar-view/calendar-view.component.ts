import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CalendarEvent, CalendarMonthViewBeforeRenderEvent, CalendarView } from 'angular-calendar';
import { Subject } from 'rxjs';
import { SupervisionService } from '../../service/supervision.service';

@Component({
  selector: 'calendar-view',
  templateUrl: './calendar-view.component.html',
  styleUrl: './calendar-view.component.scss',
  standalone: false
})
export class CalendarViewComponent implements OnInit {


  @Input() selected!: Date;
  @Input() view!: CalendarView;
  @Output() onDayClick = new EventEmitter<Date>();
  events: CalendarEvent[] = [];
  refresh = new Subject<void>();

  constructor(private supervisionService: SupervisionService){

  }
  refreshView(): void {
    this.refresh.next();
  }
  ngOnInit(): void {
    this.getMonthlyTreatment(this.selected);
  }

  dayClicked(event: any) {
    this.selected = event.day.date
    this.onDayClick.emit(this.selected);
  }

  beforeMonthViewRender(renderEvent: CalendarMonthViewBeforeRenderEvent): void {
    renderEvent.body.forEach((day) => {
      if(day.events.length > 0){
        let transferStatusGlobal = 'ico-transfered tooltip';
        for(let i = 0; i < day.events.length; i++){
            const exportEvent = day.events[i];
            if(exportEvent.meta == 'NEW'){
              transferStatusGlobal = 'ico-new tooltip';
              break;
            }
        }

        for(let i = 0; i < day.events.length; i++){
            const exportEvent = day.events[i];
            if(exportEvent.meta == 'FAILED'){
              transferStatusGlobal = 'ico-failed tooltip';
              break;
            }
        }
        day.cssClass = transferStatusGlobal;
      } else {
        day.cssClass = 'icov';
      }
       
    });
  }

  getMonthlyTreatment(date: Date) {
    this.supervisionService.getMonthlyTreatment(date.getFullYear(), date.getMonth() + 1).subscribe(response => {
      this.events = response?.map((data: any) => {
        return <CalendarEvent>{
          title: data.title,
          start: new Date(data.start),
          end: new Date(data.end),
          meta: data.status,
          color: data.color == 0 ? {
            primary: 'green',
            secondary: 'white',
          } : data.color == 1 ? {
            primary: '#e3bc08',
            secondary: 'white',
          } : {
            primary: 'red',
            secondary: 'white',
          }
        };
      });
      this.refreshView();
    })
  }

}
