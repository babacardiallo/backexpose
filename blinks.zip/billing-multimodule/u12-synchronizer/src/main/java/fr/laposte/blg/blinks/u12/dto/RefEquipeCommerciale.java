package fr.laposte.blg.blinks.u12.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "EC_ID",
        "ECA_NOM_LONG"
})
public class RefEquipeCommerciale {

    @JsonProperty("EC_ID")
    private Integer businessTeamId;

    @JsonProperty("ECA_NOM_LONG")
    private String businessTeamLongName;
}
