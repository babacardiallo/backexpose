export interface ContractOdcJson {
  contract?: {
    offer?: {};
  };
  linkedContracts?: {};
  invoiceInformation?: {};
  contractInformation?: {};
  contractVersionInformation?: {};
}
