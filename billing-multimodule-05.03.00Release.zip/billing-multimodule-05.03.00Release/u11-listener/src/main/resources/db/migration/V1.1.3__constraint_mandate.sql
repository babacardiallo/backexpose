ALTER TABLE mandate
    ADD UNIQUE (rum);