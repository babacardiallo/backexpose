import { Component } from "@angular/core";
import { Title } from "@angular/platform-browser";
import { Router, NavigationEnd } from "@angular/router";
import { filter } from "rxjs";
import { environment } from "../../environments/environment";

@Component({
    selector: 'app-seres',
    templateUrl: './seres.component.html',
    styleUrls: ['./seres.component.scss'],
    standalone: false
})

export class SeresComponent {
    appName = environment.appName;
    constructor(
        private router: Router,
        private titleService: Title,
    ) { }

    ngOnInit() {
        this.updateTitle();

        this.router.events
            .pipe(filter((event: any) => event instanceof NavigationEnd))
            .subscribe(() => {
                this.updateTitle();
            });
    }

    private updateTitle() {
        this.titleService.setTitle("Factura : Rejets SERES");

    }

}