package fr.laposte.blg.blinks.u12.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.u12.dto.AddressDTO;
import fr.laposte.blg.blinks.u12.dto.LegalPersonDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
public abstract class LegalPersonViewMapperDecorator implements LegalPersonViewMapper {

    @Autowired
    @Qualifier("delegate")
    private LegalPersonViewMapper delegate;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public LegalPersonEntity legalPersonDTOToLegalPersonEntity(LegalPersonDTO legalPersonDTO) {
        LegalPersonEntity legalPersonEntity = this.delegate.legalPersonDTOToLegalPersonEntity(legalPersonDTO);
        legalPersonEntity.setAddressEntityList(this.addressDTOListToAddressEntityList(legalPersonDTO.getAdresses()));
        return legalPersonEntity;
    }


    public List<AddressEntity> addressDTOListToAddressEntityList(List<AddressDTO> list) {
        return list.stream()
            .filter(addressDTO -> {
                AddressType addressType = null;
                try {
                    addressType = this.delegate.addressTypeMapper(addressDTO.getAddressType());
                } catch (RuntimeException e) {
                    log.warn("Error after reading address type on an address from REFPM API json response. " +
                            "The address (id_address_refpm : {{addressDTO.getAddressId()}}) will be ignored"
                        , e);
                    return false;
                }

                return Objects.nonNull(addressType);
            })
            .map(this::addressDTOToAddressEntity)
            .collect(Collectors.toList());
    }

    @Override
    public AddressEntity addressDTOToAddressEntity(AddressDTO addressDTO) {
        AddressEntity addressEntity = this.delegate.addressDTOToAddressEntity(addressDTO);
        try {
            String json = this.objectMapper.writeValueAsString(addressDTO);
            addressEntity.setAddressJson(json);
        } catch (JsonProcessingException e) {
            log.error("Couldn't serialize LegalPersonDTO as json string", e);
        }
        return addressEntity;
    }


}
