package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.u17.service.ExportProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/v1/export-process")
public class ExportProcessController {
    @Autowired
    private ExportProcessService exportProcessService;
    @GetMapping
    public Flux<ExportProcess> getAllSchedulers() {return exportProcessService.getAllProcesses();}
}
