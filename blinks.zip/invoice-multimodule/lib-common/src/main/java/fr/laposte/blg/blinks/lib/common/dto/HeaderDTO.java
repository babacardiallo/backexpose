package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonPropertyOrder({
        "timestamp",
        "producer",
        "billrunCode"
})
public class HeaderDTO {

    String timestamp;
    String producer;
    String billrunCode;
}
