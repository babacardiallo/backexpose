package fr.laposte.blg.blinks.lib.common.entities;

public enum ExportStatus {
    SUCCESS, FAILED, WARNING, EXCLUDED
}
