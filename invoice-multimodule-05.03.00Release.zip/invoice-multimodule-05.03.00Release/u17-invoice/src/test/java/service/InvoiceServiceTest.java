package service;

import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceStatusEnum;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.dto.InvoiceRestDTO;
import fr.laposte.blg.blinks.u17.dto.PrepareExportDto;
import fr.laposte.blg.blinks.u17.service.InvoiceRestService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class InvoiceServiceTest {

    @Mock
    private InvoiceRepository invoiceRepository;

    @Mock
    private InvoiceMessageRepository invoiceMessageRepository;

    @InjectMocks
    private InvoiceRestService invoiceRestService;
    private InvoiceEntity invoiceEntity;
    private InvoiceEntity invoiceEntityTest;

    @BeforeEach
    void initData() {

        invoiceEntity = new InvoiceEntity(12L, "PF20230000000145",
                "12", "1", Instant.now(),
                15L, 16L, 17L, 18L, Instant.now(), Instant.now(), 1032, InvoiceStatusEnum.NEW,  InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, null, null, null, null, null, null, null, null, false,false, false, false);
        invoiceEntityTest = new InvoiceEntity(13L, "PF20230000000146",
                "13", "2", Instant.now(),
                15L, 16L, 18L, 17L, Instant.now(), Instant.now(), 1033, InvoiceStatusEnum.NEW,  InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, InvoiceStatusEnum.NEW, null, null, null, null, null, null, null, null, false,false, false, false);    }

   @Test
    void getAllInvoicesTest() {
        Sort sortOrder = Sort.by(Sort.Direction.ASC, "idInvoice");
        Mockito.when(invoiceRepository.findAllByCreatedGreaterThanEqual(Mockito.any(PageRequest.class), Mockito.any(Instant.class)))
                .thenReturn(Flux.just(invoiceEntity, invoiceEntityTest));
       Mockito.when(invoiceRepository.countAllByCreatedGreaterThanEqual(Mockito.any(Instant.class)))
               .thenReturn(Mono.just(2L));
       Mockito.when(invoiceMessageRepository.getMessage(Mockito.anyLong())).thenReturn(Mono.just("message"));
        StepVerifier.create(invoiceRestService.getAllInvoices(PageRequest.of(0, 2, sortOrder)))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    InvoiceRestDTO invoiceRestDTO1 = invoiceResult.getContent().get(0);
                    assertEquals(invoiceEntity.getInvoiceNumber(), invoiceRestDTO1.getInvoiceNumber());
                    assertEquals(invoiceEntity.getBillrunId(), invoiceRestDTO1.getBillRunId());
                    assertEquals(invoiceEntity.getInfocaExportId(), invoiceRestDTO1.getInfocaExportId());
                    assertEquals(invoiceEntity.getCoeurfinanceExportId(), invoiceRestDTO1.getCoeurfinanceExportId());
                    assertEquals(invoiceEntity.getDocaposteExportId(), invoiceRestDTO1.getDocapostExportId());
                    InvoiceRestDTO invoiceRestDTO2 = invoiceResult.getContent().get(1);
                    assertEquals(invoiceEntityTest.getInvoiceNumber(), invoiceRestDTO2.getInvoiceNumber());
                    assertEquals(invoiceEntityTest.getBillrunId(), invoiceRestDTO2.getBillRunId());
                    assertEquals(invoiceEntityTest.getInfocaExportId(), invoiceRestDTO2.getInfocaExportId());
                    assertEquals(invoiceEntityTest.getCoeurfinanceExportId(), invoiceRestDTO2.getCoeurfinanceExportId());
                    assertEquals(invoiceEntityTest.getDocaposteExportId(), invoiceRestDTO2.getDocapostExportId());

                })
                .verifyComplete();
    }

    @Test
    void prepareExportDocaposteTest() {
        Mockito.when(invoiceRepository.prepareExportDocaposte(Mockito.anySet())).thenReturn(Mono.just(true));
        StepVerifier.create(invoiceRestService.prepareExportDocaposte(Set.of("PA20220000000027"))).
                assertNext(Assertions::assertTrue)
                .verifyComplete();
    }

    @Test
    void prepareExportInfocaTest() {
        Mockito.when(invoiceRepository.prepareExportInfoca(Mockito.anySet())).thenReturn(Mono.just(true));
        StepVerifier.create(invoiceRestService.prepareExportInfoca(Set.of("PA20220000000027"))).
                assertNext(Assertions::assertTrue)
                .verifyComplete();
    }

    @Test
    void prepareExportCoeurfinanceTest() {
        Mockito.when(invoiceRepository.prepareExportCoeurfinance(Mockito.anySet())).thenReturn(Mono.just(true));
        StepVerifier.create(invoiceRestService.prepareExportCoeurfinance(Set.of("PA20220000000027"))).
                assertNext(Assertions::assertTrue)
                .verifyComplete();
    }

    @Test
    void prepareExportTest(){
        PrepareExportDto prepareExportDto = new PrepareExportDto(Set.of("P1", "P2"), List.of("docaposte", "coeurfinance", "infoca"));
        Mockito.when(invoiceRepository.prepareExportCoeurfinance(Mockito.anySet())).thenReturn(Mono.just(true));
        Mockito.when(invoiceRepository.prepareExportInfoca(Mockito.anySet())).thenReturn(Mono.just(true));
        Mockito.when(invoiceRepository.prepareExportDocaposte(Mockito.anySet())).thenReturn(Mono.just(true));
        StepVerifier.create(invoiceRestService.prepareExport(prepareExportDto)).
                assertNext(Assertions::assertTrue)
                .verifyComplete();
    }

    @Test
    void getRecentInvoicesToExportTest(){
        Mockito.when(invoiceRepository.findAllByDocaposteExportIdIsNullAndDocaposteExportStatusEqualsOrInfocaExportIdIsNullAndInfocaExportStatusEqualsOrCoeurfinanceExportIdIsNullAndCoeurfinanceExportStatusEquals
                (Mockito.any(InvoiceStatusEnum.class),Mockito.any(InvoiceStatusEnum.class), Mockito.any(InvoiceStatusEnum.class),Mockito.any(PageRequest.class))).thenReturn(Flux.fromIterable(List.of(invoiceEntity, invoiceEntityTest)));
        Mockito.when(invoiceMessageRepository.getMessage(Mockito.anyLong())).thenReturn(Mono.just("message"));
        Mockito.when(invoiceRepository.countAllByDocaposteExportIdIsNullAndDocaposteExportStatusEqualsOrInfocaExportIdIsNullAndInfocaExportStatusEqualsOrCoeurfinanceExportIdIsNullAndCoeurfinanceExportStatusEquals
                (Mockito.any(InvoiceStatusEnum.class), Mockito.any(InvoiceStatusEnum.class), Mockito.any(InvoiceStatusEnum.class))).thenReturn(Mono.just(2L));
        StepVerifier.create(invoiceRestService.getRecentInvoicesToExport(PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "idInvoice"))))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    InvoiceRestDTO invoiceRestDTO1 = invoiceResult.getContent().get(0);
                    assertEquals(invoiceEntity.getInvoiceNumber(), invoiceRestDTO1.getInvoiceNumber());
                    assertEquals(invoiceEntity.getBillrunId(), invoiceRestDTO1.getBillRunId());
                    assertEquals(invoiceEntity.getInfocaExportId(), invoiceRestDTO1.getInfocaExportId());
                    assertEquals(invoiceEntity.getCoeurfinanceExportId(), invoiceRestDTO1.getCoeurfinanceExportId());
                    assertEquals(invoiceEntity.getDocaposteExportId(), invoiceRestDTO1.getDocapostExportId());
                    InvoiceRestDTO invoiceRestDTO2 = invoiceResult.getContent().get(1);
                    assertEquals(invoiceEntityTest.getInvoiceNumber(), invoiceRestDTO2.getInvoiceNumber());
                    assertEquals(invoiceEntityTest.getBillrunId(), invoiceRestDTO2.getBillRunId());
                    assertEquals(invoiceEntityTest.getInfocaExportId(), invoiceRestDTO2.getInfocaExportId());
                    assertEquals(invoiceEntityTest.getCoeurfinanceExportId(), invoiceRestDTO2.getCoeurfinanceExportId());
                    assertEquals(invoiceEntityTest.getDocaposteExportId(), invoiceRestDTO2.getDocapostExportId());

                })
                .verifyComplete();

    }

    @Test
    void filterInvoicesTest(){
        Mockito.when(invoiceRepository.findAllByCreatedGreaterThanEqualAndInvoiceNumberLike
                (Mockito.any(PageRequest.class), Mockito.any(Instant.class), Mockito.anyString())).thenReturn(Flux.fromIterable(List.of(invoiceEntity, invoiceEntityTest)));
        Mockito.when(invoiceMessageRepository.getMessage(Mockito.anyLong())).thenReturn(Mono.just("message"));
        Mockito.when(invoiceRepository.countAllByCreatedGreaterThanEqualAndInvoiceNumberLike
                (Mockito.any(Instant.class), Mockito.anyString())).thenReturn(Mono.just(2L));
        StepVerifier.create(invoiceRestService.filterInvoices(PageRequest.of(0, 2, Sort.by(Sort.Direction.ASC, "idInvoice")),""))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    InvoiceRestDTO invoiceRestDTO1 = invoiceResult.getContent().get(0);
                    assertEquals(invoiceEntity.getInvoiceNumber(), invoiceRestDTO1.getInvoiceNumber());
                    assertEquals(invoiceEntity.getBillrunId(), invoiceRestDTO1.getBillRunId());
                    assertEquals(invoiceEntity.getInfocaExportId(), invoiceRestDTO1.getInfocaExportId());
                    assertEquals(invoiceEntity.getCoeurfinanceExportId(), invoiceRestDTO1.getCoeurfinanceExportId());
                    assertEquals(invoiceEntity.getDocaposteExportId(), invoiceRestDTO1.getDocapostExportId());
                    InvoiceRestDTO invoiceRestDTO2 = invoiceResult.getContent().get(1);
                    assertEquals(invoiceEntityTest.getInvoiceNumber(), invoiceRestDTO2.getInvoiceNumber());
                    assertEquals(invoiceEntityTest.getBillrunId(), invoiceRestDTO2.getBillRunId());
                    assertEquals(invoiceEntityTest.getInfocaExportId(), invoiceRestDTO2.getInfocaExportId());
                    assertEquals(invoiceEntityTest.getCoeurfinanceExportId(), invoiceRestDTO2.getCoeurfinanceExportId());
                    assertEquals(invoiceEntityTest.getDocaposteExportId(), invoiceRestDTO2.getDocapostExportId());

                })
                .verifyComplete();
    }

    @Test
    void getByPrintFlagDocaposteTest(){
        Mockito.when(invoiceRepository.getByCriteriaDocaposte
                (Mockito.any(Instant.class),Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(Flux.fromIterable(List.of(invoiceEntity, invoiceEntityTest)));
        Mockito.when(invoiceMessageRepository.getMessage(Mockito.anyLong())).thenReturn(Mono.just("message"));
        Mockito.when(invoiceRepository.countByCriteriaDocaposte
                (Mockito.any(Instant.class), Mockito.anyString())).thenReturn(Mono.just(2L));
        StepVerifier.create(invoiceRestService.getByPrintFlag("filter", "invoiceNumber", "asc", 5, 0, true, false))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    InvoiceRestDTO invoiceRestDTO1 = invoiceResult.getContent().get(0);
                    assertEquals(invoiceEntity.getInvoiceNumber(), invoiceRestDTO1.getInvoiceNumber());
                    assertEquals(invoiceEntity.getBillrunId(), invoiceRestDTO1.getBillRunId());
                    assertEquals(invoiceEntity.getInfocaExportId(), invoiceRestDTO1.getInfocaExportId());
                    assertEquals(invoiceEntity.getCoeurfinanceExportId(), invoiceRestDTO1.getCoeurfinanceExportId());
                    assertEquals(invoiceEntity.getDocaposteExportId(), invoiceRestDTO1.getDocapostExportId());
                    InvoiceRestDTO invoiceRestDTO2 = invoiceResult.getContent().get(1);
                    assertEquals(invoiceEntityTest.getInvoiceNumber(), invoiceRestDTO2.getInvoiceNumber());
                    assertEquals(invoiceEntityTest.getBillrunId(), invoiceRestDTO2.getBillRunId());
                    assertEquals(invoiceEntityTest.getInfocaExportId(), invoiceRestDTO2.getInfocaExportId());
                    assertEquals(invoiceEntityTest.getCoeurfinanceExportId(), invoiceRestDTO2.getCoeurfinanceExportId());
                    assertEquals(invoiceEntityTest.getDocaposteExportId(), invoiceRestDTO2.getDocapostExportId());

                })
                .verifyComplete();
    }


    @Test
    void getByPrintFlagSeresest(){
        Mockito.when(invoiceRepository.getByCriteriaSeres
                (Mockito.any(Instant.class),Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(Flux.fromIterable(List.of(invoiceEntity, invoiceEntityTest)));
        Mockito.when(invoiceMessageRepository.getMessage(Mockito.anyLong())).thenReturn(Mono.just("message"));
        Mockito.when(invoiceRepository.countByCriteriaSeres
                (Mockito.any(Instant.class), Mockito.anyString())).thenReturn(Mono.just(2L));
        StepVerifier.create(invoiceRestService.getByPrintFlag("filter", "invoiceNumber", "asc", 5, 0, false, true))
                .assertNext(invoiceResult -> {
                    assertNotNull(invoiceResult);
                    InvoiceRestDTO invoiceRestDTO1 = invoiceResult.getContent().get(0);
                    assertEquals(invoiceEntity.getInvoiceNumber(), invoiceRestDTO1.getInvoiceNumber());
                    assertEquals(invoiceEntity.getBillrunId(), invoiceRestDTO1.getBillRunId());
                    assertEquals(invoiceEntity.getInfocaExportId(), invoiceRestDTO1.getInfocaExportId());
                    assertEquals(invoiceEntity.getCoeurfinanceExportId(), invoiceRestDTO1.getCoeurfinanceExportId());
                    assertEquals(invoiceEntity.getDocaposteExportId(), invoiceRestDTO1.getDocapostExportId());
                    InvoiceRestDTO invoiceRestDTO2 = invoiceResult.getContent().get(1);
                    assertEquals(invoiceEntityTest.getInvoiceNumber(), invoiceRestDTO2.getInvoiceNumber());
                    assertEquals(invoiceEntityTest.getBillrunId(), invoiceRestDTO2.getBillRunId());
                    assertEquals(invoiceEntityTest.getInfocaExportId(), invoiceRestDTO2.getInfocaExportId());
                    assertEquals(invoiceEntityTest.getCoeurfinanceExportId(), invoiceRestDTO2.getCoeurfinanceExportId());
                    assertEquals(invoiceEntityTest.getDocaposteExportId(), invoiceRestDTO2.getDocapostExportId());

                })
                .verifyComplete();
    }

    @Test
    void processFailedInvoicesTest(){
        Mockito.when(invoiceRepository.processFailedDocaposte()).thenReturn(Mono.just(1));
        Mockito.when(invoiceRepository.processFailedInfoca()).thenReturn(Mono.just(1));
        Mockito.when(invoiceRepository.processFailedCoeurfinance()).thenReturn(Mono.just(1));
        this.invoiceRestService.processFailedInvoices(new ArrayList<>(), true, true, true);
    }

    @Test
    void processFailedInvoicesTest2(){
        Mockito.when(invoiceRepository.processFailedDocaposteIn(Mockito.anyList())).thenReturn(Mono.just(1));
        Mockito.when(invoiceRepository.processFailedInfocaIn(Mockito.anyList())).thenReturn(Mono.just(1));
        Mockito.when(invoiceRepository.processFailedCoeurfinanceIn(Mockito.anyList())).thenReturn(Mono.just(1));
        this.invoiceRestService.processFailedInvoices(List.of("P1", "P2"), true, true, true);
    }

}
