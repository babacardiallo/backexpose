create index idx_invoice_invoice_number on invoice (invoice_number);
create index idx_invoice_billrun_id on invoice (billrun_id);
create index idx_invoice_created on invoice (created);
create index idx_invoice_docaposte_export_status on invoice (docaposte_export_status);
create index idx_invoice_infoca_export_status on invoice (infoca_export_status);
create index idx_invoice_equinox_export_status on invoice (equinox_export_status);
create index idx_export_history_file_date on export_history (file_date);
CREATE OR REPLACE VIEW `invoice_supervision` AS
    SELECT
        `inv`.`id_invoice` AS `id_invoice`,
        `inv`.`invoice_number` AS `invoice_number`,
        `inv`.`created` AS `created`,
        `inv`.`client` AS `client`,
        `inv`.`billrun_id` AS `billrun_id`,
        `inv`.`docaposte_export_status` AS `docaposte_export_status`,
        `inv`.`infoca_export_status` AS `infoca_export_status`,
        `inv`.`equinox_export_status` AS `equinox_export_status`,
        `export1`.`file_date` AS `docaposte_export_date`,
        `export1`.`id` AS `docaposte_export_id`,
        `export2`.`file_date` AS `infoca_export_date`,
        `export2`.`id` AS `infoca_export_id`,
        `export3`.`file_date` AS `equinox_export_date`,
        `export3`.`id` AS `equinox_export_id`
    FROM
        (((`invoice` `inv`
        LEFT JOIN `export_history` `export1` ON ((`inv`.`docaposte_export_id` = `export1`.`id`)))
        LEFT JOIN `export_history` `export2` ON ((`inv`.`infoca_export_id` = `export2`.`id`)))
        LEFT JOIN `export_history` `export3` ON ((`inv`.`equinox_export_id` = `export3`.`id`)));


