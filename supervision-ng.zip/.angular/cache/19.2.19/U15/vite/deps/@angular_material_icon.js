import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-KJBC2XV4.js";
import "./chunk-2PTBWJHB.js";
import "./chunk-TWZOUGUR.js";
import "./chunk-47P2XRX3.js";
import "./chunk-DG6N4IH3.js";
import "./chunk-KHSJTTI4.js";
import "./chunk-5FJDMDII.js";
import "./chunk-7ZCWYKRT.js";
import "./chunk-I76JCCZG.js";
import "./chunk-5YUJUVVP.js";
import "./chunk-MRDQ76HR.js";
import "./chunk-RVYENV4D.js";
import "./chunk-BGUFP7RE.js";
import "./chunk-ROQ5OQS3.js";
import "./chunk-S6ETTSTF.js";
import "./chunk-3GOMPWB5.js";
import "./chunk-NTD5R5GH.js";
import "./chunk-IJNFIFIC.js";
import "./chunk-FQZEMCZB.js";
import "./chunk-7IZRYL2Z.js";
import "./chunk-TXDUYLVM.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
