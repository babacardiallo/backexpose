package fr.laposte.blg.blinks.lib.common.constant;

public class KibanaCustomField {
    public static String CONTRACT_NUMBER = "contractNumber";
    public static String OFFER = "offer";
    public static String AMENDMENT_NUMBER = "amendmentNumber";
    public static String CUSTOMER_ACC_NUMBER = "custAccNumber";
    public static String ADDRESS_ID_REF_PM = "addressIdRefPM";
    public static String RUM = "rum";
    public static String CLEFS_SYNCHRO_CONTRACT = "clefSynchronisationContract";
    public static String CLEFS_SYNCHRO_CUSTOMER = "clefSynchronisationCustomer";
    public static String CLEFS_INTEGRATION_CONTRACT = "clefIntegrationContract";
    public static String CLEFS_DEBUT_INTEGRATION_CONTRACT = "clefDebutIntegrationContract";
    public static String CLEFS_FIN_INTEGRATION_CONTRACT = "clefFinIntegrationContract";
    public static String CLEFS_DEBUT_SYNCHRO_CONTRACT = "clefDebutSynchronisationContract";
    public static String CLEFS_FIN_SYNCHRO_CONTRACT = "clefFinSynchronisationContract";

}
