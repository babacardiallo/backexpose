package fr.laposte.blg.blinks.lib.common.dto;


import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonPropertyOrder({
        "scheduledPaymentDate",
        "scheduledPaymentAmountIncludingVAT"
})
public class ScheduledPaymentDTO {
    String scheduledPaymentDate;
    Double scheduledPaymentAmountIncludingVAT;
}
