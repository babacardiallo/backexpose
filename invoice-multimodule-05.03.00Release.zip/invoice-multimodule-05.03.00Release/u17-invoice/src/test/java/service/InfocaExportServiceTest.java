package service;

import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.repositories.FileSequenceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.service.ExportService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import fr.laposte.blg.blinks.u17.util.ObjectMapperWithModules;
import fr.laposte.blg.blinks.u17.util.XmlMapperWithJavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class InfocaExportServiceTest {
    @InjectMocks
    private InfocaInvoiceExportService service;
    @Mock
    private InvoiceRepository invoiceRepository;
    @Mock
    private XmlMapperWithJavaTimeModule xmlMapper;
    @Mock
    private ObjectMapperWithModules objectMapper;
    @Mock
    private InvoiceMessageRepository invoiceMessageRepository;
    @Mock
    private ExportService exportService;
    @Mock
    private FileSequenceRepository fileSequenceRepository;
    @Mock
    private DateUtil dateUtil;
    private InvoiceEntity invoice1;
    private InvoiceEntity invoice2;
    private String mes1;
    private String mes2;

    @TempDir
    Path tempDir;

    Path exportDir;

    @BeforeEach
    void initData() throws IOException {
        exportDir = tempDir.resolve("export");
        Files.createDirectories(exportDir);
        String json1 = "src/test/resources/remise_type_v9.json";
        String json2 = "src/test/resources/remise2_type_v9.json";
        mes1 = Files.readString(Path.of(json1));
        mes2 = Files.readString(Path.of(json2));

        invoice1 = InvoiceEntity.builder()
                .idInvoice(1L)
                .invoiceNumber("1")
                .reference("1L")
                .billrunId("test")
                .billrunDate(Instant.now())
                .docaposteExportId(1L)
                .infocaExportId(2L)
                .coeurfinanceExportId(3L)
                .created(Instant.now().minus(Period.ofDays(1)))
                .updated(Instant.now())
                .client(1032)
                .docaposteExportStatus(InvoiceStatusEnum.NEW)
                .infocaExportStatus(InvoiceStatusEnum.NEW)
                .coeurfinanceExportStatus(InvoiceStatusEnum.NEW)
                .docaposteErrorMessage(null)
                .docaposteErrorCode(null)
                .infocaErrorMessage(null)
                .infocaErrorCode(null)
                .coeurfinanceErrorMessage(null)
                .coeurfinanceErrorCode(null)
                .build();

        invoice2 = InvoiceEntity.builder()
                .idInvoice(2L)
                .invoiceNumber("2")
                .reference("2L")
                .billrunId("test2")
                .billrunDate(Instant.now())
                .docaposteExportId(4L)
                .infocaExportId(5L)
                .coeurfinanceExportId(6L)
                .created(Instant.now().minus(Period.ofDays(2)))
                .updated(Instant.now().minusSeconds(3600))
                .client(1033)
                .docaposteExportStatus(InvoiceStatusEnum.NEW)
                .infocaExportStatus(InvoiceStatusEnum.NEW)
                .coeurfinanceExportStatus(InvoiceStatusEnum.NEW)
                .docaposteErrorMessage(null)
                .docaposteErrorCode(null)
                .infocaErrorMessage(null)
                .infocaErrorCode(null)
                .coeurfinanceErrorMessage(null)
                .coeurfinanceErrorCode(null)
                .build();

    }

    String getMessage(Long id){
        if(id==1L){
            return mes1;
        } else {
            return mes2;
        }
    }

    @Test
    void givenInvoice_whenProcessFile_thenOk() throws IOException {
        ObjectMapperWithModules objectMapperWithModules = new ObjectMapperWithModules();
        ExportProcess exportProcess = new ExportProcess();
        exportProcess.setMinId(1L);
        exportProcess.setMaxId(2L);
        Mockito.when(invoiceRepository.findByInfocaExportIdIsNullAndIdBetweenOrderByReferenceAsc(anyLong(), anyLong()))
                .thenReturn(Flux.just(invoice1, invoice2));
        doAnswer(invocation -> Mono.just(getMessage(invocation.getArgument(0))))
                .when(invoiceMessageRepository).getMessage(anyLong());
        when(this.objectMapper.readValue(anyString(), (Class<Object>) any())).thenReturn(objectMapperWithModules.readValue(mes1, InvoiceDTO.class));
        when(exportService.generateHistory(any(Instant.class), anyList(), anyList(), anyList(), anyList(), any(FileType.class), anyString()))
                .thenReturn(Mono.just(new ExportHistoryEntity()));
        when(this.fileSequenceRepository.incrementSequenceForInfoCA()).thenReturn(Mono.just(1));
        when(fileSequenceRepository.getCurrentSequenceForInfoCAExport()).thenReturn(Mono.just(2L));
        when(dateUtil.yyyyMMdd(Instant.now())).thenReturn("2025-05-05");
        when(dateUtil.yyyyMMddDash(Instant.now())).thenReturn("2025-05-05");
        when(dateUtil.yyyyMMddDash(LocalDate.now())).thenReturn("2025-05-05");
        service.process(exportProcess, exportDir.toString());
    }
}
