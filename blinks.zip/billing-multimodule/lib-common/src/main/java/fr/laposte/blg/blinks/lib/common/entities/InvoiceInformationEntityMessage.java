package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("invoice_information_message")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class InvoiceInformationEntityMessage {
    @Id
    @Column("id_invoice_information_message")
    private Long idInvoiceInformationMessage;

    @Column("id_invoice_information")
    private Long idInvoiceInformation;

    @Column("invoicing_comments_jsonarray")
    private String invoicingCommentsJsonArray;

    @Column("invoice_information_json")
    private String invoiceInformationJson;

}
