package fr.laposte.blg.blinks.u17.mapper;


import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.u17.dto.MorningCheckDto;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.Instant;
import java.util.List;

@Mapper
public interface MorningCheckMapper {

    @Mapping(source = "fileType", target = "type")
    @Mapping(source = "startDate", target = "startDate", qualifiedByName = "getStartDate")
    @Mapping(source = "date", target = "endDate", qualifiedByName = "getEndDate")
    @Mapping(source = "fileSendDate", target = "fileSendDate", qualifiedByName = "getFileSenDate")
    @Mapping(source = "messageCount", target = "nbTreatedInvoices")
    @Mapping(source = "exportStatus", target = "status")
    @Mapping(source = "nbExcludedInvoices", target = "nbExcludedInvoices")
    @Mapping(source = "nbFailedInvoices", target = "nbFailedInvoices")
    MorningCheckDto exportHistoryEntityToMorningCheckDto(ExportHistoryEntity exportHistoryEntity);

    @Named("getStartDate")
    default String getStartDate(Instant startDate){
        return DateUtil.yyyyMMddHHmmSSMorningCheck(startDate);
    }
    @Named("getEndDate")
    default String getEndDate(Instant date){
        return DateUtil.yyyyMMddHHmmSSMorningCheck(date);
    }

    @Named("getFileSenDate")
    default String getFileSenDate(Instant fileSendDate){
        return DateUtil.yyyyMMddHHmmSSMorningCheck(fileSendDate);
    }

    List<MorningCheckDto> exportHistoryEntityToMorningCheckDto(List<ExportHistoryEntity> exportHistoryEntity);
}