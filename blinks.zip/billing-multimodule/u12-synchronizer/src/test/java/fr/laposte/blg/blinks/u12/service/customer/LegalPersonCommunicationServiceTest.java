package fr.laposte.blg.blinks.u12.service.customer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import reactor.test.StepVerifier;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@ActiveProfiles("test")
class LegalPersonCommunicationServiceTest {

    @Autowired
    private LegalPersonCommunicationServiceImpl legalPersonCommunicationService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void fetchLegalPersonDto() {
        StepVerifier.create(this.legalPersonCommunicationService.fetchLegalPerson(33))
                .expectNextMatches(legalPersonDTO -> legalPersonDTO.getCustAccNumber().equals("33"))
                .verifyComplete();

    }

    @Test
    void fetchLegalPersonDtoShouldNotContainSiegeAddress() {
        StepVerifier.create(this.legalPersonCommunicationService.fetchLegalPerson(980))
                .expectNextMatches(legalPersonDTO ->
                        legalPersonDTO.getAdresses().stream()
                                .noneMatch(address -> "SIEGE".equals(address.getAddressType()))
                )
                .verifyComplete();
    }

    @Test
    void fetchLegalPersonDtoShouldHaveNonNullRefPmAdressIdInEveryAddress() {
        StepVerifier.create(this.legalPersonCommunicationService.fetchLegalPerson(37))
                .expectNextMatches(legalPersonDTO ->
                        legalPersonDTO.getAdresses().stream()
                                .allMatch(address -> address.getAddressId() != null)
                )
                .verifyComplete();
    }


}