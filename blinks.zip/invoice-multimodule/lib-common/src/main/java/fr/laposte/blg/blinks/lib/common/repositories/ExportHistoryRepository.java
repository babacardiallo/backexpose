package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.*;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

@Repository
public interface ExportHistoryRepository extends ReactiveCrudRepository<ExportHistoryEntity, Long> {

    @Query("SELECT eh1.*\n" +
            "    FROM export_history eh1\n" +
            "    WHERE eh1.file_date = (SELECT MAX(eh2.file_date)\n" +
            "    FROM export_history eh2\n" +
            "    WHERE eh2.file_type = :type AND (eh2.file_date like :date OR :date IS NULL)) AND eh1.file_type = :type limit 1")
    Mono<ExportHistoryEntity> getLastExportedFileByType(FileType type, String date);


    @Modifying
    @Query("UPDATE export_history SET is_file_sent = 1, file_send_date = :fileSendDate WHERE (file_type = :type AND file_date = :date)")
    Mono<Integer> updateFileSendStatus(@Param("type") FileType type, @Param("date") LocalDateTime date, @Param("fileSendDate") LocalDateTime fileSendDate);


    @Query("SELECT eh.file_date, eh.is_file_empty, eh.export_status, eh.file_type, transfer_status FROM export_history eh WHERE ( YEAR(eh.file_date) = YEAR(CURRENT_DATE) AND MONTH(eh.file_date) = MONTH(CURRENT_DATE) AND eh.file_type <> :type ) ORDER BY eh.file_date DESC")
    Flux<MonthlyTreatment> getMonthlyTreatment(@Param("type") FileType type);

    @Query("SELECT eh.file_date, eh.is_file_empty, eh.export_status, eh.file_type, transfer_status FROM export_history eh WHERE ( YEAR(eh.file_date) = :annee AND MONTH(eh.file_date) = :mois AND eh.file_type <> :type ) ORDER BY eh.file_date DESC")
    Flux<MonthlyTreatment> getMonthlyTreatmentByMonthAndYear( @Param("annee") Integer annee, @Param("mois") Integer mois, @Param("type") FileType type);


    @Query("SELECT eh.* FROM export_history eh WHERE eh.file_date LIKE :date AND eh.file_type = :type ORDER BY eh.file_date DESC")
    Flux<ExportHistoryEntity> getDailyExportFileByType(FileType type, String date);

    @Query("SELECT eh1.*\n" +
            "    FROM export_history eh1\n" +
            "    WHERE eh1.file_date = (SELECT MAX(eh2.file_date)\n" +
            "    FROM export_history eh2\n" +
            "    WHERE eh2.file_type = :type AND eh2.export_status = :exportStatus  AND (eh2.file_date like :date OR :date IS NULL)) AND eh1.file_type = :type AND eh1.export_status = :exportStatus limit 1")
    Mono<ExportHistoryEntity> getLastExportedFileByTypeAndStatus(FileType type, String date, ExportStatus exportStatus);

    Mono<ExportHistoryEntity> findTopByTransferStatusInAndFileTypeInOrderByDateAsc(List<TransferStatus> statuses, Collection<FileType> fileTypes);
    
    @Query("SELECT eh.* FROM export_history eh WHERE eh.file_date LIKE :date ORDER BY eh.file_date DESC")
    Flux<ExportHistoryEntity> getDailyExportFile(String date);

    Flux<ExportHistoryEntity> findAllByIdExportIn(List<Long> idExport);

    @Modifying
    @Query("DELETE FROM export_history WHERE " +
           "file_type = 'DOCAPOSTE' AND file_date < :purgeDate AND " +
           "export_status = 'SUCCESS' AND transfer_status = 'TRANSFERED' AND " +
           "id NOT IN (SELECT DISTINCT docaposte_export_id FROM invoice WHERE docaposte_export_id IS NOT NULL)")
    Mono<Long> deleteOrphanedDocaposteExportHistory(@Param("purgeDate") Instant purgeDate);

    @Modifying
    @Query("DELETE FROM export_history WHERE " +
           "file_type = 'EQUINOX' AND file_date < :purgeDate AND " +
           "export_status = 'SUCCESS' AND transfer_status = 'TRANSFERED' AND " +
           "id NOT IN (SELECT DISTINCT equinox_export_id FROM invoice WHERE equinox_export_id IS NOT NULL)")
    Mono<Long> deleteOrphanedEquinoxExportHistory(@Param("purgeDate") Instant purgeDate);

    @Modifying
    @Query("DELETE FROM export_history WHERE " +
           "file_type = 'INFOCA' AND file_date < :purgeDate AND " +
           "export_status = 'SUCCESS' AND transfer_status = 'TRANSFERED' AND " +
           "id NOT IN (SELECT DISTINCT infoca_export_id FROM invoice WHERE infoca_export_id IS NOT NULL)")
    Mono<Long> deleteOrphanedInfocaExportHistory(@Param("purgeDate") Instant purgeDate);

}