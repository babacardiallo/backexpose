ALTER TABLE scheduler_params ADD COLUMN retention_days INTEGER;
ALTER TABLE scheduler_params ADD COLUMN module VARCHAR(32);

update scheduler_params set module = 'u17' where id in (1,2,3);

INSERT INTO scheduler_params (scheduler_name, cron_expression, export_path, cft_path, archive_path, is_enabled, waiting_delay, execution_order, retention_days, module)
VALUES
    -- Data Purge Scheduler for U18
    ('scheduler_data_purge', '0 0 2 * * ?', NULL, NULL, NULL, true, NULL, NULL, 30, 'u18' ),

    -- Export Scheduler for U18
    ('scheduler_export', '0 0 23 * * ?', '/opt/app-root/src/donnees/export/', NULL, '/opt/app-root/src/donnees/archives/', true, NULL, NULL, NULL, 'u18' ),

    -- File Purge Scheduler for U18
    ('scheduler_file_purge', '0 30 3 * * ?', NULL, NULL, '/opt/app-root/src/donnees/archives/', true, NULL, NULL, 90, 'u18' ),

    -- Transfer Scheduler for U18
    ('scheduler_transfer', '0 30 23 * * ?', '/opt/app-root/src/donnees/export/', '/opt/app-root/src/transfert/export/', '/opt/app-root/src/donnees/archives/', true, NULL, NULL,  NULL, 'u18' );