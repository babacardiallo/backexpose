package fr.laposte.blg.blinks.u11.listener.legalperson;

import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u11.mapper.LegalPersonListenerMapper;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.EventOrigin;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.TypeEnum;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Mono;

@Service
@Data
@Slf4j
@RequiredArgsConstructor
public class LegalPersonListenerService {

    private final LegalPersonService legalPersonService;

    private final LegalPersonListenerMapper legalPersonListenerMapper;

    private final SynchronizationSender synchronizationSender;

    private final ErrorLogService errorLogService;

    private final TransactionalOperator transactionalOperator;

    public Mono<Void> legalPersonUpdate(ConsumerRecord<String, LegalPerson> receiverRecord) {
        LegalPerson legalPerson;
        LegalPersonMessage legalPersonMessage = new LegalPersonMessage();
        try {
            legalPerson = receiverRecord.value();
            legalPersonMessage.setLegalPersonJson(legalPerson.toString());
        } catch (Exception e) {
            return Mono.error(e);
        }
        return Mono.just(legalPerson)
                .map(legalPerson1 -> Integer.parseInt(legalPerson1.getId().toString()))
                .flatMap(iLegalPersonId -> legalPersonService.findLegalPersonByCoclico(iLegalPersonId, false))
                .doOnNext(legalPersonEntity -> log.debug("found legal person {} in data, triggering client resynchronization", legalPersonEntity.getIdLegalPerson()))
                .map(entity -> {
                    LegalPersonEntity legalPersonEntity = this.legalPersonListenerMapper.legalPersonToLegalPersonEntity(legalPerson);
                    legalPersonEntity.setIdLegalPerson(entity.getIdLegalPerson());
                    /**
                     * Context :BILLING-428
                     * As we don't have these two attributes, we need to set them from the existing entity
                     */
                    legalPersonEntity.setLegalNatureCode(entity.getLegalNatureCode());
                    legalPersonEntity.setLegalNatureName(entity.getLegalNatureName());
                    legalPersonEntity.setCreated(entity.getCreated());
                    return legalPersonEntity;
                })
                .flatMap(legalPersonEntity ->
                        Mono.just(legalPersonEntity)
                                /////VERY IMPORTANT
                                .map(legalPersonEntity1 -> legalPersonEntity1.setSynchronized(false))
                                ////////////////////
                                .flatMap(legalPersonEntity1 -> legalPersonService.save(legalPersonEntity1, false))
                                .flatMap(legalPersonEntity1 -> legalPersonService.saveLegalPersonMessage(legalPersonEntity1, legalPersonMessage))
                                .flatMap(legalPersonEntity1 -> this.updateMainAddress(legalPerson, legalPersonEntity1))
                                .as(transactionalOperator::transactional)
                )
                .flatMap(legalPersonEntity -> publishLegalPersonSyncCommand(legalPersonEntity, receiverRecord.topic(), receiverRecord.key()))
                .onErrorResume(throwable -> {
                            var errorLog = ErrorLogEntity.builder().custAccNumber(Long.parseLong(receiverRecord.key()))
                                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.LEGALPERSON_LISTENING)
                                    .errorMessage("Error during legal person listening :" + throwable.getMessage())
                                    .codeError(CodeErrorEnum.U11005)
                                    .build();
                            log.error("Error during legal person listening {} clefs {}", throwable.getMessage(), errorLog);
                            return errorLogService.logError(errorLog).then(Mono.empty());
                        }
                )
                ;
    }

    /**
     * Update main address of legal person
     *
     * @param legalPerson       The legal person from the topic
     * @param legalPersonEntity The legal person saved in database
     * @return The legal person saved in database
     */
    public Mono<LegalPersonEntity> updateMainAddress(LegalPerson legalPerson, LegalPersonEntity legalPersonEntity) {
        return Mono.just(legalPerson.getRefpmAdressId().toString())
                .flatMap(this.legalPersonService::findMainAddress)
                .map(addressEntity -> {
                    AddressEntity address = this.legalPersonListenerMapper.legalPersonToAddressEntity(legalPerson);
                    address.setIdAddress(addressEntity.getIdAddress());
                    address.setIdLegalPerson(legalPersonEntity.getIdLegalPerson());
                    return address;
                })
                .flatMap(this.legalPersonService::saveMainAddress)
                .thenReturn(legalPersonEntity);
    }

    /**
     * Method used to publish in the private topic the command to sync the customer (legalPerson)
     *
     * @param legalPersonEntity
     * @return
     */
    public Mono<Void> publishLegalPersonSyncCommand(LegalPersonEntity legalPersonEntity, String topic, String key) {
        return Mono.just(legalPersonEntity)
                .map(legalPerson -> Synchronization.newBuilder()
                        .setAction(ActionEnum.update)
                        .setType(TypeEnum.customer)
                        .setInternalId(legalPerson.getIdLegalPerson().intValue())
                        .setEventOrigin(EventOrigin.newBuilder()
                                .setKey(key)
                                .setTopic(topic).build())
                        .build())
                .flatMap(this.synchronizationSender::send);
    }
}
