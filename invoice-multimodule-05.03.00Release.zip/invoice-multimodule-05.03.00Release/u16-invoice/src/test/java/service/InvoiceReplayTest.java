package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoice;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoiceStatus;
import fr.laposte.blg.blinks.lib.common.repositories.RejectedInvoiceRepository;
import fr.laposte.blg.blinks.u16.service.InvoiceReplayService;
import fr.laposte.blg.blinks.u16.service.KafkaInvoiceReplayProducer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InvoiceReplayTest {
    @InjectMocks
    private InvoiceReplayService invoiceReplayService;
    @Mock
    private RejectedInvoiceRepository rejectedInvoiceRepository;
    @Mock
    private KafkaInvoiceReplayProducer producer;
    @Mock
    private ObjectMapper objectMapper;

    private RejectedInvoice invoice1;
    private RejectedInvoice invoice2;


    @BeforeEach
    void setUp() {
        invoice1 = RejectedInvoice.builder()
                .invoiceNumber("PF001")
                .invoiceJson("{}")
                .status(RejectedInvoiceStatus.REJECTED).build();
        invoice2 = RejectedInvoice.builder()
                .invoiceNumber("PF002")
                .invoiceJson("{}")
                .status(RejectedInvoiceStatus.REJECTED).build();

    }

    @Test
    void replayAllInvoicesTest() throws JsonProcessingException {
        when(producer.sendInvoiceToTopic(any(Invoice.class))).thenReturn(Mono.empty());
        when(rejectedInvoiceRepository.updateAllByInvoiceNumber(anyString())).thenReturn(Mono.just(true));
        when(objectMapper.readValue(anyString(), eq(Invoice.class))).thenReturn(new Invoice());
        when(rejectedInvoiceRepository.getAllRejectedInvoices()).thenReturn(Flux.just(invoice1, invoice2));
        when(rejectedInvoiceRepository.countAllRejectedInvoices()).thenReturn(Mono.just(2L));

        StepVerifier.create(invoiceReplayService.replayAllRejectedInvoices())
                .assertNext(report -> {
                    assertEquals(2L, report.getNbSuccess().get());
                    assertEquals(0L, report.getNbErrors().get());
                    assertEquals(List.of("PF001", "PF002"), report.getListSuccess());
                })
                .verifyComplete();

    }

    @Test
    void replaySpecificInvoiceTest() throws JsonProcessingException {
        when(producer.sendInvoiceToTopic(any(Invoice.class))).thenReturn(Mono.empty());
        when(rejectedInvoiceRepository.updateAllByInvoiceNumber(anyString())).thenReturn(Mono.just(true));
        when(objectMapper.readValue(anyString(), eq(Invoice.class))).thenReturn(new Invoice());
        when(rejectedInvoiceRepository.getAllByInvoiceNumbers(anyList())).thenReturn(Flux.just(invoice1));

        StepVerifier.create(invoiceReplayService.replayInvoices(Collections.singletonList(invoice1.getInvoiceNumber())))
                .assertNext(report -> {
                    assertEquals(1L, report.getNbSuccess().get());
                    assertEquals(0L, report.getNbErrors().get());
                    assertEquals(List.of("PF001"), report.getListSuccess());
                })
                .verifyComplete();

    }

    @Test
    void replayWithJsonProcessingExceptionTest() throws JsonProcessingException {
        when(producer.sendInvoiceToTopic(any(Invoice.class))).thenReturn(Mono.empty());
        when(rejectedInvoiceRepository.updateAllByInvoiceNumber(anyString())).thenReturn(Mono.just(true));
        when(objectMapper.readValue(anyString(), eq(Invoice.class))).thenThrow(new JsonProcessingException("test exception") {});
        when(rejectedInvoiceRepository.getAllRejectedInvoices()).thenReturn(Flux.just(invoice1));
        when(rejectedInvoiceRepository.countAllRejectedInvoices()).thenReturn(Mono.just(1L));

        StepVerifier.create(invoiceReplayService.replayAllRejectedInvoices())
                .assertNext(report -> {
                    assertEquals(1L, report.getNbErrors().get());
                    assertEquals("test exception", report.getMapErrors().get(invoice1.getInvoiceNumber()));
                })
                .verifyComplete();
    }

    @Test
    void purgeTest() {
        when(rejectedInvoiceRepository.purge()).thenReturn(Mono.just(1));

        StepVerifier.create(invoiceReplayService.purge())
                .assertNext(status -> assertEquals("Démarrage du purge", status))
                .verifyComplete();

    }
}
