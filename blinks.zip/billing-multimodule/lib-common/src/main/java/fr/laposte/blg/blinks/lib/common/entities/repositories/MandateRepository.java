 package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.MandateEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface MandateRepository extends ReactiveCrudRepository<MandateEntity, Long> {

    Mono<MandateEntity> findFirstByRum(String rum);
    Mono<MandateEntity> findByRum(String rum);


}
