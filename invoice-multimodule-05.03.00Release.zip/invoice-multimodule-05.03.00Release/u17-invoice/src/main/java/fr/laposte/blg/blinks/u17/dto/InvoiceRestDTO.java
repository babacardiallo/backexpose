package fr.laposte.blg.blinks.u17.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InvoiceRestDTO {

    private Long id;
    private String invoiceNumber;
    private String message;
    private String billRunId;
    private int docapostExportId;
    private int infocaExportId;
    private int coeurfinanceExportId;

}
