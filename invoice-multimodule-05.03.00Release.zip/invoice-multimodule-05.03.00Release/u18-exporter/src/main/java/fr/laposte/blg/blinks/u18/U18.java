package fr.laposte.blg.blinks.u18;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

@Slf4j
@SpringBootApplication
@EnableJpaRepositories("fr.laposte.blg.blinks.u18.repository")
@EnableR2dbcRepositories("fr.laposte.blg.blinks.lib.common.repositories")
@EntityScan
@ConfigurationPropertiesScan
public class U18 {
    public static void main(String[] args) {
        SpringApplication.run(U18.class, args);

//        try {
//            Class.forName("io.confluent.kafka.serializers.AbstractKafkaSchemaSerDe");
//            log.info("✅ Class AbstractKafkaSchemaSerDe found in classpath");
//        } catch (ClassNotFoundException e) {
//            log.error("❌ Class AbstractKafkaSchemaSerDe missing", e);
//        }

    }

}