package fr.laposte.blg.blinks.u17.scheduler;


import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.NotificationStatus;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.u17.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.time.Duration;
import java.util.List;

@Slf4j
@EnableScheduling
public class NotificationScheduler implements Runnable {

    private static final Duration DEFAULT_WAIT_DURATION = Duration.ofMinutes(1);

    private final ExportHistoryRepository exportHistoryRepository;
    private final SchedulerParamsEntity schedulerParams;
    private final NotificationService notificationService;
    private final Duration waitDuration;

    public NotificationScheduler(ExportHistoryRepository exportHistoryRepository,
                                 SchedulerParamsEntity schedulerParams,
                                 NotificationService notificationService) {
        this(exportHistoryRepository, schedulerParams, notificationService, DEFAULT_WAIT_DURATION);
    }

    // Constructeur supplémentaire pour les tests
    public NotificationScheduler(ExportHistoryRepository exportHistoryRepository,
                                 SchedulerParamsEntity schedulerParams,
                                 NotificationService notificationService,
                                 Duration waitDuration) {
        this.exportHistoryRepository = exportHistoryRepository;
        this.schedulerParams = schedulerParams;
        this.notificationService = notificationService;
        this.waitDuration = waitDuration != null ? waitDuration : DEFAULT_WAIT_DURATION;
    }

    @Override
    public void run() {
        log.info("Starting scheduler : {} {}", schedulerParams.getId(), schedulerParams.getSchedulerName());
        processNewNotifications();
    }

    private void processNewNotifications() {
        try {
            List<ExportHistoryEntity> newExports = exportHistoryRepository
                    .findAllByNotificationStatusIn(NotificationStatus.NEW)
                    .collectList()
                    .block();

            if (newExports == null || newExports.isEmpty()) {
                log.info("Aucun export avec notificationStatus NEW à traiter");
            } else {
                log.info("Traitement notification NEW pour {} export(s)", newExports.size());
                notificationService.sendNotification(newExports, schedulerParams).block();
            }

            // Pour laisser le temps au service PNC de traiter les notifs
            log.info("Attente de 1 minute avant le contrôle des notifications CREATED");
            waitOneMinuteBeforeCreatedCheck();

            List<ExportHistoryEntity> createdExports = exportHistoryRepository
                    .findAllByNotificationStatusIn(NotificationStatus.CREATED)
                    .collectList()
                    .block();

            if (createdExports == null || createdExports.isEmpty()) {
                log.info("Aucun export avec notificationStatus CREATED à contrôler");
                return;
            }

            log.info("Contrôle du statut de {} notification(s) CREATED", createdExports.size());
            notificationService.checkNotificationStatus(createdExports).block();

        } catch (Exception e) {
            log.error("Erreur lors du traitement des notifications : {}", e.getMessage(), e);
        }
    }

    private void waitOneMinuteBeforeCreatedCheck() {
        try {
            Thread.sleep(waitDuration.toMillis());
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            log.warn("Attente interrompue avant le contrôle des notifications CREATED", ie);
        }
    }
}