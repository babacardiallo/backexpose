CREATE TABLE blg_contract_importer.contract
(
    id_contract                          int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    contract_number                      varchar(32)  NOT NULL,
    `type`                               varchar(32)  NOT NULL,
    subtype                              varchar(32)  NOT NULL,
    effective_datetime                   datetime,
    cust_acc_number                      int UNSIGNED NOT NULL,
    id_legal_person                      int UNSIGNED,
    renewal_mode                         varchar(32),
    management_mode                      varchar(32),
    signature_datetime                   datetime,
    creation_channel                     varchar(32),
    comments                             varchar(255),
    cust_contractual_agreement_reference varchar(255),
    CONSTRAINT unq_contract_contract_number UNIQUE (contract_number)
);

CREATE INDEX fk_contract_legal_person ON blg_contract_importer.contract (id_legal_person);

CREATE TABLE blg_contract_importer.contract_linked
(
    id_contract            int UNSIGNED NOT NULL,
    linked_contract_number varchar(32)  NOT NULL,
    linked_contract_id     int UNSIGNED,
    link_type              varchar(32),
    CONSTRAINT pk_contract_linked PRIMARY KEY (id_contract, linked_contract_number),
    CONSTRAINT fk_contract_linked_contract FOREIGN KEY (linked_contract_id) REFERENCES blg_contract_importer.contract (id_contract) ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT fk_contract_linked_contract_0 FOREIGN KEY (id_contract) REFERENCES blg_contract_importer.contract (id_contract) ON DELETE CASCADE ON UPDATE RESTRICT
);

CREATE INDEX fk_contract_linked_contract ON blg_contract_importer.contract_linked (linked_contract_id);

CREATE TABLE blg_contract_importer.invoice_information
(
    id_invoice_information       int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    invoice_periodicity_label    varchar(32),
    invoice_mode                 varchar(32),
    sending_support_label        varchar(32),
    bosco                        varchar(32),
    dedicated_invoice_flag       boolean,
    in_arrears_invoice_flag      boolean,
    id_address_invoice           int UNSIGNED,
    id_mandate                   int UNSIGNED,
    invoice_address_number       varchar(255),
    payment_means                varchar(32),
    means_reference              varchar(40),
    payment_period               varchar(40),
    rum                          varchar(40),
    type                         varchar(40),
    vat_deposit_zone_code        varchar(255),
    vat_liability_flag           boolean,
    bank_name                    varchar(32),
    amount                       decimal(11, 2),
    financial_security_means     varchar(32),
    risk_level_color             varchar(32),
    validity_start_datetime      datetime,
    validity_end_datetime        datetime,
    deposit_payment_flag         boolean,
    security_amount              decimal(11, 2),
    security_ceiling             decimal(11, 2),
    cust_purchase_order_number   varchar(255),
    contracting_cust_ref1        varchar(255),
    market_number                varchar(255)
);

CREATE INDEX fk_invoice_information_address ON blg_contract_importer.invoice_information (id_address_invoice);

CREATE TABLE blg_contract_importer.offer_filter
(
    offer_ops_id int UNSIGNED NOT NULL PRIMARY KEY,
    ops_code     varchar(32)  NOT NULL,
    filter       varchar(256)
) engine = InnoDB;

CREATE TABLE blg_contract_importer.valued_offer
(
    id_valued_offer int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ops_id          varchar(32)  NOT NULL,
    ops_code        varchar(32)  NOT NULL
);

CREATE TABLE blg_contract_importer.contract_version
(
    id_contract_version               int UNSIGNED                                     NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract                       int UNSIGNED                                     NOT NULL,
    amendment_number                  int UNSIGNED                                     NOT NULL,
    revision_number                   int UNSIGNED                                     NOT NULL,
    validity_start_datetime           datetime                                         NOT NULL,
    validity_end_datetime             datetime,
    `status`                          enum ('VALIDE','INACTIF','EN_COURS_DE_CREATION') NOT NULL,
    substatus                         enum ('EN_COURS_DE_CREATION','EDITE','A_VALIDER','SIGNE','VALIDE','DEMANDE_DE_RESILIATION','ECHU','EN_COURS_DE_RENOUVELLEMENT','RESILIE','TERMINE','RENOUVELE','ANNULE','AVENANT','EN_ATTENTE_SIGNATURE_CLIENT','EN_ATTENTE_SIGNATURE_POSTE'),
    termination_datetime              datetime,
    termination_reason                varchar(40),
    term                              varchar(30),
    category                          varchar(255),
    parent_contract_number            varchar(32),
    parent_amendment_number           int UNSIGNED,
    id_valued_offer                   int UNSIGNED,
    id_invoice_information            int UNSIGNED,
    is_synchronized                   boolean                                          NOT NULL DEFAULT false,
    date_synchronization              datetime,
    offset_num_consolidated int,
    partition_num_consolidated int,
    CONSTRAINT fk_contract_version_contract FOREIGN KEY (id_contract) REFERENCES blg_contract_importer.contract (id_contract) ON DELETE CASCADE ON UPDATE RESTRICT,
    CONSTRAINT fk_contract_version_invoice_information FOREIGN KEY (id_invoice_information) REFERENCES blg_contract_importer.invoice_information (id_invoice_information) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_contract_version_valued_offer FOREIGN KEY (id_valued_offer) REFERENCES blg_contract_importer.valued_offer (id_valued_offer) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT unq_contract_version UNIQUE (id_contract, amendment_number)
);

CREATE TABLE blg_contract_importer.queue_synchronization_after_error
(
    id_queue                      int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract                   int UNSIGNED,
    id_legal_person               int UNSIGNED,
    date_synchronization_expected datetime,
    action                        enum ('create','update'),
    refcom_replay                 BOOLEAN default 0,
    CONSTRAINT unq_queue_synchronization_id_contract UNIQUE (id_contract),
    CONSTRAINT unq_queue_synchronization_id_legal_person UNIQUE (id_legal_person)
);

CREATE TABLE blg_contract_importer.queue_migration_by_offer
(
    id_queue                      int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract                   int UNSIGNED,
    date_synchronization_expected datetime,
    action                        enum ('create','update'),
    offer_ops_code                varchar(32)  NOT NULL,
    CONSTRAINT unq_queue_synchronization_id_contract_0 UNIQUE (id_contract)
);

CREATE INDEX idx_queue_migration_by_offer ON blg_contract_importer.queue_migration_by_offer (offer_ops_code);

CREATE INDEX fk_contract_version_contract ON blg_contract_importer.contract_version (id_contract);

CREATE INDEX fk_contract_version_invoice_information ON blg_contract_importer.contract_version (id_invoice_information);

CREATE INDEX fk_contract_version_valued_offer ON blg_contract_importer.contract_version (id_valued_offer);

CREATE TABLE blg_contract_importer.error_log
(
    id_error_log     int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    contract_number  varchar(32),
    amendment_number int UNSIGNED,
    revision_number  int UNSIGNED,
    id_contract      int UNSIGNED,
    id_legal_person  int UNSIGNED,
    cust_acc_number  int UNSIGNED,
    id_address_refpm int UNSIGNED,
    `status`         enum ('VALIDE','INACTIF','EN_COURS_DE_CREATION'),
    substatus        enum ('EN_COURS_DE_CREATION','EDITE','A_VALIDER','SIGNE','VALIDE','DEMANDE_DE_RESILIATION','ECHU','EN_COURS_DE_RENOUVELLEMENT','RESILIE','TERMINE','RENOUVELE','ANNULE','AVENANT'),
    date_error       datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    error_message    text         NOT NULL,
    workflow_step    enum (
        'CONTRACT_LISTENING_ORDER',
        'CONTRACT_LISTENING',
        'CONTRACT_POST_LISTENING_PUBLISHING',
        'LEGALPERSON_LISTENING',
        'ADDRESS_LISTENING',
        'SYNCHRONIZATION_CUSTOMER',
        'SYNCHRONIZATION_CONTRACT',
        'MAPPING_CONTRACT_OPENCELL',
        'SCHEDULER',
        'SYNCHRONIZATION_PUBLISHING_CREATE_CONTRACT',
        'SYNCHRONIZATION_PUBLISHING_UPDATE_CONTRACT',
        'SYNCHRONIZATION_PUBLISHING_CUSTOMER',
        'CALLING_REFPM_API',
        'CALLING_MANDAT_SEPA_API',
        'CALLING_SOURCE_ORGA_API'
        )
) engine = InnoDB;

CREATE TABLE blg_contract_importer.legal_person
(
    id_legal_person      int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    cust_acc_number      int UNSIGNED NOT NULL,
    comp_name            varchar(131) NOT NULL,
    brand_name           varchar(50),
    type_code            tinyint,
    type_label           varchar(50),
    status               varchar(15),
    establish_zone_code  varchar(2),
    marketing_type_code  varchar(3),
    vat_number           varchar(14),
    siret_code           varchar(14),
    email                varchar(255),
    legal_nature_code    varchar(4),
    legal_nature_name    varchar(150),
    is_synchronized      boolean      NOT NULL DEFAULT false,
    date_synchronization datetime,
     business_team_id int,
        business_team_long_name varchar(50),
        created datetime,
        billing_typology varchar(50),
    CONSTRAINT unq_legal_person UNIQUE (cust_acc_number)
);

CREATE TABLE blg_contract_importer.address
(
    id_address       int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    address_id_refpm varchar(25)  NOT NULL,
    id_legal_person  int UNSIGNED NOT NULL,
    cust_acc_number  int UNSIGNED,
    c_datetime       datetime,
    m_datetime       datetime,
    name1            varchar(50),
    add2             varchar(50),
    add3             varchar(50),
    add4             varchar(50),
    add5             varchar(50),
    add6             varchar(50),
    add7             varchar(50),
    address_type     enum ('PRINCIPALE','FACTURATION','PRESTATION'),
    address_json     json         NOT NULL,
    CONSTRAINT fk_address_legal_person FOREIGN KEY (id_legal_person) REFERENCES blg_contract_importer.legal_person (id_legal_person) ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE INDEX fk_address_legal_person ON blg_contract_importer.address (id_legal_person);

CREATE TABLE blg_contract_importer.mandate
(
    id_mandate int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rum        varchar(40)  NOT NULL,
    iban       varchar(40)  NOT NULL,
    bic        varchar(40)  NOT NULL,
    status     varchar(40)  NOT NULL
);

CREATE TABLE blg_contract_importer.establishment
(
    id_establishment int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    regate_code      varchar(6)   NOT NULL,
    label            varchar(50)  NOT NULL
);

CREATE INDEX idx_establishment_regate_code ON blg_contract_importer.establishment (regate_code);

-- V1.0.1
ALTER TABLE blg_contract_importer.address
    ADD CONSTRAINT unq_address UNIQUE (address_id_refpm);

-- V1.0.2
DROP INDEX idx_establishment_regate_code ON blg_contract_importer.establishment;

ALTER TABLE blg_contract_importer.establishment
    ADD CONSTRAINT unq_establishment UNIQUE (regate_code);

    --V1.0.3
ALTER TABLE contract_version ADD offset_num INT;
ALTER TABLE contract_version ADD partition_num INT;

ALTER TABLE error_log ADD offset_num INT;
ALTER TABLE error_log ADD partition_num INT;

ALTER TABLE `blg_contract_importer`.`error_log`
CHANGE COLUMN `workflow_step` `workflow_step`
ENUM('CONTRACT_LISTENING_ORDER', 'CONTRACT_LISTENING', 'CONTRACT_POST_LISTENING_PUBLISHING',
'LEGALPERSON_LISTENING', 'ADDRESS_LISTENING',
'SYNCHRONIZATION_CUSTOMER', 'SYNCHRONIZATION_CONTRACT', 'MAPPING_CONTRACT_OPENCELL', 'SCHEDULER',
'SYNCHRONIZATION_PUBLISHING_CREATE_CONTRACT',
'SYNCHRONIZATION_PUBLISHING_UPDATE_CONTRACT', 'SYNCHRONIZATION_PUBLISHING_CUSTOMER',
'CALLING_REFPM_API', 'CALLING_MANDAT_SEPA_API', 'CALLING_SOURCE_ORGA_API', 'CONTRACT_LISTENING_BEFORE_CONTRACT_CREATION',
'CONTRACT_LISTENING_AFTER_MAPPING_AVRO');

    --V1.1.0
ALTER TABLE blg_contract_importer.contract_version ADD is_purged TINYINT(1) NOT NULL DEFAULT 0;

ALTER TABLE contract_version ADD COLUMN previous_date_synchronization datetime;

CREATE TABLE contract_version_message (
    id_contract_version_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract_version INT UNSIGNED default null,
    contract_version_information JSON,
    contract_consolidated JSON,
    contract_odc JSON,
    CONSTRAINT fk_contract_version_message_contract_version FOREIGN KEY (id_contract_version) REFERENCES blg_contract_importer.contract_version (id_contract_version) ON DELETE CASCADE ON UPDATE RESTRICT
);

CREATE TABLE contract_message (
    id_contract_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract INT UNSIGNED default null,
    contract_information JSON,
    CONSTRAINT fk_contract_message_contract FOREIGN KEY (id_contract) REFERENCES blg_contract_importer.contract (id_contract) ON DELETE CASCADE ON UPDATE RESTRICT
);
CREATE TABLE legal_person_message (
    id_legal_person_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_legal_person INT UNSIGNED default null,
    legal_person_json JSON,
    CONSTRAINT fk_legal_person_message_legal_person FOREIGN KEY (id_legal_person) REFERENCES blg_contract_importer.legal_person (id_legal_person) ON DELETE CASCADE ON UPDATE RESTRICT
);
CREATE TABLE invoice_information_message (
    id_invoice_information_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_invoice_information INT UNSIGNED default null,
    invoicing_comments_jsonarray JSON,
    invoice_information_json JSON,
    CONSTRAINT fk_invoice_information_invoice_invoice_information_message FOREIGN KEY (id_invoice_information) REFERENCES blg_contract_importer.invoice_information (id_invoice_information) ON DELETE CASCADE ON UPDATE RESTRICT
);
CREATE TABLE valued_offer_message (
    id_valued_offer_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_valued_offer INT UNSIGNED default null,
    message JSON,
    CONSTRAINT fk_valued_offer_message_valued_offer FOREIGN KEY (id_valued_offer) REFERENCES blg_contract_importer.valued_offer (id_valued_offer) ON DELETE CASCADE ON UPDATE RESTRICT
);

