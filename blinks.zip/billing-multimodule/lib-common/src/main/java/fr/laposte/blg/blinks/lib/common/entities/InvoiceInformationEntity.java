package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.math.BigDecimal;
import java.time.Instant;

@Table("invoice_information")
@Data
@Accessors(chain = true)
public class InvoiceInformationEntity {
    @Id
    @Column("id_invoice_information")
    private Long idInvoiceInformation;
    ////    @Column("id_contract_version")
////    private Long idContractVersion;
//    @Transient
//    private ContractVersionEntity contractVersionEntity;
    @Column("invoice_periodicity_label")
    private String invoicePeriodicityLabel;
    @Column("invoice_mode")
    private String invoiceMode;
    @Column("sending_support_label")
    private String sendingSupportLabel;
    @Column("bosco")
    private String bosco;
    @Column("dedicated_invoice_flag")
    private Boolean dedicatedInvoiceFlag;
    @Column("in_arrears_invoice_flag")
    private Boolean inArrearsInvoiceFlag;
    @Column("id_address_invoice")
    private Long idAddressInvoice;
    @Column("invoice_address_number")
    private String invoiceAddressNumber;
    @Transient
    private AddressEntity addressFacturation;
    @Column("payment_means")
    private String paymentMeans;
    @Column("means_reference")
    private String meansReference;
    @Column("payment_period")
    private String paymentPeriod;
    @Column("id_mandate")
    private Long idMandate;
    @Transient
    private MandateEntity mandate;
    @Column("rum")
    private String rum;
    @Column("type")
    private String type;

    @Column("vat_liability_flag")
    private Boolean vatLiabilityFlag;

    @Column("vat_deposit_zone_code")
    private String vatDepositZoneCode;

    @Column("bank_name")
    private String bankName;

    @Column("amount")
    private BigDecimal amount;

    @Column("financial_security_means")
    private String financialSecurityMeans;

    @Column("risk_level_color")
    private String riskLevelColor;

    @Column("validity_start_datetime")
    private Instant validityStartDatetime;

    @Column("validity_end_datetime")
    private Instant validityEndDatetime;

    @Column("deposit_payment_flag")
    private Boolean depositPaymentFlag;

    @Column("security_amount")
    private BigDecimal securityAmount;

    @Column("security_ceiling")
    private BigDecimal securityCeiling;

    @Column("cust_purchase_order_number")
    private String custPurchaseOrderNumber;
    @Column("contracting_cust_ref1")
    private String contractingCustRef1;
    @Column("market_number")
    private String marketNumber;

    @Column("framework_contract_number")
    private String frameworkContractNumber;
    @Column("cust_business_unit_ref")
    private String custBusinessUnitRef;
    @Column("contracting_cust_ref2")
    private String contractingCustRef2;

    @Column("invoicing_cust_ref2")
    private String invoicingCustRef2;

    @Column("schedule")
    private String schedule;

    @Column("invoicing_cust_ref1")
    private String invoicingCustRef1;

    @Column("payment_cc_id")
    private String paymentCCId;

    @Column("payment_cc_datetime")
    private Instant paymentCCDateTime;

    //invoicingCustRef2Object
    @Column("siren")
    private String siren;
    @Column("raison_sociale")
    private String raisonSociale;
    @Column("siret")
    private String siret;
    @Column("code_routage")
    private String codeRoutage;
    @Column("suffixe")
    private String suffixe;
    @Column("identifiant_code_routage")
    private String identifiantCodeRoutage;
}
