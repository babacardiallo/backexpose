package fr.laposte.blg.blinks.u12.service.establishment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import fr.laposte.blg.blinks.u12.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u12.dto.EstablishmentDTO;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

@ConfigurationProperties(prefix = "fr.laposte.apim.establishment")
@Data
@Service
@Slf4j
public class EstablishmentService {

    private String apiName;
    private String endpoint;

    private final ApimServiceImpl apimService;
    private final ObjectMapper objectMapper;
    private final CsvMapper csvMapper;
    private final CsvSchema schema;
    private final ObjectReader reader;

    public EstablishmentService(ApimServiceImpl apimService, ObjectMapper objectMapper) {
        this.apimService = apimService;
        this.objectMapper = objectMapper;
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false);
        this.csvMapper = new CsvMapper();
        this.schema = CsvSchema.emptySchema().withHeader().withColumnSeparator(';');
        this.reader = this.csvMapper.readerFor(EstablishmentDTO.class).with(this.schema);
    }

    public Mono<EstablishmentDTO> fetchEstablishment(String codeRegate) {
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("codeRegate", codeRegate);

        return this.apimService.get(apiName + endpoint, queryParams)
            .switchIfEmpty(Mono.error(new EstablishmentCommunicationException("No establishement fetched from sourceOrgaEntityUnit endpoint")))
            .flatMap(csvResponse -> {
                log.debug("Retour APIM Establishments {}", csvResponse);
                try {
                    return Mono.just(this.reader.readValue(csvResponse));
                } catch (JsonProcessingException e) {
                    log.error("Couldn't process establishment json", e);
                    return Mono.error(new EstablishmentCommunicationException("Response from sourceOrgaEntityUnit cannot be parsed"));
                }
            });
    }
}
