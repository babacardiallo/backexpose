import { HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, defer, from } from "rxjs";
import { switchMap } from "rxjs/operators";
import { environment } from "../../environments/environment";
import { AuthCheckService } from "./auth-check.service";

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

    constructor(public authCheckService: AuthCheckService, private http: HttpClient){}

    getCsrfToken(request: HttpRequest<any>): Observable<string> {
        let csrfTokenUrl = "";
        if(request.url.includes("blinks-collector-api") || request.url.includes("localhost:8084")) {
          csrfTokenUrl = environment.BLINKS_COLLECTOR_API_CSRF_TOKEN_ENDPOINT;
        } else {
           if(request.url.includes("u10-opencell-api")|| request.url.includes("localhost:8080")) {
            csrfTokenUrl = environment.BLINKS_COLLECTOR_OC_API_CSRF_TOKEN_ENDPOINT
           } else {
            csrfTokenUrl = environment.BLINKS_EXPORTER_OUT_API_CSRF_TOKEN_ENDPOINT
           }
        }
        return this.http.get(csrfTokenUrl, { withCredentials: true, responseType: 'text' });
    }
      
      intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // Endpoints à ignorer
        if (request.url.includes("authentification") ||
            request.url.includes("csrf") || request.url.includes("u2") || request.url.includes("u3")) {
          return next.handle(request);
        }
      
        return from(this.authCheckService.checkAuthToken()).pipe(
          switchMap(jwt =>{
            if(request.method==='GET'){
                const req = request.clone({
                    withCredentials: true,
                    setHeaders: {
                      'I2A-JWT-Assertion': jwt
                    }
                  });
                  return next.handle(req);
            } else {
                return this.getCsrfToken(request).pipe(
                    switchMap(csrf => {
                      const req = request.clone({
                        withCredentials: true,
                        setHeaders: {
                          'I2A-JWT-Assertion': jwt,
                          'X-CSRF-TOKEN': csrf
                        }
                      });
                      return next.handle(req);
                    })
                  )
            }
            
          }
          )
        );
      }
       
 
}