import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { EdrDetails } from "../../models/edr-details.model";
import { EdrTable } from "../../models/edr-table.model";
import { EdrService } from "../../service/edr.service";

@Component({
    selector: 'edr-saisie-popup-component',
    templateUrl: './edr-saisie-popup.component.html',
    styleUrls: ['./edr-saisie-popup.component.scss'],
    standalone: false
})

export class EdrSaisiePopupComponent  implements OnInit {

    content: any;

    public edrSaisies = '';

    name = 'EdrSaisiePopupComponent';

    constructor(private modalService: ModalService, private edrService: EdrService, private snackBar: MatSnackBar) {
    }

    ngOnInit() {
        
    }

   updatePerimeter(){
        const edrs = this.edrSaisies.split("\n");
        if(edrs[0]==''){
            return;
        } else {
            this.edrService.updateEdrSelectedPending(edrs).subscribe({        
                next: (response) => {
                },
                complete: () => {
                  this.snackBar.open("Les status des rejets sont passés à PENDING", 'Fermer', { duration: 8000 });
                  this.close();
                  this.edrService.emitLoadEdr();
                },
            })
        }
   }

   close(){
    this.modalService.close(this.name);
   }

  
}
