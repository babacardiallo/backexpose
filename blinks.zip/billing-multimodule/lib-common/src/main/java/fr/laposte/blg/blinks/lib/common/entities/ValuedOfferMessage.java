package fr.laposte.blg.blinks.lib.common.entities;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("valued_offer_message")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ValuedOfferMessage {
    @Id
    @Column("id_valued_offer_message")
    private Long idValuedOfferMessage;

    @Column("id_valued_offer")
    private Long idValuedOffer;

    @Column("message")
    private String message;
}
