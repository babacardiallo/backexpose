UPDATE invoice i
JOIN invoice_message m ON m.id_invoice = i.id_invoice
SET
    credit_flag = IFNULL(
        JSON_UNQUOTE(JSON_EXTRACT(m.message, "$.invoiceHeader.creditFlag")) = 'true',
        0
    ),
    statement_flag = IFNULL(
        JSON_UNQUOTE(JSON_EXTRACT(m.message, "$.invoiceHeader.isStatementFlag")) = 'true',
        0
    ),
    downpayment_flag = IFNULL(
        JSON_UNQUOTE(JSON_EXTRACT(m.message, "$.invoiceHeader.downpaymentFlag")) = 'true',
        0
    ),
    avispaiement_flag = IFNULL(
        JSON_UNQUOTE(JSON_EXTRACT(m.message, "$.invoiceHeader.avisPaiementFlag")) = 'true',
        0
    );
