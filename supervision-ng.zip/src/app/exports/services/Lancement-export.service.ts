import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, takeUntil } from 'rxjs/operators';
import { Observable, of, Subject, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PrepareExport } from '../models/prepare-export';


@Injectable({
  providedIn: 'root',
})
export class LancementExportService {
  ngUnsubscribe$ = new Subject<void>();

  urlSendFile = 'https://pic2.net-courrier.extra.laposte.fr/buildByToken/buildWithParameters?';

  constructor(private http: HttpClient) { }
  httpOptions: any = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }

  getAllInvoices(page: number, size: number, sort: string, order: string, filter: string, doca: boolean, seres: boolean): Observable<any> {
    let queryParams = new HttpParams()
      .set("page", page)
      .set("size", size)
      .set("sort", sort)
      .set("order", order)
      .set("filter", filter)
      .set("doca", doca)
      .set("seres", seres);
    return this.http.get<any>(environment.API_GET_ALL_INVOICES + "?" + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  prepareExport(exportDto: PrepareExport): Observable<any> {
    return this.http.post<PrepareExport>(environment.API_PREPARE_EXPORT, exportDto, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getAllInvoicesToExport(page: number, size: number, sort: string, order: string): Observable<any> {
    let queryParams = new HttpParams()
      .set("page", page)
      .set("size", size)
      .set("sort", sort)
      .set("order", order);
    return this.http.get<any>(environment.API_INVOICE_TO_EXPORT + "?" + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  export(endPoint: string): Observable<any> {
    return this.http.post(endPoint, {}, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  download(endPoint: string): Observable<Blob> {
    return this.http.get(endPoint, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        
      }),
      responseType: 'blob'
    });
  }



  send(env: string, mail: string) {
    let queryParams = new HttpParams()
      .set('job', 'Billing_AP0824/TEAM/U17_MAIL')
      .set('ENV', env)
      .set('MAIL', mail)
      .set('token', 'ddh4654fytf3531');
    return this.http.post<any>(this.urlSendFile + queryParams, {})
      .pipe(
        catchError((error: any) => {
          if (error.status == 0) {
            return of(1);
          } else {
            return of(0);
          }
        }),

      )

  }


}