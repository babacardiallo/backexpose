package fr.laposte.blg.blinks.u12.service.establishment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import reactor.test.StepVerifier;


@SpringBootTest
@ActiveProfiles("test")
class EstablishmentServiceImplTest {

    @Autowired
    private EstablishmentService establishmentService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void fetchEstablishmentTest() {

        StepVerifier.create(this.establishmentService.fetchEstablishment("752440"))
            .expectNextMatches(establishmentDTO -> establishmentDTO.getCodeRegate().equals("752440")
                && establishmentDTO.getCodeSource().equals("A15459")
                && establishmentDTO.getLibelle().equals("PARIS 13 PPDC"))
            .verifyComplete();

    }
}
