package fr.laposte.blg.blinks.u17.apim;

public class ConnexionException extends RuntimeException {
    public ConnexionException(String reasonPhrase) {
        super(reasonPhrase);
    }
}
