package fr.laposte.blg.blinks.lib.common.entities;


import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("queue_synchro_supervision_view")
@Data
@Accessors(chain = true)
@Builder
public class QueueSynchronizationSupervisionEntity {

    @Id
    @Column("id")
    private Long idQueue;

    @Column("id_contract")
    private Long idContract;

    @Column("id_legal_person")
    private Long idLegalPerson;

    @Column("date_synchronization_expected")
    private Instant dateSynchronizationExpected;

    @Column("action")
    private ActionEnum action;

    @Column("refcom_replay")
    private Boolean refcomReplay;

    @Column("contract_number")
    private String contractNumber;

    @Column("ops_code")
    private String opsCode;

    @Column("cust_acc_number")
    private String custAccNumber;
}
