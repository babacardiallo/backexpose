ALTER TABLE blg_contract_importer.invoice_information
    ADD COLUMN siren varchar(255),
    ADD COLUMN raison_sociale varchar(255),
    ADD COLUMN siret varchar(255),
    ADD COLUMN code_routage varchar(255),
    ADD COLUMN suffixe varchar(255),
    ADD COLUMN identifiant_code_routage varchar(255);