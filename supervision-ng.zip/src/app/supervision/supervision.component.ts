import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { environment } from '../../environments/environment';
@Component({
    selector: 'app-supervision',
    templateUrl: './supervision.component.html',
    styleUrls: ['./supervision.component.scss'],
    standalone: false
})
export class SupervisionComponent {
  appName = environment.appName;
  constructor(
    private router: Router,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.updateTitle();

    this.router.events
      .pipe(filter((event: any) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateTitle();
      });
  }

  private updateTitle() {
    this.titleService.setTitle("Factura : Supervision Exports");

  }

}