package fr.laposte.blg.blinks.u12.service.contract;

import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferEntity;
import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferMessage;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationMappingException;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.io.JsonEncoder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ValuedOfferParserTest {

    private ValuedOfferParser parser;
    private ValuedOfferEntity dummyEntity;

    @BeforeEach
    void setUp() {
        parser = new ValuedOfferParser();
        dummyEntity = new ValuedOfferEntity();

    }


    private String serializeOfferToJson(Offer offer) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DatumWriter<Offer> writer = new GenericDatumWriter<>(offer.getSchema());
        JsonEncoder encoder = EncoderFactory.get().jsonEncoder(offer.getSchema(), out);
        writer.write(offer, encoder);
        encoder.flush();
        return out.toString();
    }

    @Test
    void testFetchAllDeliveryAddressIdsInOffer_withValidOffer() throws IOException {
        Offer offer = Offer.newBuilder()
                .setOfferCriteria(Arrays.asList(
                        OfferCriteria.newBuilder()
                                .setOfferCriterionKey("ADR_PREST")
                                .setOfferCriterionValueId("1")
                                .build(),
                        OfferCriteria.newBuilder()
                                .setOfferCriterionKey("ETB_PREST")
                                .setOfferCriterionValueId("100")
                                .build()
                ))
                .setProducts(Collections.singletonList(
                        OfferProduct.newBuilder()
                                .setProductCriteria(Arrays.asList(
                                        ProductCriteria.newBuilder()
                                                .setProductCriterionKey("ADR_PREST")
                                                .setProductCriterionValueId("2")
                                                .build(),
                                        ProductCriteria.newBuilder()
                                                .setProductCriterionKey("ETB_PREST")
                                                .setProductCriterionValueId("200")
                                                .build()
                                ))
                                .setProductService(Collections.singletonList(
                                        ProductService.newBuilder()
                                                .setServiceCriteria(Arrays.asList(
                                                        ServiceCriteria.newBuilder()
                                                                .setServiceCriterionKey("ADR_PREST")
                                                                .setServiceCriterionValueId("3")
                                                                .build(),
                                                        ServiceCriteria.newBuilder()
                                                                .setServiceCriterionKey("ETB_PREST")
                                                                .setServiceCriterionValueId("300")
                                                                .build()
                                                ))
                                                .build()
                                ))
                                .build()
                ))
                .build();

        String jsonMessage = serializeOfferToJson(offer);
        ValuedOfferMessage message = new ValuedOfferMessage();
        message.setMessage(jsonMessage);

        Map<String, List<String>> result = parser.fetchAllDeliveryAddressIdsInOffer(dummyEntity, message);

        List<String> adrList = result.get("ADR_PREST");
        List<String> etbList = result.get("ETB_PREST");

        Collections.sort(adrList);
        Collections.sort(etbList);

        assertEquals(Arrays.asList("1", "2", "3"), adrList);
        assertEquals(Arrays.asList("100", "200", "300"), etbList);
    }

    @Test
    void testFetchAllDeliveryAddressIdsInOffer_withNullOfferCriteria() throws IOException {
        Offer offer = Offer.newBuilder()
                .setOfferCriteria(null)
                .setProducts(Collections.singletonList(
                        OfferProduct.newBuilder()
                                .setProductCriteria(Collections.singletonList(
                                        ProductCriteria.newBuilder()
                                                .setProductCriterionKey("ADR_PREST")
                                                .setProductCriterionValueId("10")
                                                .build()
                                ))
                                .setProductService(Collections.singletonList(
                                        ProductService.newBuilder()
                                                .setServiceCriteria(Collections.singletonList(
                                                        ServiceCriteria.newBuilder()
                                                                .setServiceCriterionKey("ADR_PREST")
                                                                .setServiceCriterionValueId("20")
                                                                .build()
                                                ))
                                                .build()
                                ))
                                .build()
                ))
                .build();

        String jsonMessage = serializeOfferToJson(offer);
        ValuedOfferMessage message = new ValuedOfferMessage();
        message.setMessage(jsonMessage);

        Map<String, List<String>> result = parser.fetchAllDeliveryAddressIdsInOffer(dummyEntity, message);
        List<String> adrList = result.get("ADR_PREST");
        List<String> etbList = result.get("ETB_PREST");

        Collections.sort(adrList);
        assertEquals(Arrays.asList("10", "20"), adrList);
        assertTrue(etbList.isEmpty());
    }

    @Test
    void testFetchAllDeliveryAddressIdsInOffer_withNullProducts() throws IOException {
        Offer offer = Offer.newBuilder()
                .setOfferCriteria(Arrays.asList(
                        OfferCriteria.newBuilder()
                                .setOfferCriterionKey("ADR_PREST")
                                .setOfferCriterionValueId("50")
                                .build(),
                        OfferCriteria.newBuilder()
                                .setOfferCriterionKey("ETB_PREST")
                                .setOfferCriterionValueId("60")
                                .build()
                ))
                .setProducts(null)
                .build();

        String jsonMessage = serializeOfferToJson(offer);
        ValuedOfferMessage message = new ValuedOfferMessage();
        message.setMessage(jsonMessage);

        Map<String, List<String>> result = parser.fetchAllDeliveryAddressIdsInOffer(dummyEntity, message);
        List<String> adrList = result.get("ADR_PREST");
        List<String> etbList = result.get("ETB_PREST");

        Collections.sort(adrList);
        Collections.sort(etbList);
        assertEquals(List.of("50"), adrList);
        assertEquals(List.of("60"), etbList);
    }


    @Test
    void testFetchAllDeliveryAddressIdsInOffer_withBothNull() throws IOException {
        Offer offer = Offer.newBuilder()
                .setOfferCriteria(null)
                .setProducts(null)
                .build();

        String jsonMessage = serializeOfferToJson(offer);
        ValuedOfferMessage message = new ValuedOfferMessage();
        message.setMessage(jsonMessage);

        Map<String, List<String>> result = parser.fetchAllDeliveryAddressIdsInOffer(dummyEntity, message);
        List<String> adrList = result.get("ADR_PREST");
        List<String> etbList = result.get("ETB_PREST");

        assertTrue(adrList.isEmpty());
        assertTrue(etbList.isEmpty());
    }

    @Test
    void testFetchAllDeliveryAddressIdsInOffer_withInvalidJson() {
        ValuedOfferMessage message = new ValuedOfferMessage();
        message.setMessage("invalid json");

        Exception exception = assertThrows(SynchronizationMappingException.class, () ->
                parser.fetchAllDeliveryAddressIdsInOffer(dummyEntity, message)
        );

        String expectedMessage = "Error during criteria and product/service mapping";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }
}