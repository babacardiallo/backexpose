# 🌍 Environnements GitLab

Les environnements suivants sont définis dans l’UI GitLab :

- mar-sdev   
- mar-srec   
- mar-sacc
- mar-sass
- mar-prod  
- mar-prod1
