package fr.laposte.blg.blinks.lib.common.entities.organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("customer_profit_center")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CustomerProfitCenter {

    @Id
    @Column("id")
    private Long id;

    @Column("coclico")
    private Integer coclico;

    @Column("entity_code")
    private String entityCode;

    @Column("profit_center")
    private String profitCenter;

    @Column("created")
    private Instant created;

    @Column("updated")
    private Instant updated;

}
