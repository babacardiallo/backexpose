import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { UntypedFormControl, UntypedFormGroup } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { EdrPage } from "../models/edr-page";
import { EdrTable } from "../models/edr-table.model";
import { EdrService } from "../service/edr.service";
import { EdrDetailsPopUpComponent } from "./edr-details-pop-up/edr-details-pop-up.component";
import { EdrSaisiePopupComponent } from "./edr-saisie-popup/edr-saisie-popup.component";
import * as XLSX from 'xlsx';
import { ModalService } from "ngx-modal-ease";

@Component({
    selector: 'edr-table',
    templateUrl: './edr-table.component.html',
    styleUrls: ['./edr-table.component.scss'],
    standalone: false
})

export class EdrTableComponent implements OnInit {

  @ViewChild(DatatableComponent) edrTable: DatatableComponent;

  searchText: string = '';

  isPending: boolean = false;

  range: UntypedFormGroup;

  edrPage: EdrPage = new EdrPage();

  listEdrs = [];

  globalStartDate: any;

  globalEndDate: any;

  globalStatus = '';

  selectedCodeErreurs = new UntypedFormControl('');

  listErreurs = [];

  M1_MODAL_PROPERTIES = {
    animation: 'enter-going-down',
    duration: '0.1s',
    easing: 'ease-out',
    padding: '1rem',
    width: '1800px',
    height: '100%'
  };


  constructor(private edrService: EdrService, private datePipe: DatePipe, private snackBar: MatSnackBar, private modalService: ModalService) {

    this.edrService.busService.subscribe(res => {
      if (res) {
        this.getListEdrsByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate);
      }
    })

  }
  ngOnInit(): void {
    const today = new Date();
    let oneMonthAgo = new Date();
    oneMonthAgo = new Date(oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1));
    this.range = new UntypedFormGroup({
      start: new UntypedFormControl(oneMonthAgo),
      end: new UntypedFormControl(today),
    });
    this.globalStartDate = this.datePipe.transform(oneMonthAgo, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
    this.globalEndDate = this.datePipe.transform(today, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
    this.getListEdrsByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate);
    this.getAllErrorsCode();
  }



  getListEdrs(page: number, size: number, sort: string, order: string) {
    this.edrService.getListEdrs(page, size, sort, order).subscribe({
      next: (response: any) => {
        this.listEdrs = response._embedded.events.map((data: any) => {
          return {
            id: data.id,
            eventUuid: data.eventUuid,
            errorDate: this.formatDate(data.errorDate),
            errorCode: data.errorCode,
            errorMessage: data.errorMessage,
            replayStatus: data.replayStatus,
            nbRetry: data.nbRetry
          };
        });
        this.edrPage.currentPage = response.page.number;
        this.edrPage.itemsOnPage = response.page.size;
        this.edrPage.totalItems = response.page.totalElements
        this.edrPage.totalPages = response.page.totalPages
      },
      complete: () => {
      },

    })
  }


  getListEdrsByDate(page: number, size: number, sort: string, order: string, startDate: any, enDate: any) {
    this.edrService.getListEdrsByDate(page, size, sort, order, startDate, enDate, this.searchText, this.globalStatus, this.selectedCodeErreurs.value).subscribe({
      next: (response: any) => {
        this.listEdrs = response._embedded.events.map((data: any) => {
          return {
            id: data.id,
            errorDate: this.formatDate(data.errorDate),
            eventUuid: data.eventUuid,
            errorCode: data.errorCode,
            errorMessage: data.errorMessage,
            replayStatus: data.replayStatus,
            nbRetry: data.nbRetry,
            contractCode: data.contractCode,
            custAccNumber: data.custAccNumber,
            offerCode: data.offerCode,
            productCode: data.productCode
          };
        });
        this.edrPage.currentPage = response.page.number;
        this.edrPage.itemsOnPage = response.page.size;
        this.edrPage.totalItems = response.page.totalElements
        this.edrPage.totalPages = response.page.totalPages
      },
      complete: () => {
      },

    })
  }


  filter(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.getListEdrsByDate(0, 10, "errorDate", "desc", this.globalStartDate, this.globalEndDate);
    }
  }

  selectedDate(event: any) {
    if (event.value) {
      this.globalStartDate = this.datePipe.transform(this.range.value.start, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
      this.globalEndDate = this.datePipe.transform(this.range.value.end, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
      this.getListEdrsByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate)
    }
  }


  showPending() {
    if (this.isPending) {
      this.globalStatus = 'PENDING';
    } else {
      this.globalStatus = '';
    }

    this.getListEdrsByDate(0, 10, "errorDate", "desc", this.globalStartDate, this.globalEndDate);
  }

  onPageChange(event: any) {
    this.getListEdrsByDate(event.offset, 10, this.edrTable.sorts[0].prop, this.edrTable.sorts[0].dir, this.globalStartDate, this.globalEndDate);
  }

  onSort(event: any) {
    this.getListEdrsByDate(this.edrPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.globalStartDate, this.globalEndDate);
    this.edrTable.offset = this.edrPage.currentPage!;
  }

  showPopup(row: EdrTable, event: Event) {
    this.modalService
        .open(EdrDetailsPopUpComponent, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
            height: this.M1_MODAL_PROPERTIES.height
          },
          data: {
            edr: row,
          }
        })
        .then((response) => console.log(response));
         event.stopPropagation()
  }

  replayPendingEdrs(e: Event) {
    let returnValue: string;
    this.edrService.postReplayPendings().subscribe({
      next: (response: string) => {
        returnValue = response;
      },
      complete: () => {
        if (returnValue == "Traitement lancé avec succès.") {
          this.snackBar.open("Les EDR en PENDING ont été envoyés pour rejeu", 'Fermer', { duration: 5000 });
        }
        else {
          this.snackBar.open("Une erreur est survenue. Veuillez réessayer", 'Fermer', { duration: 5000 });
        }
      },
    })
  }


  formatDate(date: any) {
    return date ? this.datePipe.transform(date, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
  }

  showPopupSaisie(event: Event) {
    this.modalService
    .open(EdrSaisiePopupComponent, {
      modal: {
        enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
        top: '60%'
      },
      overlay: {
        leave: 'fade-out 0.3s',
      },
      size: {
        padding: this.M1_MODAL_PROPERTIES.padding,
        width: '1200px',
        height: this.M1_MODAL_PROPERTIES.height
      },
      data: {
        content: '',
      }
    })
    .then((response) => console.log(response));
     event.stopPropagation()
  }

  updatePerimeter() {
    if (this.listEdrs.length < 1) {
      return;
    }
    this.edrService.updateEdrFilteredPending().subscribe({
      next: (response) => {
      },
      complete: () => {
        this.snackBar.open("Les statuts des rejets sont passés à PENDING", 'Fermer', { duration: 8000 });
        this.getListEdrsByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate)
      },
    })


  }



  getAllErrorsCode() {
    this.edrService.getAllCodeError().subscribe({
      next: (response: any) => {
        this.listErreurs = response;
      },
      complete: () => {
      },

    })
  }

  filterByErrorCode() {
    this.getListEdrsByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate)
  }

  exportEdrs() {

    let dataToExport: any[];
    this.edrService.getExportedEdr().subscribe({
      next: (response: any) => {
        dataToExport = response.map((data: any) => {
          return <any>{
            id: data.id,
            eventUuid: data.eventUuid,
            contractCode: data.contractCode,
            custAccNumber: data.custAccNumber,
            offerCode: data.offerCode,
            productCode: data.productCode,
            serviceCode: data.serviceCode,
            chargeCode: data.chargeCode,
            errorDate: this.formatDate(data.errorDate),
            replayStatus: data.replayStatus,
            nbRetry: data.nbRetry,
            errorCode: data.errorCode,
            errorMessage: data.errorMessage,
            kafkaMessage: data.kafkaMessage,
            offset: data.offset,
            partition: data.partition,
            analysis: data.analysis,
            solution: data.solution,
          };
        })
      },
      complete: () => {

        const fileName = 'ExportRejetsEDR_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["ID rejet", "UUID event", "N° Contrat", "N° Client", "Code offre", "Code produit", "Code service", "Code charge", "Date erreur", "Status", "Nb retry", "Code erreur", "Message erreur", "Message json charge",
          "Offset", "Partition", "Analyse", "Solution"]];
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport, {
          dateNF: 'dd/mm/yyyy à HH:MM:SS',
          cellDates: true
        });
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.sheet_add_aoa(ws, headers);
        XLSX.utils.book_append_sheet(wb, ws, 'Export');
        ws['!cols'] = [
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 20 },
          { wch: 10 },
          { wch: 25 },
          { wch: 22 },
          { wch: 100 },
          { wch: 200 },
          { wch: 10 },
          { wch: 10 },
          { wch: 50 },
          { wch: 50 },
        ];
        XLSX.writeFile(wb, fileName);
      },
    });
  }

  formatDateExport(date: number) {
    return this.datePipe.transform(date, 'yyyyMMddHHmmSS', 'fr');
  }

  onDateKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      if (this.range.value.start && this.range.value.end) {
        this.globalStartDate = this.datePipe.transform(this.range.value.start, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
        this.globalEndDate = this.datePipe.transform(this.range.value.end, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
        this.getListEdrsByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate);
      }
    }

  }


}