package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.bscc.billing.avro.billing.ContractOpencell;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
@Slf4j
@ActiveProfiles("test")
class ContractOpencellMapperTest {

    @Autowired
    ContractOpencellMapper contractOpencellMapper;

    private ContractOpencell result;

    @BeforeEach
    void init() {
        ContractVersionEntity entity = new ContractVersionEntity();

        entity.setContract(new ContractEntity());
        entity.getContract().setContractNumber("C123");
        entity.getContract().setType("TypeA");
        entity.getContract().setSubtype("SubTypeA");
        entity.getContract().setEffectiveDatetime(Instant.parse("2023-07-05T10:15:30.00Z"));
        entity.getContract().setRenewalMode("AUTO");
        entity.getContract().setSignatureDatetime(Instant.parse("2023-07-06T10:15:30.00Z"));
        entity.getContract().setCustContractualAgreementReference("RefABC");
        entity.getContract().setCreationChannel("Online");
        entity.getContract().setComments("No comments");

        entity.setValidityStartDatetime(Instant.parse("2023-08-01T10:15:30.00Z"));
        entity.setValidityEndDatetime(Instant.parse("2023-12-31T23:59:59.00Z"));
        entity.setRevisionNumber(2);
        entity.setAmendmentNumber(1);
        entity.setStatus(ContractStatusEnum.VALIDE);
        entity.setSubstatus(ContractSubStatusEnum.SIGNE);
        entity.setTerminationDatetime(Instant.parse("2024-01-01T10:00:00.00Z"));
        entity.setCategory("CAT123");
        entity.setParentContractNumber("ParentX");
        entity.setParentAmendmentNumber(99);

        entity.setInvoiceInformationEntity(new InvoiceInformationEntity());
        entity.getInvoiceInformationEntity().setInvoiceAddressNumber("12345");
        entity.getInvoiceInformationEntity().setInvoiceMode("MODE12");
        entity.getInvoiceInformationEntity().setSendingSupportLabel("PAPIER");
        entity.getInvoiceInformationEntity().setDedicatedInvoiceFlag(true);
        entity.getInvoiceInformationEntity().setInArrearsInvoiceFlag(false);
        entity.getInvoiceInformationEntity().setType("TVA");
        entity.getInvoiceInformationEntity().setBosco("12");
        entity.getInvoiceInformationEntity().setVatDepositZoneCode("VATZONE1");
        entity.getInvoiceInformationEntity().setVatLiabilityFlag(false);
        entity.getInvoiceInformationEntity().setRum("RUMXYZ");
        entity.getInvoiceInformationEntity().setPaymentMeans("CHEQUE");
        entity.getInvoiceInformationEntity().setPaymentPeriod("MONTH");
        entity.getInvoiceInformationEntity().setMeansReference("REF-987");
        entity.getInvoiceInformationEntity().setBankName("MyBank");
        entity.getInvoiceInformationEntity().setAmount(BigDecimal.valueOf(100.00));
        entity.getInvoiceInformationEntity().setSchedule("QUARTER");
        entity.getInvoiceInformationEntity().setFinancialSecurityMeans("BOND");
        entity.getInvoiceInformationEntity().setRiskLevelColor("RED");
        entity.getInvoiceInformationEntity().setValidityStartDatetime(Instant.parse("2023-08-01T10:15:30.00Z"));
        entity.getInvoiceInformationEntity().setValidityEndDatetime(Instant.parse("2023-12-31T23:59:59.00Z"));
        entity.getInvoiceInformationEntity().setDepositPaymentFlag(true);
        entity.getInvoiceInformationEntity().setSecurityAmount(BigDecimal.valueOf(5000.00));
        entity.getInvoiceInformationEntity().setSecurityCeiling(BigDecimal.valueOf(20000.00));
        entity.getInvoiceInformationEntity().setAddressFacturation(new AddressEntity());
        entity.getInvoiceInformationEntity().getAddressFacturation().setName1("John Doe");
        entity.getInvoiceInformationEntity().getAddressFacturation().setAdd2("Street 12");
        result = contractOpencellMapper.contractVersionEntityToContractOpencell(entity);

    }

    @Test
    void testContractInformationToContractOpencell_baseMapping() {

        assertEquals("C123", result.getContractInformation().getContractNumber());
        assertEquals("TypeA", result.getContractInformation().getType());
        assertEquals("SubTypeA", result.getContractInformation().getSubType());
        assertEquals("2023-07-05T12:15:30+02:00", result.getContractInformation().getEffectiveDateTime());
        assertEquals("AUTO", result.getContractInformation().getRenewalMode());
        assertEquals("2023-07-06T12:15:30+02:00", result.getContractInformation().getSignatureDateTime());
        assertEquals("RefABC", result.getContractInformation().getCustContractualAgreementReference());
        assertEquals("Online", result.getContractInformation().getCreationChannel());
        assertEquals("No comments", result.getContractInformation().getComments());
    }

    @Test
    void testContractVersionToContractOpencell_baseMapping() {
        assertEquals("2023-08-01T12:15:30+02:00", result.getContractVersionInformation().getValidityStartDateTime());
        assertEquals("2024-01-01T00:59:59+01:00", result.getContractVersionInformation().getValidityEndDateTime());
        assertEquals(2, result.getContractVersionInformation().getVersionNumber());
        assertEquals(1, result.getContractVersionInformation().getAmendmentNumber());
        assertEquals("Valide", result.getContractVersionInformation().getStatus());
        assertEquals("Signé", result.getContractVersionInformation().getSubStatus());
        assertEquals("2024-01-01T11:00:00+01:00", result.getContractVersionInformation().getTerminationDateTime());
        assertEquals("CAT123", result.getContractVersionInformation().getCategory());
        assertEquals("ParentX", result.getContractVersionInformation().getParentContractNumber());
        assertEquals(99, result.getContractVersionInformation().getParentAmendmentNumber());
    }

    @Test
    void testInvoiceInformationToContractOpencell_baseMapping() {
        assertEquals("", result.getInvoiceInformation().getSellersector());
        assertEquals(12345, result.getInvoiceInformation().getAddressNumber());
        assertEquals("John Doe", result.getInvoiceInformation().getName1());
        assertEquals("Street 12", result.getInvoiceInformation().getAdd2());
        assertEquals("MODE12", result.getInvoiceInformation().getMode());
        assertEquals("PAPIER", result.getInvoiceInformation().getSendingSupportLabel());
        assertTrue(result.getInvoiceInformation().getDedicatedInvoiceFlag());
        assertFalse(result.getInvoiceInformation().getInArrearsInvoicingFlag());
        assertEquals("TVA", result.getInvoiceInformation().getType());
        assertEquals("980", result.getInvoiceInformation().getSector());
        assertEquals("12", result.getInvoiceInformation().getCustInvoiceTermId());

        assertEquals("VATZONE1", result.getInvoiceInformation().getVatInformation().getVATdepositZoneCode());
        assertFalse(result.getInvoiceInformation().getVatInformation().getVATliabilityFlag());

    }

    @Test
    void testOtherToContractOpencell_baseMapping() {
        assertEquals("RUMXYZ", result.getPaymentInformation().getRUM());
        assertEquals("CHEQUE", result.getPaymentInformation().getMeansLabel());
        assertEquals("MONTH", result.getPaymentInformation().getPeriodLabel());
        assertEquals("REF-987", result.getPaymentInformation().getMeansReference());
        assertEquals("MyBank", result.getPaymentInformation().getBankName());
        assertEquals(BigDecimal.valueOf(100.00).doubleValue(), result.getPaymentInformation().getAmount());
        assertEquals("QUARTER", result.getPaymentInformation().getScheduleLabel());

        assertEquals("BOND", result.getFinancialSecurityInformation().getFinancialSecurityMeans());
        assertEquals("RED", result.getFinancialSecurityInformation().getRiskLevelColor());
        assertEquals("2023-08-01T12:15:30+02:00", result.getFinancialSecurityInformation().getValidityStartDate());
        assertEquals("2024-01-01T00:59:59+01:00", result.getFinancialSecurityInformation().getValidityEndDate());
        assertTrue(result.getFinancialSecurityInformation().getDepositPaymentFlag());
        assertEquals(BigDecimal.valueOf(5000.00).doubleValue(), result.getFinancialSecurityInformation().getSecurityAmount());
        assertEquals(BigDecimal.valueOf(20000.00).doubleValue(), result.getFinancialSecurityInformation().getSecurityCeiling());
    }

    @Test
    void testMapStatus() {
        ContractStatusEnum input = ContractStatusEnum.VALIDE;
        String result = (String) contractOpencellMapper.mapStatus(input);
        assertEquals("Valide", result);
    }

    @Test
    void testMapSubStatus() {
        ContractSubStatusEnum input = ContractSubStatusEnum.SIGNE;
        String result = (String) contractOpencellMapper.mapSubStatus(input);
        assertEquals("Signé", result);
    }

    @Test
    void testAsStringAndAsInstant() {
        Instant instant = Instant.parse("2025-03-19T12:00:00.00Z");
        String result = contractOpencellMapper.asString(instant);
        assertEquals("2025-03-19T13:00:00+01:00", result);
        Instant parsed = contractOpencellMapper.asInstant(result);
        assertEquals(instant, parsed);
    }

}