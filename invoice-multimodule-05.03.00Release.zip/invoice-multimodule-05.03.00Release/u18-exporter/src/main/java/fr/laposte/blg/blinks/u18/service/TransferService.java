package fr.laposte.blg.blinks.u18.service;

public interface TransferService {
    void transferFiles(String exportDir, String transferDir, String archiveDir);
}
