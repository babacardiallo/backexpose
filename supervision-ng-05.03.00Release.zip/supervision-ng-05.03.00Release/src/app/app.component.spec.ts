import { TestBed, ComponentFixture, waitForAsync } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [AppComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA],
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  /** @Test: Component creation test */
  it(
    'should create the app',
    waitForAsync(() => {
      expect(component).toBeTruthy();
    })
  );

  /** @Test: Template precessing test */
  it(
    `should have as title mentionned in environment file`,
    waitForAsync(() => {
      const app = fixture.debugElement.componentInstance;
      expect(app.appName).toEqual(environment.appName);
    })
  );
});
