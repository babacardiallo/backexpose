package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.springframework.data.relational.core.mapping.Column;

import java.time.Instant;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class ContractSuperiorRevError {

    protected String id;

    @Column("id_contract")
    protected Long contractId;

    @Column("contract_number")
    @NotBlank
    private String contractNumber;

    @Column ("amendment_number")
    private Integer amendmentNumber;

    @Column ("revision_number")
    private Integer revisionNumber;

    @Column ("superior_revision_error")
    private Integer superiorRevisionNumber;

    @Column("offset_num")
    private String offsetError;

    @Column("partition_num")
    private String partitionError;

    @Column("error_message")
    private String errorMessage;

    @Column("status")
    protected String status;

    @Column("substatus")
    protected String substatus;

    @Column("type")
    protected String type;

    @Column("subtype")
    protected String subtype;

    @Column("ops_code")
    protected String opsCode;

    @Column("ops_label")
    protected String opsLabel;

    @Column("is_synchronized")
    protected Boolean isSynchronized;

    @Column("last_date_synchronization")
    protected Instant lastDateSynchronization;

    @Column("date_error")
    protected Instant dateError;

    @Column("first_error_date")
    protected Instant firstErrorDate;

    @Column("cust_acc_number")
    protected Integer custAccNumber;

    @Column("cust_acc_number_before_synchronisation")
    protected Integer custAccNumberBeforeSynchronisation;


}
