package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("export_history")
@Data
public class FileSequenceEntity {

    @Id
    @Column("sequence_name")
    String sequenceName = "EQUINOX_FILE_SEQ";

    @Column(value = "current_sequence")
    Long currentSequence;

    @Column(value = "last_updated")
    Instant lastUpdated;

}
