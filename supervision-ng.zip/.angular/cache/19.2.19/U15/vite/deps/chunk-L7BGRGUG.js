import {
  ExtendedModule
} from "./chunk-ZGITMXG6.js";
import {
  FlexModule
} from "./chunk-ZLQSVB4A.js";
import {
  GridModule
} from "./chunk-7PKUJ5B4.js";
import {
  BREAKPOINT,
  DEFAULT_CONFIG,
  LAYOUT_CONFIG,
  SERVER_TOKEN
} from "./chunk-MTU7EXM5.js";
import {
  isPlatformServer
} from "./chunk-ROQ5OQS3.js";
import {
  Inject,
  NgModule,
  PLATFORM_ID,
  Version,
  setClassMetadata,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵinject
} from "./chunk-S6ETTSTF.js";
import {
  __spreadValues
} from "./chunk-TXDUYLVM.js";

// node_modules/@ngbracket/ngx-layout/fesm2022/ngbracket-ngx-layout.mjs
var FlexLayoutModule = class _FlexLayoutModule {
  /**
   * Initialize the FlexLayoutModule with a set of config options,
   * which sets the corresponding tokens accordingly
   */
  static withConfig(configOptions, breakpoints = []) {
    return {
      ngModule: _FlexLayoutModule,
      providers: configOptions.serverLoaded ? [{
        provide: LAYOUT_CONFIG,
        useValue: __spreadValues(__spreadValues({}, DEFAULT_CONFIG), configOptions)
      }, {
        provide: BREAKPOINT,
        useValue: breakpoints,
        multi: true
      }, {
        provide: SERVER_TOKEN,
        useValue: true
      }] : [{
        provide: LAYOUT_CONFIG,
        useValue: __spreadValues(__spreadValues({}, DEFAULT_CONFIG), configOptions)
      }, {
        provide: BREAKPOINT,
        useValue: breakpoints,
        multi: true
      }]
    };
  }
  constructor(serverModuleLoaded, platformId) {
    if (isPlatformServer(platformId) && !serverModuleLoaded) {
      console.warn("Warning: Flex Layout loaded on the server without FlexLayoutServerModule");
    }
  }
  static {
    this.ɵfac = function FlexLayoutModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FlexLayoutModule)(ɵɵinject(SERVER_TOKEN), ɵɵinject(PLATFORM_ID));
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FlexLayoutModule,
      imports: [FlexModule, ExtendedModule, GridModule],
      exports: [FlexModule, ExtendedModule, GridModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FlexModule, ExtendedModule, GridModule, FlexModule, ExtendedModule, GridModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FlexLayoutModule, [{
    type: NgModule,
    args: [{
      imports: [FlexModule, ExtendedModule, GridModule],
      exports: [FlexModule, ExtendedModule, GridModule]
    }]
  }], () => [{
    type: void 0,
    decorators: [{
      type: Inject,
      args: [SERVER_TOKEN]
    }]
  }, {
    type: Object,
    decorators: [{
      type: Inject,
      args: [PLATFORM_ID]
    }]
  }], null);
})();
var VERSION = new Version("19.0.0");

export {
  FlexLayoutModule,
  VERSION
};
/*! Bundled license information:

@ngbracket/ngx-layout/fesm2022/ngbracket-ngx-layout.mjs:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   *)
*/
//# sourceMappingURL=chunk-L7BGRGUG.js.map
