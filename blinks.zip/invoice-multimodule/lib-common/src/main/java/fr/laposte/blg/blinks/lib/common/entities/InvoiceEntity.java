package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("invoice")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceEntity {

    @Id
    @Column("id_invoice")
    private Long idInvoice;

    @Column("invoice_number")
    private String invoiceNumber;

    @Column("reference_number")
    private String reference;

    @Column("billrun_id")
    private String billrunId;

    @Column("billrun_date")
    private Instant billrunDate;

    @Column("docaposte_export_id")
    private Long docaposteExportId;

    @Column("infoca_export_id")
    private Long infocaExportId;

    @Column("equinox_export_id")
    private Long equinoxExportId;

    @Column("created")
    private Instant created;

    @Column("updated")
    private Instant updated;

    @Column("client")
    private Integer client;

    @Column("docaposte_export_status")
    private InvoiceStatusEnum docaposteExportStatus;

    @Column("infoca_export_status")
    private InvoiceStatusEnum infocaExportStatus;

    @Column("equinox_export_status")
    private InvoiceStatusEnum equinoxExportStatus;

    @Column("docaposte_error_message")
    private String docaposteErrorMessage;

    @Column("docaposte_error_code")
    private String docaposteErrorCode;

    @Column("infoca_error_message")
    private String infocaErrorMessage;

    @Column("infoca_error_code")
    private String infocaErrorCode;

    @Column("equinox_error_message")
    private String equinoxErrorMessage;

    @Column("equinox_error_code")
    private String equinoxErrorCode;

}
