package fr.laposte.blg.blinks.u14.controller.dto;

public class ElectionKibanaCst {
    public static final String SEQUENCE = "sequenceFichierElection";
    public static final String COCLICO =  "coclicoElection";
    public static final String MARKET_NUMBER = "marketNumberElection";
    public static final String CONTRACT_NUMBER =  "contractNumberElection";
    public static final String MODE = "actionElection";
    public static final String ERROR = "errorMessageElection";
    public static final String CLEFS = "clefs";
}
