package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.EstablishmentEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface EstablishmentRepository extends ReactiveCrudRepository<EstablishmentEntity, Long> {

    Mono<EstablishmentEntity> findByRegateCode(String regateCode);
}
