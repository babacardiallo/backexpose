package fr.laposte.blg.blinks.u10.repositories;

import fr.laposte.blg.blinks.u10.entities.RejetContract;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Repository
public interface RejetContractBaseRepository extends JpaRepository<RejetContract, UUID> {


    @Query("SELECT DISTINCT rjt.errorCode FROM RejetContract rjt ORDER BY rjt.errorCode asc")
    List<String> getAllCodeErrors();

    @Modifying
    @Transactional
    @Query("""
            UPDATE RejetContract rjc SET rjc.status='PENDING' WHERE
             (rjc.errorDate BETWEEN :startDate AND :endDate)
             AND (rjc.status = 'FAILED')""")
    int updateFilteredRejetContracts(@Param("startDate") Instant startDate, @Param("endDate")Instant endDate);

    @Query("""
            SELECT rjc FROM RejetContract rjc WHERE
             (rjc.errorDate BETWEEN :startDate AND :endDate)
             AND (rjc.status IN ('PENDING','FAILED'))
             ORDER BY rjc.errorDate desc""")
    List<RejetContract> exportRejetContracts(@Param("startDate") Instant startDate, @Param("endDate")Instant endDate);

}
