ALTER TABLE legal_person
    ADD COLUMN business_team_id INT,
    ADD COLUMN business_team_long_name varchar(255);

ALTER TABLE queue_synchronization_after_error
    ADD COLUMN refcom_replay tinyint not null default 0;