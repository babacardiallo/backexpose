package fr.laposte.blg.blinks.u14.service.producer;

import fr.laposte.blg.blinks.u14.service.ContractOfferBuilderService;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;

import java.util.Properties;

@Slf4j
@Service
@Profile("mar-srec|mar-sdev|sloc")
public class KafkaTestContractProducer {

    private final ContractOfferBuilderService contractOfferBuilderService;
    @Value("${fr.laposte.topic.contract_test}")
    String topic;
    @Resource(name = "kafkaConfig")
    Properties kafkaConfig;
    private KafkaSender<String, gkContractFullOutV1> contractSender;

    public KafkaTestContractProducer(ContractOfferBuilderService contractOfferBuilderService) {
        this.contractOfferBuilderService = contractOfferBuilderService;
    }

    @PostConstruct
    void init() {
        SenderOptions<String, gkContractFullOutV1> senderOptions = SenderOptions.create(kafkaConfig);
        contractSender = KafkaSender.create(senderOptions);
    }

    public Mono<Void> sendContractToTopic(gkContractFullOutV1 contract) {
        return contractSender.send(Mono.just(contract)
                .map(contractOfferBuilderService::buildContract)
                .map(message -> SenderRecord.create(new ProducerRecord<>(topic, message.getContract().getContractInformation().getContractNumber().toString(), message), message)))
            .doOnNext(message -> log.info("contract published in {}: {}", topic, contract))
                .doOnError(error ->log.error("eeror: {}", error.getMessage()))
            .then();
    }
}