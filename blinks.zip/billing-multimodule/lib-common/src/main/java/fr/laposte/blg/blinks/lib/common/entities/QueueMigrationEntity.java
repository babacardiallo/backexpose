package fr.laposte.blg.blinks.lib.common.entities;


import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("queue_migration_by_offer")
@Data
@Accessors(chain = true)
@Builder
public class QueueMigrationEntity {

    @Id
    @Column("id_queue")
    private Long idQueue;
    @Column("id_contract")
    private Long idContract;
    @Column("date_synchronization_expected")
    private Instant dateSynchronizationExpected;
    @Column("action")
    private ActionEnum action;
    @Column("offer_ops_code")
    private String offerOpsCode;

}
