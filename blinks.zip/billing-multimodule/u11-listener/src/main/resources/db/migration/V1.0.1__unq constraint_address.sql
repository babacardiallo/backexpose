ALTER TABLE blg_contract_importer.address
ADD CONSTRAINT unq_address UNIQUE (address_id_refpm);