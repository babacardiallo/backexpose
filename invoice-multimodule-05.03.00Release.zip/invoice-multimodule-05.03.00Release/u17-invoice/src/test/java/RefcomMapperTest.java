import fr.laposte.blg.blinks.u17.dto.MoulinetteRefcomDto;
import fr.laposte.blg.blinks.u17.dto.RefcomDto;
import fr.laposte.blg.blinks.u17.mapper.RefcomMapper;
import fr.laposte.blg.blinks.u17.mapper.RefcomMapperImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {RefcomMapper.class, RefcomMapperImpl.class})
class RefcomMapperTest {

    @Autowired
    private RefcomMapper refcomMapper;

    @Test
    void refcomDtoToMoulinetteRefcomDtoTest(){
        RefcomDto refcomDto = new RefcomDto();
        refcomDto.setCoclico("1");
        refcomDto.setEcId("ec1");
        refcomDto.setTtId("ttId");
        refcomDto.setEntityCode("1");
        refcomDto.setConsultationDate("2025-05-02");
        MoulinetteRefcomDto moulinetteRefcomDto =  refcomMapper.RefcomDtoToMoulinetteRefcomDto(refcomDto);
        Assertions.assertNotNull(moulinetteRefcomDto);
        Assertions.assertEquals("1", moulinetteRefcomDto.getCoclico());
        Assertions.assertEquals("1", moulinetteRefcomDto.getEntityCode());
    }
}
