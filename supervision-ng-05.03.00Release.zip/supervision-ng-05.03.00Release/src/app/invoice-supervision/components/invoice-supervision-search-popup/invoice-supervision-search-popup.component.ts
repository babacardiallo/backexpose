import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";

@Component({
    selector: 'invoice-supervision-search-popup',
    templateUrl: './invoice-supervision-search-popup.component.html',
    styleUrls: ['./invoice-supervision-search-popup.component.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: false
})

export class InvoiceSupervisionSearchPopupComponent  implements OnInit {

    content: any;

    public invoicesSaisies = '';

    constructor( private snackBar: MatSnackBar, private modalService: ModalService) {
    }

    ngOnInit() {
        
    }
    launch(){
        if(this.invoicesSaisies.trim()!=''){
            const invoiceNumbers = this.invoicesSaisies.trim().split("\n");
            this.modalService.close(invoiceNumbers);
        }
   }

   close(){
    this.modalService.close();
   }

  
}
