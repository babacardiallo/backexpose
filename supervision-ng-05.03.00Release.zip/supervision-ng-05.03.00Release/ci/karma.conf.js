module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-coverage'),
      require('karma-chrome-launcher'),
      require('karma-sonarqube-unit-reporter'),
      require('@angular-devkit/build-angular/plugins/karma'),
    ],
    client: {
      clearContext: false,
    },
    mime: {
      'text/x-typescript': ['ts', 'tsx'],
    },
    coverageReporter: {
      dir: './reports/tests',
      reporters: [{ type: 'lcovonly', subdir: './' }, { type: 'text-summary' }],
    },
    sonarQubeUnitReporter: {
      outputFile: 'reports/tests/results.xml',
      sonarQubeVersion: 'LATEST',
      useBrowserName: false,
      testFilePattern: '.spec.ts',
      overrideTestDescription: true,
    },
    reporters: ['sonarqubeUnit', 'coverage', 'progress'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_ERROR,
    browsers: ['ChromeHeadlessNS'],
    customLaunchers: {
      ChromeHeadlessNS: {
        base: 'ChromeHeadless',
        flags: ['--no-sandbox'],
      },
    }
  });
};
