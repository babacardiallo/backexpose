package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ErrorLogRepository;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Objects;

@Service
@Data
@Slf4j
@RequiredArgsConstructor //Génère le contructeur avec tous les arguments nécessaires, du coup les injections
public class ErrorLogService {

    private final ErrorLogRepository errorLogRepository;

    public Mono<ErrorLogEntity> logError(ErrorLogEntity errorLogEntity) {
        log.error(Markers.appendFields(errorLogEntity), errorLogEntity.getErrorMessage());
        return errorLogRepository.save(errorLogEntity);
    }


    public Mono<ErrorLogEntity> logErrorContract(ContractVersionEntity contractVersionEntity, String errorMessage, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, gkContractFullOutV1 contractFromOdc){
        assert (Objects.nonNull(contractVersionEntity.getContract()));
        ErrorLogEntity.ErrorLogEntityBuilder errorLogEntityBuilder = ErrorLogEntity.builder();
        ErrorLogEntity errorLogEntity = errorLogEntityBuilder
            .amendmentNumber(contractVersionEntity.getAmendmentNumber())
            .contractNumber(contractVersionEntity.getContract().getContractNumber())
            .status(contractVersionEntity.getStatus())
            .substatus(contractVersionEntity.getSubstatus())
            .revisionNumber(contractVersionEntity.getRevisionNumber())
            .workflowStep(workflowStepEnum)
            .errorMessage(errorMessage)
            .dateError(Instant.now())
            .offset(contractVersionEntity.getOffset())
            .partition(contractVersionEntity.getPartition())
            .contractOdcJson(contractFromOdc.toString())
            .opsCode(contractVersionEntity.getValuedOffer().getOpsCode())
            .build();
        log.error(Markers.appendFields(errorLogEntity), errorLogEntity.getErrorMessage());
        return errorLogRepository.save(errorLogEntity);
    }

    public Mono<ErrorLogEntity> logErrorCustomer(Long idLegalPerson, Long coclico, String errorMessage, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, CodeErrorEnum codeError) {
        return logErrorCustomer(idLegalPerson, null, coclico, errorMessage, workflowStepEnum, codeError);
    }

    public Mono<ErrorLogEntity> logErrorCustomer(Long idLegalPerson, String contractNumber, Long coclico, String errorMessage, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum,  CodeErrorEnum codeError) {

        ErrorLogEntity.ErrorLogEntityBuilder errorLogEntityBuilder = ErrorLogEntity.builder();
        ErrorLogEntity errorLogEntity = errorLogEntityBuilder
            .idLegalPerson(idLegalPerson)
            .contractNumber(contractNumber)
            .custAccNumber(coclico)
            .workflowStep(workflowStepEnum)
            .errorMessage(errorMessage)
            .dateError(Instant.now())
            .codeError(codeError)
            .build();
        log.error(Markers.appendFields(errorLogEntity), errorLogEntity.getErrorMessage());
        return errorLogRepository.save(errorLogEntity);
    }

    public Mono<Void> purgeErrorLogForOneContractVersion(String contractNumber, int amendmentNumber, int revisionNumber) {
        return errorLogRepository.deleteByContractNumberAndAmendmentNumberAndRevisionNumberLessThanEqual(contractNumber
            , amendmentNumber, revisionNumber);
    }

    public Mono<Void> purgeErrorLogForOneContractVersion(ContractVersionEntity contractVersionEntity) {
        return this.purgeErrorLogForOneContractVersion(contractVersionEntity.getContract().getContractNumber()
            , contractVersionEntity.getAmendmentNumber(), contractVersionEntity.getRevisionNumber());
    }

    public Mono<Void> purgeErrorLogForOneLegalPerson(Long idLegalPerson) {
        return errorLogRepository.deleteByIdLegalPerson(idLegalPerson);
    }

    public Mono<Void> purgeErrorLogForOneLegalPersonByCoclico(Long coclico, ErrorLogEntity.ErrorWorkflowStepEnum workflow) {
        return errorLogRepository.deleteByCustAccNumberAndWorkflowStepEquals(coclico, workflow);
    }

    public Mono<Void> purgeErrorOfSchedulerForOneContract(Long idContract) {
        return errorLogRepository.deleteByIdContractAndWorkflowStepEquals(idContract, ErrorLogEntity.ErrorWorkflowStepEnum.SCHEDULER);
    }

    public Mono<ErrorLogEntity> findErrorEntityForThisContractVersion(String contractNumber, int amendmentNumber) {
        return errorLogRepository.findByContractNumberAndAmendmentNumberSynchro(contractNumber, amendmentNumber);
    }

    public Mono<Integer> removeAllLessRevisions(String contractNumber, int amendmentNumber, int revisionNumber) {
        log.info("Suppression des erreurs de révision inférieur ou égale du contractVersion contactNumber: {}, amendmentNumber: {}, revision: {}", contractNumber, amendmentNumber, revisionNumber
        );
        return  errorLogRepository.removeAllLessRevisions(contractNumber, amendmentNumber, revisionNumber);
    }

}
