package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonMessage;
import fr.laposte.blg.blinks.lib.common.entities.repositories.AddressRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LegalPersonMessageRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LegalPersonRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class LegalPersonServiceTest {

    @InjectMocks
    LegalPersonService legalPersonService;

    @Mock
    AddressRepository addressRepository;

    @Mock
    LegalPersonMessageRepository legalPersonMessageRepository;

    @Mock
    LegalPersonRepository legalPersonRepository;

    @Test
    void findLegalPersonByIdLegalPerson_LoadingAdresses() {

        Mockito.when(legalPersonRepository.findById(Mockito.anyLong())).thenReturn(Mono.just(
            new LegalPersonEntity()
                .setIdLegalPerson(1L)
        ));

        Mockito.when(addressRepository.findByIdLegalPerson(Mockito.eq(1L)))
            .thenReturn(
                Flux.just(new AddressEntity().setIdAddress(1L))
            );
        StepVerifier.create(legalPersonService.findLegalPersonByIdLegalPerson(1L, true))
            .assertNext(legalPersonEntity -> {
                assertEquals(legalPersonEntity.getIdLegalPerson(), 1L);
                assertEquals(legalPersonEntity.getAddressEntityList().get(0).getIdAddress(), 1L);
//                assertEquals(legalPersonEntity.getAddressEntityList().get(0).getIdAddress(), Arrays.asList(new AddressEntity().setIdAddress(1L).setLegalPersonEntity(legalPersonEntity)));
            })
            .verifyComplete();

    }

    @Test
    void findLegalPersonByIdLegalPerson_notLoadingAdresses() {

        Mockito.when(legalPersonRepository.findById(Mockito.anyLong())).thenReturn(Mono.just(
            new LegalPersonEntity()
                .setIdLegalPerson(1L)
        ));

        StepVerifier.create(legalPersonService.findLegalPersonByIdLegalPerson(1L, false))
            .assertNext(legalPersonEntity -> {
                assertEquals(legalPersonEntity.getIdLegalPerson(), 1L);
                assertNull(legalPersonEntity.getAddressEntityList());
            })
            .verifyComplete();

        verify(this.addressRepository, times(0)).findByIdLegalPerson(anyLong());
    }

    @Test
    void findLegalPersonByCoclico_loadingAddresses() {

        Mockito.when(legalPersonRepository.findByCustAccNumber(Mockito.anyInt())).thenReturn(Mono.just(
            new LegalPersonEntity()
                .setIdLegalPerson(1L)
                .setCustAccNumber(1)
        ));

        Mockito.when(addressRepository.findByIdLegalPerson(Mockito.eq(1L)))
            .thenReturn(
                Flux.just(new AddressEntity().setIdAddress(1L))
            );
        StepVerifier.create(legalPersonService.findLegalPersonByCoclico(1, true))
            .assertNext(legalPersonEntity -> {
                assertEquals(legalPersonEntity.getIdLegalPerson(), 1L);
                assertEquals(legalPersonEntity.getAddressEntityList().get(0).getIdAddress(), 1L);
//                assertEquals(legalPersonEntity.getAddressEntityList().get(0).getIdAddress(), Arrays.asList(new AddressEntity().setIdAddress(1L).setLegalPersonEntity(legalPersonEntity)));
            })
            .verifyComplete();
    }

    @Test
    void findLegalPersonByCoclico_notLoadingAddresses() {

        Mockito.when(legalPersonRepository.findByCustAccNumber(Mockito.anyInt())).thenReturn(Mono.just(
            new LegalPersonEntity()
                .setIdLegalPerson(1L)
                .setCustAccNumber(1)
        ));

        Mockito.when(addressRepository.findByIdLegalPerson(Mockito.eq(1L)))
            .thenReturn(
                Flux.just(new AddressEntity().setIdAddress(1L))
            );

        StepVerifier.create(legalPersonService.findLegalPersonByCoclico(1, true))
            .assertNext(legalPersonEntity -> {
                assertEquals(legalPersonEntity.getIdLegalPerson(), 1L);
                assertEquals(legalPersonEntity.getAddressEntityList().get(0).getIdAddress(), 1L);
//                assertEquals(legalPersonEntity.getAddressEntityList().get(0).getIdAddress(), Arrays.asList(new AddressEntity().setIdAddress(1L).setLegalPersonEntity(legalPersonEntity)));
            })
            .verifyComplete();

    }

    @Test
    void save_withoutSavingAddresses() {
        var legalPersonToSave = new LegalPersonEntity()
            .setIdLegalPerson(1L)
            .setCustAccNumber(1);
        Mockito.when(legalPersonRepository.save(any(LegalPersonEntity.class)))
            .thenReturn(Mono.just(legalPersonToSave));

        StepVerifier.create(legalPersonService.save(legalPersonToSave, false))
            .assertNext(legalPersonEntity -> assertEquals(legalPersonEntity.getIdLegalPerson(), legalPersonToSave.getIdLegalPerson()))
            .verifyComplete();

        verify(this.addressRepository, times(0)).save(any(AddressEntity.class));

    }

    @Test
    void save_savingAddresses() {
        var legalPersonToSave = new LegalPersonEntity()
            .setIdLegalPerson(1L)
            .setCustAccNumber(1)
            .setAddressEntityList(
                Arrays.asList(
                    new AddressEntity().setIdAddress(1L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.PRESTATION)
                        .setAddressIdRefPM("REF"),
                    new AddressEntity().setIdAddress(2L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.FACTURATION)
                        .setAddressIdRefPM("REF"),
                    new AddressEntity().setIdAddress(3L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.PRINCIPALE)
                        .setAddressIdRefPM("REF")
                )
            );
        Mockito.when(legalPersonRepository.save(any(LegalPersonEntity.class)))
            .thenReturn(Mono.just(legalPersonToSave)); //address
        Mockito.when(addressRepository.save(any(AddressEntity.class)))
            .thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));

        Mockito.when(addressRepository.findByAddressIdRefPM(Mockito.anyString()))
                .thenReturn(Mono.empty());

        StepVerifier.create(legalPersonService.save(legalPersonToSave, true))
            .assertNext(legalPersonEntity -> {

                assertEquals(legalPersonEntity.getIdLegalPerson(), legalPersonToSave.getIdLegalPerson());
                assertIterableEquals(legalPersonEntity.getAddressEntityList(), Arrays.asList(
                    new AddressEntity().setIdAddress(1L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.PRESTATION)
                        .setAddressIdRefPM("REF")
                        .setLegalPersonEntity(legalPersonEntity),
                    new AddressEntity().setIdAddress(2L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.FACTURATION)
                        .setAddressIdRefPM("REF")
                        .setLegalPersonEntity(legalPersonEntity),
                    new AddressEntity().setIdAddress(3L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.PRINCIPALE)
                        .setAddressIdRefPM("REF")
                        .setLegalPersonEntity(legalPersonEntity)
                ));
            })
            .verifyComplete();

    }

    @Test
    void saveLegalPersonMessage(){
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(1L);
        Mockito.when(legalPersonMessageRepository.findByIdLegalPerson(anyLong())).thenReturn(Mono.just(new LegalPersonMessage(1L,1L, "{}" )));
        Mockito.when(legalPersonMessageRepository.save(any(LegalPersonMessage.class))).thenReturn(Mono.just(new LegalPersonMessage(1L,1L, "{}" )));
        StepVerifier.create(legalPersonService.saveLegalPersonMessage(legalPersonEntity,new LegalPersonMessage(1L,1L, "{}" )))
                .assertNext(legalPersonEntity1-> assertEquals(legalPersonEntity1.getIdLegalPerson(), 1L))
                .verifyComplete();
    }

    @Test
    void markLegalPersonSynchronized(){
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(1L);
        legalPersonEntity.setCustAccNumber(1);
        legalPersonEntity.setSynchronized(false);
        Mockito.when(legalPersonRepository.save(any(LegalPersonEntity.class))).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));
        Mockito.when(legalPersonRepository.findByCustAccNumber(Mockito.anyInt()))
                .thenReturn(Mono.just(legalPersonEntity));
        StepVerifier.create(legalPersonService.markLegalPersonSynchronized("1"))
                .assertNext(legalPersonEntity1-> assertTrue(legalPersonEntity1.isSynchronized()))
                .verifyComplete();
    }

    @Test
    void findMainAddressTest(){
        Mockito.when(addressRepository.findByAddressIdRefPM(Mockito.anyString())).thenReturn(Mono.just(new AddressEntity().setIdAddress(1L)
                .setIdLegalPerson(1L)
                .setAddressType(AddressType.PRESTATION)
                .setAddressIdRefPM("REF")));
        StepVerifier.create(legalPersonService.findMainAddress("REF"))
                .assertNext(addressEntity-> assertEquals(addressEntity.getAddressIdRefPM(), "REF"))
                .verifyComplete();
    }
    @Test
    void saveMainAddressTest(){
        Mockito.when(addressRepository.save(Mockito.any(AddressEntity.class))).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));
        StepVerifier.create(legalPersonService.saveMainAddress(new AddressEntity().setIdAddress(1L)
                        .setIdLegalPerson(1L)
                        .setAddressType(AddressType.PRESTATION)
                        .setAddressIdRefPM("REF")))
                .assertNext(addressEntity-> assertEquals(1L,addressEntity.getIdAddress()))
                .verifyComplete();
    }

    @Test
    void findAllClientsAlreadySynchronizedTest(){
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(1L);
        legalPersonEntity.setCustAccNumber(1);
        legalPersonEntity.setSynchronized(false);
        Mockito.when(legalPersonRepository.findAllByIsSynchronizedTrue()).thenReturn(Flux.just(legalPersonEntity));
        StepVerifier.create(legalPersonService.findAllClientsAlreadySynchronized())
                .assertNext(legalPersonEntity1-> assertEquals(1L,legalPersonEntity1.getIdLegalPerson()))
                .verifyComplete();
    }

    @Test
    void findAllClientsTest(){
        LegalPersonEntity legalPersonEntity = new LegalPersonEntity();
        legalPersonEntity.setIdLegalPerson(1L);
        legalPersonEntity.setCustAccNumber(1);
        legalPersonEntity.setSynchronized(false);
        Mockito.when(legalPersonRepository.findAllBy()).thenReturn(Flux.just(legalPersonEntity));
        StepVerifier.create(legalPersonService.findAllClients())
                .assertNext(legalPersonEntity1-> assertEquals(1L,legalPersonEntity1.getIdLegalPerson()))
                .verifyComplete();
    }
}