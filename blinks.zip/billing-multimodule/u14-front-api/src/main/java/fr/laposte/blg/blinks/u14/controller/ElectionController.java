package fr.laposte.blg.blinks.u14.controller;


import fr.laposte.blg.blinks.u14.service.ElectionService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.concurrent.atomic.AtomicBoolean;

@RestController
@RequestMapping("/api/election")
@OpenAPIDefinition(tags = {@Tag(name = "Election injection de contrats")}, info = @Info(description = "permet de déclencher l'injection des contrats pour les éelections"))
@CrossOrigin
@Data
@RequiredArgsConstructor
public class ElectionController {

    private final ElectionService electionService;

    private AtomicBoolean isRunning = new AtomicBoolean(false);

    @PostMapping(value = "/injection/contract")
    @Operation(
            summary = "Election injection de contrats",
            description = "Service permettant d'injecter les contrats pour les élections")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> runContractInjection(@RequestParam String fileName) {
        if (!isRunning.get()) {
            isRunning.set(true);
            Mono.fromRunnable(() -> electionService.process(fileName))
                    .subscribeOn(Schedulers.boundedElastic())
                    .doOnTerminate(() -> isRunning.set(false))
                    .subscribe();
            return ResponseEntity.accepted().body("Le traitement du fichier a démarré !");
        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Un fichier est en cours de traitement, veuillez patientez ... ");
        }
    }

}
