package fr.laposte.blg.blinks.u17.util;

import java.util.ArrayList;
import java.util.List;

public class StringExportUtils {

    public static String[] replaceNewLineChar(String[] values){
        List<String> finalList = new ArrayList<>();
        for(String value : values) {
            if(value !=null){
                finalList.add(value.replaceAll("\\n|\\r", " "));
            } else {
                finalList.add(value);
            }
        }
        String[] result = finalList.toArray(String[]::new);
        return result;
    }

    public static List<String[]> replaceNewLineChar(List<String[]> values){
        List<String[]> finalList = new ArrayList<>();
        for(String[] value : values) {
            finalList.add(replaceNewLineChar(value));
        }
        return finalList;

    }
}
