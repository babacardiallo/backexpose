package fr.laposte.blg.blinks.u18.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.u18.service.MessagePurgeService;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Slf4j
public class DataPurgeScheduler implements Runnable {

    private final MessagePurgeService purgeService;
    private final SchedulerParamsEntity schedulerParams;

    public DataPurgeScheduler(MessagePurgeService purgeService, SchedulerParamsEntity schedulerParams) {
        this.purgeService = purgeService;
        this.schedulerParams = schedulerParams;
    }

    @Override
    public void run() {
        log.info("Starting TransferScheduler job for scheduler: {}", schedulerParams.getSchedulerName());

        int retentionDays = schedulerParams.getRetentionDays();
        Instant threshold = Instant.now().minus(retentionDays, ChronoUnit.DAYS);
        log.info("Starting data purge for messages older than {}", threshold);

        int deletedCount = purgeService.purgeMessagesOlderThan(threshold);
        log.info("Data purge completed. {} messages deleted.", deletedCount);
    }
}
