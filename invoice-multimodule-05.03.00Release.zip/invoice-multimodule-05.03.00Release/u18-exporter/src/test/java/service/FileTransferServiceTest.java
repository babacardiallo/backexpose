package service;


import fr.laposte.blg.blinks.u18.service.impl.FileTransferServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FileTransferServiceTest {


    @TempDir
    Path tempDir;
    Path exportDir;
    Path cftDir;
    Path archiveDir;
    @InjectMocks
    private FileTransferServiceImpl fileTransferService;

    @BeforeEach
    void setUpDirectories() throws IOException {
        exportDir = tempDir.resolve("export");
        cftDir = tempDir.resolve("cft");
        archiveDir = tempDir.resolve("archive");
        Files.createDirectories(exportDir);
        Files.createDirectories(cftDir);
        Files.createDirectories(archiveDir);
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(exportDir);
             DirectoryStream<Path> stream1 = Files.newDirectoryStream(archiveDir);
             DirectoryStream<Path> stream2 = Files.newDirectoryStream(cftDir)) {
            for (Path file : stream) {
                try {
                    Files.delete(file);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            for (Path file : stream1) {
                try {
                    Files.delete(file);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            for (Path file : stream2) {
                try {
                    Files.delete(file);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    @Test
    void testTransferSuccess() throws Exception {
        String fileName = "testfile.txt";
        Path exportFile = exportDir.resolve(fileName);
        Files.write(exportFile, "dummy content".getBytes());
        fileTransferService.transferFiles(exportDir.toString(), cftDir.toString(), archiveDir.toString());
        try (Stream<Path> files = Files.list(exportDir);
             Stream<Path> archives = Files.list(archiveDir);
             Stream<Path> transfers = Files.list(cftDir)) {
            assertEquals(0L, files.count());
            assertEquals(1L, archives.count());
            assertEquals(1L, transfers.count());
        }
    }

    @Test
    void testTransferFailCauseFileAlreadyExists() throws Exception {
        String fileName = "testfile.txt";
        Path exportFile = exportDir.resolve(fileName);
        Path transferFile = cftDir.resolve(fileName);
        Files.write(exportFile, "dummy content".getBytes());
        Files.write(transferFile, "dummy content".getBytes());
        fileTransferService.transferFiles(exportDir.toString(), cftDir.toString(), archiveDir.toString());
        try (Stream<Path> files = Files.list(exportDir);
             Stream<Path> archives = Files.list(archiveDir);
             Stream<Path> transfers = Files.list(cftDir)) {
            assertEquals(1L, files.count());
            assertEquals(0L, archives.count());
            assertEquals(1L, transfers.count());
        }
    }
}
