package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.InvoiceSupervision;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Repository
public interface InvoiceSupervisionRepository extends ReactiveCrudRepository<InvoiceSupervision, Long> {
    Flux<InvoiceSupervision> findAllByInvoiceNumber(@Param("pageable") Pageable pageable, @Param("invoiceNumber") String invoiceNumber);
    Mono<Long> countAllByInvoiceNumber(@Param("invoiceNumber") String invoiceNumber);
    Flux<InvoiceSupervision> findAllByInvoiceNumberIn(@Param("pageable")Pageable pageable, @Param("invoiceNumbers") List<String> invoiceNumbers);
    Mono<Long> countAllByInvoiceNumberIn(@Param("invoiceNumbers") List<String> invoiceNumbers);
}
