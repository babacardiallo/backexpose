CREATE INDEX idx_id_legal_person on error_log (id_legal_person);
CREATE OR REPLACE VIEW customer_supervision AS
SELECT CONCAT(lp.cust_acc_number,
                              lp.id_legal_person) as `id`,
       CAST(lp.cust_acc_number as CHAR(50))       as cust_acc_number,
       lp.id_legal_person,
       CAST(lp.type_code as CHAR(50))             as type,
       lp.marketing_type_code                     as market_type,
       lp.comp_name                               as name,
       lp.brand_name                              as brand,
       lp.is_synchronized                         as is_synchro,
       lp.date_synchronization                    as date_last_synchronization,
       MAX(`el`.`date_error`)                     as max_date_error

FROM legal_person lp
         LEFT JOIN error_log el on lp.id_legal_person = el.id_legal_person
GROUP BY lp.cust_acc_number, error_message;