package controller;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.u17.controller.SchedulerController;
import fr.laposte.blg.blinks.u17.service.SchedulerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SchedulerControllerTest {

    @Mock
    private SchedulerService schedulerService;

    private SchedulerController schedulerController;

    private SchedulerParamsEntity testScheduler;

    @BeforeEach
    void setUp() {
        schedulerController = new SchedulerController(schedulerService);

        testScheduler = new SchedulerParamsEntity();
        testScheduler.setId(1L);
        testScheduler.setSchedulerName("scheduler_transfer");
        testScheduler.setCronExpression("0 * * * * *");
        testScheduler.setIsEnabled(true);
        testScheduler.setExportPath("/export");
        testScheduler.setCftPath("/cft");
        testScheduler.setArchivePath("/archive");
    }

    @Test
    void testGetAllSchedulers() {
        
        when(schedulerService.getAllSchedulers()).thenReturn(Flux.just(testScheduler));

        
        Flux<SchedulerParamsEntity> result = schedulerController.getAllSchedulers();

        
        StepVerifier.create(result)
                .assertNext(scheduler -> {
                    assertEquals(1L, scheduler.getId());
                    assertEquals("scheduler_transfer", scheduler.getSchedulerName());
                })
                .verifyComplete();

        verify(schedulerService).getAllSchedulers();
    }

    @Test
    void testGetAllSchedulersEmpty() {
        
        when(schedulerService.getAllSchedulers()).thenReturn(Flux.empty());

        
        Flux<SchedulerParamsEntity> result = schedulerController.getAllSchedulers();

        
        StepVerifier.create(result)
                .verifyComplete();

        verify(schedulerService).getAllSchedulers();
    }

    @Test
    void testUpdateSchedulerParamsSuccess() {
        
        SchedulerParamsEntity updatedScheduler = new SchedulerParamsEntity();
        updatedScheduler.setCronExpression("0 0 * * * *");
        updatedScheduler.setIsEnabled(false);

        when(schedulerService.updateTask(eq(1L), any(SchedulerParamsEntity.class)))
                .thenReturn(Mono.just(testScheduler));

        
        Mono<ResponseEntity<SchedulerParamsEntity>> result =
                schedulerController.updateSchedulerParams(1L, updatedScheduler);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.OK, response.getStatusCode());
                    assertNotNull(response.getBody());
                    assertEquals(1L, response.getBody().getId());
                })
                .verifyComplete();

        verify(schedulerService).updateTask(eq(1L), any(SchedulerParamsEntity.class));
    }

    @Test
    void testUpdateSchedulerParamsNotFound() {
        
        SchedulerParamsEntity updatedScheduler = new SchedulerParamsEntity();
        when(schedulerService.updateTask(eq(999L), any(SchedulerParamsEntity.class)))
                .thenReturn(Mono.empty());

        
        Mono<ResponseEntity<SchedulerParamsEntity>> result =
                schedulerController.updateSchedulerParams(999L, updatedScheduler);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
                    assertNull(response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).updateTask(eq(999L), any(SchedulerParamsEntity.class));
    }

    @Test
    void testDisableSchedulerSuccess() {
        
        when(schedulerService.cancelTask(1L)).thenReturn(Mono.just(testScheduler));

        
        Mono<ResponseEntity<SchedulerParamsEntity>> result = schedulerController.disableScheduler(1L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.OK, response.getStatusCode());
                    assertNotNull(response.getBody());
                    assertEquals(1L, response.getBody().getId());
                })
                .verifyComplete();

        verify(schedulerService).cancelTask(1L);
    }

    @Test
    void testDisableSchedulerNotFound() {
        
        when(schedulerService.cancelTask(999L)).thenReturn(Mono.empty());

        
        Mono<ResponseEntity<SchedulerParamsEntity>> result = schedulerController.disableScheduler(999L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
                    assertNull(response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).cancelTask(999L);
    }

    @Test
    void testEnableSchedulerSuccess() {
        
        when(schedulerService.enableTask(1L)).thenReturn(Mono.just(testScheduler));

        
        Mono<ResponseEntity<SchedulerParamsEntity>> result = schedulerController.enableScheduler(1L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.OK, response.getStatusCode());
                    assertNotNull(response.getBody());
                    assertEquals(1L, response.getBody().getId());
                })
                .verifyComplete();

        verify(schedulerService).enableTask(1L);
    }

    @Test
    void testEnableSchedulerNotFound() {
        
        when(schedulerService.enableTask(999L)).thenReturn(Mono.empty());

        
        Mono<ResponseEntity<SchedulerParamsEntity>> result = schedulerController.enableScheduler(999L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
                    assertNull(response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).enableTask(999L);
    }

    @Test
    void testRunOnceSuccess() {
        
        when(schedulerService.runOnce(1L)).thenReturn(Mono.empty());

        
        Mono<ResponseEntity<String>> result = schedulerController.runOnce(1L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.OK, response.getStatusCode());
                    assertEquals("Scheduler will run once", response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).runOnce(1L);
    }

    @Test
    void testRunOnceWithError() {
        
        RuntimeException testException = new RuntimeException("Scheduler not found");
        when(schedulerService.runOnce(999L)).thenReturn(Mono.error(testException));

        
        Mono<ResponseEntity<String>> result = schedulerController.runOnce(999L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
                    assertEquals("Error: Scheduler not found", response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).runOnce(999L);
    }

    @Test
    void testOrganizeExistingArchivesSuccess() {
        
        when(schedulerService.organizeExistingArchives(1L)).thenReturn(Mono.just(5));

        
        Mono<ResponseEntity<String>> result = schedulerController.organizeExistingArchives(1L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.OK, response.getStatusCode());
                    assertEquals("Successfully organized 5 files", response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).organizeExistingArchives(1L);
    }

    @Test
    void testOrganizeExistingArchivesZeroFiles() {
        
        when(schedulerService.organizeExistingArchives(1L)).thenReturn(Mono.just(0));

        
        Mono<ResponseEntity<String>> result = schedulerController.organizeExistingArchives(1L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.OK, response.getStatusCode());
                    assertEquals("Successfully organized 0 files", response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).organizeExistingArchives(1L);
    }

    @Test
    void testOrganizeExistingArchivesWithError() {
        
        IllegalArgumentException testException = new IllegalArgumentException("Not a transfer scheduler");
        when(schedulerService.organizeExistingArchives(999L)).thenReturn(Mono.error(testException));

        
        Mono<ResponseEntity<String>> result = schedulerController.organizeExistingArchives(999L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
                    assertEquals("Error organizing archives: Not a transfer scheduler", response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).organizeExistingArchives(999L);
    }

    @Test
    void testOrganizeExistingArchivesWithGenericError() {
        
        RuntimeException testException = new RuntimeException("Database connection failed");
        when(schedulerService.organizeExistingArchives(1L)).thenReturn(Mono.error(testException));

        
        Mono<ResponseEntity<String>> result = schedulerController.organizeExistingArchives(1L);

        
        StepVerifier.create(result)
                .assertNext(response -> {
                    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
                    assertEquals("Error organizing archives: Database connection failed", response.getBody());
                })
                .verifyComplete();

        verify(schedulerService).organizeExistingArchives(1L);
    }
}
