import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ClientsDetailsPopUpComponent } from "../../../clients/components/clients-details-pop-up/clients-details-pop-up.component";
import { ClientsService } from "../../../clients/service/clients.service";
import { ContratsTable } from "../../models/contrats-table.model";
import { ContratsReplayerPopUpComponent } from "../contrats-replayer-pop-up/contrats-replayer-pop-up.component";
import { DatePipe } from "@angular/common";
import { ContratsTableService } from "../../service/contrats-table.service";
import { ContractDetails } from "../../models/contract-details.model";
import { ClientsTable } from "../../../clients/models/clients-table.model";
import { ContratsRevisionError } from "../../models/contrats-revision-error";
import { ModalService } from "ngx-modal-ease";

@Component({
    selector: 'contrats-details-pop-up-component',
    templateUrl: './contrats-details-pop-up.component.html',
    styleUrls: ['./contrats-details-pop-up.component.scss'],
    standalone: false
})

export class ContratsDetailsPopUpComponent  implements OnInit {

    contrat: any;
    statusBar = 0;
    isIntegre = false;
    isSynch = false;
    isOc = false;
    isRead = false;
    offerJson: JSON;
    clientInfo = "";
    client: ClientsTable;
    isContratOdcExpanded: boolean = false;
    isOfferExpanded: boolean = false;
    contratOdcExpandTitle = 'Tout déplier';
    offerExpandTitle = 'Tout déplier';
    isClientExist: boolean = false;
    contractDetails: ContractDetails;
    contractSupRevError: ContratsRevisionError;
    M1_MODAL_PROPERTIES = {
        animation: 'enter-going-down',
        duration: '0.1s',
        easing: 'ease-out',
        padding: '1rem',
        width: '1000px',
        height: '70%'
    };
    M2_MODAL_PROPERTIES = {
        animation: 'enter-going-down',
        duration: '0.1s',
        easing: 'ease-out',
        padding: '1rem',
        width: '1800px',
        height: '100%'
    };
      name = 'ContratsDetailsPopUpComponent';

    constructor(private modalService: ModalService,private clientService: ClientsService, private datePipe: DatePipe, private contratsTableService: ContratsTableService) {
    }

    async ngOnInit() {
        this.contractDetails = new ContractDetails();
        await this.getContractDetails(this.contrat.contractNumber, this.contrat.amendmentNumber);
        await this.contractStatus();
        await this.getContractSupRevError(this.contrat.contractNumber, this.contrat.amendmentNumber, this.contrat.revisionNumber);
        this.formatOffer();
        this.getCustomerBycoclico();
    }

    async contractStatus() {
        this.isRead = true;
        this.isIntegre = true;
        if (this.contrat.isSynchronized) {
            this.isSynch = true;
        }
    }

    async getContractDetails(contractNumber: string, amendmentNumber: number): Promise<any> {
        return new Promise((resolve) => {
            this.contratsTableService.getContractDetails(contractNumber, amendmentNumber).subscribe({
                next: (response: any) => {
                    this.contractDetails = <ContractDetails>{
                        errorMessage: response.errorMessage,
                        invoiceAddressNumber: response.invoiceAddressNumber,
                        dedicatedInvoiceFlag: response.dedicatedInvoiceFlag,
                        invoicePeriodicityLabel: response.invoicePeriodicityLabel,
                        sendingSupportLabel: response.sendingSupportLabel,
                        paymentMeans: response.paymentMeans,
                        rum: response.rum,
                        custPurchaseOrderNumber: response.custPurchaseOrderNumber,
                        contractingCustRef: response.contractingCustRef,
                        marketNumber: response.marketNumber,
                        contractConsolidatedJson: response.contractConsolidatedJson != null ? JSON.parse(response.contractConsolidatedJson) : null,
                        offsetConsolidated: response.offsetConsolidated,
                        partitionConsolidated: response.partitionConsolidated,
                        contractOdcJson: response.contractOdcJson != null ? JSON.parse(response.contractOdcJson) : null,
                        offsetOdc: response.offsetOdc,
                        partitionOdc: response.partitionOdc,
                        category: response.category
                    };
                },
                complete: () => {
                    resolve(true);
                },
            });
        });
    }

    async getContractSupRevError(contractNumber: string, amendementNumber: number, revisionNumber: number): Promise<any> {
        return new Promise((resolve) => {
            this.contratsTableService.getSuperiorRevErrorOneContract(contractNumber, amendementNumber, revisionNumber).subscribe({
                next: (response: any) => {
                    this.contractSupRevError = <ContratsRevisionError>{
                        contractNumber: response.contractNumber,
                        amendmentNumber: response.amendementNumber,
                        supRevisionNumber: response.revisionSupNumber,
                        supRevOdcMessage: response.odcSupMessage != null ? JSON.parse(response.odcSupMessage) : null,
                        errorMessage: response.errorSupMessage,
                        supErrorOffset: response.offset,
                        supErrorPartition: response.partition
                    };
                },
                complete: () => {
                    if (this.contractSupRevError.errorMessage != null) {
                        this.contrat.hasSuperiorRevError = true;
                        this.contrat.superiorRevError = this.contractSupRevError.supRevisionNumber;
                        this.contrat.supOffsetError = this.contractSupRevError.supErrorOffset;
                        this.contrat.supPartitionError = this.contractSupRevError.supErrorPartition;
                        this.contrat.superiorRevErrMessage = this.contractSupRevError.errorMessage;
                        this.contrat.superiorRevOdcMessage = this.contractSupRevError.supRevOdcMessage;
                    }
                    else {
                        this.contrat.hasSuperiorRevError = false;
                    }
                    resolve(true);
                },
            })
        })
    }

    dateSynchroError(contract: ContratsTable): string {
        if (contract.isSynchronized) {
            return `${this.formatDatePopup(contract.lastDateSynchronization)} - Aucune erreur`;
        } else if (!contract.isSynchronized) {
            if (contract.lastDateSynchronization !== null && contract.dateError === null) {
                return `${this.formatDatePopup(contract.lastDateSynchronization)} - Aucune erreur`;
            } else if (contract.lastDateSynchronization !== null && contract.dateError !== null) {
                return `${this.formatDatePopup(contract.lastDateSynchronization)} - ${this.formatDatePopup(contract.dateError)} - ${this.formatDatePopup(contract.firstErrorDate)}`;
            } else if (contract.lastDateSynchronization === null && contract.dateError !== null) {
                return `Jamais synchronisé - ${this.formatDatePopup(contract.dateError)} - ${this.formatDatePopup(contract.firstErrorDate)} `;
            } else {
                return "Jamais synchronisé - Aucune erreur";
            }
        }
        return "Impossible de récupérer les date de synchronisation ou d'erreur";
    }


    formatOffer() {
        if (this.contrat.odcContract &&
            this.contrat.odcContract.contract &&
            this.contrat.odcContract.contract.offer &&
            JSON.stringify(this.contrat.odcContract.contract.offer)) {
            try {
                this.offerJson = JSON.parse(JSON.stringify(this.contrat.odcContract.contract.offer));
            } catch (e) {
                console.error("Erreur en parsant la valued offer" + e);
            }
            delete this.contrat.odcContract.contract.offer;
        }
    }

    getRevisionLastSynchro(contractDetails: ContractDetails): number | string {
        const revision = contractDetails.contractConsolidatedJson?.contractVersionInformation?.versionNumber;
        if (revision != null) {
            return revision;
        }
        return "";
    }


    formatValuedOfferToJson(contractDetails: ContractDetails) {
        if (contractDetails.contractConsolidatedJson?.valuedOffer != null) {
            contractDetails.contractConsolidatedJson.valuedOffer = contractDetails.contractConsolidatedJson?.valuedOffer?.replace(/\\{"/g, '{"').replace(/}"\\]/g, '}]');
            try {
                contractDetails.contractConsolidatedJson.valuedOfferJson = JSON.parse(contractDetails.contractConsolidatedJson.valuedOffer);
            } catch (e) {
                console.error("Erreur en parsant la valued offer" + e);
                contractDetails.contractConsolidatedJson.valuedOfferJson = "Erreur lors de la récupération de la valued offer"
            }
            delete contractDetails.contractConsolidatedJson.valuedOffer;
        }
    }


    showReplayerPopup(contract: ContratsTable, event: Event) {
        this.modalService
        .open(ContratsReplayerPopUpComponent, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
            top: '35%'
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
            height: this.M1_MODAL_PROPERTIES.height
          },
          data: {
            contract: contract,
          },
        })
        .then((response) => console.log(response));
    }

    getCustomerBycoclico(): void {
        this.clientInfo = this.contrat.custAccNumberBeforeSynchronisation;
        if (this.contrat.custAccNumber) {
            this.clientService.getOneClient(this.contrat.custAccNumber).
                subscribe({
                    next: (response: any) => {
                        this.client = response;
                        this.client.isSynchronized = response.synchro;
                        this.client.type = Boolean(JSON.parse(response.type)) ? "Public" : "Privé";
                        this.client.dateSynchronization = response.dateLastSynchro ? new Date(response.dateLastSynchro * 1000) : null;
                        this.client.dateError = response.dateError ? new Date(response.dateError * 1000) : null;
                        this.clientInfo = response.custAccNumber + " " + response.name;
                        this.isClientExist = true;
                    },
                    complete: () => {
                    }
                })
        }
    }


    showPopupClient(event: Event) {
        this.modalService
        .open(ClientsDetailsPopUpComponent, {
          modal: {
            enter: `${this.M2_MODAL_PROPERTIES.animation} ${this.M2_MODAL_PROPERTIES.duration} ${this.M2_MODAL_PROPERTIES.easing}`,
            top: '50%'
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M2_MODAL_PROPERTIES.padding,
            width: this.M2_MODAL_PROPERTIES.width,
            height: this.M2_MODAL_PROPERTIES.height
          },
          data: {
            client: this.client,
          },
        })
        .then((response) => console.log(response));
        event.stopPropagation();
    }

    formatDatePopup(date: any) {
        return date ? this.datePipe.transform(date, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
    }

    moreOrLessContractJson() {
        this.isContratOdcExpanded = !this.isContratOdcExpanded;
        if (this.isContratOdcExpanded) {
            this.contratOdcExpandTitle = 'Tout plier'
        } else {
            this.contratOdcExpandTitle = 'Tout déplier'
        }
    }

    moreOrLessOfferJson() {
        this.isOfferExpanded = !this.isOfferExpanded;
        if (this.isOfferExpanded) {
            this.offerExpandTitle = 'Tout plier';
        } else {
            this.offerExpandTitle = 'Tout déplier';
        }
    }

    close(){
        this.modalService.close(this.name);
    }
}
