package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_assignement_nomenclature")
@Data
@Accessors(chain = true)
public class BusinessAssignementNomenclature implements Disposable, Persistable<Long> {
    @Id
    @Column("business_assignement_id")
    private Long businessAssignementId;
    @Column("business_assignment_custaccnumber")
    private String businessAssignmentCustaccnumber;
    @Column("business_portfolio_id")
    private Long businessPortfolioId;
    @Column("business_assignment_start_date")
    private Instant businessAssignmentStartDate;
    @Column("business_assignment_end_date")
    private Instant businessAssignmentEndDate;
    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessAssignmentStartDate) && businessAssignmentStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessAssignmentEndDate)
                                || businessAssignmentEndDate.isAfter(Instant.now())
                );
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessAssignementId;
    }

    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
