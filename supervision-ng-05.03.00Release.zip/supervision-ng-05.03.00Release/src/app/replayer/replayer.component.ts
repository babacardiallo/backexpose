import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
    selector: 'app-replayer',
    templateUrl: './replayer.component.html',
    styleUrls: ['./replayer.component.scss'],
    standalone: false
})
export class ReplayerComponent implements OnInit {
  pageTitle: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.updateTitle();

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateTitle();
      });
  }

  private updateTitle() {
    const firstChild = this.route.snapshot.firstChild;
    const currentRoute = firstChild?.url[0]?.path;

    if (currentRoute === 'replayClients') {
      this.pageTitle = 'Rejeux Clients';
    } else if (currentRoute === 'replayContracts') {
      this.pageTitle = 'Rejeux Contrats';
    } else {
      this.pageTitle = 'Rejeux';
    }

    this.titleService.setTitle("Factura : " + this.pageTitle);
  }
}
