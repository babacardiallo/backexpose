import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OffreErrorDetailPopUpComponent } from './offre-error-detail-pop-up.component';

describe('OffreErrorDetailPopUpComponent', () => {
  let component: OffreErrorDetailPopUpComponent;
  let fixture: ComponentFixture<OffreErrorDetailPopUpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OffreErrorDetailPopUpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OffreErrorDetailPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
