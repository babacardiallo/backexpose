package fr.laposte.blg.blinks.u17.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@EnableScheduling
public class PurgeScheduler implements Runnable {

    private final SchedulerParamsEntity schedulerParams;
    private final InvoiceRepository invoiceRepository;
    private final ExportHistoryRepository exportHistoryRepository;

    public PurgeScheduler(SchedulerParamsEntity schedulerParams, InvoiceRepository invoiceRepository, ExportHistoryRepository exportHistoryRepository) {
        this.schedulerParams = schedulerParams;
        this.invoiceRepository = invoiceRepository;
        this.exportHistoryRepository = exportHistoryRepository;
    }

    @Override
    public void run() {
        log.info("Starting PurgeScheduler job for scheduler: {}", schedulerParams.getSchedulerName());

        try {
            int purgedFilesCount = purgeOldArchiveFiles();
            log.info("Purged {} archive files older than 1 year", purgedFilesCount);
            purgeOldInvoices();
            purgeOrphanedExportHistory();

        } catch (Exception e) {
            log.error("Error during purge process", e);
        }

        log.info("PurgeScheduler job completed for scheduler: {}", schedulerParams.getSchedulerName());
    }

    private int purgeOldArchiveFiles() {
        String archivePath = schedulerParams.getArchivePath();
        if (archivePath == null || archivePath.trim().isEmpty()) {
            log.warn("Archive path is not configured for purge scheduler");
            return 0;
        }

        Path archiveDir = Paths.get(archivePath);
        if (!Files.exists(archiveDir)) {
            log.warn("Archive directory does not exist: {}", archiveDir);
            return 0;
        }
        Path docaposteDir = archiveDir.resolve(FileType.DOCAPOSTE.toString());
        Path coeurfinanceDir = archiveDir.resolve(FileType.COEURFINANCE.toString());
        Path infocaDir = archiveDir.resolve(FileType.INFOCA.toString());
        Path equinoxDir = archiveDir.resolve(FileType.EQUINOX.toString());

        AtomicInteger purgedCount = new AtomicInteger(0);
        Instant oneYearAgo = ZonedDateTime.now(ZoneId.systemDefault())
                .minusDays(365)
                .toInstant();
        List.of(docaposteDir, coeurfinanceDir, infocaDir, equinoxDir).forEach(
                dir ->{
                    log.debug("Start purge on directory : {}", dir);
                    try (var fileStream = Files.walk(dir)) {
                        fileStream
                                .filter(Files::isRegularFile)
                                .forEach(file -> {
                                    try {
                                        BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
                                        Instant lastModified = attrs.lastModifiedTime().toInstant();

                                        if (lastModified.isBefore(oneYearAgo)) {
                                            Files.delete(file);
                                            log.debug("Deleted old archive file: {}", file);
                                            purgedCount.getAndIncrement();
                                        }
                                    } catch (IOException e) {
                                        log.error("Error processing file: {}", file, e);
                                    }
                                });
                    } catch (IOException e) {
                        log.error("Error walking archive directory: {}", dir, e);
                    }
                }
        );


        return purgedCount.get();
    }

    private void purgeOldInvoices() {
        Instant threeMonthsAgo = ZonedDateTime.now(ZoneId.systemDefault())
                .minusDays(90)
                .toInstant();

        invoiceRepository.deleteByUpdatedBefore(threeMonthsAgo)
                .subscribe(
                        deletedCount -> log.info("Purged {} invoices older than 3 months", deletedCount),
                        error -> log.error("Error purging old invoices", error)
                );
    }

    // Purge des export history qui ne sont plus liés à aucune facture.
    private void purgeOrphanedExportHistory() {
        Instant threeMonthsAgo = ZonedDateTime.now(ZoneId.systemDefault())
                .minusDays(90)
                .toInstant();

        exportHistoryRepository.deleteOrphanedDocaposteExportHistory(threeMonthsAgo)
                .subscribe(
                        deletedCount -> log.info("Purged {} orphaned DOCAPOSTE export_history records older than 3 months", deletedCount),
                        error -> log.error("Error purging orphaned DOCAPOSTE export_history", error)
                );

        exportHistoryRepository.deleteOrphanedCoeurfinanceExportHistory(threeMonthsAgo)
                .subscribe(
                        deletedCount -> log.info("Purged {} orphaned COEURFINANCE export_history records older than 3 months", deletedCount),
                        error -> log.error("Error purging orphaned COEURFINANCE export_history", error)
                );

        exportHistoryRepository.deleteOrphanedInfocaExportHistory(threeMonthsAgo)
                .subscribe(
                        deletedCount -> log.info("Purged {} orphaned INFOCA export_history records older than 3 months", deletedCount),
                        error -> log.error("Error purging orphaned INFOCA export_history", error)
                );
        exportHistoryRepository.deleteOrphanedEquinoxExportHistory(threeMonthsAgo)
                .subscribe(
                        deletedCount -> log.info("Purged {} orphaned EQUINOX export_history records older than 3 months", deletedCount),
                        error -> log.error("Error purging orphaned EQUINOX export_history", error)
                );
    }
}