package fr.laposte.blg.blinks.lib.common.entities;

public enum AddressType {
    PRINCIPALE,
    PRESTATION,
    FACTURATION,
    SIEGE
}