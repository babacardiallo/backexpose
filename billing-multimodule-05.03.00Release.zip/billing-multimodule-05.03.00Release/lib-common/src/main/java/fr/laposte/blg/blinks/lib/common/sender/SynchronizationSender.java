package fr.laposte.blg.blinks.lib.common.sender;

import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueMigrationEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.bscc.billing.avro.EventOrigin;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.TypeEnum;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderRecord;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class SynchronizationSender {

    //TODO Faire en sorte que cette conf ne soit uniquement configurable pour les modules qui ont besoin de publier sur le topic privé
    @Value("${fr.laposte.topic.synchronization}")
    private String topicName;

    @Resource(name = "synchronizationKafkaSender")
    private KafkaSender<String, Synchronization> synchronizationKafkaSender;

    private final ErrorLogService errorLogService;

    public Mono<Void> send(Synchronization synchronization) {
        return this.synchronizationKafkaSender.send(
            Mono.just(synchronization)
                .map(avro -> SenderRecord.create(
                    new ProducerRecord<>(this.topicName, synchronization.getType() + "-" + synchronization.getInternalId() , synchronization),
                    synchronization)))
            .then();
    }

    public Mono<QueueSynchronizationEntity> sendQueuedItem(QueueSynchronizationEntity queueSynchronizationEntity) {
        return Mono.just(queueSynchronizationEntity)
            .doOnNext(synchronization -> log.debug("Sending idQueueSynchronization {} to private topic", synchronization.getIdQueue()))
            .map(entity -> {

                    var builder = Synchronization.newBuilder().setAction(queueSynchronizationEntity.getAction());
                    builder.setEventOrigin(EventOrigin.newBuilder().setTopic("SCHEDULER-SYNCHRO")
                        .setKey(queueSynchronizationEntity.getIdQueue().toString())
                        .build());

                        if (Objects.nonNull(entity.getIdContract())) {
                            builder.setInternalId(queueSynchronizationEntity.getIdContract().intValue())
                                    .setType(TypeEnum.contract);
                        } else {
                            builder.setType(TypeEnum.customer)
                                    .setRefcomReplay(entity.getRefcomReplay())
                                    .setInternalId(entity.getIdLegalPerson().intValue());
                        }
                        return builder.build();
                    }
            )
            .flatMap(this::send)
            .onErrorResume(throwable -> {
                var errorLog = ErrorLogEntity.builder()
                    .idContract(queueSynchronizationEntity.getIdContract())
                    .idLegalPerson(queueSynchronizationEntity.getIdLegalPerson())
                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.SCHEDULER)
                    .errorMessage(throwable.getMessage())
                    .build();
                return errorLogService.logError(errorLog)
                    .then(Mono.empty());
            })
            .thenReturn(queueSynchronizationEntity);
    }

    public Mono<QueueMigrationEntity> sendQueuedMigrationItem(QueueMigrationEntity queueMigrationEntity) {
        return Mono.just(queueMigrationEntity)
            .doOnNext(migration -> log.debug("Sending idQueueMigration {} to private topic", migration.getIdQueue()))
            .map(entity -> {

                    var builder = Synchronization.newBuilder().setAction(queueMigrationEntity.getAction())
                        .setInternalId(queueMigrationEntity.getIdContract().intValue())
                        .setType(TypeEnum.contract);
                    builder.setEventOrigin(EventOrigin.newBuilder().setTopic("SCHEDULER-MIGRATION")
                        .setKey(queueMigrationEntity.getIdQueue().toString())
                        .build());

                    return builder.build();
                }
            )
            .flatMap(this::send)
            .onErrorResume(throwable -> {
                var errorLog = ErrorLogEntity.builder()
                    .idContract(queueMigrationEntity.getIdContract())
                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.SCHEDULER)
                    .errorMessage(throwable.getMessage())
                    .build();
                return errorLogService.logError(errorLog)
                    .then(Mono.empty());
            })
            .thenReturn(queueMigrationEntity);
    }
}
