package fr.laposte.blg.blinks.u11.listener.address;

import MD.LatestValue.Address;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Data
@ConfigurationProperties(prefix = "fr.laposte.billing.listener.address.canal-suez")
@ConditionalOnProperty(value = "fr.laposte.billing.listener.address.activated", havingValue = "true")
@Slf4j
public class AddressListener {

    String kafkaTopic;
    // Groupe de consommation
    String kafkaGroupId;

    private final AddressListenerService addressService;

    @Autowired
    public AddressListener(AddressListenerService addressService) {
        this.addressService = addressService;
    }


    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", kafkaTopic);
        log.info("Kafka groupId: {}", kafkaGroupId);
        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", kafkaTopic, kafkaGroupId);
    }


    @KafkaListener(groupId = "${fr.laposte.billing.listener.address.canal-suez.kafka-group-id}",
            topics = "${fr.laposte.billing.listener.address.canal-suez.kafka-topic}", containerFactory = "specificAvroValueConsumerFactory")
    public void onMessages(List<ConsumerRecord<String, Address>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} address(s) from topic '{}'", total, kafkaTopic);
        AtomicInteger errorCount = new AtomicInteger(0);
        try {
            Flux.fromIterable(records)
                    .concatMap(message -> {
                        log.info("Record received: key={}, topic={}, partition={}, offset={}",
                                message.key(), message.topic(), message.partition(), message.offset());

                        return addressService.updateAddress(message)
                                .doOnError(throwable -> {
                                    errorCount.incrementAndGet();
                                    var errorMessage = String.format("Error on Address Listener on addressId: %s", message.key());
                                    log.error(errorMessage, throwable);
                                })
                                .onErrorResume(throwable -> Mono.empty());
                    })
                    .then()
                    .block();

            if (errorCount.get() == 0) {
                ack.acknowledge();
                log.info("Batch processed and acknowledged: {} record(s)", total);
            } else {
                log.warn("Batch NOT acknowledged: {} errors out of {} record(s)", errorCount.get(), total);
                retryIndividually(records, ack);
            }

        } catch (Exception error) {
            log.error("Fatal error during batch processing ({} record(s))", total, error);
            retryIndividually(records, ack);
        }
    }

    private void retryIndividually(List<ConsumerRecord<String, Address>> records, Acknowledgment ack) {
        Flux.fromIterable(records)
                .concatMap(message -> addressService.updateAddress(message)
                        .doOnSuccess(c -> {
                            log.info("Address key: {} is acknowledged successfully", message.key());
                            ack.acknowledge();
                        })
                        .doOnError(e -> log.error("Error processing address key={}", message.key(), e))
                        .onErrorResume(throwable -> Mono.empty())
                )
                .then()
                .block();
    }

}
