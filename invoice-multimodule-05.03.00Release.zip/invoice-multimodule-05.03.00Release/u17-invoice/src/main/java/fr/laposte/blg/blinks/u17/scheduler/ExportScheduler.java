package fr.laposte.blg.blinks.u17.scheduler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcessStatus;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.service.DocaposteService;
import fr.laposte.blg.blinks.u17.service.CoeurfinanceService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import fr.laposte.blg.blinks.u17.util.SchedulerUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@EnableScheduling
public class ExportScheduler implements Runnable {
    private final ExportProcessRepository exportProcessRepository;
    private final InvoiceRepository invoiceRepository;
    private final SchedulerParamsEntity schedulerParams;
    private final SchedulerUtils schedulerUtils;
    private final DocaposteService docaposteService;
    private final CoeurfinanceService coeurfinanceService;
    private final InfocaInvoiceExportService infocaInvoiceExportService;
    private final TaskScheduler taskScheduler;


    public ExportScheduler(DocaposteService docaposteService,
                           CoeurfinanceService coeurfinanceService,
                           InfocaInvoiceExportService infocaInvoiceExportService,
                           ExportProcessRepository exportProcessRepository,
                           InvoiceRepository invoiceRepository,
                           SchedulerParamsEntity schedulerParams,
                           SchedulerUtils schedulerUtils,
                           TaskScheduler taskScheduler){
        this.docaposteService = docaposteService;
        this.coeurfinanceService = coeurfinanceService;
        this.infocaInvoiceExportService = infocaInvoiceExportService;
        this.exportProcessRepository = exportProcessRepository;
        this.invoiceRepository = invoiceRepository;
        this.schedulerParams = schedulerParams;
        this.schedulerUtils = schedulerUtils;
        this.taskScheduler = taskScheduler;
    }


    @Override
    public void run() {
        ExportOnceScheduler exportOnceScheduler = new ExportOnceScheduler(docaposteService, coeurfinanceService, infocaInvoiceExportService, exportProcessRepository, schedulerParams, taskScheduler);
        log.info("Starting scheduler : {} {}",  schedulerParams.getId(), schedulerParams.getSchedulerName());
        try {
            this.onSaveDailyProcess()
                    .doOnNext(r -> exportOnceScheduler.run())
                    .subscribe();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }



    private Mono<Integer> onSaveDailyProcess() throws JsonProcessingException {
        JsonNode jsonNode = this.schedulerUtils.mapStringToJson(schedulerParams.getCustomParams());
        return Mono.zip(invoiceRepository.getMinIdForProcess(), invoiceRepository.getMaxIdForProcess())
                .switchIfEmpty(Mono.zip(invoiceRepository.getMaxId(), invoiceRepository.getMaxId()))
                .flatMapMany(tuple2 -> {
                    List<ExportProcess> exportProcessList = new ArrayList<>();
                    exportProcessList.add(new ExportProcess(tuple2.getT1(), tuple2.getT2(), null, FileType.DOCAPOSTE, ExportProcessStatus.NEW, null, null, jsonNode.findPath(FileType.DOCAPOSTE.toString().toLowerCase()).asInt()));
                    exportProcessList.add(new ExportProcess(tuple2.getT1(), tuple2.getT2(), null, FileType.DOCAPOSTE_AVIS_PAIEMENT, ExportProcessStatus.NEW, null, null, jsonNode.findPath(FileType.DOCAPOSTE_AVIS_PAIEMENT.toString().toLowerCase()).asInt()));
                    exportProcessList.add(new ExportProcess(tuple2.getT1(), tuple2.getT2(), null, FileType.COEURFINANCE, ExportProcessStatus.NEW, null, null, jsonNode.findPath(FileType.COEURFINANCE.toString().toLowerCase()).asInt()));
                    exportProcessList.add(new ExportProcess(tuple2.getT1(), tuple2.getT2(), null, FileType.INFOCA, ExportProcessStatus.NEW, null, null, jsonNode.findPath(FileType.INFOCA.toString().toLowerCase()).asInt()));
                    return Flux.fromIterable(exportProcessList);
                })
                .flatMap(exportProcessRepository::save)
                .collectList()
                .flatMap(r -> {
                    if(r!=null && !r.isEmpty()){
                        return exportProcessRepository.deleteSuccessProcess();
                    } else {
                       return Mono.just(1);
                    }
                });

    }

}
