export class ContractReplayParameters {
    method: string;
    contractNumber: string;
    date: Date;
}