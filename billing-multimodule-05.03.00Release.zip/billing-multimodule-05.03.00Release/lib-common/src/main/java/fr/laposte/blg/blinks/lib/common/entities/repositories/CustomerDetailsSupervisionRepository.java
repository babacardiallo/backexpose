package fr.laposte.blg.blinks.lib.common.entities.repositories;


import fr.laposte.blg.blinks.lib.common.entities.CustomerDetailsSupervisionEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface CustomerDetailsSupervisionRepository extends ReactiveCrudRepository<CustomerDetailsSupervisionEntity, Long> {

    Mono<CustomerDetailsSupervisionEntity> findByCustAccNumber(int coclico);
}
