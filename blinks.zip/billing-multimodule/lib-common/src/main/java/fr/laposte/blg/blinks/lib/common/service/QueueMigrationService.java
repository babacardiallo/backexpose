package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.QueueMigrationEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.QueueMigrationRepository;
import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class QueueMigrationService {

    private final QueueMigrationRepository queueMigrationRepository;

    public Flux<QueueMigrationEntity> findQueueMigrationToMigrateByOffer() {
        return queueMigrationRepository.findQueueMigrationEligible();
    }

    public Mono<Void> deleteQueueMigrationById(Long idQueueMigration) {
        return queueMigrationRepository.deleteByIdQueue(idQueueMigration);
    }

    public Mono<QueueMigrationEntity> findQueueMigrationByIdContract(long idContract) {
        return queueMigrationRepository
            .findQueueMigrationEntityByIdContract(idContract);
    }

    public Mono<QueueMigrationEntity> enQueueContract(Long idContract, ActionEnum actionEnum, String offerOpsCode) {

        QueueMigrationEntity queueMigrationEntity = QueueMigrationEntity.builder()
            .action(actionEnum)
            .offerOpsCode(offerOpsCode)
            .idContract(idContract).build();
        return
            findQueueMigrationByIdContract(idContract)
                .map(QueueMigrationEntity1 -> queueMigrationEntity.setIdQueue(QueueMigrationEntity1.getIdQueue()))
                .defaultIfEmpty(queueMigrationEntity)
                .flatMap(queueMigrationRepository::save);
    }

    public Mono<Integer> enableMigrationForOffer(Instant dateMigrationExpected, String offerOpsCode) {
        return queueMigrationRepository.setDateMigrationExpectedForOffer(dateMigrationExpected, offerOpsCode);
    }

}
