CREATE TABLE blg_contract_importer.refops
(
    offer_ops_id                int UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ops_code                    varchar(32)  not null,
    ops_label                   varchar(256) not null,
    offer_technical_version     varchar(32)  null,
    offer_functional_version    varchar(32)  null,
    offer_version_creation_datetime datetime     null,
    offer_activation_datetime       datetime     null,
    data                        json         null,
    CONSTRAINT unq_ops_code UNIQUE (ops_code)
);
