package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("legal_person_message")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class LegalPersonMessage {
    @Id
    @Column("id_legal_person_message")
    private Long idLegalPersonMessage;

    @Column("id_legal_person")
    private Long idLegalPerson;

    @Column("legal_person_json")
    private String legalPersonJson;
}
