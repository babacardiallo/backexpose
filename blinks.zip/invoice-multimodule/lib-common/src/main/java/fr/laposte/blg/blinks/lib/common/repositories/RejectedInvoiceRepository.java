package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoice;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface RejectedInvoiceRepository extends ReactiveCrudRepository<RejectedInvoice, Long> {

    @Query("SELECT * FROM rejected_invoice Rej" +
            " WHERE Rej.error_date = (SELECT MAX(error_date) FROM rejected_invoice Rej2" +
            " WHERE Rej.invoice_number = Rej2.invoice_number AND Rej2.invoice_number IN (:invoiceNumbers) AND Rej2.status = 'REJECTED')")
    Flux<RejectedInvoice> getAllByInvoiceNumbers(List<String> invoiceNumbers);

    @Query("SELECT * FROM rejected_invoice Rej" +
            " WHERE Rej.error_date = (SELECT MAX(error_date) FROM rejected_invoice Rej2" +
            " WHERE Rej.invoice_number = Rej2.invoice_number AND Rej2.status = 'REJECTED')")
    Flux<RejectedInvoice> getAllRejectedInvoices();

    @Query("SELECT COUNT(*) FROM rejected_invoice Rej" +
            " WHERE Rej.error_date = (SELECT MAX(error_date) FROM rejected_invoice Rej2" +
            " WHERE Rej.invoice_number = Rej2.invoice_number AND Rej2.status = 'REJECTED')")
    Mono<Long> countAllRejectedInvoices();

    @Modifying
    @Query("DELETE FROM rejected_invoice WHERE" +
            " (CAST(replayed_date AS DATE) <= CAST(DATE_SUB(NOW(), INTERVAL 7 DAY) AS DATE) AND status = 'REPLAYED')" +
            " OR (status = 'REJECTED' AND invoice_number IN (SELECT invoice_number FROM invoice))")
    Mono<Integer> purge();

    @Modifying
    @Query("UPDATE rejected_invoice SET status = 'REPLAYED', replayed_date = NOW() WHERE invoice_number = :invoiceNumber AND status = 'REJECTED'")
    Mono<Boolean> updateAllByInvoiceNumber(String invoiceNumber);

}
