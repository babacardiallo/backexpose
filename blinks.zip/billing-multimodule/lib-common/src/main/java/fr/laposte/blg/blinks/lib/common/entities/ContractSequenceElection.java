package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Table("contract_sequence_election")
public class ContractSequenceElection {

    @Id
    @Column("sequence_name")
    String sequenceName = "ELECTION";

    @Column(value = "current_sequence")
    Long currentSequence;

    @Column(value = "last_updated")
    Instant lastUpdated;
}
