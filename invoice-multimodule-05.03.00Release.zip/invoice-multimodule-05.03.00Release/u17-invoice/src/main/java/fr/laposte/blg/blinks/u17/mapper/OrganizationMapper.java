package fr.laposte.blg.blinks.u17.mapper;

import fr.laposte.blg.blinks.lib.common.entities.organization.OrganizationEntity;
import fr.laposte.blg.blinks.u17.dto.organization.OrganizationDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Mapper
public interface OrganizationMapper {

    @Mapping(source = "code", target = "code")
    @Mapping(source = "codeRegate", target = "codeRegate")
    @Mapping(source = "creationDate", target = "creationDate")
    @Mapping(source = "closingDate", target = "closingDate")
    @Mapping(source = "deactivationDate", target = "deactivationDate")
    @Mapping(source = "modificationDate", target = "modificationDate")
    @Mapping(ignore = true, target = "id")
    OrganizationEntity organizationDtoToOrganizationEntity(OrganizationDto organizationDto);

    /**
     * Méthode spécifique de mapping pour convertir une ligne CSV en OrganizationDto
     *
     * @return L'objet de classe OrganizationDto
     */
    default OrganizationDto rawDataToOrganizationtDto(String lineCSV, List<String> metas) {
        List<String> values = Arrays.asList(lineCSV.split(";"));
        OrganizationDto.OrganizationDtoBuilder builderOrganizationDto = OrganizationDto.builder();
        OrganizationDto organizationDtoToReturn = builderOrganizationDto.build();
        organizationDtoToReturn.setCode(values.get(metas.indexOf("CODE")));
        // Le Code régate est obligatoire
        organizationDtoToReturn.setCodeRegate(Optional.of(values.get(metas.indexOf("CODE_REGATE"))).orElseThrow());
        Optional.ofNullable(values.get(metas.indexOf("DATE_CREATION"))).filter(datestr -> !datestr.isBlank())
                .map(this::fromString).ifPresent(organizationDtoToReturn::setCreationDate);
        Optional.ofNullable(values.get(metas.indexOf("DATE_DESACTIVATION"))).filter(datestr -> !datestr.isBlank())
                .map(this::fromString).ifPresent(organizationDtoToReturn::setDeactivationDate);
        Optional.ofNullable(values.get(metas.indexOf("DATE_MODIFICATION"))).filter(datestr -> !datestr.isBlank())
                .map(this::fromString).ifPresent(organizationDtoToReturn::setModificationDate);
        Optional.ofNullable(values.get(metas.indexOf("DATE_FERMETURE"))).filter(datestr -> !datestr.isBlank())
                .map(this::fromString).ifPresent(organizationDtoToReturn::setClosingDate);
        return organizationDtoToReturn;
    }

    default LocalDate fromString(String dateString) {
        return LocalDate.parse(dateString, DateTimeFormatter.ISO_LOCAL_DATE);
    }
}
