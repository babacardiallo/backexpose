import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';
import { environment } from '../../environments/environment';
import { ChoixExportComponent } from './components/choix-export/choix-export.component';
import { InvoiceToExportComponent } from './components/invoice-export/invoice-export.component';
import { InvoiceRejeuComponent } from './components/invoice-rejeu/invoice-rejeu.component';
import { Invoice } from './models/invoice';
import { PrepareExport } from './models/prepare-export';
import { LancementExportService } from './services/Lancement-export.service';

@Component({
    selector: 'app-lancementexport',
    templateUrl: './lancement-export.component.html',
    styleUrls: ['./lancement-export.component.scss'],
    standalone: false
})

export class LancementExportComponent implements OnInit {

    @ViewChild(ChoixExportComponent) choix: ChoixExportComponent;

    @ViewChild(InvoiceRejeuComponent) rejeu: InvoiceRejeuComponent;

    @ViewChild(InvoiceToExportComponent) export: InvoiceToExportComponent;

    appName = environment.appName;

    public invoiceSelectedFormated = '';

    constructor(private lancementExportService: LancementExportService, private cdr: ChangeDetectorRef, private router: Router,
        private titleService: Title,) { }

    ngOnInit() {
        this.updateTitle();

        this.router.events
            .pipe(filter(event => event instanceof NavigationEnd))
            .subscribe(() => {
                this.updateTitle();
            });
    }


    getSelectInvoices(selecteds: Array<Invoice>) {
        const invoicesFilled = selecteds.map(value => value.invoiceNumber);
        this.invoiceSelectedFormated = invoicesFilled.toString().split(",").join("\n")
    }

    updatePerimetre() {
        this.rejeu.isLoading = true;
        this.export.isLoading = true;
        const exportDto: PrepareExport = new PrepareExport();
        exportDto.invoices = this.invoiceSelectedFormated.split("\n");
        exportDto.exportChoices = this.choix.perimtresChoisies;
        this.lancementExportService.prepareExport(exportDto).subscribe(res => {
            setTimeout(() => {
                this.rejeu.fetchAllInvoices();
                this.rejeu.invoices.selected = [];
                this.invoiceSelectedFormated = "";
                this.export.fetchAllInvoices();
                this.rejeu.isLoading = false;
                this.export.isLoading = false;
            }, 2000);
        })
    }

    refreshInvoices(event: Event) {
        this.rejeu.isLoading = true;
        this.rejeu.fetchAllInvoices();
        setTimeout(() => {
            this.rejeu.isLoading = false;
        }, 2000);
    }


    private updateTitle() {
        this.titleService.setTitle("Factura : Exports Partenaires");
    }

}