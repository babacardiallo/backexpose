export class InvoiceSupervisionTable {
    idInvoice!: number;
    invoiceNumber?: string;
    created?: string;
    client?: number;
    billrunId?: string;
    docaposteExportStatus?: string;
    infocaExportStatus?: string;
    equinoxExportStatus?: string;
    docaposteExportDate?: string;
    infocaExportDate?: string;
    equinoxExportDate?: string;
    docaposteExportId?: number;
    infocaExportId?: number;
    equinoxExportId?: number;
    present?: number;
    fromTableOnly?: boolean;
}
