package fr.laposte.blg.blinks.u11.scheduler;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.net.ssl.SSLSession;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DatabaseCheckSchedulerTest {

    @InjectMocks
    private DatabaseCheckScheduler databaseCheckScheduler;

    @Mock
    private HttpClientFactory httpClientFactory;

    @Test
    void shutDownAppWhenDbNotHealthyTest() throws IOException, InterruptedException {
        HttpResponse httpResponse = new HttpResponse() {
            @Override
            public int statusCode() {
                return 200;
            }

            @Override
            public HttpRequest request() {
                return null;
            }

            @Override
            public Optional<HttpResponse> previousResponse() {
                return Optional.empty();
            }

            @Override
            public HttpHeaders headers() {
                return null;
            }

            @Override
            public Object body() {
                return "{\"status\":\"UP\",\"details\":{\"database\":\"MySQL\",\"validationQuery\":\"validate(REMOTE)\"}}";
            }

            @Override
            public Optional<SSLSession> sslSession() {
                return Optional.empty();
            }

            @Override
            public URI uri() {
                return null;
            }

            @Override
            public HttpClient.Version version() {
                return null;
            }
        };
        HttpClient httpClient = mock(HttpClient.class);
        Mockito.when(httpClientFactory.create())
                .thenReturn(httpClient);
        Mockito.when(httpClient.send(any(), any()))
                .thenReturn(httpResponse);
        databaseCheckScheduler.shutDownAppWhenDbNotHealthy();
        verify(httpClient, times(1)).send(any(), any());
    }
}

