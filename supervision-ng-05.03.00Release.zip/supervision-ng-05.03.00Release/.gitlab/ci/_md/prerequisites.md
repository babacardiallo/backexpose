# Prerequisites
## 1- AgentK
We need an AgentK for each  Kube cluster

>JIRA for BUILD MAR PAAS here: https://jira.net.extra.laposte.fr/jira/browse/APPUI-93373  \
>AgentK link: https://git.net-courrier.extra.laposte.fr/groupe_blg/agentk/-/clusters  \

>JIRA for RUN MAR PAAS here: todo \
>todo 

---
## 2- Gitlab Envs 
We need to environement under gitlab and link them to Openshift Kube-space


---
## 3- Variables


---

## 4- Repository deploy token
To be able to use the Registry gitlab: 
registry.bscc.net.intra.laposte.fr/groupe_blg/billing-multimodule/
  
We need to create a deploy token in gitlab:

>Goto Gitlab Gui -> Project Repo -> Menu Settings -> Repository -> Deploy keys 

Used values:
> name: blinks-collector-gitlab-registry-read-token \
> user: blinks-collector-gitlab-registry-reader \
> token: gldt-Cs6X4PHCQp5QX3sdaLoJ \
> desc: Utilisé dans le paas pour pull les images du registry gitlab \
> link: https://git.net-courrier.extra.laposte.fr/groupe_blg/billing-multimodule/-/settings/repository#js-deploy-tokens 

**Warning: This  token should be added as a secret in each PAAS namespace!**

Use the following command to add the secret:
```
kubectl create secret docker-registry blinks-collector-gitlab-registry-secret \
--docker-server=registry.bscc.net.intra.laposte.fr \
--docker-username=blinks-collector-gitlab-registry-reader \
--docker-password=gldt-Cs6X4PHCQp5QX3sdaLoJ \
--docker-email=unused
```

---

