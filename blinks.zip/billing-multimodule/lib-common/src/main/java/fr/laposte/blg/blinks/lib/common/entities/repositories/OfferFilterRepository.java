package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.OfferFilterEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface OfferFilterRepository extends ReactiveCrudRepository<OfferFilterEntity, Long> {

    Mono<OfferFilterEntity> findFirstByOfferOpsId(Long offerOpsId);
    Mono<OfferFilterEntity> findFirstByOpsCode(String offerOpsCode);
    Mono<Void> deleteByOpsCode(String opsCode);

    Flux<OfferFilterEntity> findAllByOpsCodeLike(String filter, @Param("pageable") Pageable pageable);
    Mono<Long> countAllByOpsCodeLike(String filter);
    Flux<OfferFilterEntity> findAllBy(@Param("pageable") Pageable pageable);

    @Transactional(readOnly = true)
    @Query("SELECT count(offer_ops_id) from offer_filter")
    Mono<Long> countOffers();

    @Query("SELECT ops_code FROM offer_filter")
    Flux<String> getAllActivesOpsCode();
}
