import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContratsReplayerPopUpComponent } from './contrats-replayer-pop-up.component';

describe('ContratsReplayerPopUpComponent', () => {
    let component: ContratsReplayerPopUpComponent;
    let fixture: ComponentFixture<ContratsReplayerPopUpComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ContratsReplayerPopUpComponent]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ContratsReplayerPopUpComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
