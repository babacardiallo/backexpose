package fr.laposte.blg.blinks.u17.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ScheduledPaymentTreatment {
    String scheduledPaymentDate;
    Double scheduledPaymentAmountIncludingVAT;
    Instant date;
}
