package fr.laposte.blg.blinks.u11.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.entities.RefopsEntity;
import fr.laposte.r5.uk.kafka.avro.viewoscar.Oscar;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.time.Instant;

@Mapper
@DecoratedWith(RefopsListenerDecorator.class)
public interface RefopsListenerMapper {
    @Mappings({
        @Mapping(target = "offerOpsId", ignore = true),
        @Mapping(source = "offerCode", target = "opsCode"),
        @Mapping(source = "offerName", target = "opsLabel"),
        @Mapping(source = "offerTechnicalVersion", target = "offerTechnicalVersion"),
        @Mapping(source = "offerFunctionalVersion", target = "offerFunctionalVersion"),
        @Mapping(source = "startDate", target = "offerVersionCreationDatetime"),
        @Mapping(target = "data", ignore = true) // in decorator
    })
    RefopsEntity refopsToRefopsEntity(Oscar refopsOffer) throws JsonProcessingException;

    default String toString(CharSequence charSequence) {
        return (charSequence != null) ? charSequence.toString() : null;
    }

    default Instant asInstant(String date) {
        return date != null && !date.isBlank() ? Instant.parse(date+"T00:00:00.00Z") : null;
    }
}
