package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OfferSupervisionDtoNoPagination {
    private String opsCode;
    private String opsLabel;
    private Instant offerActivationDate;
    private int contractSynch;
    private int contractVersionSynch;
    private int contractIntegrated;
    private int contractVersionIntegrated;
    private int errorListening;
    private int errorSynch;
    private Boolean isActiveOffer;
}
