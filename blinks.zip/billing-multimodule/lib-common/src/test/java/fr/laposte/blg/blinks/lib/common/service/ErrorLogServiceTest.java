package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractEntity;
import fr.laposte.blg.blinks.lib.common.entities.ContractStatusEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractSubStatusEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ErrorLogRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;


import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ErrorLogServiceTest {
    @InjectMocks
    private ErrorLogService errorLogService;
    @Mock
    private ErrorLogRepository errorLogRepository;

    @Test
    void logErrorTest(){
        Mockito.when(errorLogRepository.save(Mockito.any(ErrorLogEntity.class)))
                        .thenAnswer(args-> Mono.just(args.getArgument(0)));
        StepVerifier.create(errorLogService.logError(ErrorLogEntity.builder().idErrorLog(1L).errorMessage("Unhandled error").codeError(CodeErrorEnum.U11001).build()))
                .assertNext(errorLogEntity -> {
                    assertEquals(1L, errorLogEntity.getIdErrorLog());
                    assertEquals(CodeErrorEnum.U11001, errorLogEntity.getCodeError());
                })
                .verifyComplete();
    }

    @Test
    void logErrorContractTest(){
        gkContractFullOutV1 gkContractFullOutV1 = new gkContractFullOutV1();
        ContractEntity contractEntity =
                ContractEntity.builder()
                .idContract(1L)
                .contractNumber("D-0").build();
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsId("0001");
        valuedOfferEntity.setOpsCode("0001");
        ContractVersionEntity contractVersionEntity=
                ContractVersionEntity.builder()
                .idContractVersion(1L)
                .idContract(1L)
                .amendmentNumber(0)
                .revisionNumber(1)
                .status(ContractStatusEnum.VALIDE)
                .substatus(ContractSubStatusEnum.VALIDE)
                .contract(contractEntity)
                .valuedOffer(valuedOfferEntity)
                .build();
        Mockito.when(errorLogRepository.save(Mockito.any(ErrorLogEntity.class)))
                        .thenAnswer(args-> Mono.just(args.getArgument(0)));
        StepVerifier.create(errorLogService.logErrorContract(contractVersionEntity, "error", ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING_AFTER_MAPPING_AVRO, gkContractFullOutV1))
                .assertNext(errorLogEntity -> {
                    assertEquals(0, errorLogEntity.getAmendmentNumber());
                    assertEquals(1, errorLogEntity.getRevisionNumber());
                    assertEquals(ContractStatusEnum.VALIDE, errorLogEntity.getStatus());
                    assertEquals(ContractSubStatusEnum.VALIDE, errorLogEntity.getSubstatus());
                    assertEquals("D-0", errorLogEntity.getContractNumber());
                    assertEquals("0001", errorLogEntity.getOpsCode());
                })
                .verifyComplete();
    }

    @Test
    void logErrorCustomerest(){
        Mockito.when(errorLogRepository.save(Mockito.any(ErrorLogEntity.class)))
                .thenAnswer(args-> Mono.just(args.getArgument(0)));
        StepVerifier.create(errorLogService.logErrorCustomer(1L, 1L, "error", ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER, CodeErrorEnum.U12009))
                .assertNext(errorLogEntity -> {
                    assertEquals(1L, errorLogEntity.getIdLegalPerson());
                    assertEquals(1L, errorLogEntity.getCustAccNumber());
                    assertEquals(CodeErrorEnum.U12009, errorLogEntity.getCodeError());
                })
                .verifyComplete();
    }
    @Test
    void purgeErrorLogForOneContractVersionTest(){
        ContractEntity contractEntity =
                ContractEntity.builder()
                        .idContract(1L)
                        .contractNumber("D-0").build();
        ContractVersionEntity contractVersionEntity=
                ContractVersionEntity.builder()
                        .idContractVersion(1L)
                        .idContract(1L)
                        .amendmentNumber(0)
                        .revisionNumber(1)
                        .status(ContractStatusEnum.VALIDE)
                        .substatus(ContractSubStatusEnum.VALIDE)
                        .contract(contractEntity)
                        .build();
        Mockito.when(errorLogRepository.deleteByContractNumberAndAmendmentNumberAndRevisionNumberLessThanEqual(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(Mono.empty());
        StepVerifier.create(errorLogService.purgeErrorLogForOneContractVersion(contractVersionEntity))
                .expectSubscription()
                .verifyComplete();
    }

    @Test
    void purgeErrorLogForOneLegalPersonTest(){
        Mockito.when(errorLogRepository.deleteByIdLegalPerson(Mockito.anyLong()))
                .thenReturn(Mono.empty());
        StepVerifier.create(errorLogService.purgeErrorLogForOneLegalPerson(1L))
                .expectSubscription()
                .verifyComplete();
    }

    @Test
    void purgeErrorLogForOneLegalPersonByCoclicoTest(){
        Mockito.when(errorLogRepository.deleteByCustAccNumberAndWorkflowStepEquals(Mockito.anyLong(), Mockito.any(ErrorLogEntity.ErrorWorkflowStepEnum.class)))
                .thenReturn(Mono.empty());
        StepVerifier.create(errorLogService.purgeErrorLogForOneLegalPersonByCoclico(1L, ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER))
                .expectSubscription()
                .verifyComplete();
    }

    @Test
    void purgeErrorOfSchedulerForOneContractTest(){
        Mockito.when(errorLogRepository.deleteByIdContractAndWorkflowStepEquals(Mockito.anyLong(),  Mockito.any(ErrorLogEntity.ErrorWorkflowStepEnum.class)))
                .thenReturn(Mono.empty());
        StepVerifier.create(errorLogService.purgeErrorOfSchedulerForOneContract(1L))
                .expectSubscription()
                .verifyComplete();
    }

    @Test
    void removeAllLessRevisionsTest(){
        Mockito.when(errorLogRepository.removeAllLessRevisions(Mockito.anyString(),  Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(Mono.empty());
        StepVerifier.create(errorLogService.removeAllLessRevisions("D-0", 1, 1))
                .expectSubscription()
                .verifyComplete();
    }
}
