import { ContractOdcJson } from "./contract-odc-json";
import { ContractConsolidatedJson } from "./contrat-consolidated-json";

export class ContratsTable {
    contractId?: string;
    contractNumber?: string;
    amendmentNumber?: number;
    revisionNumber?: number;
    status?: string;
    substatus?: string;
    type?: string;
    subtype?: string;
    opsCode?: string;
    opsLabel?: string;
    isSynchronized?: boolean;
    lastDateSynchronization?: number | string | Date;
    dateError?: number | string | Date;
    firstErrorDate?: number | string | Date;
    hasSuperiorRevError?: boolean = false;
    superiorRevError?: number;
    superiorRevErrMessage?: string;
    superiorRevOdcMessage?: JSON;
    custAccNumber?: number;
    custAccNumberBeforeSynchronisation?: number;
    supOffsetError?: string;
    supPartitionError?: string;
    refClient?: number;
}
