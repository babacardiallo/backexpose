package fr.laposte.blg.blinks.u17.controller;


import fr.laposte.blg.blinks.u17.service.OrganizationService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

@Data
@RestController
@CrossOrigin
@RequestMapping("/organization")
@Slf4j
@OpenAPIDefinition(tags = {@Tag(name = "Organsisation Controller")}, info = @Info(description = "Permet d'importer le référentiel des organisations SourceOrga"))

/**
 * Controleur exposant l'api des organisations/entités disponibles dans le
 * référentiel Source/orga et stocké dans notre base de données
 *
 */
public class OrganizationController {

    private final OrganizationService serviceEntity;
    private AtomicBoolean isRunning = new AtomicBoolean(false);

    /**
     * Opération permettant le lancement d'un import des organisations depuis
     * Source/Orga
     *
     * @param dateFrom Date permettant de sélectionner uniquement les organisations
     *                 modifiés après cette date. Si vide, on prend en compte toutes
     *                 les organisations.
     * @return Status de l'opération
     */
    @RequestMapping(value = "/import-update", method = RequestMethod.POST)
    @Operation(
            summary = "Import des Organisations",
            description = "permet d'appeler SourceOrga, de récupérer les organisations et ensuite de les enregistrer " +
                    "dans la table des organisations")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity importAndUpdateEntities(
            @RequestParam @DateTimeFormat(pattern = "dd-MM-yyyy") Optional<LocalDate> dateFrom) {
        log.info("Organization update starting ...");
        if (!isRunning.get()) {
            serviceEntity.importAndUpdateAllEntities(dateFrom)
                    .doOnTerminate(() -> isRunning.set(false))
                    .subscribe(importOrganizationReportDto -> {
                        log.info("End of update Organizations : \n " +
                                "success : {} \n" +
                                "warnings : {}", importOrganizationReportDto.getNbSuccess(), importOrganizationReportDto.getNbWarnings());
                    });
            return ResponseEntity.status(HttpStatus.ACCEPTED).body("Source Orga update is starting ...");


        } else {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("An SourceOrga update is already running. Please Wait ... ");
        }
    }

}
