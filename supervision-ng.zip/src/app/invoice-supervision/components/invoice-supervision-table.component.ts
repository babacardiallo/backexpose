import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { InvoiceSupervisionPage } from "../models/invoice-supervision-page";
import { InvoiceSupervisionTable } from "../models/invoice-supervision-table.model";
import { InvoiceSupervisionService } from "../service/invoice-supervision.service";
import { InvoiceSupervisionDetails } from "./invoice-supervision-details-popup/invoice-supervision-details-popup";
import { InvoiceSupervisionSearchPopupComponent } from "./invoice-supervision-search-popup/invoice-supervision-search-popup.component";
import { ModalService } from 'ngx-modal-ease';


@Component({
    selector: 'invoice-supervision-table',
    templateUrl: './invoice-supervision-table.component.html',
    styleUrls: ['./invoice-supervision-table.component.scss'],
    standalone: false
})

export class InvoiceSupervisionTableComponent implements OnInit {
    searchText: string = '';
    listInvoiceSupervision: InvoiceSupervisionTable[] = [];
    @ViewChild(DatatableComponent) invoiceSupervisionTable: DatatableComponent;
    invoiceSupervisionPage: InvoiceSupervisionPage = new InvoiceSupervisionPage();
    invoiceNumbers: string[] = [];
    lockPresentSort: any = true;
    isMultiSearch = false;
    M1_MODAL_PROPERTIES = {
        animation: 'enter-going-down',
        duration: '0.1s',
        easing: 'ease-out',
        padding: '1rem',
        width: '1900px',
        height: '100%'
    };
    inBlinks: boolean = true;
    outOfBlinks: boolean = true;

    constructor(private invoiceSupervisionService: InvoiceSupervisionService, private snackBar: MatSnackBar,  private datePipe: DatePipe, private modalService: ModalService) {

    }

    ngOnInit(): void {
    }

    startFilter(event: KeyboardEvent) {
        if (event.key === 'Enter') {
            if (this.searchText != null && this.searchText != '' && this.searchText.trim() != '') {
                this.invoiceNumbers = [this.searchText];
                this.isMultiSearch = false;
                this.inBlinks = true;
                this.outOfBlinks = true;
                this.getAllInvoiceSupervision(0, 10, "invoiceNumber", "desc", this.invoiceNumbers, this.inBlinks, this.outOfBlinks, this.isMultiSearch);
            }
        }
    }

    onPageChange(event: any) {
        this.getAllInvoiceSupervision(event.offset, 10, this.invoiceSupervisionTable.sorts[0].prop, this.invoiceSupervisionTable.sorts[0].dir, this.invoiceNumbers, this.inBlinks, this.outOfBlinks, this.isMultiSearch);
    }

    onSort(event: any) {      
        this.getAllInvoiceSupervision(this.invoiceSupervisionPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.invoiceNumbers, this.inBlinks, this.outOfBlinks, this.isMultiSearch);
        this.invoiceSupervisionTable.offset = this.invoiceSupervisionPage.currentPage!;
    }

    switchSearch(){
      this.invoiceSupervisionTable.sorts = [{prop : "invoiceNumber", dir: "desc"}];
      this.getAllInvoiceSupervision(0, 10, "invoiceNumber", "desc", this.invoiceNumbers, this.inBlinks, this.outOfBlinks, this.isMultiSearch);
    }

    getAllInvoiceSupervision(page: number, size: number, sort: string, order: string, invoiceNumbers: string[], inBlinks: boolean, outOfBlinks: boolean, isMultiSearch: boolean): Promise<any> {      
        return new Promise((resolve) => {
            if(invoiceNumbers.length < 1){
              return;
            }
            if (invoiceNumbers.length > 100) {
                this.snackBar.open("la recherche est limitée à 100 factures", 'Fermer', { duration: 5000 });
            } else {
                this.invoiceSupervisionService.getAllInvoiceSupervision(page, size, sort, order, invoiceNumbers, inBlinks, outOfBlinks, isMultiSearch).subscribe({
                    next: (response: any) => {
                        this.listInvoiceSupervision = response.content.map((data: any) => {
                            return {
                                idInvoice: data.idInvoice,
                                invoiceNumber: data.invoiceNumber,
                                created: this.formatDatePopup(data.created),
                                client: data.client,
                                billrunId: data.billrunId,
                                docaposteExportStatus: data.docaposteExportStatus,
                                infocaExportStatus: data.infocaExportStatus,
                                equinoxExportStatus: data.equinoxExportStatus,
                                docaposteExportDate: this.formatDatePopup(data.docaposteExportDate),
                                infocaExportDate: this.formatDatePopup(data.infocaExportDate),
                                equinoxExportDate: this.formatDatePopup(data.equinoxExportDate),
                                docaposteExportId: data.docaposteExportId,
                                infocaExportId: data.infocaExportId,
                                equinoxExportId: data.equinoxExportId,
                                present: data.present,
                                fromTableOnly: data.fromTableOnly
                            };
                        });
                        this.invoiceSupervisionPage.currentPage = response.number;
                        this.invoiceSupervisionPage.itemsOnPage = response.size;
                        this.invoiceSupervisionPage.totalItems = response.totalElements
                        this.invoiceSupervisionPage.totalPages = response.totalPages
                    },
                    complete: () => {
                        this.lockPresentSort = this.listInvoiceSupervision[0]?.fromTableOnly;
                        resolve(true);
                    },

                });
            }
        });
    }

    showPopup(row: InvoiceSupervisionTable, event: Event) {
        this.modalService
        .open(InvoiceSupervisionDetails, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
            height: this.M1_MODAL_PROPERTIES.height
          },
          data: {
            invoice: row,
          }
        })
        .then((response) => console.log(response));
         event.stopPropagation()
    }

    openSearchPopup(event: Event) {
        this.modalService
        .open(InvoiceSupervisionSearchPopupComponent, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
            top: '40%'
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
            height: "1200px"
          },
          data: {
            content: '',
          }
        })
        .then((response: any) => {
            if (response.data) {
                this.searchText = '';
                this.invoiceNumbers = response.data;
                const sortedList = new Set(this.invoiceNumbers);
                this.invoiceNumbers = [...sortedList];
                this.isMultiSearch = true;
                this.getAllInvoiceSupervision(0, 10, "invoiceNumber", "desc", this.invoiceNumbers, this.inBlinks, this.outOfBlinks, this.isMultiSearch);
            }
          });
         event.stopPropagation()

    }

    formatDatePopup(date: any) {
        return date ? this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
    }
}



