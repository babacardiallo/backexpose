package fr.laposte.blg.blinks.u12.service.establishment;

public class EstablishmentCommunicationException extends RuntimeException {

    public EstablishmentCommunicationException(String message) {
        super(message);
    }

    public EstablishmentCommunicationException(String message, Throwable cause) {
        super(message, cause);
    }
}
