insert into scheduler_params VALUES(
3,
'scheduler_purge',
'0 0 2 * * *',
null,
null,
'/opt/app-root/src/donnees/archives/export/',
1,
null,
null
);