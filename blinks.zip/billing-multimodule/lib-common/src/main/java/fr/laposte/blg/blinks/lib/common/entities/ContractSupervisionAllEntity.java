package fr.laposte.blg.blinks.lib.common.entities;

import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table ("contract_supervision_all")

public class ContractSupervisionAllEntity extends ContractSupervisionEntity {
    public ContractSupervisionAllEntity(String id, String contractNumber, Long contractId, Integer amendmentNumber, Integer revisionNumber,
                                        String status, String substatus, Long idContractVersion,  String type, String subtype, String opsCode, Long opsId,
                                        String opsLabel, Boolean isSynchronized, Instant lastDateSynchronization, Instant dateError, Instant firstErrorDate, Integer custAccNumber,
                                        Integer custAccNumberBeforeSynchronisation) {
        super(id, contractNumber, contractId, amendmentNumber, revisionNumber, status, substatus, idContractVersion, type, subtype, opsCode, opsId, opsLabel, isSynchronized, lastDateSynchronization, dateError, firstErrorDate, custAccNumber, custAccNumberBeforeSynchronisation);
    }

}
