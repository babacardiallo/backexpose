CREATE TABLE valued_offer_message (
    id_valued_offer_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_valued_offer INT UNSIGNED default null,
    message JSON,
    CONSTRAINT fk_valued_offer_message_valued_offer FOREIGN KEY (id_valued_offer) REFERENCES blg_contract_importer.valued_offer (id_valued_offer) ON DELETE CASCADE ON UPDATE RESTRICT
);