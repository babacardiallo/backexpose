import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { SeresTable } from '../models/seres-table.model';


@Injectable({
  providedIn: 'root',
})
export class SeresService {
  ngUnsubscribe$ = new Subject<void>();

  private criteria: string = '';

  constructor(private http: HttpClient) {
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }),
  }

  getListSeresByDate(page: number, size: number, sort: string, order: string, startDate: any, endDate: any, filter: string, status: string, errorsCode: [], noPrintableOnly: boolean): Observable<any> {
    let url = environment.API_SERES_ALL_BY_DATE + "?page=" + page + "&size=" + size + "&sort=" + sort + "&order=" + order + "&startDate=" + startDate + "&endDate=" + endDate + "&noPrintableOnly=" + noPrintableOnly;
    if (filter != '') {
      url = url + "&filter=" + filter
    }
    if (status != '') {
      url = url + "&status=" + status
    }
    if (errorsCode.length > 0) {
      errorsCode.forEach(err => {
        url = url + "&errorCodes=" + err;
      })
    }
    return this.http.get<any>(url, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getSeresDetails(id: number): Observable<any> {
    return this.http.get<SeresTable>(environment.API_SERES_DETAILS + id, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getSeresExport(startDate: any, endDate: any, filter: string, errorsCode: [], noPrintableOnly: boolean) {
    let url = environment.API_SERES_EXPORTED + "?startDate=" + startDate + "&endDate=" + endDate + "&noPrintableOnly=" + noPrintableOnly;
    if (filter != '') {
      url = url + "&filter=" + filter
    }
    if (errorsCode.length > 0) {
      errorsCode.forEach(err => {
        url = url + "&errorCodes=" + err;
      })
    }
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  getAllCodeErrorSeres(): Observable<any> {
    return this.http.get<any>(environment.API_GET_ALL_CODE_ERROR_SERES, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

}
