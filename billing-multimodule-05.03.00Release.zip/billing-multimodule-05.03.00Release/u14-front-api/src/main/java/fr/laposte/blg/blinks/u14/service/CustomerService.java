package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.CustomerDetailsSupervisionEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.*;
import fr.laposte.blg.blinks.u14.controller.dto.ContractVersionSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.CustomerPartialSupervisionDto;
import fr.laposte.blg.blinks.u14.controller.dto.CustomerSupervisionDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Service
public class CustomerService {

    private final CustomerSupervisionRepository customerRepository;
    private final CustomerDetailsSupervisionRepository customerDetailsSupervisionRepository;
    private final LegalPersonRepository legalPersonRepository;
    private final ContractSupervisionActivesRepository contractSupervisionActivesRepository;
    private final AddressRepository addressRepository;
    private final LegalPersonMessageRepository legalPersonMessageRepository;

    public CustomerService(CustomerSupervisionRepository customerRepository, ContractSupervisionAllRepository contractSupervisionRepository, CustomerDetailsSupervisionRepository customerDetailsSupervisionRepository, LegalPersonRepository legalPersonRepository, ContractSupervisionActivesRepository contractSupervisionActivesRepository, AddressRepository addressRepository, LegalPersonMessageRepository legalPersonMessageRepository) {
        this.customerRepository = customerRepository;
        this.customerDetailsSupervisionRepository = customerDetailsSupervisionRepository;
        this.legalPersonRepository = legalPersonRepository;
        this.contractSupervisionActivesRepository = contractSupervisionActivesRepository;
        this.addressRepository = addressRepository;
        this.legalPersonMessageRepository = legalPersonMessageRepository;

    }

    public Mono<Page<CustomerPartialSupervisionDto>> filterCustomer(boolean errors, Pageable pageable, String filter) {
        filter = "%" + filter + "%";
        if (errors) {
            return customerRepository.findAllByDateErrorIsNotNullAndCustAccNumberTextLikeOrDateErrorIsNotNullAndTypeLikeOrDateErrorIsNotNullAndMarketTypeLikeOrDateErrorIsNotNullAndNameLikeOrDateErrorIsNotNullAndBrandLike(pageable, filter, filter, filter, filter, filter)
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                            0L
                            )
                    ).concatMap(customerPartialSupervisionDto ->
                            addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                    .map(nbAddress -> {
                                        customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                        return customerPartialSupervisionDto;
                                    }))
                    .collectList()
                    .zipWith(customerRepository.countElementByCriteria(filter))
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        } else {
            return customerRepository.findAllByCustAccNumberTextLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(pageable, filter, filter, filter, filter, filter)
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                                    0L
                            )
                    ).concatMap(customerPartialSupervisionDto ->
                            addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                    .map(nbAddress -> {
                                        customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                        return customerPartialSupervisionDto;
                                    }))
                    .collectList()
                    .zipWith(customerRepository.countAllByCustAccNumberTextLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(filter))
                    .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
        }
    }

        public Flux<CustomerPartialSupervisionDto> getAllPartialCustomer () {
            return legalPersonRepository.getAllCustomers()
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                            0L
                            )
                    );
        }

        public Mono<CustomerPartialSupervisionDto> getOnePartialCustomer ( int coclico){
            return legalPersonRepository.getOneCustomer(coclico).map(customer -> new CustomerPartialSupervisionDto(
                            customer.getIdLegalPerson(),
                            customer.getCustAccNumber(),
                            customer.getType(),
                            customer.getMarketType(),
                            customer.getName(),
                            customer.getBrand(),
                            customer.isSynchro(),
                            customer.getDateLastSynchro(),
                            customer.getDateError(),
                    0L
                    )
            );
        }

        public Mono<CustomerSupervisionDto> getCustomerWithDetails (int coclico){
            return legalPersonRepository.findByCustAccNumber(coclico)
                    .flatMap(legalPersonEntity ->
                            Mono.zip(customerDetailsSupervisionRepository.findByCustAccNumber(coclico),
                                    legalPersonMessageRepository.findByIdLegalPerson(legalPersonEntity.getIdLegalPerson())))
                    .map(tuple2 -> {
                        CustomerDetailsSupervisionEntity customer = tuple2.getT1();
                        return new CustomerSupervisionDto(
                                customer.getSiret(),
                                customer.getLegalNatureCode(),
                                customer.getLegalNatureName(),
                                customer.getImplantationCode(),
                                customer.getVatNumber(),
                                tuple2.getT2().getLegalPersonJson(),
                                customer.getErrorMessage()
                        );
                    });
        }

        public Flux<ContractVersionSupervisionDto> getContractVersionByCustAccNumber ( int coclico){
            return contractSupervisionActivesRepository.findByCustAccNumberBeforeSynchronisation(coclico)
                    .map(contractSupervision -> new ContractVersionSupervisionDto(
                            contractSupervision.getContractNumber(),
                            contractSupervision.getAmendmentNumber(),
                            contractSupervision.getRevisionNumber(),
                            contractSupervision.getSubtype(),
                            contractSupervision.getIsSynchronized(),
                            contractSupervision.getLastDateSynchronization(),
                            contractSupervision.getFirstErrorDate(),
                            contractSupervision.getOpsCode()
                    ));
        }


        public Mono<Page<CustomerPartialSupervisionDto>> getAllCustomer ( boolean errors, Pageable pageable){
            if (errors) {
                return customerRepository.findAllByDateErrorIsNotNull(pageable)
                        .map(customer -> new CustomerPartialSupervisionDto(
                                        customer.getIdLegalPerson(),
                                        customer.getCustAccNumber(),
                                        customer.getType(),
                                        customer.getMarketType(),
                                        customer.getName(),
                                        customer.getBrand(),
                                        customer.isSynchro(),
                                        customer.getDateLastSynchro(),
                                        customer.getDateError(),
                                0L
                                )
                        ).concatMap(customerPartialSupervisionDto ->
                                addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                        .map(nbAddress -> {
                                            customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                            return customerPartialSupervisionDto;
                                        }))
                        .collectList()
                        .zipWith(customerRepository.countAllByDateErrorIsNotNull())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            } else {
                return customerRepository.findAllBy(pageable)
                        .map(customer -> new CustomerPartialSupervisionDto(
                                        customer.getIdLegalPerson(),
                                        customer.getCustAccNumber(),
                                        customer.getType(),
                                        customer.getMarketType(),
                                        customer.getName(),
                                        customer.getBrand(),
                                        customer.isSynchro(),
                                        customer.getDateLastSynchro(),
                                        customer.getDateError(),
                                0L
                                )
                        ).concatMap(customerPartialSupervisionDto ->
                        addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                .map(nbAddress -> {
                                    customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                    return customerPartialSupervisionDto;
                                }))
                        .collectList()
                        .zipWith(customerRepository.count())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            }


        }


    public Flux<CustomerPartialSupervisionDto> getAllFilteredExportedCustomers(boolean errors, String filter) {
        filter = "%" + filter + "%";
        if (errors) {
            return customerRepository.findAllByDateErrorIsNotNullAndCustAccNumberLikeOrDateErrorIsNotNullAndTypeLikeOrDateErrorIsNotNullAndMarketTypeLikeOrDateErrorIsNotNullAndNameLikeOrDateErrorIsNotNullAndBrandLike(filter, filter, filter, filter, filter)
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                                    0L
                            )
                    ).flatMap(customerPartialSupervisionDto ->
                            addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                    .map(nbAddress -> {
                                        customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                        return customerPartialSupervisionDto;
                                    }));
        } else {
            return customerRepository.findAllByCustAccNumberLikeOrTypeLikeOrMarketTypeLikeOrNameLikeOrBrandLike(filter, filter, filter, filter, filter)
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                                    0L
                            )
                    ).flatMap(customerPartialSupervisionDto ->
                            addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                    .map(nbAddress -> {
                                        customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                        return customerPartialSupervisionDto;
                                    }));
        }
    }


    public Flux<CustomerPartialSupervisionDto> getAllExportedCustomer (boolean errors){
        if (errors) {
            return customerRepository.findAllByDateErrorIsNotNull()
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                                    0L
                            )
                    ).flatMap(customerPartialSupervisionDto ->
                            addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                    .map(nbAddress -> {
                                        customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                        return customerPartialSupervisionDto;
                                    }));
        } else {
            return customerRepository.findAllBy()
                    .map(customer -> new CustomerPartialSupervisionDto(
                                    customer.getIdLegalPerson(),
                                    customer.getCustAccNumber(),
                                    customer.getType(),
                                    customer.getMarketType(),
                                    customer.getName(),
                                    customer.getBrand(),
                                    customer.isSynchro(),
                                    customer.getDateLastSynchro(),
                                    customer.getDateError(),
                                    0L
                            )
                    ).flatMap(customerPartialSupervisionDto ->
                            addressRepository.countByIdLegalPerson((long) customerPartialSupervisionDto.getIdLegalPerson())
                                    .map(nbAddress -> {
                                        customerPartialSupervisionDto.setNbAddresses(nbAddress);
                                        return customerPartialSupervisionDto;
                                    }));
        }


    }

    public Flux<Integer> getListCoclicoByLastExecutionDate(Instant lastExecutionDate){
        if(lastExecutionDate!=null){
            return legalPersonRepository.getListCoclicoByLastExecutionDate(lastExecutionDate);
        }
        return legalPersonRepository.getListCoclico();
    }

}
