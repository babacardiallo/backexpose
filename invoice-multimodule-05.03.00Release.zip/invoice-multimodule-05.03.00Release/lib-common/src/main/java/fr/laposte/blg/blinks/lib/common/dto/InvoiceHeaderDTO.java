package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Setter
@Getter
@JsonPropertyOrder({
        "invoiceNumber",
        "invoiceAttachmentNumber",
        "status",
        "isStatementFlag",
        "decentralizedStatementFlag",
        "dedicatedInvoiceFlag",
        "creditFlag",
        "refundableFlag",
        "downpaymentFlag",
        "printFlag",
        "invoiceDeliveryMode",
        "invoiceDeliveryMails",
        "pdfGeneratedByOpencell",
        "comment",
        "comment2",
        "parentContractNumber",
        "parentContractSubType",
        "avisPaiementFlag",
        "billingDate",
        "billingAmount",
        "vats",
        "scheduledPayment",
        "paymentCC"
})
public class InvoiceHeaderDTO {
    String invoiceNumber;
    String invoiceAttachmentNumber;
    String status;
    Boolean isStatementFlag;
    Boolean decentralizedStatementFlag;
    Boolean dedicatedInvoiceFlag;
    Boolean creditFlag;
    Boolean refundableFlag;
    Boolean downpaymentFlag;
    Boolean printFlag;
    String invoiceDeliveryMode;
    String invoiceDeliveryMails;
    Boolean pdfGeneratedByOpencell;
    String comment;
    String comment2;
    String parentContractNumber;
    String parentContractSubType;
    Boolean avisPaiementFlag;
    BillingDateDTO billingDate;
    BillingAmountDTO billingAmount;

    @JacksonXmlElementWrapper(localName = "vats")
    @JacksonXmlProperty(localName = "vat")
    List<VatDto> vats;

    @JacksonXmlElementWrapper(localName = "scheduledPayments")
    @JacksonXmlProperty(localName = "scheduledPayment")
    List<ScheduledPaymentDTO> scheduledPayment;

    PaymentCcDTO paymentCc;
}
