import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InvoiceSupervisionDetails } from './invoice-supervision-details-popup';


describe('InvoiceSupervisionDetails', () => {
    let component: InvoiceSupervisionDetails;
    let fixture: ComponentFixture<InvoiceSupervisionDetails>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [InvoiceSupervisionDetails]
        })
            .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(InvoiceSupervisionDetails);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
