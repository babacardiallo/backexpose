package fr.laposte.blg.blinks.u17.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u17.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u17.dto.RefcomDto;
import fr.laposte.blg.blinks.u17.dto.RefcomResponseDto;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@ConfigurationProperties(prefix = "fr.laposte.apim.refcom")
@Slf4j
@Data
public class RefcomCommunicationService {

    private String apiName;
    private Bucket bucket;

    private final ApimServiceImpl apimService;
    private final ObjectMapper objectMapper;



    public Flux<RefcomDto> fetchEntityCodes(LocalDate date, List<Long> coclicos) {
        bucket = Bucket.builder()
                .addLimit(Bandwidth.simple(20, Duration.ofSeconds(1)))
                .build();

        return Flux.fromIterable(coclicos)
                .flatMap(coclico -> {
                    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
                    queryParams.add("vue", "get_client_decisionnel_equinox");
                    queryParams.add("coclico", coclico.toString());
                    queryParams.add("dateConsultation", date.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
                    queryParams.add("_accept", "json");
                    log.info("QUERY PARAMS {}", queryParams);

                    // Instead of blocking, use the bucket's rate limiting
                    return Mono.defer(() -> {
                        // Consume from the bucket
                        bucket.asBlocking().consumeUninterruptibly(1);
                        return apimService.get(apiName, queryParams)
                                .flatMap(json -> mapToRefcomDto(json, coclico));
                    }).delayElement(Duration.ofMillis(60)); // Adjust the delay as needed
                }, 20); // This specifies the maximum concurrency
    }


    private Mono<RefcomDto> mapToRefcomDto(String json, Long coclico) {
        try {
            RefcomResponseDto apiResponse = objectMapper.readValue(json, RefcomResponseDto.class);
            if (apiResponse.getResult() != null && !apiResponse.getResult().isEmpty()) {
                return Flux.fromIterable(apiResponse.getResult()).next();
            } else {
                return Mono.just(new RefcomDto(String.valueOf(coclico), "", "","",""));
            }
        } catch (Exception e) {
            return Mono.error(e);
        }
    }

    public Flux<RefcomDto> fetchEntityCodesPerList(LocalDate date, List<Long> coclicos) {
        bucket = Bucket.builder()
                .addLimit(Bandwidth.simple(20, Duration.ofSeconds(1)))
                .build();

        return Flux.just(coclicos)
                .flatMap(coclico -> {
                    String coclicoParam = StringUtils.join(coclico, ",");
                    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
                    queryParams.add("vue", "get_client_decisionnel_equinox");
                    queryParams.add("coclico", coclicoParam);
                    queryParams.add("dateConsultation", date.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
                    queryParams.add("_accept", "json");
                    log.info("QUERY PARAMS {}", queryParams);

                    // Instead of blocking, use the bucket's rate limiting
                    return apimService.get(apiName, queryParams)
                            .flatMapMany(this::mapToRefcomDto);// Adjust the delay as needed
                }, 20); // This specifies the maximum concurrency
    }


    private Flux<RefcomDto> mapToRefcomDto(String json) {
        try {
            RefcomResponseDto apiResponse = objectMapper.readValue(json, RefcomResponseDto.class);
            if (apiResponse.getResult() != null && !apiResponse.getResult().isEmpty()) {
                return Flux.fromIterable(apiResponse.getResult());
            } else {
                return Flux.empty();
            }
        } catch (Exception e) {
            return Flux.error(e);
        }
    }
}
