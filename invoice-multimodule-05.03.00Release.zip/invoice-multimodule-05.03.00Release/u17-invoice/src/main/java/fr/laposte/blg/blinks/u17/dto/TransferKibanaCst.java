package fr.laposte.blg.blinks.u17.dto;

public class TransferKibanaCst {
    public static final String TRANSFERKEYS =  "transferKeys";

    private TransferKibanaCst(){

    }
}
