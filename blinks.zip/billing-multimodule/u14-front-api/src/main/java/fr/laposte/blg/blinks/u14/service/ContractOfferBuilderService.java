package fr.laposte.blg.blinks.u14.service;

import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ContractOfferBuilderService {

    public gkContractFullOutV1 buildContract(gkContractFullOutV1 contract) {
        if (contract.getContract().getOffer() != null) {
            if (contract.getContract().getOffer().getOfferCriteria() != null) {
                contract.getContract().getOffer().getOfferCriteria().forEach(offerCriteria -> {
                    if (offerCriteria.getOfferCriterionCriteria() != null) {
                        offerCriteria.setOfferCriterionCriteria(this.buildOfferCriteria(offerCriteria.getOfferCriterionCriteria()));
                    }
                });
            }
            if (contract.getContract().getOffer().getProducts() != null) {
                contract.getContract().getOffer().getProducts().forEach(offerProduct -> {
                    this.buildProduct(offerProduct);

                    if (offerProduct.getProductService() != null) {
                        offerProduct.getProductService().forEach(productService -> {
                            this.buildService(productService);
                        });
                    }
                });
            }
        }

        return contract;
    }

    public List<Object> buildOfferCriteria(List<Object> offerCriteriaList) {
        List<Object> result = new ArrayList<>();
        offerCriteriaList.forEach(o1 -> {
            if (o1 instanceof List) {
                List<OfferCriteria> subList = new ArrayList<>();
                ((List<?>) o1).forEach(o -> {
                    if (o instanceof Map) {
                        OfferCriteria offerCriteria = OfferCriteria.newBuilder()
                                .setOfferCriterionKey(((Map<String, String>) o).get("offerCriterionKey"))
                                .setOfferCriterionValueId(((Map<String, String>) o).get("offerCriterionValueId"))
                                .setOfferCriterionOccur(((Map<String, Integer>) o).get("offerCriterionOccur"))
                                .setOfferCriterionCriteria(((Map<String, List<Object>>) o).get("offerCriterionCriteria"))
                                .build();
                        subList.add(offerCriteria);
                    }
                });
                result.add(subList);
            }
        });
        return result;
    }

    public OfferProduct buildProduct(OfferProduct offerProduct) {
        if (offerProduct.getProductCriteria() != null) {
            offerProduct.getProductCriteria().forEach(productCriteria -> {
                if (productCriteria.getProductCriterionCriteria() != null) {
                    productCriteria.setProductCriterionCriteria(this.buildProductCriteria(productCriteria.getProductCriterionCriteria()));
                }
            });
        }
        return offerProduct;
    }

    public List<Object> buildProductCriteria(List<Object> productCriteriaList) {
        List<Object> result = new ArrayList<>();
        productCriteriaList.forEach(o1 -> {
            if (o1 instanceof List) {
                List<ProductCriteria> subList = new ArrayList<>();
                ((List<?>) o1).forEach(o -> {
                    if (o instanceof Map) {
                        ProductCriteria productCriteria = ProductCriteria.newBuilder()
                                .setProductCriterionKey(((Map<String, String>) o).get("productCriterionKey"))
                                .setProductCriterionValueId(((Map<String, String>) o).get("productCriterionValueId"))
                                .setProductCriterionOccur(((Map<String, Integer>) o).get("productCriterionOccur"))
                                .setProductCriterionCriteria(((Map<String, List<Object>>) o).get("productCriterionCriteria"))
                                .build();
                        subList.add(productCriteria);
                    }
                });
                result.add(subList);
            }
        });
        return result;
    }

    public ProductService buildService(ProductService productService) {
        if (productService.getServiceCriteria() != null) {
            productService.getServiceCriteria().forEach(serviceCriteria -> {
                if (serviceCriteria.getServiceCriterionCriteria() != null) {
                    serviceCriteria.setServiceCriterionCriteria(this.buildServiceCriteria(serviceCriteria.getServiceCriterionCriteria()));
                }
            });
        }
        return productService;
    }

    public List<Object> buildServiceCriteria(List<Object> serviceCriteriaList) {
        List<Object> result = new ArrayList<>();
        serviceCriteriaList.forEach(o1 -> {
            if (o1 instanceof List) {
                List<ServiceCriteria> subList = new ArrayList<>();
                ((List<?>) o1).forEach(o -> {
                    if (o instanceof Map) {
                        ServiceCriteria serviceCriteria = ServiceCriteria.newBuilder()
                                .setServiceCriterionKey(((Map<String, String>) o).get("serviceCriterionKey"))
                                .setServiceCriterionValueId(((Map<String, String>) o).get("serviceCriterionValueId"))
                                .setServiceCriterionOccur(((Map<String, Integer>) o).get("serviceCriterionOccur"))
                                .setServiceCriterionCriteria(((Map<String, List<Object>>) o).get("serviceCriterionCriteria"))
                                .build();
                        subList.add(serviceCriteria);
                    }
                });
                result.add(subList);
            }
        });
        return result;
    }
}
