alter table invoice rename column id to id_invoice;

CREATE TABLE invoice_message (
    id_invoice_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_invoice INT UNSIGNED default null,
    message JSON,
    CONSTRAINT fk_invoice_message_invoice FOREIGN KEY (id_invoice) REFERENCES blg_invoice.invoice (id_invoice) ON DELETE CASCADE ON UPDATE RESTRICT
);