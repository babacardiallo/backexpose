package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ExcelAdvDto {
    private String coclico;
    private String marketNumber;
    private String commentAdv;
    private String refAddressFactu;
    private String moyentPaiement;
    private String delaiPaiement;
    private String rum;
    private String bankName;
    private String numeroBonCommande;
    private String refSiteClientContractant;


}
