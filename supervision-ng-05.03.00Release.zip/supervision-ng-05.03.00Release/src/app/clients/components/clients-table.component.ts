import { DatePipe } from "@angular/common";
import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild } from "@angular/core";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { ModalService } from "ngx-modal-ease";
import { catchError, map, mapTo, merge, mergeAll, mergeMap, of, switchMap, toArray } from "rxjs";
import { ClientPage } from "../models/client.page";
import { ClientsTable } from "../models/clients-table.model";
import { ClientsService } from "../service/clients.service";
import { ClientsDetailsPopUpComponent } from "./clients-details-pop-up/clients-details-pop-up.component";

@Component({
    selector: 'clients-table-component',
    templateUrl: './clients-table.component.html',
    styleUrls: ['./clients-table.component.scss'],
    standalone: false
})

export class ClientsTableComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild(DatatableComponent) clientsTable: DatatableComponent;
    listClients: any[] = [];
    showOnlySyncErrors: boolean = false;
    clientPage: ClientPage = new ClientPage();
    searchText = '';
    M1_MODAL_PROPERTIES = {
        animation: 'enter-going-down',
        duration: '0.1s',
        easing: 'ease-out',
        padding: '1rem',
        width: '1900px',
        height: '100%'
    };



    constructor(private clientsService: ClientsService, private datePipe: DatePipe, private modalService: ModalService) { }
    ngOnInit(): void {

    }

    async ngAfterViewInit(): Promise<void> {
        await this.getAllClients(false, 0, 10, "custAccNumber", "desc", "");
    }


    ngOnDestroy(): void {
        this.clientsService.ngUnsubscribe$.next();
        this.clientsService.ngUnsubscribe$.complete();
    }


    getAllClients(errors: boolean, page: number, itemPerPage: number, sort: string, order: string, filter: string): void {
        this.clientsService.getAllClients(errors, page, itemPerPage, sort, order, filter)
            .pipe(
                map(response => {
                    this.clientPage = {
                        currentPage: response.pageable.pageNumber,
                        itemsOnPage: response.pageable.pageSize,
                        currentOffset: response.pageable.offset,
                        totalPages: response.totalPages,
                        totalItems: response.totalElements
                    }
                    return response.content;
                }),
                map((content: any) => {
                    const listIds: any = [];
                    content.forEach((element: any) => {
                        listIds.push(element.custAccNumber);
                    });
                    return this.clientsService.getCustomerInvoices(content, listIds);
                }),
                mergeAll(),
                mergeMap((clients: any) => {
                    return clients.map((client: any) => {
                        client.isSynchronized = client.synchro;
                        client.type = Boolean(JSON.parse(client.type)) ? "Public" : "Privé";
                        client.dateSynchronization = client.dateLastSynchro ? new Date(client.dateLastSynchro * 1000) : null;
                        client.dateError = client.dateError ? new Date(client.dateError * 1000) : null;
                        return client;
                    });
                }),
                toArray()
            ).subscribe(response => {

                this.listClients = response;
            });
    }




    /* getAllClients(errors: boolean, page: number, itemPerPage: number, sort: string, order: string, filter: string): void {
        this.clientsService.getAllClients(errors, page, itemPerPage,sort,order,filter)
            .pipe(
                map(response =>{
                    this.clientPage = {
                        currentPage: response.pageable.pageNumber,
                        itemsOnPage: response.pageable.pageSize,
                        currentOffset: response.pageable.offset,
                        totalPages: response.totalPages,
                        totalItems: response.totalElements
                    }
                    return response.content;
                }),
                mergeAll(),
                mergeMap((client: any) => {
                    client.isSynchronized = client.synchro;
                    client.type = client.type ? "Public" : "Privé";
                    client.dateSynchronization = client.dateLastSynchro ? new Date(client.dateLastSynchro * 1000) : null;
                    client.dateError = client.dateError ? new Date(client.dateError * 1000) : null;
                    this.clientsService.getCustomerNbInvoices(client).subscribe({
                       next: (value) => {
                           client.nbInvoices = value;
                           return this.clientsService.getCustomerNbAddresses(client);
                       },
                       error: (err) => {
                        return this.clientsService.getCustomerNbAddresses(client);
                       },
                    });
                    return this.clientsService.getCustomerNbAddresses(client);
                }),
                toArray()
            ).subscribe(response => {
                this.listClients = response;
            })

    } */

    showPopup(row: ClientsTable, event: Event) {
        this.modalService
        .open(ClientsDetailsPopUpComponent, {
          modal: {
            enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
          },
          overlay: {
            leave: 'fade-out 0.3s',
          },
          size: {
            padding: this.M1_MODAL_PROPERTIES.padding,
            width: this.M1_MODAL_PROPERTIES.width,
            height: this.M1_MODAL_PROPERTIES.height
          },
          data: {
            client: row
          }
        })
        .then((response) => console.log(response));
        event.stopPropagation();
    }

    showSyncErrors() {
        this.getAllClients(this.showOnlySyncErrors, 0, 10, "custAccNumber", "desc", "");
    }

    getRowClass = (row: ClientsTable) => {
        let className = "";
        if (row.dateError !== null) {
            className = "error_synch";
        }
        return className;
    };

    updateFilter(event: KeyboardEvent) {
        if (!event.target) {
            return null;
        }
        const val = (event.target as HTMLInputElement).value;
        if (event.key === 'Enter') {
            this.getAllClients(this.showOnlySyncErrors, 0, 10, "custAccNumber", "desc", val);
        }
    }

    formatDateTable(date: number) {
        return date ? this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
    }


    onPageChange(event: any) {
        this.getAllClients(this.showOnlySyncErrors, event.offset, 10, this.clientsTable.sorts[0].prop, this.clientsTable.sorts[0].dir, this.searchText);
    }

    onSort(event: any) {
        this.getAllClients(this.showOnlySyncErrors, this.clientPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.searchText);
        this.clientsTable.offset = this.clientPage.currentPage!;
    }


}
