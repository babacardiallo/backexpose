package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationSupervisionEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;

@Repository
public interface QueueSynchronizationSupervisionRepository extends ReactiveCrudRepository<QueueSynchronizationSupervisionEntity, Long> {

    Flux<QueueSynchronizationSupervisionEntity> findAllByAction(ActionEnum actionEnum, @Param("pageable") Pageable pageable);
    Mono<Long> countAllByAction(ActionEnum actionEnum);

    Flux<QueueSynchronizationSupervisionEntity> findAllBy(@Param("pageable") Pageable pageable);
    Mono<Long> countAllBy();

    Flux<QueueSynchronizationSupervisionEntity> findAllByActionInAndContractNumberLikeOrActionInAndOpsCodeLikeOrActionInAndCustAccNumberLike(List<ActionEnum> actionEnums1, String contractNumber, List<ActionEnum> actionEnums2, String opsCode, List<ActionEnum> actionEnums3, String custAccNumber, @Param("pageable") Pageable pageable);
    Mono<Long> countAllByActionInAndContractNumberLikeOrActionInAndOpsCodeLikeOrActionInAndCustAccNumberLike(List<ActionEnum> actionEnums1, String contractNumber, List<ActionEnum> actionEnums2, String opsCode, List<ActionEnum> actionEnums3, String custAccNumber);

    Flux<QueueSynchronizationSupervisionEntity> findAllByActionEqualsAndContractNumberLikeOrActionEqualsAndOpsCodeLikeOrActionEqualsAndCustAccNumberLike(ActionEnum action1, String contractNumber, ActionEnum action2, String opsCode, ActionEnum action3, String custAccNumber,  @Param("pageable") Pageable pageable);
    Mono<Long> countAllByActionEqualsAndContractNumberLikeOrActionEqualsAndOpsCodeLikeOrActionEqualsAndCustAccNumberLike(ActionEnum action1, String contractNumber, ActionEnum action2, String opsCode, ActionEnum action3, String custAccNumber);
}
