package fr.laposte.blg.blinks.u16.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.lib.common.dto.ReplayReportDto;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoice;
import fr.laposte.blg.blinks.lib.common.repositories.RejectedInvoiceRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
@RequiredArgsConstructor
@Data
@Slf4j
public class InvoiceReplayService {

    private final KafkaInvoiceReplayProducer producer;
    private final RejectedInvoiceRepository rejectedInvoiceRepository;
    private final ObjectMapper objectMapper;
    private final String purgeStatus = "Démarrage du purge";

    public Mono<ReplayReportDto> replayInvoices(List<String> invoiceNumbers){
        ReplayReportDto reportDto = new ReplayReportDto();
        reportDto.setNbTotal(invoiceNumbers.size());
        return run(rejectedInvoiceRepository.getAllByInvoiceNumbers(invoiceNumbers), reportDto);

    }

    public Mono<ReplayReportDto> replayAllRejectedInvoices(){
        ReplayReportDto reportDto = new ReplayReportDto();
        return run(rejectedInvoiceRepository.getAllRejectedInvoices(), reportDto)
                .zipWith(rejectedInvoiceRepository.countAllRejectedInvoices())
                .flatMap(tuple2 -> {
                    ReplayReportDto replayReportDto = tuple2.getT1();
                    replayReportDto.setNbTotal(tuple2.getT2());
                    return Mono.just(replayReportDto);
                });

    }

    private Mono<ReplayReportDto> run(Flux<RejectedInvoice> rejectedInvoiceFlux, ReplayReportDto reportDto){
        return rejectedInvoiceFlux
                .flatMap(rejectedInvoice -> {
                    Invoice invoice = new Invoice();
                    objectMapper.registerModule(new JavaTimeModule());
                    try {
                        invoice = objectMapper.readValue(rejectedInvoice.getInvoiceJson(), Invoice.class);
                    } catch (JsonProcessingException e) {
                        reportDto.getNbErrors().incrementAndGet();
                        reportDto.getMapErrors().put(rejectedInvoice.getInvoiceNumber(), e.getMessage());
                    }
                    return Mono.zip(Mono.just(rejectedInvoice), Mono.just(invoice));
                })
                .flatMap(tuple2 -> producer.sendInvoiceToTopic(tuple2.getT2()).thenReturn(tuple2.getT1())
                        .onErrorResume(t -> {
                            log.error("Error during the replay of the invoice {}", t.getMessage());
                            reportDto.getNbErrors().incrementAndGet();
                            reportDto.getMapErrors().put(tuple2.getT1().getInvoiceNumber(), t.getMessage());
                            return Mono.empty();
                        }))
                .flatMap(rejectedInvoice -> rejectedInvoiceRepository.updateAllByInvoiceNumber(rejectedInvoice.getInvoiceNumber()).thenReturn(rejectedInvoice))
                .doOnNext(s -> reportDto.getListSuccess().add(s.getInvoiceNumber()))
                .count()
                .map(invoiceReplayed -> {
                    reportDto.getNbSuccess().set(invoiceReplayed);
                    reportDto.setNbTotal(invoiceReplayed);
                    return reportDto;
                });

    }

    public Mono<String> purge(){
        return rejectedInvoiceRepository.purge().thenReturn(purgeStatus);
    }


}
