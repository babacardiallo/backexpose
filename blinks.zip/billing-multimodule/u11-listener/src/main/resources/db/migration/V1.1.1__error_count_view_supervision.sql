ALTER VIEW `offer_supervision` AS
    SELECT
        `vo`.`ops_code` AS `ops_code`,
        `ro`.`ops_label` AS `ops_label`,
        `ro`.`offer_activation_datetime` AS `offer_activation_date`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        (CASE
            WHEN (`c`.`contract_number` IS NOT NULL) THEN `c`.`contract_number`
        END) AS `contract_synch`,
        `cv`.`id_contract_version` AS `contract_version_synch`,
        (CASE
            WHEN (`er`.`workflow_step` LIKE 'CONTRACT_%') THEN `er`.`workflow_step`
        END) AS `error_listening`,
        (CASE
            WHEN (`er`.`workflow_step` LIKE '%SYNCHRONIZATION%') THEN `er`.`workflow_step`
        END) AS `error_synchronization`
    FROM
        ((((`contract_version` `cv`
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        JOIN `contract` `c` ON ((`cv`.`id_contract` = `c`.`id_contract`)))
        LEFT JOIN `error_log` `er` ON ((`c`.`contract_number` = `er`.`contract_number`)))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
    WHERE
        `vo`.`ops_code` IN (SELECT
                `offer_filter`.`ops_code`
            FROM
                `offer_filter`);