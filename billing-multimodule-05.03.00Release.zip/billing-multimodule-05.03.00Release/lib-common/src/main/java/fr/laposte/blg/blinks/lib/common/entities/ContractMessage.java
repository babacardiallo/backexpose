package fr.laposte.blg.blinks.lib.common.entities;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("contract_message")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ContractMessage {
    @Id
    @Column("id_contract_message")
    private Long idContractMessage;

    @Column("id_contract")
    private Long idContract;

    @Column("contract_information")
    private String contractInformation;
}
