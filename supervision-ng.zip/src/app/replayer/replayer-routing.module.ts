import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { environment } from '../../environments/environment';
import { AuthGuard } from '../auth/auth-guard.service';
import { ReplayerClientsComponent } from './components/replayer-contract/replayer-clients/replayer-clients.component';
import { ReplayerContractComponent } from "./components/replayer-contract/replayer-contract.component";
import { ReplayerComponent } from './replayer.component';

const routes: Routes = [
    {
        path: '',
        component: ReplayerComponent,
        children: [
            { path: 'replayClients', component: ReplayerClientsComponent, canActivate: [AuthGuard], data: { permissions: { only: ['ADMIN'],   } }},
            { path: 'replayContracts', component: ReplayerContractComponent, canActivate: [AuthGuard], data: { permissions: { only: ['ADMIN'],   } }},
        ]
    }
];
@NgModule({
    imports: [
        RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ReplayerRoutingModule { }
