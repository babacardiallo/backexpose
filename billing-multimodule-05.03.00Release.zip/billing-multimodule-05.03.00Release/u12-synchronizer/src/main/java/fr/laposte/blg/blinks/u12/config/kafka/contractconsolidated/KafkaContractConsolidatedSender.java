package fr.laposte.blg.blinks.u12.config.kafka.contractconsolidated;

import fr.laposte.bscc.billing.avro.billing.ContractConsolidated;
import jakarta.annotation.Resource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;

import java.util.Properties;

@Configuration
public class KafkaContractConsolidatedSender {

    @Resource(name = "kafkaContractConsolidatedSenderConf")
    Properties kafkaContractConsolidatedSenderConf;

    @Bean
    public KafkaSender<String, ContractConsolidated> contractConsolidatedKafkaSender() {
        SenderOptions<String, ContractConsolidated> basicSenderOptions = SenderOptions.create(kafkaContractConsolidatedSenderConf);
        basicSenderOptions.stopOnError(false);
        return KafkaSender.create(basicSenderOptions);
    }
}
