import { Component, Input, OnInit } from '@angular/core';
import { CalendarView } from 'angular-calendar';
import { SupervisionService } from '../../service/supervision.service';

@Component({
  selector: 'month-view',
  templateUrl: './month-view.component.html',
  styleUrl: './month-view.component.scss',
  standalone: false
})
export class MonthViewComponent implements OnInit {

  @Input() selected!: Date;

  coeurfinanceObject: any = {size: 0};
  equinoxObject: any = {size: 0};
  infocaObject: any = {size: 0};
  docaposteObject: any = {size: 0};
  expandedAccordionCoeurfinance: boolean = false;
  expandedAccordionEquinox: boolean = false;
  expandedAccordionInfoca: boolean = false;
  expandedAccordionDocaposte: boolean = false;
  constructor(private supervisionService: SupervisionService){

  }
  ngOnInit(): void {
    this.getMonthlyTreatment(this.selected);
  }

  getMonthlyTreatment(date: Date) {
    this.selected = date;
    this.supervisionService.getMonthlyMorningCheck(date.getFullYear(), date.getMonth() + 1)
      .pipe().subscribe(response => {
        this.coeurfinanceObject = response.COEURFINANCE;
        this.equinoxObject = response.EQUINOX;
        this.infocaObject = response.INFOCA;
        this.docaposteObject = response.DOCAPOSTE;
      });
  }

  openCoeurfinanceAcccordion() {
    this.expandedAccordionCoeurfinance = true;
  }

  closeCoeurfinanceAcccordion() {
    this.expandedAccordionCoeurfinance = false;
  }

  openEquinoxAcccordion() {
    this.expandedAccordionEquinox = true;
  }

  closeEquinoxAcccordion() {
    this.expandedAccordionEquinox = false;
  }

  openInfocaAcccordion() {
    this.expandedAccordionInfoca = true;
  }

  closeInfocaAcccordion() {
    this.expandedAccordionInfoca = false;
  }

  openDocaposteAcccordion() {
    this.expandedAccordionDocaposte = true;
  }

  closeDocaposteAcccordion() {
    this.expandedAccordionDocaposte = false;
  }
  getDisplayedMonth(): string {
    const displayedDate =  new Intl.DateTimeFormat('fr-FR', { month: 'long' }).format(this.selected) + " " + this.selected.getFullYear();
    return displayedDate;
  }

}
