package fr.laposte.blg.blinks.u11.mapper;

import fr.laposte.blg.blinks.lib.common.entities.MandateEntity;
import fr.laposte.blg.blinks.u11.listener.contract.dto.MandateDTO;
import org.springframework.stereotype.Component;

@Component
public class MandateMapper {

    public MandateEntity mandateToMandateEntity(MandateDTO newMandateFromKafka, MandateEntity mandateDb) {
        if (newMandateFromKafka == null) {
            return null;
        }
        mandateDb.setRum(newMandateFromKafka.getRum());
        mandateDb.setIban(newMandateFromKafka.getIban());
        mandateDb.setBic(newMandateFromKafka.getBic());
        mandateDb.setStatus(newMandateFromKafka.getStatus());
        return mandateDb;
    }
}
