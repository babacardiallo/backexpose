import fr.laposte.blg.blinks.lib.common.entities.SeresReplaySupervision;
import fr.laposte.blg.blinks.u17.dto.SeresReplayDto;
import fr.laposte.blg.blinks.u17.mapper.SeresReplayMapper;
import fr.laposte.blg.blinks.u17.mapper.SeresReplayMapperImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Instant;

@SpringBootTest(classes = {SeresReplayMapper.class, SeresReplayMapperImpl.class})
public class SeresReplayMapperTest {

    @Autowired
    private SeresReplayMapper seresReplayMapper;

    @Test
    void seresReplayEntityToSeresReplayDtoTest(){
        SeresReplaySupervision seresReplayEntity = new SeresReplaySupervision();
        seresReplayEntity.setId(1L);
        seresReplayEntity.setInvoiceNumber("PF01");
        seresReplayEntity.setErrorCode(1);
        seresReplayEntity.setErrorMessage("error");
        seresReplayEntity.setErrorDate(Instant.now());
        seresReplayEntity.setInvoiceUrl("url");
        SeresReplayDto seresReplayDto = this.seresReplayMapper.seresReplayEntityToSeresReplayDto(seresReplayEntity);
        Assertions.assertNotNull(seresReplayDto);
        Assertions.assertEquals(1L, seresReplayDto.getId());
        Assertions.assertEquals("PF01", seresReplayDto.getInvoiceNumber());
        Assertions.assertEquals(1, seresReplayDto.getErrorCode());
        Assertions.assertEquals("error", seresReplayDto.getErrorMessage());
        Assertions.assertEquals("url", seresReplayDto.getInvoiceUrl());
    }
}
