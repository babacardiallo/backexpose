import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { takeUntil } from "rxjs";
import { atLeastOne, atLeastOneChecked } from "../../../consts/consts";
import { ContractReplayParameters } from "../../models/contract-replay-unit.model";
import { ContratsTableService } from "../../service/contrats-table.service"


@Component({
    selector: 'contrats-replayer-pop-up-component',
    templateUrl: './contrats-replayer-pop-up.component.html',
    styleUrls: ['./contrats-replayer-pop-up.component.scss'],
    standalone: false
})

export class ContratsReplayerPopUpComponent implements OnInit {
    contract: any;
    dateDisabled: boolean;
    selectedDate: string;
    popupForm: UntypedFormGroup;
    contractReplayParameters: ContractReplayParameters = new ContractReplayParameters();
    name = 'ContratsReplayerPopUpComponent';

    constructor(private modalService: ModalService,private contractService: ContratsTableService, private formBuilder: UntypedFormBuilder, private datePipe: DatePipe, private snackBar: MatSnackBar) {
    }

    ngOnInit(): void {
        this.initForm();
        this.subscribeForm();
    }

    ngOnDestroy(): void {
        this.contractService.ngUnsubscribe$.next();
        this.contractService.ngUnsubscribe$.complete();
    }

    initForm() {
        this.popupForm = this.formBuilder.group({
            checkCreate: new UntypedFormControl(false),
            checkUpdate: new UntypedFormControl(false),
            date: new UntypedFormControl(''),
            dateDisabled: new UntypedFormControl(),
        }, {
            validator: [atLeastOne(Validators.required, ['date', 'dateDisabled']), atLeastOneChecked(['checkCreate', 'checkUpdate'])],
        });
    }

    subscribeForm() {
        this.popupForm.get('dateDisabled')?.valueChanges.pipe(takeUntil(this.contractService.ngUnsubscribe$)).subscribe({
            next: (disableBoolean) => {
                if (disableBoolean) {
                    this.popupForm.controls['date'].setValue(null, { emitEvent: false });
                    this.popupForm.get('date')?.disable();
                }
                else {
                    this.popupForm.get('date')?.enable();
                    this.popupForm.controls['dateDisabled'].setValue(null, { emitEvent: false });
                }
            }
        });

        this.popupForm.get('checkCreate')?.valueChanges.pipe(takeUntil(this.contractService.ngUnsubscribe$)).subscribe((checked) => {
            if (checked) {
                this.popupForm.controls['checkUpdate'].setValue(null, { emitEvent: false });
            }
        });

        this.popupForm.get('checkUpdate')?.valueChanges.pipe(takeUntil(this.contractService.ngUnsubscribe$)).subscribe((checked) => {
            if (checked) {
                this.popupForm.controls['checkCreate'].setValue(null, { emitEvent: false });
            }
        });
    }

    confirm(): void {
        this.contractReplayParameters.contractNumber = this.contract.contractNumber;
        this.contractReplayParameters.date = this.popupForm.get('date')?.value;
        this.contractReplayParameters.method = this.popupForm.get('checkCreate')?.value == true ? "create" : "update";
        this.replayContract();
        this.close();
    }

    replayContract() {
        if (this.contractReplayParameters.contractNumber) {
            if (!this.contractReplayParameters.date) {
                this.contractService.replayContractUnit(this.contractReplayParameters.contractNumber, this.contractReplayParameters.method)
                    .subscribe({
                        next: (response: any) => {
                            this.snackBar.open(JSON.stringify(response), 'Fermer', { duration: 5000 });
                        },
                        error: (response: any) => {
                            this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
                        }
                    });
            }
            else {
                this.contractService.replayContractUnit(this.contractReplayParameters.contractNumber, this.contractReplayParameters.method, this.formatDate(this.contractReplayParameters.date)!)
                    .subscribe({
                        next: (response: any) => {
                            this.snackBar.open(JSON.stringify(response), 'Fermer', { duration: 5000 });
                        },
                        error: (response: any) => {
                            this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
                        }
                    });
            }
        }
        else {
            console.error("Impossible de récupérer le numéro de contrat");
        }
    }

    formatDate(date: Date | string) {
        return this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm:ss', 'fr');
    }

    close(){
        this.modalService.close(this.name);
    }
}