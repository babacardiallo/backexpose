export class InvoicePage {
    currentPage?: number;
    itemsOnPage?: number;
    currentOffset?: number;
    totalPages?: number;
    totalItems?: number;
}