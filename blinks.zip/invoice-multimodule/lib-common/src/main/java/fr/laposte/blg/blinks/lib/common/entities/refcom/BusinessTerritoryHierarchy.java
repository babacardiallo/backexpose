package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_territory_hierarchy")
@Data
@Accessors(chain = true)

public class BusinessTerritoryHierarchy implements Disposable, Persistable<Long> {
    @Id
    @Column("business_territory_id")
    private Long businessTerritoryId;
    @Column("business_territory_type_id")
    private Integer businessTerritoryTypeId;
    @Column("business_entity_code")
    private String businessEntityCode;
    @Column("business_territory_start_date")
    private Instant businessTerritoryStartDate;
    @Column("business_territory_end_date")
    private Instant businessTerritoryEndDate;
    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessTerritoryStartDate) &&
                        businessTerritoryStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessTerritoryEndDate)
                                || businessTerritoryEndDate.isAfter(Instant.now())
                );
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessTerritoryId;
    }


    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
