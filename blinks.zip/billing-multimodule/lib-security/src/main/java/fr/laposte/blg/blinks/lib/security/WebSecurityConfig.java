package fr.laposte.blg.blinks.lib.security;

import fr.laposte.bscc.shared.jwt.filter.reactive.JwtAuthorizationWebFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UserDetailsRepositoryReactiveAuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

@Configuration
@EnableWebFluxSecurity
@Slf4j
public class WebSecurityConfig {

    @Autowired
    JwtAuthorizationWebFilter jwtAuthorizationWebFilter;

    @Value("${fr.laposte.security.api.user}")
    String user;

    @Value("${fr.laposte.security.api.mdp}")
    String mdp;
    @Value("${fr.laposte.security.cors.allowed-origins}")
    List<String> allowedOrigins;



    @Bean
    public SecurityWebFilterChain securityWebFilterChainByPass(ServerHttpSecurity http) {
        log.info("Configuration de la sécuité du module");
        http.csrf(Customizer.withDefaults())
                .authorizeExchange(exchange ->
                        exchange.pathMatchers(
                                        "/health/**",
                                        "/actuator/**",
                                        "/swagger-resources/**",
                                        "/configuration/**",
                                        "/swagger-ui.html",
                                        "/swagger-ui/**",
                                        "/csrf/token").permitAll()
                                .anyExchange().authenticated()
                )
                .cors(cors -> cors.configurationSource(request -> {
                    CorsConfiguration configuration = new CorsConfiguration();
                    configuration.setAllowedOrigins(allowedOrigins);
                    configuration.setAllowedMethods(List.of("*"));
                    configuration.setAllowedHeaders(List.of("*"));
                    configuration.setAllowCredentials(true);
                    return configuration;
                }))
                // Important Set Jwt filter before BasicAuth filter !!
                .addFilterBefore(jwtAuthorizationWebFilter, SecurityWebFiltersOrder.AUTHENTICATION)
                .addFilterAt(new ByPassJwtAuthFilter(authenticationManager()),
                        SecurityWebFiltersOrder.AUTHENTICATION);


        return http.build();
    }


    @Bean
    public UserDetailsRepositoryReactiveAuthenticationManager authenticationManager() {
        return new UserDetailsRepositoryReactiveAuthenticationManager(userDetailsService());
    }

    @Bean
    public MapReactiveUserDetailsService userDetailsService() {
        final UserDetails userDetails = User.withUsername(user)
                .password(passwordEncoder().encode(mdp))
                .roles("ADMIN", "CONS")
                .build();
        return new MapReactiveUserDetailsService(userDetails);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }



}
