package fr.laposte.blg.blinks.u18.service.impl;

import fr.laposte.blg.blinks.lib.common.repositories.FileSequenceRepository;
import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import fr.laposte.blg.blinks.u18.entity.MessageStatus;
import fr.laposte.blg.blinks.u18.repository.CustomerAccountRepository;
import fr.laposte.blg.blinks.u18.service.FileWriterService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class FileWriterServiceImpl implements FileWriterService {

    private final CustomerAccountRepository repository;
    private final FileSequenceRepository fileSequenceRepository;

    @Value("${module-config.paths.export.file-name}")
    private String fileName;

    @Value("${module-config.data.export.item-per-page}")
    private int itemPerPage;

    @Override
    public void exportPendingMessagesToNdjson(String outputFolder) {
        Pageable pageable = PageRequest.of(0, itemPerPage);
        Page<CustomerAccountMessage> messages = repository.findAllByStatus(MessageStatus.PENDING, pageable);

        if (messages.isEmpty()) {
            log.info("Aucun message à exporter.");
            return;
        }
        try {
            Path tempDir = Files.createTempDirectory(Path.of(outputFolder), "tmp_");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            DateTimeFormatter formatterDigits = DateTimeFormatter.ofPattern("yyyyMMdd");
            String timestamp = LocalDateTime.now().format(formatter);
            String timestamp8digits = LocalDateTime.now().format(formatterDigits);
            incrementCopilotMdSequence();
            String sequence = getCopilotMdCurrentSequence();
            String name = this.fileName + sequence + ".cp_." + timestamp;
            Path fileTempDir = Paths.get(String.valueOf(tempDir), name);
            if (!Files.exists(fileTempDir.getParent())) {
                Files.createDirectories(fileTempDir.getParent());
            }
            try(BufferedWriter writer = Files.newBufferedWriter(fileTempDir, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                List<CustomerAccountMessage> results = new ArrayList<>();
                writeMessagePerPage(writer, messages, results);
                repository.saveAll(results);
                log.info("Export NDJSON terminé : {} messages traités", messages.getTotalElements());
            }
            createArchive(Path.of(outputFolder), fileTempDir, timestamp8digits);

        } catch (IOException e) {
            log.error("Erreur lors de l'écriture du fichier NDJSON", e);

        }

    }

    private boolean writeMessageToNdjson(BufferedWriter writer, CustomerAccountMessage msg) {
        try {
            writer.write(msg.getMessageValue());
            writer.newLine();

            return true;
        } catch (Exception e) {
            log.error("Erreur lors de l'export du message ID={} : {}", msg.getId(), e.getMessage());//TODO: translate to english
            return false;
        }
    }

    private void writeMessagePerPage(BufferedWriter writer, Page<CustomerAccountMessage> messages, List<CustomerAccountMessage> results){
        List<CustomerAccountMessage> messageList = messages.getContent();
        messageList
                .forEach(msg -> {
                    boolean success = writeMessageToNdjson(writer, msg);
                    msg.setStatus(success ? MessageStatus.EXPORTED : MessageStatus.ERROR);
                });
        results.addAll(messageList);
        int pageNumber = messages.getNumber();
        int total = messages.getTotalPages();
        if(pageNumber+1<total) {
            Pageable pageable = PageRequest.of(pageNumber+1, itemPerPage);
            Page<CustomerAccountMessage> nextMessages = repository.findAllByStatus(MessageStatus.PENDING, pageable);
            writeMessagePerPage(writer, nextMessages, results);
        }
    }

    private String  getCopilotMdCurrentSequence(){
        Long currentSequence =  fileSequenceRepository.getCurrentSequenceForCopilotMdExport().block();
        return String.format("%04d", currentSequence);
    }

    private void incrementCopilotMdSequence(){
        Long currentSequence = fileSequenceRepository.getCurrentSequenceForCopilotMdExport().block();
        int sequence;
        assert currentSequence!=null;
        if(currentSequence==9999){
            sequence = 1;
        } else {
            sequence = Math.toIntExact(currentSequence) + 1;
        }
        fileSequenceRepository.incrementSequenceForCopilotMdExport(sequence).block();
    }

    private void createArchive(Path finalPath, Path tempFile, String timestamp8digits){
        String archiveFileName = this.fileName + "aaaa" + ".cp_." + timestamp8digits;
        Path archiveDir = Paths.get(String.valueOf(finalPath), archiveFileName);
        log.info("Début de la création de l'archive: {}", archiveDir.toAbsolutePath());
        try(FileOutputStream fos = new FileOutputStream(archiveDir.toFile());
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            GzipCompressorOutputStream gzos = new GzipCompressorOutputStream(bos);
            TarArchiveOutputStream taos = new TarArchiveOutputStream(gzos)) {
            taos.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
            TarArchiveEntry entry = new TarArchiveEntry(tempFile.toFile(), tempFile.getFileName().toString());
            entry.setSize(tempFile.toFile().length());
            taos.putArchiveEntry(entry);
            Files.copy(tempFile, taos);
            taos.closeArchiveEntry();
            log.info("Création du fichier archive: {} terminée avec succés", archiveDir.toAbsolutePath());
            log.info("Suppression du dossier et du fichier temporaire: {}", tempFile.toAbsolutePath());
            Files.walk(tempFile.getParent())
                    .sorted(Comparator.reverseOrder())
                    .forEach(path -> {
                        try {
                            Files.delete(path);
                        } catch (IOException e) {
                            log.error("erreur lors de la suppression du fichier temporaire: {}", tempFile.toAbsolutePath());
                        }
                    });
            log.info("Suppression du fichier temporaire: {} terminée avec succés", tempFile.toAbsolutePath());
        } catch (IOException e) {
            log.error("Erreur lors de la création de l'archive: {}", archiveDir.toAbsolutePath(), e);
        }
    }

}
