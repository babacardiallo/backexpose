package fr.laposte.blg.blinks.u14;

import fr.laposte.blg.blinks.lib.common.config.EnableBillingLibrary;
import fr.laposte.blg.blinks.lib.security.EnableBillingLibrarySecurity;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.config.EnableWebFlux;

/**
 * Classe Application du module u14.
 */
@SpringBootApplication(scanBasePackages = "fr.laposte.blg.blinks")
@OpenAPIDefinition(info = @Info(title = "u14-API", version = "1.0", description = "Documentation de l'api de billing"))
@RestController
@EnableWebFlux
@EnableBillingLibrary
@EnableBillingLibrarySecurity
public class U14 {

    public static void main(String[] args) {
        SpringApplication.run(U14.class, args);
    }

    @GetMapping("/")
    public ResponseEntity<String> get() {
        return ResponseEntity.ok("Welcome in the u14 api module of Paktole");
    }
}
