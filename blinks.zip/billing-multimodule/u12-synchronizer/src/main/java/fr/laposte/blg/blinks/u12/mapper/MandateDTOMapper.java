package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.MandateEntity;
import fr.laposte.blg.blinks.u12.dto.MandateDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface MandateDTOMapper {

    @Mapping(source = "rum", target = "rum")
    @Mapping(source = "iban", target = "iban")
    @Mapping(source = "bic", target = "bic")
    @Mapping(source = "status", target = "status")
    @Mapping(target = "idMandate", ignore = true)
    MandateEntity mandateDTOToMandateEntity(MandateDTO mandateDTO);
}
