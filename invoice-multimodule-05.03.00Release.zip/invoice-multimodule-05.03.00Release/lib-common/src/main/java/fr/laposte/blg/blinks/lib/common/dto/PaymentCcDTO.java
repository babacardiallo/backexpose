package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;

@Setter
@Getter
@Slf4j
@JsonPropertyOrder({
        "paymentCCDateTime",
        "paymentCCId",
        "amountCC"
})
public class PaymentCcDTO {
    @JsonProperty("paymentCCDateTime")
    Instant paymentCcDateTime;
    @JsonProperty("paymentCCId")
    String paymentCcId;
    @JsonProperty("amountCC")
    Double amountCc;
}
