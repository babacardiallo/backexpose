package fr.laposte.blg.blinks.u17.mapper;

import fr.laposte.blg.blinks.lib.common.entities.SeresReplaySupervision;
import fr.laposte.blg.blinks.u17.dto.SeresReplayDto;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.Instant;

@Mapper
public interface SeresReplayMapper {

    @Mapping(source = "errorDate", target = "errorDate", qualifiedByName = "convertReplayDateToString")
    @Mapping(source = "printFlag", target = "printable")
    SeresReplayDto seresReplayEntityToSeresReplayDto(SeresReplaySupervision seresReplaySupervision);


    @Named("convertReplayDateToString")
    default String getErrorDate(Instant errorDate){
        return DateUtil.yyyyMMddHHmmSSMorningCheck(errorDate);
    }

}
