package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_business_portfolio_com_changes")
@Data
@Accessors(chain = true)

public class BusinessPortfolioComChanges implements Disposable, Persistable<Long> {
    @Id
    @Column("business_portfolio_id")
    private Long businessPortfolioId;

    @Column("business_portfolio_start_date")
    private Instant businessPortfolioStartDate;

    @Column("business_portfolio_end_date")
    private Instant businessPortfolioEndDate;

    @Column("business_portfolio_type_id")
    private Integer businessPortfolioTypeId;

    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessPortfolioStartDate) &&
                        businessPortfolioStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessPortfolioEndDate)
                                || businessPortfolioEndDate.isAfter(Instant.now())
                );
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessPortfolioId;
    }

    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
