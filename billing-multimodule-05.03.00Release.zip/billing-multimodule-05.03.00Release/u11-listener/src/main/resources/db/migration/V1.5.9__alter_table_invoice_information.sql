ALTER TABLE blg_contract_importer.invoice_information
    ADD COLUMN payment_cc_id varchar(255),
    ADD COLUMN payment_cc_datetime datetime;