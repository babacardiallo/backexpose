package fr.laposte.blg.blinks.u11.listener.refops;


import fr.laposte.r5.uk.kafka.avro.viewoscar.Oscar;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Data
@Slf4j
@ConfigurationProperties(prefix = "fr.laposte.billing.listener.refops.canal-suez")
@ConditionalOnProperty(value = "fr.laposte.billing.listener.refops.activated", havingValue = "true")
public class RefopsListener{
    String kafkaTopic;
    // Groupe de consommation
    String kafkaGroupId;

    private final RefopsListenerService refopsListenerService;

    @Autowired
    public RefopsListener(RefopsListenerService refopsListenerService) {
        this.refopsListenerService = refopsListenerService;
    }

    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", kafkaTopic);
        log.info("Kafka groupId: {}", kafkaGroupId);
        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", kafkaTopic, kafkaGroupId);
    }

    @KafkaListener(groupId = "${fr.laposte.billing.listener.refops.canal-suez.kafka-group-id}",
            topics = "${fr.laposte.billing.listener.refops.canal-suez.kafka-topic}", containerFactory = "specificAvroValueConsumerFactory")
    public void onMessages(List<ConsumerRecord<String, Oscar>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} Refops from topic '{}'", total, kafkaTopic);
        AtomicInteger errorCount = new AtomicInteger(0);
        try {
            Flux.fromIterable(records)
                    .concatMap(message -> {
                        log.info("Record received: key={}, topic={}, partition={}, offset={}",
                                message.key(), message.topic(), message.partition(), message.offset());
                        return refopsListenerService.readRefopsOffer(message)
                                .onErrorResume(exception -> {
                                    errorCount.incrementAndGet();
                                    var errorMessage = String.format("Error on Refops Listener on offer number : %s", message.key());
                                    log.error(errorMessage, exception);
                                    return Mono.empty();
                                });
                    })
                    .then()
                    .block();
            if (errorCount.get() > 0) {
                log.warn("Batch processing failed with {} errors — retrying individually {} records ))",
                        errorCount.get(), total);
                retryIndividually(records, ack);
            } else {
                ack.acknowledge();
                log.info("Batch processed and acknowledged successfully");
            }
        } catch (Exception error) {
            log.error("Unexpected error during batch processing — retrying individually ({} record(s))", total, error);
            retryIndividually(records, ack);
        }
    }

    private void retryIndividually(List<ConsumerRecord<String, Oscar>> records, Acknowledgment ack) {
        Flux.fromIterable(records)
                .concatMap(message -> refopsListenerService.readRefopsOffer(message)
                        .doOnSuccess(c -> {
                            log.info("Refops key: {} is acknowledged successfully", message.key());
                            ack.acknowledge();
                        })
                        .doOnError(e -> log.error("Error processing Refops key={}", message.key(), e))
                        .onErrorResume(throwable -> Mono.empty())
                )
                .then()
                .block();
    }


}
