import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReplayQueueComponent } from './replay-queue.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: ReplayQueueComponent }
        ])],
    exports: [RouterModule]
})
export class ReplayQueueRoutingModule { }
