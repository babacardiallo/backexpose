import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplayerContractComponent } from './replayer-contract.component';

describe('ReplayerContractComponent', () => {
  let component: ReplayerContractComponent;
  let fixture: ComponentFixture<ReplayerContractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReplayerContractComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplayerContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
