package fr.laposte.blg.blinks.u17.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CalendarEventDto {
    private String title;
    private Date start;
    private Date end;
    private int color;
    private String status;
}
