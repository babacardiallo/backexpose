package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.u17.dto.StatDto;
import fr.laposte.blg.blinks.u17.service.StatService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/stat")
@Validated
@OpenAPIDefinition(tags = {@Tag(name = "StatController")})
public class StatController {

    private final StatService statService;

    @GetMapping("/totaux-invoice")
    @Operation(
            summary = "Totaux",
            description = "Service permettant de retourner le nombre de factures / avoirs en base," +
                    " et le nombre de factures exportées vers Doca / vers Infoca / vers Coeur Finance")
    Mono<StatDto[]> getTotaux() {
        return statService.getTotaux();
    }
}
