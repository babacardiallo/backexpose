import { NgModule } from '@angular/core';
import { SupervisionComponent } from "./supervision.component";
import { SupervisionRoutingModule } from "./supervision-routing.module";
import { SharedModule } from "../shared/shared.module";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { SupervisionTableComponent } from './components/supervision-table.component';
import { CdkAccordionModule } from "@angular/cdk/accordion";
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import {
  NguCarousel,
  NguCarouselDefDirective,
  NguCarouselNextDirective,
  NguCarouselPrevDirective,
  NguItemComponent
} from '@ngu/carousel';
import { NgxPermissionsModule } from 'ngx-permissions';



@NgModule({
  declarations: [SupervisionComponent, SupervisionTableComponent],
  imports: [
    SharedModule,
    NgxDatatableModule,
    SupervisionRoutingModule,
    CdkAccordionModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    NguCarousel,
    NguCarouselDefDirective,
    NguCarouselNextDirective,
    NguCarouselPrevDirective,
    NguItemComponent,
    NgxPermissionsModule.forChild()
  ],
  exports: [
    SupervisionComponent
  ]
})
export class SupervisionModule { }
