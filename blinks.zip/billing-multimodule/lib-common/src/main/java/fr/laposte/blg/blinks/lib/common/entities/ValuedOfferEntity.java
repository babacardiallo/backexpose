package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Data
@Table("valued_offer")
@Accessors(chain = true)
public class ValuedOfferEntity {
    @Id
    @Column("id_valued_offer")
    private Long idValuedOffer;
    @Column("ops_id")
    private String opsId;
    @Column("ops_code")
    @NotBlank
    private String opsCode;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ValuedOfferEntity that = (ValuedOfferEntity) o;
        return idValuedOffer.equals(that.idValuedOffer) &&
            opsId.equals(that.opsId) &&
            opsCode.equals(that.opsCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idValuedOffer, opsId, opsCode);
    }
}
