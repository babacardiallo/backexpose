package fr.laposte.blg.blinks.u12.okapi;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Data
@ConfigurationProperties(prefix = "fr.laposte.okapi")
public class OkapiProperties {
    private String host;
    private String key;
}
