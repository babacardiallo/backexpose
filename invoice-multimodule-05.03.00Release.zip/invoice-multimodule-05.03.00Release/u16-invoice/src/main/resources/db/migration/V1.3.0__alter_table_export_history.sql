ALTER TABLE export_history
ADD nb_excluded_invoices INT not null default 0,
ADD nb_failed_invoices INT not null default 0;