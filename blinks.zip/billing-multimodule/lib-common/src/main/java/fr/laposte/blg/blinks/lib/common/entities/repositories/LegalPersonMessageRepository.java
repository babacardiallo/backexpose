package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.LegalPersonMessage;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface LegalPersonMessageRepository extends ReactiveCrudRepository<LegalPersonMessage, Long> {

    @Query("SELECT legal_person_json from legal_person_message where id_legal_person = :id")
    Mono<String> getLegalPersonMessage(long id);

    Mono<LegalPersonMessage> findByIdLegalPerson(long id);
}
