import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.dto.*;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceMessageEntity;
import fr.laposte.blg.blinks.u17.util.ObjectMapperWithModules;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class MessageToInvoiceDtoMapperTest {
    public static final String CONTRACTS_KEY = "contracts";
    public static final String ACCOUNT_DETAILS_KEY = "accountDetails";
    public static final String INVOICE_CONTRACT_INFO_KEY = "invoiceContractInfo";
    public static final String LINKED_ACCOUNTS_KEY = "linkedAccounts";
    private final ObjectMapperWithModules objectMapper = new ObjectMapperWithModules();
    private InvoiceMessageEntity invoiceMessage;
    private InvoiceMessageEntity invoiceMessage2;

    @BeforeEach
    void init() throws IOException {


        invoiceMessage = InvoiceMessageEntity.builder()
                .idInvoiceMessage(1L)
                .idInvoice(1L)
                .message(Files.readString(Path.of("src/test/resources/remise_type_v9.json")))
                .build();

        invoiceMessage2 = InvoiceMessageEntity.builder()
                .idInvoiceMessage(1L)
                .idInvoice(1L)
                .message(Files.readString(Path.of("src/test/resources/remise2_type_v9.json")))
                .build();
    }

    @Test
    void whenMappingHeader_shouldBeOk() throws JsonProcessingException, JSONException {
        JSONObject mesJson = new JSONObject(invoiceMessage.getMessage());
        Object header = mesJson.get("header");
        HeaderDTO headerDTO = objectMapper.readValue(header.toString(), HeaderDTO.class);

        assertNotNull(headerDTO);
        assertNotNull(headerDTO.getTimestamp());
        assertNotNull(headerDTO.getProducer());
        assertNotNull(headerDTO.getBillrunCode());
    }

    @Test
    void whenMappingInvoiceHeader_shouldBeOk() throws JsonProcessingException, JSONException {
        JSONObject mesJson = new JSONObject(invoiceMessage.getMessage());
        Object invoiceHeader = mesJson.get("invoiceHeader");

        InvoiceHeaderDTO invoiceHeaderDTO = objectMapper.readValue(invoiceHeader.toString(), InvoiceHeaderDTO.class);
        assertNotNull(invoiceHeaderDTO);
        assertNotNull(invoiceHeaderDTO.getInvoiceNumber());
        assertNotNull(invoiceHeaderDTO.getInvoiceAttachmentNumber());
        assertNotNull(invoiceHeaderDTO.getStatus());
        assertEquals(false, invoiceHeaderDTO.getDecentralizedStatementFlag());
        assertNotNull(invoiceHeaderDTO.getDedicatedInvoiceFlag());
        assertNotNull(invoiceHeaderDTO.getCreditFlag());
        assertNotNull(invoiceHeaderDTO.getRefundableFlag());
        assertNotNull(invoiceHeaderDTO.getDownpaymentFlag());
        assertNotNull(invoiceHeaderDTO.getPrintFlag());
        assertNotNull(invoiceHeaderDTO.getComment());
        assertNotNull(invoiceHeaderDTO.getComment2());
        assertNotNull(invoiceHeaderDTO.getParentContractNumber());
        assertNotNull(invoiceHeaderDTO.getParentContractSubType());

        assertNotNull(invoiceHeaderDTO.getBillingDate().getStartDate()); // 01/06/2023 00:00:00
        assertNotNull(invoiceHeaderDTO.getBillingDate().getEndDate()); // 11/06/2023 00:00:00
        assertNotNull(invoiceHeaderDTO.getBillingDate().getCalculationDate()); // 11/06/2023 00:00:00
        assertNotNull(invoiceHeaderDTO.getBillingDate().getExpiryDate()); // 03/07/2023 00:00:00
        assertNotNull(invoiceHeaderDTO.getBillingDate().getPaymentDate()); // 03/07/2023 00:03:20
        assertNotNull(invoiceHeaderDTO.getBillingDate().getConsumptionRefDate()); // 11/06/2023 00:00:00
        assertNotNull(invoiceHeaderDTO.getBillingDate().getLastDepositDate()); // 03/07/2023 00:33:20

        assertNotNull(invoiceHeaderDTO.getBillingAmount().getExcludingTaxTotalAmount());
        assertNotNull(invoiceHeaderDTO.getBillingAmount().getExcludingTaxNetTotalAmount());
        assertNotNull(invoiceHeaderDTO.getBillingAmount().getTotalAmount());
        assertNotNull(invoiceHeaderDTO.getBillingAmount().getVatTotalAmount());
        assertNotNull(invoiceHeaderDTO.getBillingAmount().getVatAmountPaid());
        assertNotNull(invoiceHeaderDTO.getBillingAmount().getDiscountLineExcludingTaxAmount());
        assertNotNull(invoiceHeaderDTO.getBillingAmount().getAmountDue());

        assertNotNull(invoiceHeaderDTO.getVats());
        assertNotNull(invoiceHeaderDTO.getInvoiceDeliveryMode());
        assertNotNull(invoiceHeaderDTO.getInvoiceDeliveryMails());
        assertNotNull(invoiceHeaderDTO.getPdfGeneratedByOpencell());
    }

    @Test
    void whenMappingBillingAccount_shouldBeOk() throws JsonProcessingException, JSONException {
        JSONObject mesJson = new JSONObject(invoiceMessage.getMessage());
        Object billingAccount = mesJson.get("billingAccount");
        BillingAccountDTO billingAccountDTO = objectMapper.readValue(billingAccount.toString(), BillingAccountDTO.class);

        assertNotNull(billingAccountDTO.getCustAccNumber());
        assertNotNull(billingAccountDTO.getExtension());
        assertNotNull(billingAccountDTO.getPeriodicityCode());
        assertNotNull(billingAccountDTO.getSectorCode());
        assertNotNull(billingAccountDTO.getPeriodicityLabel());
        assertNotNull(billingAccountDTO.getPaymentMeanCode());
        assertNotNull(billingAccountDTO.getPaymentMeanLabel());
        assertNotNull(billingAccountDTO.getPaymentPeriodCode());
        assertNotNull(billingAccountDTO.getPaymentPeriodLabel());
        assertNotNull(billingAccountDTO.getSectorCode());
        assertNotNull(billingAccountDTO.getBillingAddress().getAddress());
        assertNotNull(billingAccountDTO.getBillingAddress().getName1());
        assertNotNull(billingAccountDTO.getBillingAddress().getAdd2());
    }

    @Test
    void whenMappingCustomer_shouldBeOk() throws JsonProcessingException, JSONException {
        JSONObject mesJson = new JSONObject(invoiceMessage.getMessage());
        Object customer = mesJson.get("customer");
        CustomerDTO customerDTO = objectMapper.readValue(customer.toString(), CustomerDTO.class);

        assertNotNull(customerDTO.getCustomerInformation().getCustAccNumber());
        assertNotNull(customerDTO.getCustomerInformation().getName());
        assertNotNull(customerDTO.getCustomerInformation().getBrandName());
        assertNotNull(customerDTO.getCustomerInformation().getTypeCode());
        assertNotNull(customerDTO.getCustomerInformation().getTypeLabel());
        assertNotNull(customerDTO.getCustomerInformation().getAdvPortfolioCode());
        assertNotNull(customerDTO.getCustomerInformation().getSiretCode());
        assertNotNull(customerDTO.getCustomerInformation().getCvatno());

        assertNotNull(customerDTO.getCustomerAddress().getAddressId());
        assertNotNull(customerDTO.getCustomerAddress().getName1());
        assertNotNull(customerDTO.getCustomerAddress().getAdd2());
    }

    @Test
    void whenMappingInvoiceContractInfo_shouldBeOk() throws JsonProcessingException, JSONException {
        JSONObject mesJson = new JSONObject(invoiceMessage.getMessage());
        JSONObject contract = (JSONObject) mesJson.getJSONArray(CONTRACTS_KEY).get(0);
        JSONObject invoiceContractInfo = contract.getJSONObject(INVOICE_CONTRACT_INFO_KEY);
        InvoiceContractInfoDTO invoiceContract = objectMapper.readValue(invoiceContractInfo.toString(), InvoiceContractInfoDTO.class);

        assertNotNull(invoiceContract);
        assertEquals("D-2362543-1", invoiceContract.getContractNumber());
        assertNotNull(invoiceContract.getContractVersionValidityStartDateTime());
        assertNotNull(invoiceContract.getContractVersionValidityEndDateTime());
        assertNotNull(invoiceContract.getContractType());
        assertNotNull(invoiceContract.getContractSubType());
        assertNotNull(invoiceContract.getOpsCode());
    }

    @Test
    void whenMappingLinkedAccounts_shouldBeOk() throws JsonProcessingException, JSONException {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dateService = LocalDate.parse("13/04/2023", format);
        JSONObject mesJson = new JSONObject(invoiceMessage.getMessage());
        JSONObject contract = (JSONObject) mesJson.getJSONArray(CONTRACTS_KEY).get(0);
        Object linkedAccountObject = contract.getJSONArray(LINKED_ACCOUNTS_KEY).get(0);
        LinkedAccountDTO linkedAccount = objectMapper.readValue(linkedAccountObject.toString(), LinkedAccountDTO.class);

        assertNotNull(linkedAccount);
        assertEquals("49280-103", linkedAccount.getConsumerAccountCode());
        assertEquals("test", linkedAccount.getClientAccountCode());
        assertEquals("test2", linkedAccount.getExternalReference());
        assertEquals(60.8, linkedAccount.getExcludingTaxTotalAmount());

        assertNotNull(linkedAccount.getAccountAddress());
        assertEquals(604967, linkedAccount.getAccountAddress().getAddressId());
        assertEquals("SOCIETE GENERALE", linkedAccount.getAccountAddress().getName1());
        assertEquals("DEPARTEMENT BOURSES ET CONSERVATION", linkedAccount.getAccountAddress().getAdd2());
        assertEquals("TITRES SGSS CCO CPT CTE", linkedAccount.getAccountAddress().getAdd3());
        assertEquals("32 RUE DU CHAMP DE TIR", linkedAccount.getAccountAddress().getAdd4());
        assertEquals("BP 81236", linkedAccount.getAccountAddress().getAdd5());
        assertEquals("44312 NANTES CEDEX 3", linkedAccount.getAccountAddress().getAdd6());
        assertEquals("44312 NANTES CEDEX 3", linkedAccount.getAccountAddress().getAdd7());

        assertNotNull(linkedAccount.getServiceEstablishments());
        assertEquals("205tt4505", linkedAccount.getServiceEstablishments().get(0).getRegateCode());
        assertEquals("testLabel", linkedAccount.getServiceEstablishments().get(0).getRegateLabel());
        assertEquals(60.73, linkedAccount.getServiceEstablishments().get(0).getExcludingTaxTotalAmount());

        InvoiceLineDTO lineDTO = linkedAccount.getInvoiceLines().get(0);
        assertNotNull(lineDTO);
        assertEquals(158058, lineDTO.getNumber());
        assertEquals(16, lineDTO.getQuantity());
        assertEquals(3.8, lineDTO.getUnitPrice());
        assertEquals(60.8, lineDTO.getExcludingTaxAmount());
        assertEquals(dateService, lineDTO.getServiceDate());
        assertEquals("205tt4505", lineDTO.getRegateCode());
    }

    @Test
    void whenMappingAccountDetails_shouldBeOk() throws JsonProcessingException, JSONException {
        JSONObject mesJson = new JSONObject(invoiceMessage2.getMessage());
        JSONObject details = (JSONObject) mesJson.getJSONArray(ACCOUNT_DETAILS_KEY).get(0);
        AccountDetailsDTO detailsDTO = objectMapper.readValue(details.toString(), AccountDetailsDTO.class);

        assertNotNull(detailsDTO);
        assertEquals("15", detailsDTO.getAccountInvoiceNumber());
        assertNotNull(detailsDTO.getAccountInvoiceCalculationDate());
        assertEquals(3.0, detailsDTO.getExcludingTaxNetTotalAmount());
        assertEquals(2.0, detailsDTO.getAmountDue());
    }
}
