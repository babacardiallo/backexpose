package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class ElectionKibanaLogDto {

    private String sequenceFichierElection;
    private String coclicoElection;
    private String marketNumberElection;
    private String contractNumberElection;
    private String actionElection;
    private String errorMessageElection;
}
