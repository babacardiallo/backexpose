ALTER TABLE error_log
    ADD COLUMN first_error_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP;