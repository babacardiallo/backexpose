import { AfterContentChecked, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { OffresTableService } from '../../service/offres-table.service';
import { OffresAjoutParameters } from '../../models/offres-ajouts-parameters.model';
import { DatePipe } from '@angular/common';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { takeUntil } from 'rxjs/operators'
import { OffresRefops } from '../../models/offres-refops.model';
import { atLeastOne } from '../../../consts/consts';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ModalService } from 'ngx-modal-ease';

@Component({
    selector: 'offres-ajout-pop-up-component',
    templateUrl: './offres-ajout-pop-up.component.html',
    styleUrls: ['./offres-ajout-pop-up.component.scss'],
    standalone: false
})

export class OffresAjoutPopUpComponent implements OnInit, OnDestroy, AfterContentChecked {
    offresAjoutParameters: OffresAjoutParameters = new OffresAjoutParameters();
    dateDisabled: boolean;
    selectedDate: string;
    popupForm: UntypedFormGroup;
    allRefopsOffer: OffresRefops[];
    validOffer: boolean = true;
    codeOps: string = '';
    disableSelection: boolean = false;
    name = 'OffresAjoutPopUpComponent';



    constructor(private offreService: OffresTableService, private datePipe: DatePipe, private formBuilder: UntypedFormBuilder, private cdr: ChangeDetectorRef, private modalService: ModalService) {
    }
    ngAfterContentChecked(): void {
        this.cdr.detectChanges();
    }

    ngOnInit(): void {
        this.initForm();
        this.subscribeForm();
        this.getListRefops();
    }
    ngOnDestroy(): void {
        this.offreService.ngUnsubscribe$.next();
        this.offreService.ngUnsubscribe$.complete();
    }

    initForm() {
        this.popupForm = this.formBuilder.group({
            codeOps: new UntypedFormControl(this.codeOps, [Validators.required, Validators.pattern("^[0-9]*$")]),
            date: new UntypedFormControl(''),
            dateDisabled: new UntypedFormControl(),
        }, { validator: atLeastOne(Validators.required, ['date', 'dateDisabled']) });
        if (this.disableSelection) {
            this.popupForm.get('codeOps')?.disable();
        } else {
            this.popupForm.get('codeOps')?.enable();
        }
    }

    subscribeForm() {
        this.validOffer = false;
        // setValue calls valueChanges par défaut, il faut mettre emitEvent à false pour éviter une boucle.
        this.popupForm.get('dateDisabled')?.valueChanges.pipe(takeUntil(this.offreService.ngUnsubscribe$)).subscribe({
            next: (disableBoolean) => {
                if (disableBoolean) {
                    this.popupForm.controls['date'].setValue(null, { emitEvent: false });
                    this.popupForm.get('date')?.disable();
                }
                else {
                    this.popupForm.get('date')?.enable();
                    this.popupForm.controls['dateDisabled'].setValue(null, { emitEvent: false });
                }
            }
        });
    }

    confirm(): void {
        this.offresAjoutParameters.codeOps = this.popupForm.get('codeOps')?.value;
        this.offresAjoutParameters.date = this.popupForm.get('date')?.value;
        if (this.offresAjoutParameters.date) {
            this.selectedDate = this.formatDate(this.offresAjoutParameters.date)!.toString();
        }
        this.callAddOffre();
        this.close(true);
    }

    callAddOffre(): void {
        if (this.offresAjoutParameters.codeOps) {
            if (!this.offresAjoutParameters.date || this.popupForm.get('dateDisabled')?.value) {
                let defaultDate = new Date();
                this.offreService.addOffreHttp(this.offresAjoutParameters.codeOps, this.formatDate(defaultDate)!).subscribe({
                });
            }
            else {
                this.offreService.addOffreHttp(this.offresAjoutParameters.codeOps, this.selectedDate).subscribe({
                });
            }
        }
        else {
            console.error("Aucun code OPS renseigné");
        }
    }

    getListRefops(): void {
        this.offreService.getAllRefops().subscribe({
            next: (response: any) => {
                this.allRefopsOffer = response.map((data: any) => {
                    return <OffresRefops>{
                        codeOps: data.opsCode,
                        nameOps: data.opsLabel,
                        activationDate: data.offerActivationDatetime
                    };
                })
            },
            complete: () => { },
        });

    }

    offerExists(): string {
        this.validOffer = false;
        if (!this.allRefopsOffer) {
            return "Erreur lors de la récupération des offres Refops."
        }
        if (this.popupForm.get('codeOps')?.value.length != 4 || !/^\d+$/.test(this.popupForm.get('codeOps')?.value)) {
            return "Entrez un code OPS à 4 chiffres.";
        }
        for (let i = 0; i < this.allRefopsOffer.length; i++) {
            if (this.popupForm.get('codeOps')?.value == this.allRefopsOffer[i].codeOps) {
                if (this.allRefopsOffer[i].activationDate != null) {
                    return "L'offre " + this.allRefopsOffer[i].nameOps + " a déjà été activée le " + this.formatDateRefops(this.allRefopsOffer[i].activationDate!);
                }
                this.validOffer = true;
                return this.allRefopsOffer[i].nameOps!;
            }
        }
        this.validOffer = true; // BILLING-1473 : activation offre possible même si non récupérée dans refops
        return "Cette offre n'existe pas ou aucun libellé trouvé pour cette offre";
    }

    formatDate(date: Date | string) {
        return this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm:ss', 'fr');
    }

    formatDateRefops(date: number) {
        /* We receive a timestamp as a number. 
        Date expects the number of milliseconds since the UNIX epoch, not since 1970, so we multiply the timestamp by 1000 to get the real date*/
        const dateFormated = new Date(date * 1000);
        return this.datePipe.transform(dateFormated, 'dd/MM/yyyy à HH:mm:ss', 'fr');
    }


    close(result: boolean) {
        this.modalService.close(result);
    }


}
