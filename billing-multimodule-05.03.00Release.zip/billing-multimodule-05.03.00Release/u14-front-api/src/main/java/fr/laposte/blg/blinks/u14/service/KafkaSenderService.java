package fr.laposte.blg.blinks.u14.service;

import MD.LatestValue.Address;
import MD.LatestValue.LegalPerson;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderRecord;

@Service
@Profile("sloc")
public class KafkaSenderService {

    private final KafkaSender<String, gkContractFullOutV1> contractKafkaSender;

    private final KafkaSender<String, LegalPerson> legalPersonKafkaSender;

    private final KafkaSender<String, Address> addressKafkaSender;

    private final ContractOfferBuilderService contractOfferBuilderService;

    public KafkaSenderService(KafkaSender<String, gkContractFullOutV1> contractKafkaSender, KafkaSender<String, LegalPerson> legalPersonKafkaSender, KafkaSender<String, Address> addressKafkaSender, ContractOfferBuilderService contractOfferBuilderService) {
        this.contractKafkaSender = contractKafkaSender;
        this.legalPersonKafkaSender = legalPersonKafkaSender;
        this.addressKafkaSender = addressKafkaSender;
        this.contractOfferBuilderService = contractOfferBuilderService;
    }

    public Mono<Void> send(gkContractFullOutV1 contract) {
        return contractKafkaSender.send(Mono.just(contract)
                        .map(this.contractOfferBuilderService::buildContract)
                        .map(message -> SenderRecord.create(new ProducerRecord<>("gk_contractFull_fakeLoc_v1", message.getContract().getContractInformation().getContractNumber().toString(), message), message)))
                .then();
    }

    public Mono<Void> send(LegalPerson legalPerson) {
        return this.legalPersonKafkaSender.send(Mono.just(legalPerson)
                        .map(message -> SenderRecord.create(new ProducerRecord<>("h3_mdLegalPersonLatestValues_out_v2", message.getId().toString(), message), message)))
                .then();
    }

    public Mono<Void> send(Address address) {
        return this.addressKafkaSender.send(Mono.just(address)
                        .map(message -> SenderRecord.create(new ProducerRecord<>("h3_mdLegalPersonAddressesLatestValues_out_v2", message.getRefpmAdressId().toString(), message), message)))
                .then();
    }
}
