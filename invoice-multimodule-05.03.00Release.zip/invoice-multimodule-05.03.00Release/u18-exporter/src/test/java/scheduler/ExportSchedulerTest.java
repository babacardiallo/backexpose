package scheduler;


import fr.laposte.blg.blinks.u18.scheduler.ExportScheduler;
import fr.laposte.blg.blinks.u18.service.impl.FileWriterServiceImpl;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;


import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExportSchedulerTest {

    @Mock
    private FileWriterServiceImpl fileWriterService;

    @Test
    void exportRunTest(){
        SchedulerParamsEntity updatedParams = new SchedulerParamsEntity();
        updatedParams.setIsEnabled(true);
        updatedParams.setSchedulerName("scheduler_export");
        updatedParams.setRetentionDays(1);
        ExportScheduler exportScheduler = new ExportScheduler(fileWriterService, updatedParams);
        doNothing().when(fileWriterService).exportPendingMessagesToNdjson(anyString());
        exportScheduler.run();
    }
}
