package fr.laposte.blg.blinks.u17.service;

import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportStatus;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import fr.laposte.blg.blinks.lib.common.entities.organization.CustomerProfitCenter;
import fr.laposte.blg.blinks.lib.common.entities.organization.OrganizationEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.organization.CustomerProfitCenterRepository;
import fr.laposte.blg.blinks.lib.common.utils.TrackExecutionTime;
import fr.laposte.blg.blinks.u17.apim.SSLContextConfig;
import fr.laposte.blg.blinks.u17.dto.RefcomDto;
import fr.laposte.blg.blinks.u17.util.DateUtil;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.DefaultUriBuilderFactory;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@ConfigurationProperties(prefix = "fr.laposte.customer")
@Slf4j
@Data
public class SourceOrganizationService {

    private String host;
    private String path;
    private String user;
    private String mdp;

    /**
     * Service permettant de récupérer le webClient customisé avec le support SSL
     *
     * @see {{@link SSLContextConfig#configureWebClientWithSsl()}
     */
    private final WebClient.Builder webClientBuilder;
    private final CustomerProfitCenterRepository customerProfitCenterRepository;
    private final ExportHistoryRepository exportHistoryRepository;
    private final RefcomCommunicationService refcomCommunicationService;
    private final OrganizationService organizationService;
    private final DateUtil dateUtil;
    private Instant startTime;
    private static final String DEFAULT_PROFIT_CENTER = "750854";
    private int fetchedCustomer = 0;
    private int updatedCustomerProfitCenter = 0;
    private Long idProcess = 0L;
    private static String PREFIX_BATCH_FETCH_CUSTOMER = "REFCOM_BATCH_FETCH_CUSTOMER: ";
    private static String PREFIX_BATCH_FETCH_ENTITY_CODE = "REFCOM_BATCH_FETCH_ENTITY_CODE: ";
    private static String PREFIX_BATCH_FETCH_FINAL_RESULT = "REFCOM_BATCH_FETCH_FINAL_RESULT: ";
    private static String PROCESS_ID_FIELD = "refComExportId";
    private static String FETCH_CUSTOMER_FIELD = "fetchedCustomerFromU14";
    private static String UPDATED_CUSTOMER_PROFIT_CENTER_FIELD = "updatedCustomerProfitCenter";
    private static String PROCESS_MESSAGE_FIElD = "refComProcessMessage";
    private static String PROCESS_REFCOM_CUSTOMER = "refComCoclicoUsed";
    private static String PROCESS_REFCOM_ENTITY_CODE = "refComEntityCode";
    private static String PROCESS_REFCOM_PROFIT_CENTER_FOUND = "refComProfitCenter";
    private static String USERNAME = "username";
    private static String PASSWORD = "password";




    @TrackExecutionTime
    public void fetchCustomer(){
        fetchedCustomer = 0;
        log.info(Markers.append(PROCESS_ID_FIELD, this.idProcess)
                , " === Début du traitement d'import des clients, ExportId: {}",this.idProcess);
        startTime = Instant.now();
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        log.info("QUERY PARAMS {}", queryParams);
        final int size = 32 * 1024 * 1024;
        final ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(size))
                .build();
        DefaultUriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory(host);
        uriBuilderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY);
        exportHistoryRepository.getLastExportedFileByTypeAndStatus(FileType.REFCOM_BATCH, null, ExportStatus.SUCCESS)
                .flatMap(exportHistoryEntity -> {
                    queryParams.add("lastExecutionDate", exportHistoryEntity.getDate().toString());
                    return host.contains("localhost") ?
                            fetchCustomerAndSave(strategies, uriBuilderFactory, true, queryParams, WebClient.builder())
                            : fetchCustomerAndSave(strategies, uriBuilderFactory, true, queryParams, webClientBuilder);
                }).switchIfEmpty(Mono.defer(() -> host.contains("localhost") ?
                        fetchCustomerAndSave(strategies, uriBuilderFactory, true, queryParams, WebClient.builder())
                        : fetchCustomerAndSave(strategies, uriBuilderFactory, true, queryParams, webClientBuilder)))
                .flatMap(result -> {
                    ExportHistoryEntity process = new ExportHistoryEntity();
                    process.setDate(Instant.now());
                    process.setExportDuration(null);
                    process.setComment("");
                    process.setExportStatus(ExportStatus.FAILED);
                    process.setFileType(FileType.REFCOM_BATCH);
                    process.setFileName("REFCOM_BATCH");
                    return exportHistoryRepository.save(process);
                })
                .doOnNext(result -> {
                    this.idProcess = result.getIdExport();
                    log.info(Markers.append(FETCH_CUSTOMER_FIELD, this.fetchedCustomer)
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                    .and(Markers.append(PROCESS_MESSAGE_FIElD, "Fin du traitement d'import des clients avec succès"))
                            , PREFIX_BATCH_FETCH_CUSTOMER + " === Fin du traitement d'import des clients, ExportId: {}, Nombre de clients ajoutés en base depuis U14: {}, {} ===",this.idProcess, this.fetchedCustomer);

                    log.info(Markers.append(PROCESS_ID_FIELD, this.idProcess)
                            , " === Début du traitement de mise à jour des centres de profit, ExportId: {}",this.idProcess);
                }).block();
    }

    @TrackExecutionTime
    public void fetchAndUpdateEntityCode(int choppedSize){
         this.updatedCustomerProfitCenter = 0;
         this.fetchCustomer();
         this.customerProfitCenterRepository.getAllCoclico()
                    .collectList()
                    .flatMap(coclicos -> fetchAndSaveEntityCode(LocalDate.now(), coclicos, choppedSize, true))
                    .flatMap(value -> {
                        log.info(Markers.append(UPDATED_CUSTOMER_PROFIT_CENTER_FIELD, this.updatedCustomerProfitCenter)
                                        .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                        .and(Markers.append(PROCESS_MESSAGE_FIElD, "Fin du traitement de mise à jour des centres de profit avec succès"))
                                , PREFIX_BATCH_FETCH_FINAL_RESULT + " === Fin du traitement de mise à jour des centres de profit, ExportId: {}, Nombre de clients mises à jour: {}, {} ===",this.idProcess, this.updatedCustomerProfitCenter);
                        return updateHistory(ExportStatus.SUCCESS, "Traitement effectué avec succés", startTime, value);
                    })
                    .onErrorResume(error -> {
                        log.error(Markers.append(UPDATED_CUSTOMER_PROFIT_CENTER_FIELD, this.updatedCustomerProfitCenter)
                                        .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                        .and(Markers.append(PROCESS_MESSAGE_FIElD, "Echec du traitement de mise à jour des centres de profit: " + error.getMessage()))
                                , PREFIX_BATCH_FETCH_FINAL_RESULT + " === Echec du traitement de mise à jour des centres de profit: " +  error.getMessage() + ", ExportId: {}, Nombre de clients mises à jour: {}, {} ===",this.idProcess, this.updatedCustomerProfitCenter);
                        return updateHistory(ExportStatus.FAILED, error.getMessage(), startTime, true);
                    }).block();

    }

    @TrackExecutionTime
    public void fetchAndUpdateEntityCodeForNullProfitCenter(int choppedSize){
         this.updatedCustomerProfitCenter = 0;
         this.fetchCustomer();
         this.customerProfitCenterRepository.getCoclicoWithNullProfitCenter()
                .collectList()
                .flatMap(coclicos -> fetchAndSaveEntityCode(LocalDate.now(), coclicos, choppedSize, true))
                .flatMap(value -> {
                    log.info(Markers.append(UPDATED_CUSTOMER_PROFIT_CENTER_FIELD, this.updatedCustomerProfitCenter)
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                    .and(Markers.append(PROCESS_MESSAGE_FIElD, "Fin du traitement de mise à jour des centres de profit avec succès"))
                            , PREFIX_BATCH_FETCH_FINAL_RESULT+ " === Fin du traitement de mise à jour des centres de profit, ExportId: {}, Nombre de clients mises à jour: {}, {} ===",this.idProcess, this.updatedCustomerProfitCenter);
                    return updateHistory(ExportStatus.SUCCESS, "Traitement effectué avec succés", startTime, value);
                })
                .onErrorResume(error -> {
                    log.error(Markers.append(UPDATED_CUSTOMER_PROFIT_CENTER_FIELD, this.updatedCustomerProfitCenter)
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                    .and(Markers.append(PROCESS_MESSAGE_FIElD, "Echec du traitement de mise à jour des centres de profit: " + error.getMessage()))
                            , PREFIX_BATCH_FETCH_FINAL_RESULT + " === Echec du traitement de mise à jour des centres de profit: " +  error.getMessage() + ", ExportId: {}, Nombre de clients mises à jour: {}, {} ===",this.idProcess, this.updatedCustomerProfitCenter);
                    return updateHistory(ExportStatus.FAILED, error.getMessage(), startTime, true);
                }).block();

    }

    @TrackExecutionTime
    public void fetchAndUpdateEntityCodeByDate(String referencedDate, int choppedSize){
         this.updatedCustomerProfitCenter = 0;
         this.fetchCustomer();
         this.customerProfitCenterRepository.getCoclicoOrderByLastDateOfUpdateAsc(referencedDate != null ? referencedDate:dateUtil.yyyyMMddDash(Instant.now()))
                .collectList()
                .flatMap(coclicos -> fetchAndSaveEntityCode(LocalDate.now(), coclicos, choppedSize, true))
                .flatMap(value -> {
                    log.info(Markers.append(UPDATED_CUSTOMER_PROFIT_CENTER_FIELD, this.updatedCustomerProfitCenter)
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                    .and(Markers.append(PROCESS_MESSAGE_FIElD, "Fin du traitement de mise à jour des centres de profit avec succès"))
                            , PREFIX_BATCH_FETCH_FINAL_RESULT+ " === Fin du traitement de mise à jour des centres de profit, ExportId: {}, Nombre de clients mises à jour: {}, {} ===",this.idProcess, this.updatedCustomerProfitCenter);
                    return updateHistory(ExportStatus.SUCCESS, "Traitement effectué avec succés", startTime, value);
                })
                .onErrorResume(error -> {
                    log.error(Markers.append(UPDATED_CUSTOMER_PROFIT_CENTER_FIELD, this.updatedCustomerProfitCenter)
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                    .and(Markers.append(PROCESS_MESSAGE_FIElD, "Echec du traitement de mise à jour des centres de profit: " + error.getMessage()))
                            , PREFIX_BATCH_FETCH_FINAL_RESULT + " === Echec du traitement de mise à jour des centres de profit: " +  error.getMessage() + ", ExportId: {}, Nombre de clients mises à jour: {}, {} ===",this.idProcess, this.updatedCustomerProfitCenter);
                    return updateHistory(ExportStatus.FAILED, error.getMessage(), startTime, true);
                }).block();



    }

    public Mono<Boolean> fetchCustomerAndSave(ExchangeStrategies strategies, DefaultUriBuilderFactory uriBuilderFactory, Boolean value, MultiValueMap<String, String> queryParams, WebClient.Builder builder) {
        return builder
                .exchangeStrategies(strategies)
                .uriBuilderFactory(uriBuilderFactory)
                .build()
                .get().uri(uriBuilder -> uriBuilder.
                        path(path).queryParams(queryParams).build())
                .headers(httpHeaders -> {
                    httpHeaders.set(USERNAME, user);
                    httpHeaders.set(PASSWORD, mdp);
                })
                .retrieve()
                .bodyToFlux(Integer.class)
                .retryWhen(Retry.backoff(5, Duration.ofMillis(500)).filter(throwable -> throwable instanceof WebClientResponseException.TooManyRequests))
                .flatMap(this::saveCustomer)
                .then(Mono.just(value))
                .doOnError(error -> {
                    log.error(Markers.append(FETCH_CUSTOMER_FIELD, this.fetchedCustomer)
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                                    .and(Markers.append(PROCESS_MESSAGE_FIElD, "Echec du traitement d'import des clients: " + error.getMessage()))
                            , PREFIX_BATCH_FETCH_CUSTOMER + " === Echec du traitement d'import des clients: "+ error.getMessage() +", ExportId: {}, Nombre de clients ajoutés en base depuis U14: {}, {} ===",this.idProcess, this.fetchedCustomer);
                })
                .onErrorMap(error -> new RuntimeException("Error while fetching customer " + error.getMessage(), error));
    }

    public Mono<CustomerProfitCenter> saveCustomer(Integer coclico) {
        return customerProfitCenterRepository.existsCustomerProfitCenterByCoclico(coclico)
                .flatMap(exists -> {
                    if(exists){
                       return Mono.empty();
                    } else {
                        fetchedCustomer++;
                        return customerProfitCenterRepository.save(CustomerProfitCenter.builder().coclico(coclico).build());
                    }
                });
    }

    public Mono<Boolean> fetchAndSaveEntityCode(LocalDate consultationDate, List<Long> coclicos, int choppedSize, Boolean value) {
        return Flux.fromIterable(chopped(coclicos, choppedSize !=0 ? choppedSize:100))
                .concatMap(clients -> refcomCommunicationService.fetchEntityCodesPerList(consultationDate, clients))
                .concatMap(refcomDto -> {
                    return Mono.zip(customerProfitCenterRepository.findByCoclico(Integer.parseInt(refcomDto.getCoclico())), Mono.just(refcomDto));
                })
                .map(tuple2 -> {
                    RefcomDto refcomDto = tuple2.getT2();
                    CustomerProfitCenter customerProfitCenter = tuple2.getT1();
                    customerProfitCenter.setEntityCode(refcomDto.getEntityCode());
                    if(refcomDto == null || refcomDto.getEntityCode()==null || refcomDto.getEntityCode().isBlank()){
                        customerProfitCenter.setProfitCenter(DEFAULT_PROFIT_CENTER);
                    }
                    customerProfitCenter.setUpdated(Instant.now());
                    return customerProfitCenter;
                })
                .flatMap(customerProfitCenter -> Mono.zip(Mono.just(customerProfitCenter),
                        organizationService.findByCode(customerProfitCenter.getEntityCode())
                                .switchIfEmpty(Mono.defer(() -> Mono.just(OrganizationEntity.builder().codeRegate(DEFAULT_PROFIT_CENTER).build())))))
                .map(tuple2 -> {
                    CustomerProfitCenter customerProfitCenter = tuple2.getT1();
                    customerProfitCenter.setProfitCenter(tuple2.getT2().getCodeRegate());
                    return customerProfitCenter;
                })
                .flatMap(customerProfitCenterRepository::save)
                .doOnNext(customerProfitCenter -> {
                    this.updatedCustomerProfitCenter++;
                    log.info(Markers.append(PROCESS_REFCOM_CUSTOMER, customerProfitCenter.getCoclico())
                                    .and(Markers.append(PROCESS_REFCOM_ENTITY_CODE, customerProfitCenter.getEntityCode()))
                                    .and(Markers.append(PROCESS_REFCOM_PROFIT_CENTER_FOUND, customerProfitCenter.getProfitCenter()))
                                    .and(Markers.append(PROCESS_ID_FIELD, this.idProcess))
                            , PREFIX_BATCH_FETCH_ENTITY_CODE + "Coclico: {}, EntityCode: {}, ProfitCenter: {}, ExportId: {}", customerProfitCenter.getCoclico(), customerProfitCenter.getEntityCode(), customerProfitCenter.getProfitCenter(), this.idProcess);
                })
                .onErrorMap(error -> new RuntimeException("Error while fetching entity code from APIM " + error.getMessage(), error))
                .then(Mono.just(value));
    }

    public Mono<Boolean> updateHistory(ExportStatus exportStatus, String message, Instant startTime, Boolean value){
        return exportHistoryRepository.findById(this.idProcess)
                .flatMap(exportHistoryEntity -> {
                    Instant endTime = Instant.now();
                    exportHistoryEntity.setDate(Instant.now());
                    exportHistoryEntity.setExportDuration(Duration.between(startTime, endTime).toMillis());
                    exportHistoryEntity.setComment(message);
                    exportHistoryEntity.setExportStatus(exportStatus);
                    exportHistoryEntity.setFileType(FileType.REFCOM_BATCH);
                    exportHistoryEntity.setFileName("REFCOM_BATCH");
                    exportHistoryEntity.setTransferStatus(TransferStatus.NO_FILE);
                    return exportHistoryRepository.save(exportHistoryEntity).thenReturn(value);
                });

    }
    public List<List<Long>> chopped(List<Long> initialList, int n){
        List<List<Long>> parts = new ArrayList<>();
        final int N = initialList.size();
        for (int i = 0; i < N; i += n) {
            parts.add(new ArrayList<>(
                    initialList.subList(i, Math.min(N, i + n)))
            );
        }
        return parts;
    }
}



