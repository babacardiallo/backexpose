package fr.laposte.blg.blinks.u12.service.mandate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u12.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u12.dto.MandateDTO;
import fr.laposte.blg.blinks.u12.service.customer.LegalPersonCommunicationException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

@ConfigurationProperties(prefix = "fr.laposte.apim.mandate")
@Data
@Slf4j
@Service
public class MandateServiceImpl implements MandateService {

    private String apiName;
    private String endpoint;

    private final ApimServiceImpl apimService;
    private final ObjectMapper objectMapper;

    @Autowired
    public MandateServiceImpl(ApimServiceImpl apimService, ObjectMapper objectMapper) {
        this.apimService = apimService;
        this.objectMapper = objectMapper;
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false);
    }

    @Override
    public Mono<MandateDTO> fetchMandate(String rum) {
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("rum", rum);

        return apimService.get(apiName + endpoint, queryParams)
            .switchIfEmpty(Mono.error(new LegalPersonCommunicationException("No mandate fetched from Mandates endpoint")))
            .flatMap(jsonResponse -> {
                log.debug("Retour APIM Mandates {}", jsonResponse);
                MandateDTO mandateDTO = null;
                try {
                    JsonNode jsonNode = objectMapper.readTree(jsonResponse);
                    mandateDTO = objectMapper.treeToValue(jsonNode, MandateDTO.class);
                } catch (JsonProcessingException e) {
                    return Mono.error(new LegalPersonCommunicationException("Response from Mandates api cannot be parsed", e));
                }
                return Mono.just(mandateDTO);
            });
    }
}
