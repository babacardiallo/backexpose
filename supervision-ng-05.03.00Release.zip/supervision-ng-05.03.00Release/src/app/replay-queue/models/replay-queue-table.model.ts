export class ReplayQueueTableModel {
    id?: number;
    idContract?: number;
    idLegalPerson?: number;
    dateSynchronizationExpected?: Date | number | string;
    action?: string;
    refcomReplay?: string;
    contractNumber?: string;
    opsCode?: string;
    custAccNumber?: string;
}