-- Création de la table référentiel des organisations. Elle sera alimenté à partir de source organisation.

CREATE TABLE blg_invoice.source_orga_organization
(
    `id`                 int(10)    NOT NULL AUTO_INCREMENT,
    `code`               varchar(6) NOT NULL,
    `code_regate`        varchar(6) NOT NULL,
    `date_creation`      datetime DEFAULT NULL,
    `date_modification`  datetime DEFAULT NULL,
    `date_desactivation` datetime DEFAULT NULL,
    `date_fermeture`     datetime DEFAULT NULL,
    PRIMARY KEY (id),
    CONSTRAINT unq_code UNIQUE (code)
);

