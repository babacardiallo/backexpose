package fr.laposte.blg.blinks.u12.service.customer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.u12.dto.AddressDTO;
import fr.laposte.blg.blinks.u12.dto.LegalPersonDTO;
import fr.laposte.blg.blinks.u12.okapi.OkapiServiceImpl;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Data
@ConfigurationProperties(prefix = "fr.laposte.okapi.legal-person")
@ConditionalOnProperty(value = "fr.laposte.okapi.legal-person.service", havingValue = "true")
@Slf4j
@Primary
public class LegalPersonCommunicationServiceImpl implements LegalPersonCommunicationService {

    private String apiName;
    private String endpoint;

    private final OkapiServiceImpl okapiService;
    private final ObjectMapper objectMapper;


    @Autowired
    public LegalPersonCommunicationServiceImpl(OkapiServiceImpl okapiService, ObjectMapper objectMapper) {
        this.okapiService = okapiService;
        this.objectMapper = objectMapper;
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, false);
    }

    @Override
    public Mono<LegalPersonDTO> fetchLegalPerson(int coclico) {
        String graphqlQuery = """
                    query legalPersonData($custAccNumber: String!) {
                      legalPersonView(
                        legalPersonViewCriteria: {
                          custAccNumber: $custAccNumber
                        }
                      ) {
                        paging {
                          totalResults
                        }
                        data {
                           custAccNumber
                           compName
                           brandName
                           custTypeCode
                           active
                           establishZoneCode
                           marketingTypeCode
                           cvatno
                           siret
                           email
                           legalNatureCode
                           legalNatureName
                           legalPersonBillingTypology
                        }
                      }
                      legalPersonAddress(
                        addressCriteria: {
                          custAccNumber: $custAccNumber
                        }
                      ) {
                        paging {
                          totalResults
                        }
                        data {
                            refpmAddressId
                            custAccNumber
                            creationDateTime
                            modificationDateTime
                            add1
                            add2
                            add3
                            add4
                            add5
                            add6
                            add7
                            addressType
                        }
                        errors {
                          code
                          message
                        }
                      }
                    }
                """;

        Map<String, Object> variables = new HashMap<>();
        variables.put("custAccNumber", Integer.toString(coclico));

        return okapiService.get(apiName + endpoint, graphqlQuery, variables)
                .switchIfEmpty(Mono.error(new LegalPersonCommunicationException("No legal person fetched from LegalPersonView endpoint")))
                .flatMap(jsonResponse -> {
                    log.debug("Retour Okapi LegalPersonView {}", jsonResponse);
                    LegalPersonDTO legalPersonDTO = new LegalPersonDTO();
                    try {
                        JsonNode rootNode = objectMapper.readTree(jsonResponse).path("data");

                        JsonNode legalPersonViewNode = rootNode.path("legalPersonView").path("data");
                        if (legalPersonViewNode.isArray() && legalPersonViewNode.size() == 1) {
                            legalPersonDTO = objectMapper.treeToValue(legalPersonViewNode.elements().next(), LegalPersonDTO.class);
                        } else if (legalPersonViewNode.isArray() && legalPersonViewNode.size() > 1) {
                            return Mono.error(new LegalPersonCommunicationException("Response from LegalPerson contains more than one customer"));
                        } else {
                            return Mono.error(new LegalPersonCommunicationException("Response from LegalPerson api is empty"));
                        }
                        JsonNode legalPersonAddressNode = rootNode.path("legalPersonAddress").path("data");
                        List<AddressDTO> addresses = objectMapper.readerForListOf(AddressDTO.class).readValue(legalPersonAddressNode);
                        List<AddressDTO> filteredAddresses = addresses.stream()
                                .filter(address -> !"SIEGE".equals(address.getAddressType()))
                                .collect(Collectors.toList());

                        legalPersonDTO.setAddresses(filteredAddresses);
                        validateRequiredFields(legalPersonDTO);

                    } catch (JsonProcessingException e) {
                        return Mono.error(new LegalPersonCommunicationException("Response from LegalPerson api cannot be parsed.", e));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    return Mono.just(legalPersonDTO);
                });
    }

    private void validateRequiredFields(LegalPersonDTO legalPersonDTO) {
        if (legalPersonDTO.getActive() == null) {
            throw new LegalPersonCommunicationException("Field 'active' is missing");
        }
        if (legalPersonDTO.getCustAccNumber() == null) {
            throw new LegalPersonCommunicationException("Field 'custAccNumber' is missing");
        }
        if (legalPersonDTO.getCustTypeCode() == null) {
            throw new LegalPersonCommunicationException("Field 'custTypeCode' is missing");
        }
        if (legalPersonDTO.getEstablishZoneCode() == null) {
            throw new LegalPersonCommunicationException("Field 'establishZoneCode' is missing");
        }
        if (legalPersonDTO.getAdresses() != null) {
            for (int i = 0; i < legalPersonDTO.getAdresses().size(); i++) {
                AddressDTO address = legalPersonDTO.getAdresses().get(i);
                if (address.getName1() == null) {
                    throw new LegalPersonCommunicationException("Field 'name1' (add1) is missing in address number " + address.getAddressId());
                }
            }
        }
    }

}
