package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonRootName("Docaposte")
public class DocaposteDto {

    @JacksonXmlElementWrapper(localName = "invoices")
    @JacksonXmlProperty(localName = "invoice")
    List<InvoiceDTO> invoices;
}
