package fr.laposte.blg.blinks.lib.common.repositories.organization;

import fr.laposte.blg.blinks.lib.common.entities.organization.CustomerProfitCenter;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CustomerProfitCenterRepository extends ReactiveCrudRepository<CustomerProfitCenter, Long> {

    Mono<Boolean> existsCustomerProfitCenterByCoclico(Integer coclico);

    Mono<CustomerProfitCenter> findByCoclico(Integer coclico);

    @Query("SELECT coclico from customer_profit_center WHERE entity_code IS NULL OR entity_code = ''")
    Flux<Long> getCoclicoWithNullEntityCode();

    @Query("SELECT coclico from customer_profit_center WHERE profit_center IS NULL OR profit_center = ''")
    Flux<Long> getCoclicoWithNullProfitCenter();

    @Query("SELECT coclico from customer_profit_center WHERE updated < :date ORDER BY updated ASC")
    Flux<Long> getCoclicoOrderByLastDateOfUpdateAsc(String date);

    @Query("SELECT profit_center from customer_profit_center where coclico = :coclico")
    Mono<String> getProfitCenterByCoclico(Integer coclico);

    @Query("SELECT coclico from customer_profit_center")
    Flux<Long> getAllCoclico();

}
