package fr.laposte.blg.blinks.u16;

import fr.laposte.blg.blinks.lib.security.EnableInvoiceLibrarySecurity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.annotation.PostConstruct;

/**
 * Classe Application du module u16.
 */
@SpringBootApplication(scanBasePackages = "fr.laposte.blg.blinks")
@Slf4j
@EnableR2dbcRepositories(basePackages = "fr.laposte.blg.blinks.lib.common.repositories")
@EnableInvoiceLibrarySecurity
public class U16Application {

    public static void main(String[] args) {
        SpringApplication.run(U16Application.class, args);
    }

    @PostConstruct
    public void init() {
        log.info("USER DIR {} ", System.getProperty("user.dir"));
    }

    @GetMapping("/")
    public ResponseEntity<String> get() {
        return ResponseEntity.ok("Welcome in the u16 module of Factura");
    }
}
