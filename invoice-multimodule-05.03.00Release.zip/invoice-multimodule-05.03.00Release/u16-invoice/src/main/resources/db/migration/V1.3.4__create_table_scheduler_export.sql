CREATE table export_process
(
id  int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
min_id int UNSIGNED,
max_id int UNSIGNED,
execution_date datetime,
file_type ENUM ('DOCAPOSTE','INFOCA', 'EQUINOX'),
export_process_status ENUM ('NEW', 'RUNNING', 'SUCCESS', 'FAILED'),
error_code VARCHAR(255) default NULL,
error_message TEXT default NULL
);
