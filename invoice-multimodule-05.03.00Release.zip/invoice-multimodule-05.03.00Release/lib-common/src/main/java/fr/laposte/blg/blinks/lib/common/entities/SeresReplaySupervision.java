package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;


@Table("seres_replay_supervision")
@Data
public class SeresReplaySupervision {
    @Id
    @Column("id")
    private Long id;

    @Column("invoice_number")
    private String invoiceNumber;

    @Column("error_date")
    private Instant errorDate;

    @Column("error_code")
    private Integer errorCode;

    @Column("error_message")
    private String errorMessage;

    @Column("invoice_url")
    private String invoiceUrl;

    @Column("print_flag")
    private String printFlag;

}

