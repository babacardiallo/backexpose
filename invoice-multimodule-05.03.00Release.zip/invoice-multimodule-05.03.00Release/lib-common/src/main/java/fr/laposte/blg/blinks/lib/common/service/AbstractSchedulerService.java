package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

@Slf4j
public abstract class AbstractSchedulerService {

    protected final TaskScheduler scheduler;
    protected final SchedulerParamsRepository schedulerParamsRepository;
    protected final String moduleName;
    protected final Map<String, ScheduledFuture<?>> scheduledTasks = new ConcurrentHashMap<>();

    protected AbstractSchedulerService(TaskScheduler scheduler, SchedulerParamsRepository schedulerParamsRepository, String moduleName) {
        this.scheduler = scheduler;
        this.schedulerParamsRepository = schedulerParamsRepository;
        this.moduleName = moduleName;
    }

    protected void initializeSchedulers() {
        schedulerParamsRepository.findAllByIsEnabledAndModule(true, moduleName)
                .subscribe(this::scheduleTask);
    }

    protected abstract Runnable createTask(SchedulerParamsEntity schedulerParamsEntity);

    protected void scheduleTask(SchedulerParamsEntity schedulerParamsEntity) {
        if (!moduleName.equals(schedulerParamsEntity.getModule())) {
            log.debug("Skipping scheduler {} as it belongs to module {} but current module is {}",
                     schedulerParamsEntity.getSchedulerName(), schedulerParamsEntity.getModule(), moduleName);
            return;
        }

        Runnable task = createTask(schedulerParamsEntity);
        ScheduledFuture<?> future = scheduler.schedule(task, new CronTrigger(schedulerParamsEntity.getCronExpression()));
        scheduledTasks.put(schedulerParamsEntity.getId().toString(), future);
        log.info("Scheduled task started for task : {}", schedulerParamsEntity.getSchedulerName());
    }

    public Mono<SchedulerParamsEntity> updateTask(Long id, SchedulerParamsEntity schedulerParamsEntity) {
        return schedulerParamsRepository.findById(id)
                .filter(existing  -> moduleName.equals(existing.getModule()))
                .flatMap(existing -> {
                    existing.setCronExpression(schedulerParamsEntity.getCronExpression());
                    existing.setExportPath(schedulerParamsEntity.getExportPath());
                    existing.setCftPath(schedulerParamsEntity.getCftPath());
                    existing.setArchivePath(schedulerParamsEntity.getArchivePath());
                    existing.setIsEnabled(schedulerParamsEntity.getIsEnabled());
                    existing.setWaitingDelay(schedulerParamsEntity.getWaitingDelay());
                    existing.setCustomParams(schedulerParamsEntity.getCustomParams());
                     return schedulerParamsRepository.save(existing);
                })
                .doOnNext(updated -> {
                    ScheduledFuture<?> future = scheduledTasks.get(id.toString());
                    if (future != null) {
                        future.cancel(false);
                    }
                    if (Boolean.TRUE.equals(updated.getIsEnabled())) {
                        scheduleTask(updated);
                    }
                });
    }

    public Mono<SchedulerParamsEntity> cancelTask(Long id) {
        return schedulerParamsRepository.findById(id)
                .filter(entity  -> moduleName.equals(entity.getModule()))
                .flatMap(entity -> {
                    entity.setIsEnabled(false);
                    log.info("Scheduled task canceled for task : {}", entity.getSchedulerName());
                    return schedulerParamsRepository.save(entity);
                })
                .doOnNext(updated -> {
                    ScheduledFuture<?> future = scheduledTasks.remove(id.toString());
                    if (future != null) {
                        future.cancel(false);
                    }
                });
    }

    public Mono<SchedulerParamsEntity> enableTask(Long id) {
        return schedulerParamsRepository.findById(id)
                .filter(entity  -> moduleName.equals(entity.getModule()))
                .flatMap(entity -> {
                    entity.setIsEnabled(true);
                    return schedulerParamsRepository.save(entity);
                })
                .doOnNext(updated -> {
                    if (!scheduledTasks.containsKey(id.toString())) {
                        scheduleTask(updated);
                    }
                });
    }

    public Mono<Void> runOnce(Long id) {
        return schedulerParamsRepository.findById(id)
                .filter(schedulerParamsEntity -> moduleName.equals(schedulerParamsEntity.getModule()))
                .flatMap(schedulerParamsEntity -> {
                    Runnable task = createTask(schedulerParamsEntity);
                    scheduler.schedule(task, Instant.now());
                    log.info("Scheduler: {} will run one time", schedulerParamsEntity.getSchedulerName());
                    return Mono.empty();
                });
    }

    public Flux<SchedulerParamsEntity> getAllSchedulers() {
        return schedulerParamsRepository.findAllByModule(moduleName);
    }
}
