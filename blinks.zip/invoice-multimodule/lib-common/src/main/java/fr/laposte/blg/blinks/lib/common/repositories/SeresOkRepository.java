package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.SeresOkEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface SeresOkRepository extends ReactiveCrudRepository<SeresOkEntity, Long> {
}
