import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReplayQueueTable } from './replay-queue-table.component';

describe('ReplayQueueTable', () => {
  let component: ReplayQueueTable;
  let fixture: ComponentFixture<ReplayQueueTable>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReplayQueueTable]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplayQueueTable);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
