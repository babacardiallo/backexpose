import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CdkStepperModule } from "@angular/cdk/stepper";
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { NgxPermissionsModule } from 'ngx-permissions';
import { EdrComponent } from './edr.component';
import { EdrRoutingModule } from './edr-routing.module';
import { EdrTableComponent } from './components/edr-table.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EdrDetailsPopUpComponent } from './components/edr-details-pop-up/edr-details-pop-up.component';
import { MatSelectModule } from '@angular/material/select';
import { EdrSaisiePopupComponent } from './components/edr-saisie-popup/edr-saisie-popup.component';
import { ModalService } from 'ngx-modal-ease';

@NgModule({
    imports: [
        SharedModule,
        NgxDatatableModule,
        MatStepperModule,
        CdkStepperModule,
        MatSnackBarModule,
        MatGridListModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        NgxPermissionsModule.forChild(),
        EdrRoutingModule,
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        FormsModule,
        ReactiveFormsModule,
        MatSelectModule,
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [EdrComponent, EdrTableComponent, EdrDetailsPopUpComponent, EdrSaisiePopupComponent],
    exports: [EdrComponent]
})
export class EdrModule { }
