export interface ContractConsolidatedJson {
    valuedOffer?: string;
    valuedOfferJson?: {};
    contractVersionInformation?: {
        versionNumber: number;
    };
}
