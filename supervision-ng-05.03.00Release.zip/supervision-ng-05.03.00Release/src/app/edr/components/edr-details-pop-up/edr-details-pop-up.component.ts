import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { EdrDetails } from "../../models/edr-details.model";
import { EdrTable } from "../../models/edr-table.model";
import { EdrService } from "../../service/edr.service";

@Component({
    selector: 'edr-details-pop-up-component',
    templateUrl: './edr-details-pop-up.component.html',
    styleUrls: ['./edr-details-pop-up.component.scss'],
    standalone: false
})

export class EdrDetailsPopUpComponent implements OnInit {

    edr: any;
    edrDetails: EdrDetails = new EdrDetails();
    name = 'EdrDetailsPopUpComponent';

    constructor(private modalService: ModalService, private edrService: EdrService, private snackBar: MatSnackBar) {
    }

    ngOnInit() {
        this.getEdrDetails(this.edr.id);
    }

    getEdrDetails(id: string) {
        this.edrService.getEdrDetails(id).subscribe({
            next: (response: any) => {
                this.edrDetails = <EdrDetails>{
                    id: response.id,
                    offset: response.offset,
                    partition: response.partition,
                    serviceCode: response.serviceCode,
                    chargeCode: response.chargeCode,
                    analysis: response.analysis,
                    solution: response.solution,
                    kafkaMessage: JSON.parse(response.kafkaMessage)
                };
            },
            complete: () => {
            },

        })
    }


    replayEdr(edr: EdrTable, e: Event) {
        if (edr.replayStatus == 'FAILED') {
            let returnValue: number;
            this.edrService.updateEdrPending(edr.id!).subscribe({
                next: (response: number) => {
                    returnValue = response;
                },
                complete: () => {
                    if (returnValue == 1) {
                        this.snackBar.open("Le status du rejet " + edr.id + " est passé à PENDING", 'Fermer', { duration: 5000 });
                        this.close();
                        this.edrService.emitLoadEdr();
                    }
                    else {
                        this.snackBar.open("Une erreur a eu lieu lors du rejeu du rejet " + edr.id + ". Veuillez réessayer", 'Fermer', { duration: 5000 });
                    }
                },
            })
        }
        else {
            this.snackBar.open("Le rejet " + edr.id + ". est déjà au statut PENDING", 'Fermer', { duration: 5000 });
        }

    }

    close(){
        this.modalService.close(this.name);
    }
}
