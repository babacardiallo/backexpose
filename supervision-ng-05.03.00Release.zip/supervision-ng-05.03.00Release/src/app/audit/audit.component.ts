import { Component } from '@angular/core';
import { environment } from '../../environments/environment';
@Component({
    selector: 'app-audit',
    templateUrl: './audit.component.html',
    styleUrls: ['./audit.component.scss'],
    standalone: false
})
export class AuditComponent {
  appName = environment.appName;
}
