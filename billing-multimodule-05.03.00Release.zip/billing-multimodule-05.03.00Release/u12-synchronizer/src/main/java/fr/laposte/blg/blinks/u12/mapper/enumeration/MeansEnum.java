package fr.laposte.blg.blinks.u12.mapper.enumeration;

import lombok.AllArgsConstructor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
public enum MeansEnum {

    MOD_PAI_FAC_10("10", "Paiement comptant"),
    MOD_PAI_FAC_20("20", "Paiement direct"),
    MOD_PAI_FAC_30("30", "Prélèvement bancaire"),
    MOD_PAI_FAC_40("40", "Virement"),
    MOD_PAI_FAC_50("50", "Cf. Contrat d'affranchissement"),
    MOD_PAI_FAC_60("60", "Cf. Convention"),
    MOD_PAI_FAC_70("70", "Cf. Contrat principal"),
    MOD_PAI_FAC_80("80", "Cf. A préciser"),
    MOD_PAI_FAC_90("90", "Paiement CB"),;

    private static final Map<String, String> BY_LABEL = new HashMap<>();

    static {
        Arrays.stream(values()).forEach(e -> BY_LABEL.put(e.label, e.code));
    }

    private String code;
    private String label;

    public static String getCode(String label) {
        return BY_LABEL.get(label);
    }

}
