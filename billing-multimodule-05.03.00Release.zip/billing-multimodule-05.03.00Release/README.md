
# 📦 Blinks Collector – Mono-Repo Maven

Projet Java Spring Boot multi-modules généré avec l’archetype `archetype-mono-repo`.

---

## 🧱 Modules inclus

- `lib-base`
- `lib-common`
- `lib-security`
- `u10-opencell-api`
- `u11-listener`
- `u12-synchronizer`
- `u13-scheduler`
- `u14-front-api`

---

## 🚀 Build Maven

```bash
mvn clean install -T8 -am -DskipTests
```

## ▶️ Lancer un module

```bash
cd <nom-du-module>
mvn spring-boot:run
```

---

## 🌱 Conventions Git

| Type de branche    | Format               | Base |
|--------------------|----------------------|------|
| Branche principale | `develop`            | — |
| Branche de test    | `test`               | — |
| Feature            | `feat-xxxx`          | `develop` |
| Hotfix             | `hotfix-xxxx`        | `develop` |
| Fix                | 'fix-xxxx`            | `develop` |

---

## 🔧 Développement

Créer une branche de feature à partir de `develop` :

```bash
git checkout develop
git pull origin develop
git checkout -b feature-refjira
```

---
git checkout test
git pull origin test
git merge origin/feat-1234-nouvelle-fonction
git push origin test

---

## 🚀 Déploiement d’une release

### 1. Rebase de la feature sur `develop`

```bash
git checkout feature-refjira
git pull origin develop --rebase
```

### 2. Merge vers `develop` (via MR)

```bash
git checkout develop
git pull origin develop
git merge feature-refjira
git push origin develop
```

> Cela déclenche un déploiement avec le tag `develop`.

---

## 🏷️ Création d’un tag de release

Créer un tag `x.y.z` à partir de `develop` pour déclencher un build et un déploiement versionné :

```bash
git checkout develop
git pull origin develop
git tag -a x.y.z -m "Release x.y.z"
git push origin x.y.z
```

> Cela génère une image Docker taguée `x.y.z`.

---

## 🐛 Hotfix

Créer une branche de correctif à partir de `develop` :

```bash
git checkout develop
git pull origin develop
git checkout -b hotfix-1234
```

Corriger, puis merger sur `develop` et taguer si nécessaire.

---