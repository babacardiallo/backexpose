package fr.laposte.blg.blinks.u16.scheduler;


import fr.laposte.blg.blinks.u16.service.InvoiceReplayService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@EnableScheduling
@RequiredArgsConstructor
public class RejectedInvoiceScheduler {

    private final InvoiceReplayService invoiceReplayService;

    @Scheduled(cron = "0 0 0 * * *")
    public void purge() {
        invoiceReplayService.purge()
                .doOnSuccess(log::info)
                .subscribe();
    }
}
