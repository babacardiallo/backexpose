import { ContractOdcJson } from "./contract-odc-json";
import { ContractConsolidatedJson } from "./contrat-consolidated-json";

export class ContractDetails {
    errorMessage?: string;
    invoiceAddressNumber?: string;
    dedicatedInvoiceFlag?: boolean;
    invoicePeriodicityLabel?: string;
    sendingSupportLabel?: string;
    paymentMeans?: string;
    rum?: string;
    custPurchaseOrderNumber?: string;
    contractingCustRef?: string;
    marketNumber?: string;
    contractConsolidatedJson?: ContractConsolidatedJson;
    offsetConsolidated?: string;
    partitionConsolidated?: string;
    contractOdcJson?: ContractOdcJson;
    offsetOdc?: string;
    partitionOdc?: string;
    category?: string;
}