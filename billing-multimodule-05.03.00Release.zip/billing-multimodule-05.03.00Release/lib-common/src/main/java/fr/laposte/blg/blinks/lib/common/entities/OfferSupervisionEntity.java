package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table ("offer_supervision")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class OfferSupervisionEntity {
    @Column("ops_code")
    @NotBlank
    private String opsCode;

    @Column ("ops_label")
    private String opsLabel;

    @Column ("offer_activation_date")
    private Instant offerActivationDate;

    @Column("contract_synch")
    private String contractSynch;

    @Column("contract_version_synch")
    private Long contractVersionSynch;

    @Column("error_listening")
    private String errorListening;

    @Column("error_synchronization")
    private String errorSynchronization;

}
