package fr.laposte.blg.blinks.u14.controller;

import fr.laposte.blg.blinks.u14.controller.dto.QueueSupervisionDto;
import fr.laposte.blg.blinks.u14.service.QueueRestService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@CrossOrigin
@RequestMapping("/api/queue-supervision")
public class QueueSupervisionController {

    private final QueueRestService queueRestService;
    public QueueSupervisionController(QueueRestService queueRestService){this.queueRestService=queueRestService;}

    @GetMapping("/all")
    @ResponseBody
    @Operation(
            summary = "Table queue de rejeu",
            description = "Permet de lister la table queue de rejeu")
    Mono<Page<QueueSupervisionDto>> getAll(
            @RequestParam(defaultValue = "0") boolean create,
            @RequestParam(defaultValue = "0") boolean update,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "contractNumber") String sort,
            @RequestParam(defaultValue = "desc") String order,
            @RequestParam(defaultValue = "") String filter
    ) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "idQueue"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return  queueRestService.getAllByCriteria(create, update, filter, pageable);
    }

    @GetMapping("/details/{id}")
    @ResponseBody
    @Operation(
            summary = "Détails d'un rejeu",
            description = "Permet récupèrer le détails d'un rejeu")
    Mono<QueueSupervisionDto> getDetails(
            @PathVariable("id") Long id
    ) {
        return queueRestService.getOne(id);
    }


}
