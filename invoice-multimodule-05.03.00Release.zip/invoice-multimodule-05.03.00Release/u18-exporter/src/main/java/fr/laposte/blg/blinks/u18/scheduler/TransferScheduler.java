package fr.laposte.blg.blinks.u18.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.u18.service.TransferService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TransferScheduler implements Runnable {

    private final TransferService transferService;
    private final SchedulerParamsEntity schedulerParams;

    public TransferScheduler(TransferService transferService, SchedulerParamsEntity schedulerParams) {
        this.transferService = transferService;
        this.schedulerParams = schedulerParams;
    }

    @Override
    public void run() {
        log.info("Starting TransferScheduler job for scheduler: {}", schedulerParams.getSchedulerName());

        log.info("Starting file transfer from export to transfer folder.");
        transferService.transferFiles(schedulerParams.getExportPath(), schedulerParams.getCftPath(), schedulerParams.getArchivePath());
        log.info("File transfer completed.");
    }
}
