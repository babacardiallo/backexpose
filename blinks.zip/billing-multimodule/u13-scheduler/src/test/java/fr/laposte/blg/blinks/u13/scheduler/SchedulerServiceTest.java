package fr.laposte.blg.blinks.u13.scheduler;

import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.OfferFilterEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.entities.ValuedOfferEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SchedulerServiceTest {

    @Mock
    private OfferFilterRepository offerFilterRepository;

    @Mock
    private ContractService contractService;

    @InjectMocks
    private SchedulerService schedulerService;

    @Mock
    private QueueSynchronizationEntity queueSynchronizationEntity;

    @Mock
    private ContractVersionEntity contractVersionEntity;

    @Mock
    private ValuedOfferEntity valuedOffer;

    @Mock
    private OfferFilterEntity offerFilterEntity;

    @BeforeEach
    void setUp() {
        when(queueSynchronizationEntity.getIdContract()).thenReturn(123L);
        when(contractService.findAnyVersionOfTheContract(anyLong())).thenReturn(Mono.just(contractVersionEntity));

    }

    @Test
    void isOfferOfContractEligibleForSynchronization_shouldReturnTrue_whenOfferIsEligible() {
        when(contractService.loadValuedOffer(any())).thenReturn(Mono.just(contractVersionEntity));
        when(contractVersionEntity.getValuedOffer()).thenReturn(valuedOffer);
        when(valuedOffer.getOpsId()).thenReturn("0002");
        when(offerFilterRepository.findFirstByOfferOpsId(2L)).thenReturn(Mono.just(offerFilterEntity));
        Mono<Boolean> result = schedulerService.isOfferOfContractEligibleForSynchronization(queueSynchronizationEntity);
        StepVerifier.create(result)
                .expectNext(true)
                .verifyComplete();
    }

    @Test
    void isOfferOfContractEligibleForSynchronization_shouldReturnFalse_whenOfferNotFound() {
        when(contractService.loadValuedOffer(any())).thenReturn(Mono.just(contractVersionEntity));
        when(contractVersionEntity.getValuedOffer()).thenReturn(valuedOffer);
        when(valuedOffer.getOpsId()).thenReturn("0002");
        when(offerFilterRepository.findFirstByOfferOpsId(2L)).thenReturn(Mono.empty());
        Mono<Boolean> result = schedulerService.isOfferOfContractEligibleForSynchronization(queueSynchronizationEntity);
        StepVerifier.create(result)
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    void isOfferOfContractEligibleForSynchronization_shouldReturnFalse_whenParsingError() {
        when(contractService.loadValuedOffer(any())).thenReturn(Mono.just(contractVersionEntity));
        when(contractVersionEntity.getValuedOffer()).thenReturn(valuedOffer);
        when(valuedOffer.getOpsId()).thenReturn("parsing error");
        Mono<Boolean> result = schedulerService.isOfferOfContractEligibleForSynchronization(queueSynchronizationEntity);
        StepVerifier.create(result)
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    void isOfferOfContractEligibleForSynchronization_shouldReturnFalse_whenContractServiceThrowsException() {
        when(contractService.findAnyVersionOfTheContract(anyLong())).thenReturn(Mono.error(new RuntimeException("Service error")));
        Mono<Boolean> result = schedulerService.isOfferOfContractEligibleForSynchronization(queueSynchronizationEntity);
        StepVerifier.create(result)
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    void isOfferOfContractEligibleForSynchronization_shouldReturnFalse_whenLoadValuedOfferFails() {
        when(contractService.loadValuedOffer(any())).thenReturn(Mono.error(new RuntimeException("Failed to load valued offer")));
        Mono<Boolean> result = schedulerService.isOfferOfContractEligibleForSynchronization(queueSynchronizationEntity);
        StepVerifier.create(result)
                .expectNext(false)
                .verifyComplete();
    }
}
