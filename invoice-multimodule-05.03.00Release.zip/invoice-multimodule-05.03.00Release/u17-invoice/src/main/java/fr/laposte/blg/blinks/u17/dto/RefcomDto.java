package fr.laposte.blg.blinks.u17.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({
        "CL_COCLICO",
        "EN_CODE",
        "TT_ID",
        "EC_ID",
        "DATE_CONSULTATION"
})
public class RefcomDto {
    @JsonProperty("CL_COCLICO")
    private String coclico;

    @JsonProperty("EN_CODE")
    private String entityCode;

    @JsonProperty("TT_ID")
    private String ttId;

    @JsonProperty("EC_ID")
    private String ecId;

    @JsonProperty("DATE_CONSULTATION")
    private String consultationDate;

}
