/* eslint-disable @typescript-eslint/no-unused-vars */
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  /** Async Before each */
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [HomeComponent]
    }).compileComponents();
  }));

  /** Sync before each */
  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  /** @Test: Component creation test */
  it('Should create component', () => {
    expect(component).toBeTruthy();
  });

  /** @Test: Component display external HTML template */
  it('Should display external HTML template', () => {
    // query for the message <p> by CSS element selector
    expect(fixture.debugElement.query(By.css('#home'))).toBeTruthy();
  });
});
