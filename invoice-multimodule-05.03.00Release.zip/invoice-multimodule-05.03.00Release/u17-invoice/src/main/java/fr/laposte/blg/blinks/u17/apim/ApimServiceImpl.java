package fr.laposte.blg.blinks.u17.apim;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import org.apache.logging.log4j.util.Strings;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.*;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriUtils;
import reactor.core.Exceptions;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.retry.Retry;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Data
@ConfigurationProperties(prefix = "fr.laposte.apim")
@Slf4j
public class ApimServiceImpl {

    String host;
    String clientId;
    String clientSecret;

    Pattern patternCode = Pattern.compile(".*code>(.*)<.*code>.*");
    Pattern patternMessage = Pattern.compile(".*message>(.*)<.*message>.*");
    Pattern patternDescription = Pattern.compile(".*description>(.*)<.*description>.*");

    /* Service des secrets */
    private final SecretService secretService;
    /**
     * Service permettant de récupérer le webClient customisé avec le support SSL
     *
     * @see {{@link SSLContextConfig#configureWebClientWithSsl()}
     */
    private final WebClient.Builder webClientBuilder;

    String token;
    Instant tokenPeremption = Instant.now().minus(Duration.ofDays(1));

    /**
     * Gestion de l'envoie d'une requête sur une API REST au travers de l'APIM. Etablit préallablement une session avec l'APIM.
     *
     * @param path partie context de l'URL de la requête
     * @param obj  corp de la requête
     * @param <T>  type du corp de la requête
     * @return corp de la réponse si le résultat est positif
     */
    public <T> Mono<String> post(String path, T obj) {
        DefaultUriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory(host);
        uriBuilderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY);
        return generateNewToken()
                .flatMap(token -> webClientBuilder
                        .uriBuilderFactory(uriBuilderFactory)
                        .build()
                        .post()
                        .uri(path)
                        .body(BodyInserters.fromValue(obj))
                        .header("Accept", "*/*")
                        .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                        .header("Authorization", "Bearer " + token)
                        .exchangeToMono(this::traiterRepAPIM)
                        .elapsed())

                // Si une erreur de d'expiration de token se produit
                .onErrorResume(WebClientResponseException.Unauthorized.class, err -> generateNewToken()
                        .flatMap(newToken -> webClientBuilder
                                .uriBuilderFactory(uriBuilderFactory)
                                .build()
                                .post()
                                .uri(path)
                                .body(BodyInserters.fromValue(obj))
                                .header("Accept", "*/*")
                                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                                .header("Authorization", "Bearer " + newToken)
                                .exchangeToMono(this::traiterRepAPIM)
                                .elapsed()))

                // Si une erreur se produit
                .doOnError(err -> {
                    log.error("Service APIM, Erreur de traitement bas niveau HTTP", err);
                    throw ApimException.builder()
                            .codeApim("HTTP")
                            .messageApim(err.getMessage())
                            .descriptionApim("")
                            .build();
                })
                .doOnNext(resp -> {
                    log.info(Markers.append("timeElapsed", resp.getT1())
                            .and(Markers.append("pathResource", path)), "Temps de la requete {}: {}", path, resp.getT1());
                })
                .map(Tuple2::getT2);
    }

    /**
     * Surcharge d'opérateur pour assurer la rétrocompatibilité
     * {@linkplain ApimServiceImpl}
     *
     * @param path
     * @return
     */
    public Mono<String> get(String path) {
        return get(path, new LinkedMultiValueMap<String, String>());
    }

    public Mono<String> get(String path, MultiValueMap<String, String> queryParams) {
        //Encodage des valeurs pour éviter que les symboles + dans les valeurs ne soit interprétés
        queryParams.replaceAll((s, strings) -> strings.stream().map(s1 -> UriUtils.encode(s1, StandardCharsets.UTF_8))
                .collect(Collectors.toList())
        );
        log.debug("host {}", host);
        log.debug("PATH ON  GET {}", path);
        log.debug("QUERY PARAMS  GET {}", queryParams);
        /**
         * Permet d'augmenter le buffer pour prendre en charge la taille importante de la réponse source orga à
         * l'initialisation
         */
        final int size = 32 * 1024 * 1024;
        final ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(size))
                .build();
        DefaultUriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory(host);
        uriBuilderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY);
        return generateNewToken()
                .flatMap(token -> webClientBuilder
                        .exchangeStrategies(strategies)
                        .uriBuilderFactory(uriBuilderFactory)
                        .build()
                        .get().uri(uriBuilder -> uriBuilder.
                                path(path).queryParams(queryParams).build())
                        .header("Authorization", "Bearer " + token)
                        .exchangeToMono(this::traiterRepAPIM)
                )
                // Si une erreur de d'expiration de token se produit
                .onErrorResume(WebClientResponseException.Unauthorized.class, err -> generateNewToken()
                        .flatMap(newToken -> webClientBuilder
                                .exchangeStrategies(strategies)
                                .uriBuilderFactory(uriBuilderFactory)
                                .build()
                                .get().uri(uriBuilder -> uriBuilder.
                                        path(path).queryParams(queryParams).build())
                                .header("Authorization", "Bearer " + newToken)
                                .exchangeToMono(this::traiterRepAPIM)
                        ))
                // Si une erreur se produit
                .doOnError(err -> {
                    log.error("Service APIM, Erreur de traitement bas niveau HTTP", err);
                    throw ApimException.builder()
                            .codeApim("HTTP")
                            .messageApim(err.getMessage())
                            .descriptionApim("")
                            .build();
                });
    }

    Mono<String> traiterRepAPIM(ClientResponse response) {
        return Mono.just(response)
                .flatMap(rep -> {
                    // Moulinette refcom, on a parfois un 204 qu'il faut quand meme traiter
                    HttpStatusCode status = response.statusCode();
                    if (status.equals(HttpStatus.NO_CONTENT)) {
                        try {
                            ObjectNode emptyNode = new ObjectMapper().createObjectNode();
                            String emptyJson = new ObjectMapper().writeValueAsString(emptyNode);
                            return Mono.just(emptyJson);
                        } catch (Exception e) {
                            return Mono.error(e);
                        }
                    } else {
                        return rep.bodyToMono(String.class)
                                .retryWhen(Retry.backoff(10, Duration.ofSeconds(1)).filter(throwable -> throwable instanceof WebClientResponseException.TooManyRequests))
                                .doOnNext(s -> log.debug(Markers.appendFields(response), "RETOUR APIM COMPLET : {}// STATUS CODE : {}", s, response.statusCode()))
                                .switchIfEmpty(Mono.error(() -> {
                                    String message = String.format("Service APIM, Reponse inattendue code (%s) avec corps reponse vide", status);
                                    log.error(message, status);
                                    return ApimException.builder()
                                            .codeApim(Integer.toString(status.value()))
                                            .messageApim(message)
                                            .descriptionApim("Reponse inattendue : corps de la reponse vide, " + status)
                                            .build();
                                }));
                    }
                })
                .map(body -> {
                    Optional.of(response)
                            .filter(rep -> !rep.statusCode().equals(HttpStatus.OK))
                            .filter(rep -> !rep.statusCode().equals(HttpStatus.FOUND))
                            // On reprend le corp de la réponse
                            .map(rep -> body)
                            // Si le mess. d'err. commence par le marqueur des err. renv. par l'APIM
                            .filter(apimMessage -> apimMessage.matches(".*http...wso2.org.*"))
                            .ifPresent(apimMessage -> {
                                // Création d'une exception APIM
                                ApimException.ApimExceptionBuilder exception = ApimException.builder();
                                // Calcul du code d'erreur APIM
                                Optional.of(apimMessage)
                                        .map(CharSequence.class::cast)
                                        .map(patternCode::matcher)
                                        .filter(Matcher::find)
                                        .map(matcher -> matcher.group(1))
                                        .ifPresent(exception::codeApim);
                                // Calcul du message d'erreur APIM
                                Optional.of(apimMessage)
                                        .map(CharSequence.class::cast)
                                        .map(patternMessage::matcher)
                                        .filter(Matcher::find)
                                        .map(matcher -> matcher.group(1))
                                        .ifPresent(exception::messageApim);
                                // Calcul du descriptif d'erreur APIM
                                Optional.of(apimMessage)
                                        .map(CharSequence.class::cast)
                                        .map(patternDescription::matcher)
                                        .filter(Matcher::find)
                                        .map(matcher -> matcher.group(1))
                                        .ifPresent(exception::descriptionApim);
                                // Lancement de l'exception d'erreur sur le chainon DORSALE/APIM
                                throw exception.build();
                            });
                    Optional.of(response)
                            // Si la réponse est en erreur
                            .filter(rep -> rep.statusCode().is4xxClientError())
                            // Si le corp de la réponse est un document json
                            .filter(rep -> rep.headers()
                                    .contentType()
                                    .filter(type -> type.includes(MediaType.APPLICATION_JSON))
                                    .isPresent())
                            // On reprend le corp de la réponse
                            .map(rep -> body)
                            // On parse la réponse au format JSON
                            .map(JSONValue::parse)
                            // Si la document est bien au format json
                            .filter(JSONObject.class::isInstance)
                            // Changement de son type en json
                            .map(JSONObject.class::cast)
                            .ifPresent(json -> {
                                // Création d'une exception APIM
                                ApimException.ApimExceptionBuilder exception = ApimException.builder();
                                Optional.ofNullable(response)
                                        .map(ClientResponse::statusCode);
                                Optional.ofNullable(json.getAsString("error"))
                                        .ifPresent(exception::messageApim);
                                Optional.ofNullable(json.getAsString("error_description"))
                                        .ifPresent(exception::descriptionApim);
                                log.error("Response error {}", json);
                                // Lancement de l'exception d'erreur sur le chainon DORSALE/APIM
                                throw exception.build();
                            });
                    return body;
                });
    }

    /**
     * On génère un nouveau jeton pour se connecter à l'APIM
     */
    public Mono<String> generateNewToken() {
        // Si un jeton a déjà été généré
        // ET Si la date du jour est antérieur à la date de péremption du jeton
        if (Objects.nonNull(token) && Instant.now().isBefore(tokenPeremption)) {
            // Récupération du token existant
            return Mono.just(token);
        }
        DefaultUriBuilderFactory uriBuilderFactory = new DefaultUriBuilderFactory(host);
        uriBuilderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY);
        /* Chargement du secret de mot de passe de l'APIM */
        return secretService.loadSecret(clientSecret)
                .flatMap(clientMdp -> {
                    MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
                    map.add("grant_type", "client_credentials");
                    map.add("client_id", clientId);
                    map.add("client_secret", clientMdp);
                    log.debug("[APPEL TOKEN] Params pour APPEL TOKEN {}", map);

                    try {
                        return webClientBuilder.clone()
                                .filters(exchangeFilterFunctions -> {
                                    exchangeFilterFunctions.add(logRequest());
                                    exchangeFilterFunctions.add(logResponse());
                                })
                                .uriBuilderFactory(uriBuilderFactory)
                                .build()
                                .post()
                                .uri("/token")
                                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                                .body(BodyInserters.fromFormData(map))
                                .exchangeToMono(this::traiterRepAPIM);
                    } catch (StackOverflowError e) {
                        //TODO To remove after resolution of production issue
                        log.error(e.toString());
                        return Mono.error(new Exception("TOKEN connection error STACKOVERFLOW :").initCause(
                                e
                        ));
                    }
                })
                // Si une erreur se produit
                .onErrorResume(err -> {
                    log.error("Service APIM, Erreur de traitement bas niveau HTTP", err);
                    ApimException ex = ApimException.builder()
                            .codeApim("HTTP")
                            .messageApim(err.getMessage())
                            .descriptionApim("")
                            .build();
                    ex.initCause(err);
                    return Mono.error(ex);
                })
                .map(body -> {
                    try {
                        return new ObjectMapper().readValue(body, ApimTokenDto.class);
                    } catch (IOException e) {
                        String mess = "Impossible de lire la reponse APIM : jeton mal formate : " + e.getMessage();
                        log.error(mess, e);
                        throw Exceptions.propagate(new ConnexionException(mess));
                    }
                })
                .map(entity -> {
                    // Calcul du token
                    token = entity.getAccess_token();
                    if (Objects.isNull(token))
                        throw Exceptions.propagate(new ConnexionException("Reponse incorrecte : access_token vide !"));
                    Long dureeTotale = entity.getExpires_in();
                    // pour gérer une marge de 10 secondes
                    dureeTotale = dureeTotale - 10;
                    if (Objects.isNull(dureeTotale))
                        throw Exceptions.propagate(new ConnexionException("Reponse incorrecte : expires_in vide !"));
                    tokenPeremption = Instant.now().plusSeconds(dureeTotale);
                    long dureeMinutes = dureeTotale / 60;
                    long dureeSecondes = dureeTotale % 60;
                    log.debug(Markers.append("token", token)
                                    .and(Markers.append("duree-minutes", dureeMinutes))
                                    .and(Markers.append("duree-secondes", dureeSecondes)),
                            "Le token {} expirera dans {} minutes et {} secondes", token, dureeMinutes, dureeSecondes);
                    return token;
                });
    }

    // This method returns filter function which will log request data

    /**
     * @return
     * @Deprecated because we suppose that it causes a StackOverFlowError
     */
    private static ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            if (log.isDebugEnabled()) {

                log.debug("Request: {} {}", clientRequest.method(), clientRequest.url());
                clientRequest.headers()
                        .forEach((name, values) -> values.forEach(value -> log.debug("{}={}", name, value)));
            }
            return Mono.just(clientRequest);
        });
    }

    private static ExchangeFilterFunction logResponse() {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            if (log.isDebugEnabled()) {
                StringBuilder sb = new StringBuilder("Response: \n");
                //append clientRequest method and url
                clientResponse
                        .headers()
                        .asHttpHeaders()
                        .forEach((name, values) -> values.forEach(value -> sb.append("HEADER name :").append(name)
                                .append("|")
                                .append("value :").append(value).append(Strings.LINE_SEPARATOR)));
                log.debug(sb.toString());
            }
            return Mono.just(clientResponse);
        });
    }
}
