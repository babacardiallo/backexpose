-- Territories can have a business_entity_code null
ALTER TABLE blg_invoice.refcom_business_territory_hierarchy
MODIFY business_entity_code varchar(6) null;
