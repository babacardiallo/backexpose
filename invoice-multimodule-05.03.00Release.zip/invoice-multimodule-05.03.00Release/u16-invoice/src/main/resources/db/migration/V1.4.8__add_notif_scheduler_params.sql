ALTER TABLE scheduler_params CHANGE execution_order custom_params json;

INSERT INTO scheduler_params (scheduler_name, cron_expression, export_path, cft_path, archive_path, is_enabled, waiting_delay, custom_params, retention_days, module)
VALUES
    -- Notification Scheduler for U17
    ('scheduler_notification', '0 0/5 22-23 * * ?', NULL, NULL, NULL, true, NULL,
     '{
    "code": "FACTURA_NOTIFICATION_MAIL_EXPORTS_BLINKS",
    "emails": [
        "tom.stefanutti@laposte.fr"
    ],
    "infoca": 0,
    "equinox": 0,
    "partner": "FACTURA",
    "version": 2,
    "docaposte": 0
}',  NULL, 'u17' );