package service;


import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import fr.laposte.blg.blinks.u18.entity.MessageStatus;
import fr.laposte.blg.blinks.u18.repository.CustomerAccountRepository;
import fr.laposte.blg.blinks.u18.service.impl.FileWriterServiceImpl;
import fr.laposte.blg.blinks.lib.common.repositories.FileSequenceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FileWriterServiceTest {
    @Mock
    private CustomerAccountRepository repository;
    @Mock
    private FileSequenceRepository fileSequenceRepository;
    @InjectMocks
    private FileWriterServiceImpl fileWriterService;
    @TempDir
    Path tempDir;
    Path exportDir;


    @BeforeEach
    void initData() throws IOException {
        exportDir = tempDir.resolve("export");
        Files.createDirectories(exportDir);
        ReflectionTestUtils.setField(fileWriterService, "itemPerPage", 5);
        ReflectionTestUtils.setField(fileWriterService, "fileName", "blg5");
    }

    @Test
    void exportPendingMessagesToNdjsonSuccess(){
        Pageable pageable = PageRequest.of(0, 5);
        List<CustomerAccountMessage> customerAccountMessages =
                List.of(
                        CustomerAccountMessage.builder().id(UUID.randomUUID()).contractNumber("D-001").messageValue("{}").build(),
                        CustomerAccountMessage.builder().id(UUID.randomUUID()).contractNumber("D-002").messageValue("{}").build()
                );
        Page<CustomerAccountMessage> customerAccountMessages1 = new PageImpl<>(customerAccountMessages, pageable, customerAccountMessages.size());
        when(repository.findAllByStatus(any(MessageStatus.class), any(Pageable.class))).thenReturn(customerAccountMessages1);
        when(fileSequenceRepository.getCurrentSequenceForCopilotMdExport()).thenReturn(Mono.just(1L));
        when(fileSequenceRepository.incrementSequenceForCopilotMdExport(anyInt())).thenReturn(Mono.just(1));
        when(repository.saveAll(any(List.class))).thenReturn(customerAccountMessages);
        fileWriterService.exportPendingMessagesToNdjson(exportDir.toString());
        verify(repository, times(1)).saveAll(any(List.class));

    }


    @Test
    void exportPendingMessagesToNdjsonNoMessageToExport(){
        Pageable pageable = PageRequest.of(0, 5);
        Page<CustomerAccountMessage> customerAccountMessages1 = new PageImpl<>(new ArrayList<>(), pageable, 0);
        when(repository.findAllByStatus(any(MessageStatus.class), any(Pageable.class))).thenReturn(customerAccountMessages1);
        fileWriterService.exportPendingMessagesToNdjson(exportDir.toString());
        verify(repository, never()).saveAll(any(List.class));

    }


}
