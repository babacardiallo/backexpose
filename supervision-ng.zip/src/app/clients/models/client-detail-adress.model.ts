export class ClientAddress {

  addressIdRefPM?: string;
  addressType?: string;
  addressSort?: number;
  name1?: string;
  add1?: string;
  add2?: string;
  add3?: string;
  add4?: string;
  add5?: string;
  add6?: string;
  add7?: string;

}
