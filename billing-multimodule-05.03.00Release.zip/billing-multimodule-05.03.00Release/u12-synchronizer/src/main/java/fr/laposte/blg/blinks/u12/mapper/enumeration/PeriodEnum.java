package fr.laposte.blg.blinks.u12.mapper.enumeration;

import lombok.AllArgsConstructor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
public enum PeriodEnum {

    DELAI_FAC_10("10", "0 jours"),
    DELAI_FAC_20("20", "10 jours"),
    DELAI_FAC_30("30", "20 jours"),
    DELAI_FAC_40("40", "30 jours"),
    DELAI_FAC_50("50", "35 jours"),
    DELAI_FAC_60("60", "40 jours"),
    DELAI_FAC_70("70", "42 jours"),
    DELAI_FAC_80("80", "45 jours"),
    DELAI_FAC_90("90", "50 jours"),
    DELAI_FAC_100("100", "60 jours"),
    DELAI_FAC_110("110", "Cf. Convention"),
    DELAI_FAC_120("120", "Cf. Contrat d'affranchissement"),
    DELAI_FAC_130("130", "Cf. Contrat principal"),
    DELAI_FAC_140("140", "A préciser"),
    DELAI_FAC_150("150", "Aucun");

    private static final Map<String, String> BY_LABEL = new HashMap<>();

    static {
        Arrays.stream(values()).forEach(e -> BY_LABEL.put(e.label, e.code));
    }

    private String code;
    private String label;

    public static String getCode(String label) {
        return BY_LABEL.get(label);
    }

}
