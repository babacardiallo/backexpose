package fr.laposte.blg.blinks.u11.listener.contract;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.constant.KibanaCustomField;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractVersionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ValuedOfferRepository;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.QueueMigrationService;
import fr.laposte.blg.blinks.u11.listener.contract.dto.LogIntegration;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ContractListenerException;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ContractPublishingException;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ListeningOrderContractVersionException;
import fr.laposte.blg.blinks.u11.mapper.ContractFullListenerMapper;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.EventOrigin;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.TypeEnum;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.io.JsonEncoder;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class ContractFullService {
    /**
     * Jackson BEAN
     */

    private final ContractFullListenerMapper contractFullListenerMapper;

    private final ContractService contractService;

    private final OfferFilterRepository offerFilterRepository;

    private final ErrorLogService errorLogService;

    private final QueueMigrationService queueMigrationService;

    private final SynchronizationSender synchronizationSender;

    private final ContractVersionRepository contractVersionRepository;

    private final ValuedOfferRepository valuedOfferRepository;
    /**
     * Main business logic for contract handling
     *
     * @param receiverRecord The contract avro from ODC topic
     * @return Mono
     */
    public Mono<Void> readODCContract(ConsumerRecord<String, gkContractFullOutV1> receiverRecord) {
        gkContractFullOutV1 contractFullOutV1;
        if (receiverRecord.value() == null) {
            return purgeContractVersion(receiverRecord);
        }
        try {
            contractFullOutV1 = receiverRecord.value(); //La donnée n'a pas pu être casté donc surement de la donnée erroné ou de test
        } catch (Exception e) {
            var errorLog = ErrorLogEntity.builder()
                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING_BEFORE_CONTRACT_CREATION)
                    .contractNumber(receiverRecord.key())
                    .errorMessage(e.getMessage())
                    .offset(String.valueOf(receiverRecord.offset()))
                    .partition(String.valueOf(receiverRecord.partition()))
                    .contractOdcJson(String.valueOf(receiverRecord.value()))
                    .opsCode(String.valueOf(receiverRecord.value().getContract().getOffer().getOpsCode()))
                    .codeError(CodeErrorEnum.U11002)
                    .build();
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
            log.error(Markers.append(KibanaCustomField.CLEFS_INTEGRATION_CONTRACT, node), "Error on Contract Listener on contract number : {}, clefs: {}", receiverRecord.key(), node);
            return errorLogService.logError(errorLog).then();
        }

        //Nous recevons au final des versions de contrats
        ContractInformation contractInformationAvro = contractFullOutV1.getContract().getContractInformation();
        ContractVersionInformation contractVersionInformationAvro = contractFullOutV1.getContract().getContractVersionInformation();
        InvoiceInformation invoiceInformationAvro = contractFullOutV1.getContract().getInvoiceInformation();
        Offer valuedOfferAvro = contractFullOutV1.getContract().getOffer();

        ContractVersionEntity contractVersionInformation;
        ContractEntity contractEntity;
        InvoiceInformationEntity invoiceInformationEntity;
        ValuedOfferEntity valuedOffer;
        ContractVersionMessage contractVersionMessage = new ContractVersionMessage();
        ContractMessage contractMessage = new ContractMessage();
        ValuedOfferMessage valuedOfferMessage = new ValuedOfferMessage();
        InvoiceInformationEntityMessage invoiceInformationEntityMessage = new InvoiceInformationEntityMessage();
        //Mappings pour passer des classes autogenerated avro à nos classes d'entity
        try {

            contractEntity = contractFullListenerMapper.contractInformationAvroToContractEntity(contractInformationAvro);
            contractVersionInformation =
                    contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationAvro);
            invoiceInformationEntity = contractFullListenerMapper.invoiceInformationODCToInvoiceInformationEntity(invoiceInformationAvro);
            valuedOffer = contractFullListenerMapper.offerAvroToValuedOfferEntity(valuedOfferAvro);

            /**
             * We give to the contract version all the attributes
             */
            contractVersionInformation.setContract(contractEntity)
                    .setInvoiceInformationEntity(invoiceInformationEntity)
                    .setValuedOffer(valuedOffer)
                    .setPartition(String.valueOf(receiverRecord.partition()))
                    .setOffset(String.valueOf(receiverRecord.offset()));

            /**
             * We build json table for contract version message
             */
            contractVersionMessage.setOdcContract(contractFullOutV1.toString());
            contractVersionMessage.setContractVersionInformation(buildContractVersionMessage(contractVersionInformationAvro));
            /**
             * We build json table for contract message
             */
            contractMessage.setContractInformation(buildContractMessage(contractInformationAvro));

            /**
             * We build json table for valued offer message
             */
            valuedOfferMessage.setMessage(buildValuedOfferMessage(valuedOfferAvro));

            /**
             * We build json table for invoice information message
             */
            buildInvoiceInformationEntityMessage(invoiceInformationEntityMessage, invoiceInformationAvro);

            LogIntegration logIntegration = new LogIntegration();
            logIntegration.setContractNumber(contractEntity.getContractNumber());
            logIntegration.setAmendmentNumber(contractVersionInformation.getAmendmentNumber());
            logIntegration.setRevisionNumber(contractVersionInformation.getRevisionNumber());
            logIntegration.setCustAccNumber(contractEntity.getCustAccNumber()!=null ? contractEntity.getCustAccNumber().toString(): "");
            logIntegration.setMessage("Debut Integration");
            ObjectMapper obj = new ObjectMapper();
            obj.registerModule(new JavaTimeModule());
            JsonNode nodeDebut = obj.convertValue(logIntegration, JsonNode.class);
            log.info(Markers.append(KibanaCustomField.CLEFS_DEBUT_INTEGRATION_CONTRACT, nodeDebut), "[CONTRACT NUMBER: " + logIntegration.getContractNumber() + "] Debut Integration contract: {}, message: {}", logIntegration.getContractNumber(), logIntegration);


        } catch (Exception exception) {
            var errorMessage = String.format("Error on Contract Listener on contract number : %s", receiverRecord.key());
            log.error(errorMessage, exception);

            var errorLog = ErrorLogEntity.builder()
                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING_AFTER_MAPPING_AVRO)
                    .contractNumber(contractInformationAvro.getContractNumber().toString())
                    .errorMessage(exception.getMessage())
                    .offset(String.valueOf(receiverRecord.offset()))
                    .partition(String.valueOf(receiverRecord.partition()))
                    .amendmentNumber(Integer.parseUnsignedInt(contractVersionInformationAvro.getAmendmentNumber().toString()))
                    .revisionNumber(Integer.parseUnsignedInt(contractVersionInformationAvro.getContractVersionNumber().toString()))
                    .contractOdcJson(String.valueOf(receiverRecord.value()))
                    .opsCode(String.valueOf(valuedOfferAvro.getOpsCode()))
                    .codeError(CodeErrorEnum.U11003)
                    .custAccNumber(Long.parseUnsignedLong(contractInformationAvro.getCustAccNumber().toString()))
                    .build();
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
            log.error(Markers.append(KibanaCustomField.CLEFS_INTEGRATION_CONTRACT, node), "Error on Contract Listener on contract number : {}, clefs: {}", receiverRecord.key(), node);
            return errorLogService.logError(errorLog).then();
        }

        return
            Mono.zip(Mono.just(contractVersionInformation),Mono.just(contractFullOutV1))
                .filterWhen(this::preconditionsToSaveAVersion)
                .filterWhen(tuple2 -> this.contractService.isContractVersionAmendmentSuperior(tuple2.getT1()))
                .filter(tuple2 -> this.isContractVersionEligibleForSynchronization(tuple2.getT1()))
                .flatMap(tuple2 -> this.contractService.checkIfContractIsNew(tuple2.getT1()))
                //We save the contractEntity for all cases (Create and Update) because we have some contract attributes which can be changed over the versions and amendments
                .flatMap(contractFromTuple -> Mono.zip(contractService.save(contractFromTuple.getT1(), contractMessage), Mono.just(contractFromTuple.getT2())))
                .flatMap(tuple2 ->
                    contractService.createOrUpdateContractVersionChain(contractVersionInformation, tuple2.getT1(), contractVersionMessage, valuedOfferMessage, invoiceInformationEntityMessage)
                        //On check si le contract peut être synchronisé tout de suite.
                        .filterWhen(this::isOfferOfContractEligibleForSynchronization)
                        .flatMap(contractVersionEntity -> this.triggerImmediateSynchronization(contractVersionEntity, tuple2.getT2()
                                , receiverRecord.topic(), receiverRecord.key())
                            .onErrorResume(ContractListenerException.class, throwable -> {
                                var errorLog = ErrorLogEntity.builder()
                                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_POST_LISTENING_PUBLISHING)
                                    .contractNumber(contractEntity.getContractNumber())
                                    .errorMessage(throwable.getMessage())
                                    .amendmentNumber(contractVersionEntity.getAmendmentNumber())
                                    .revisionNumber(contractVersionEntity.getRevisionNumber())
                                    .status(Optional.ofNullable(throwable.getContractVersionEntity())
                                        .map(ContractVersionEntity::getStatus)
                                        .orElse(null))
                                    .substatus(Optional.ofNullable(throwable.getContractVersionEntity())
                                        .map(ContractVersionEntity::getSubstatus)
                                        .orElse(null))
                                    .offset(throwable.getOffset())
                                    .partition(throwable.getPartition())
                                    .contractOdcJson(String.valueOf(receiverRecord.value()))
                                    .opsCode(valuedOffer.getOpsCode())
                                    .codeError(CodeErrorEnum.U11004)
                                    .custAccNumber(contractEntity.getCustAccNumber()!=null ?contractEntity.getCustAccNumber().longValue():0L)
                                    .build();
                                ObjectMapper objectMapper = new ObjectMapper();
                                objectMapper.registerModule(new JavaTimeModule());
                                JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                log.error(Markers.append(KibanaCustomField.CLEFS_INTEGRATION_CONTRACT, node), "Error on Contract Listener on contract number : {}, clefs: {}", receiverRecord.key(), node);
                                return errorLogService.logError(errorLog)
                                    .then(Mono.empty());

                                                })
                                        ) //On publie
                                        //Si le contrat n'a pas d'offre éligible, nous le mettons dans la file d'attente
                                        .switchIfEmpty(Mono.defer(() -> this.enqueueMigration(contractVersionInformation).thenReturn(contractVersionInformation))
                                        )
                                        .onErrorMap(
                                                throwable -> !(throwable instanceof ContractListenerException),
                                                throwable -> new ContractListenerException("Unhandled error in the listener of contracts :" + throwable.getMessage()
                                                        , throwable
                                                        , ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING
                                                        , contractEntity.getContractNumber()
                                                        , contractVersionInformation.getAmendmentNumber()
                                                        , contractVersionInformation.getRevisionNumber()
                                                        , contractVersionInformation
                                                        , contractVersionInformation.getOffset()
                                                        , contractVersionInformation.getPartition()
                                                        , contractFullOutV1.toString()
                                                        , contractVersionInformation.getValuedOffer().getOpsCode()

                                                )
                                        )
                                        .onErrorResume(ContractListenerException.class, throwable -> {
                                            var errorLog = ErrorLogEntity.builder()
                                                    .workflowStep(ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING)
                                                    .contractNumber(contractEntity.getContractNumber())
                                                    .errorMessage(throwable.getMessage())
                                                    .amendmentNumber(contractVersionInformation.getAmendmentNumber())
                                                    .revisionNumber(contractVersionInformation.getRevisionNumber())
                                                    .status(Optional.ofNullable(throwable.getContractVersionEntity())
                                                            .map(ContractVersionEntity::getStatus)
                                                            .orElse(null))
                                                    .substatus(Optional.ofNullable(throwable.getContractVersionEntity())
                                                            .map(ContractVersionEntity::getSubstatus)
                                                            .orElse(null))
                                                    .offset(throwable.getOffset())
                                                    .partition(throwable.getPartition())
                                                    .contractOdcJson(throwable.getContractJson())
                                                    .opsCode(valuedOffer.getOpsCode())
                                                    .custAccNumber(contractEntity.getCustAccNumber()!=null ?contractEntity.getCustAccNumber().longValue():0L)
                                                    .codeError(CodeErrorEnum.U11001)
                                                    .build();
                                            ObjectMapper objectMapper = new ObjectMapper();
                                            objectMapper.registerModule(new JavaTimeModule());
                                            JsonNode node = objectMapper.convertValue(errorLog, JsonNode.class);
                                            log.error(Markers.append(KibanaCustomField.CLEFS_INTEGRATION_CONTRACT, node), "Error on Contract Listener on contract number : {}, clefs: {}", receiverRecord.key(), node);
                                            return errorLogService.logError(errorLog)
                                                    .then(Mono.empty());
                                        }))
                                       .flatMap(contractVersionFinal -> {
                                           LogIntegration logIntegration = new LogIntegration();
                                           logIntegration.setContractNumber(contractEntity.getContractNumber());
                                           logIntegration.setAmendmentNumber(contractVersionInformation.getAmendmentNumber());
                                           logIntegration.setRevisionNumber(contractVersionInformation.getRevisionNumber());
                                           logIntegration.setCustAccNumber(contractEntity.getCustAccNumber().toString());
                                           logIntegration.setMessage("Fin Integration");
                                           ObjectMapper obj = new ObjectMapper();
                                           obj.registerModule(new JavaTimeModule());
                                           JsonNode nodeFin = obj.convertValue(logIntegration, JsonNode.class);
                                           log.info(Markers.append(KibanaCustomField.CLEFS_FIN_INTEGRATION_CONTRACT, nodeFin), "[CONTRACT NUMBER: " + logIntegration.getContractNumber() + "] Fin Integration contract: {}, message: {}", logIntegration.getContractNumber(), logIntegration);
                                           return errorLogService.
                                                   removeAllLessRevisions(contractEntity.getContractNumber(), contractVersionInformation.getAmendmentNumber(), contractVersionInformation.getRevisionNumber());
                                       }).then();

    }

    public Mono<ContractVersionEntity> triggerImmediateSynchronization(ContractVersionEntity contractVersionEntity, boolean isNewContract, String topic, String key) {
        ActionEnum actionEnum = isNewContract ? ActionEnum.create : ActionEnum.update;
        Map<String, Object> clefs = new HashMap<>();
        clefs.put(KibanaCustomField.CONTRACT_NUMBER, contractVersionEntity.getContract().getContractNumber());
        return Mono.just(contractVersionEntity.getContract())
                .map(contract ->
                        Synchronization.newBuilder()
                                .setAction(actionEnum)
                                .setType(TypeEnum.contract)
                                .setInternalId(contract.getIdContract().intValue())
                                .setEventOrigin(EventOrigin.newBuilder()
                                        .setKey(key)
                                        .setTopic(topic).build())
                                .build()
                )
                .flatMap(this.synchronizationSender::send)
                .doOnSuccess((t) ->
                        log.debug("Synchronization triggered for the contract {} clefs {}"
                                , contractVersionEntity.getContract().getContractNumber()
                                ,clefs))
                .onErrorMap(throwable -> new ContractPublishingException(throwable, contractVersionEntity))
                .thenReturn(contractVersionEntity);
    }

    /**
     * Managing topic with null values received in gk_fullContract for purging purpose
     *
     * @param receiverRecord
     * @return empty Mono
     */
    public Mono<Void> purgeContractVersion(ConsumerRecord<String, gkContractFullOutV1> receiverRecord) {
        final String contractNumber = receiverRecord.key().substring(0, receiverRecord.key().length() - 2);
        final int amendmentNumber = Integer.parseInt(receiverRecord.key().substring(receiverRecord.key().length() - 1));
        Map<String, Object> clefs = new HashMap<>();
        clefs.put(KibanaCustomField.CONTRACT_NUMBER, contractNumber);
        clefs.put(KibanaCustomField.AMENDMENT_NUMBER, amendmentNumber);
        log.info("Purging contract version number : {} amendment number {} clefs {}", contractNumber, amendmentNumber, clefs);
        return contractVersionRepository.findByContractNumberAndByAmendmentNumber(contractNumber, amendmentNumber)
                .map(contractVersionEntity -> contractVersionEntity.setIsPurged(true))
                .flatMap(this.contractVersionRepository::save)
                .then();
    }


    /**
     * Base logic unit to program a synchronization for a specific contract
     *
     * @param contractVersionEntity
     * @return
     */
    public Mono<QueueMigrationEntity> enqueueMigration(ContractVersionEntity contractVersionEntity) {
        Map<String, Object> clefs = new HashMap<>();
        clefs.put(KibanaCustomField.CONTRACT_NUMBER, contractVersionEntity.getIdContract());
        return
                queueMigrationService.enQueueContract(contractVersionEntity.getIdContract(), ActionEnum.create, contractVersionEntity.getValuedOffer().getOpsCode())
                        .doOnSuccess(queueSynchronizationEntity -> {
                            clefs.put("Expected Synchronization Date", queueSynchronizationEntity.getDateSynchronizationExpected());
                            log.debug("Contract {} with the date {} enqueued successfully ! clefs {}"
                                    , queueSynchronizationEntity.getIdContract()
                                    , queueSynchronizationEntity.getDateSynchronizationExpected()
                                    , clefs);
                        });

    }


    public Mono<Boolean> preconditionsToSaveAVersion(Tuple2<ContractVersionEntity, gkContractFullOutV1> tuple) {
        //Préconditions liés à la résiliation
        var status = tuple.getT1().getStatus();
        var subStatus = tuple.getT1().getSubstatus();
        Mono<ContractVersionEntity> lastContractVersionMono =
                Mono.defer(() -> contractService.findByContractNumberAndAmendmentNumber(
                        tuple.getT1().getContract().getContractNumber(),
                        tuple.getT1().getAmendmentNumber())
                );
        Mono<Boolean> intermediateResult = Mono.just(true);
        
        return intermediateResult.onErrorResume(ListeningOrderContractVersionException.class, throwable ->
                errorLogService
                        .logErrorContract(tuple.getT1(), throwable.getMessage(), ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING_ORDER, tuple.getT2())
                        .thenReturn(false)
        );
    }

    /**
     * Check if the contract is eligible for synchronization. If not, we save only the necessary data needed to check the
     * precedence during the synchronization.
     *
     * @param contractVersionEntity version to check
     * @return true if the contract is eligible to be synchronized
     */
    public boolean isContractVersionEligibleForSynchronization(ContractVersionEntity contractVersionEntity) {
        boolean isContractEligibleForSynchronization = false;
        ContractStatusEnum statusEnum = contractVersionEntity.getStatus();
        ContractSubStatusEnum subStatusEnum = contractVersionEntity.getSubstatus();
        if (statusEnum.equals(ContractStatusEnum.VALIDE)) {
            if(subStatusEnum.equals(ContractSubStatusEnum.VALIDE)
                || subStatusEnum.equals(ContractSubStatusEnum.DEMANDE_DE_RESILIATION)
                || subStatusEnum.equals(ContractSubStatusEnum.EN_COURS_DE_RENOUVELLEMENT)
                || subStatusEnum.equals(ContractSubStatusEnum.ECHU)) {
                isContractEligibleForSynchronization = true;
            }
        }
        else if (statusEnum.equals(ContractStatusEnum.INACTIF)) {
            if (subStatusEnum.equals(ContractSubStatusEnum.RENOUVELE)
                || subStatusEnum.equals(ContractSubStatusEnum.RESILIE)
                || subStatusEnum.equals(ContractSubStatusEnum.AVENANT)
                || subStatusEnum.equals(ContractSubStatusEnum.TERMINE)) {
                isContractEligibleForSynchronization = true;
            }
        }
        Map<String, Object> clefs = new HashMap<>();
        clefs.put(KibanaCustomField.CONTRACT_NUMBER, contractVersionEntity.getContract().getContractNumber());
        clefs.put("isEligible", isContractEligibleForSynchronization);
        log.debug("The contract {} is eligible for synchronization and will be persisted = {}, clefs {}",
                contractVersionEntity.getContract().getContractNumber(),
                isContractEligibleForSynchronization,
                clefs);
        return isContractEligibleForSynchronization;
    }

    /**
     * Check if the offer in the contract is eligible or synchronization
     *
     * @param contractVersionEntity the contract from ODC
     * @return Mono with true if offer eligible, false otherwise
     */
    public Mono<Boolean> isOfferOfContractEligibleForSynchronization(ContractVersionEntity contractVersionEntity) {
        var idOpsFilter = Optional.ofNullable(contractVersionEntity.getValuedOffer().getOpsId()).orElseThrow(() ->
                new ContractListenerException("Unable to get the offerId from the valuedOffer"
                        , null
                        , ErrorLogEntity.ErrorWorkflowStepEnum.CONTRACT_LISTENING
                        , contractVersionEntity.getContract().getContractNumber()
                        , contractVersionEntity.getAmendmentNumber()
                        , contractVersionEntity.getRevisionNumber()
                        , contractVersionEntity
                        , contractVersionEntity.getValuedOffer().getOpsCode()));
        Map<String, Object> clefs = new HashMap<>();
        clefs.put(KibanaCustomField.CONTRACT_NUMBER, contractVersionEntity.getContract().getContractNumber() + contractVersionEntity.getAmendmentNumber());
        clefs.put(KibanaCustomField.OFFER, idOpsFilter);

        return offerFilterRepository.findFirstByOfferOpsId(Long.parseLong(idOpsFilter))
                .doOnNext(offerFilterEntity -> log.debug("The version of contract {} is eligible to be synchronized : offer {}, clefs {}", contractVersionEntity.getContract().getContractNumber() + contractVersionEntity.getAmendmentNumber(), idOpsFilter, clefs))
                .map(offerFilterEntity -> true)
                //TODO La partie parsing via le jPATH n'est pas implémenté car jamais utilisé jusqu'à présent
                .defaultIfEmpty(false)
                .onErrorReturn(false);
    }

    public Mono<Boolean> isOfferOfContractEligibleUpdate(ContractVersionEntity contractVersionEntity) {
        return valuedOfferRepository.findByIdValuedOffer(contractVersionEntity.getIdValuedOffer())
                .flatMap(valuedOfferEntity -> {
                    String opsId = valuedOfferEntity.getOpsId();
                    return offerFilterRepository.findFirstByOfferOpsId(Long.parseLong(opsId))
                            .map(offerFilterEntity -> true)
                            .defaultIfEmpty(false);
                })
                .onErrorReturn(false);
    }

    public Flux<ContractVersionEntity> getContractVersionByRum(String rum) {
        return contractVersionRepository.findByRum(rum);
    }

    public Mono<ContractVersionEntity> save(ContractVersionEntity versionEntity) {
        return contractVersionRepository.save(versionEntity);
    }

    public String buildContractVersionMessage(ContractVersionInformation contractVersionInformationODC) {
        String result = contractVersionInformationODC.toString();
        try {
            DatumWriter<ContractVersionInformation> writer = new GenericDatumWriter<>(contractVersionInformationODC.getSchema());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            JsonEncoder encoder = EncoderFactory.get().jsonEncoder(contractVersionInformationODC.getSchema(), out);
            writer.write(contractVersionInformationODC, encoder);
            encoder.flush();
            result = out.toString();
        } catch (IOException e) {
            throw new ContractListenerException("Unable to json encode contractVersionInformation block");
        }
        return result;
    }

    public String buildContractMessage(ContractInformation contractInformationAvro) {
        try {
            DatumWriter<ContractInformation> writer = new GenericDatumWriter<>(contractInformationAvro.getSchema());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            JsonEncoder encoder = EncoderFactory.get().jsonEncoder(contractInformationAvro.getSchema(), out);
            writer.write(contractInformationAvro, encoder);
            encoder.flush();
            return out.toString();
        } catch (IOException e) {
            throw new ContractListenerException("Unable to json encode contractInformation block");
        }

    }
    public String buildValuedOfferMessage(Offer valuedOfferAvro) {
        try {
            DatumWriter<Offer> writer = new GenericDatumWriter<>(valuedOfferAvro.getSchema());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            JsonEncoder encoder = EncoderFactory.get().jsonEncoder(valuedOfferAvro.getSchema(), out);
            writer.write(valuedOfferAvro, encoder);
            encoder.flush();
            return out.toString();
        } catch (IOException e) {
            throw new ContractListenerException("Unable to json encode valuedOffer block");
        }

    }

    public void buildInvoiceInformationEntityMessage(InvoiceInformationEntityMessage invoiceInformationEntityMessage, InvoiceInformation invoiceInformationODC)  {
        invoiceInformationEntityMessage.setInvoicingCommentsJsonArray(invoiceInformationODC.getInvoicingComments().toString());
        try {
            DatumWriter<InvoiceInformation> writer = new GenericDatumWriter<>(invoiceInformationODC.getSchema());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            JsonEncoder encoder = EncoderFactory.get().jsonEncoder(invoiceInformationODC.getSchema(), out);
            writer.write(invoiceInformationODC, encoder);
            encoder.flush();
            invoiceInformationEntityMessage.setInvoiceInformationJson(out.toString());
        } catch (IOException e) {
            throw new ContractListenerException("Unable to json encode invoiceInformation block");
        }
    }



}
