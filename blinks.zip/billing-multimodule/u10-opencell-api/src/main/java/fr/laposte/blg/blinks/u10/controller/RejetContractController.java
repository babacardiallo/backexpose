package fr.laposte.blg.blinks.u10.controller;


import fr.laposte.blg.blinks.u10.entities.RejetContract;
import fr.laposte.blg.blinks.u10.repositories.RejetContractBaseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/rejetcontract")
public class RejetContractController {


    private final RejetContractBaseRepository rejetContractBaseRepository;

    @GetMapping("/all-code-errors")
    List<String> getAllCodeErrors() {
        return rejetContractBaseRepository.getAllCodeErrors();
    }

    @PostMapping("/updateFilteredRejetContract")
    int updateFilteredRejetContract(@RequestParam Instant startDate,
                            @RequestParam Instant endDate) {
        return rejetContractBaseRepository.updateFilteredRejetContracts(startDate, endDate);
    }

    @GetMapping("/exportRejetContract")
    List<RejetContract> exportRejetContract(@RequestParam Instant startDate,
                                            @RequestParam Instant endDate){

        return rejetContractBaseRepository.exportRejetContracts(startDate, endDate);
    }
}
