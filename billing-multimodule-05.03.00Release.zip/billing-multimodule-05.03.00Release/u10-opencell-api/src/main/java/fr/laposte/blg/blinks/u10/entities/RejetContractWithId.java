package fr.laposte.blg.blinks.u10.entities;

import org.springframework.data.rest.core.config.Projection;

import java.time.Instant;
import java.util.UUID;

@Projection(name = "withId", types = {RejetContract.class})
public interface RejetContractWithId {
    UUID getId();
    Instant getErrorDate();
    String getContractNumber();
    String getCustAccNumber();
    String getErrorCode();
    String getErrorMessage();
    String getKafkaMessage();
    Integer getNbRetry();
    String getStatus();
    Integer getOffset();
    Integer getPartition();
    String getOfferCode();
    String getAction();
    String getVersionNumber();
    String getAmendmentNumber();
    String getMeansCode();
    String getInvoicePeriodicityCode();
    String getAnalysis();
    String getSolution();
}