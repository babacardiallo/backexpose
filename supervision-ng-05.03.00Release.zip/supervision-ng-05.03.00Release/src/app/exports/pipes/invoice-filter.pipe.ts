import { Pipe, PipeTransform } from '@angular/core';
import { Invoice } from '../models/invoice';

@Pipe({
    name: 'invoiceFilter',
    standalone: false
})
export class InvoiceFilter implements PipeTransform {

  transform(list: any, text: string): any {
    if (text === '') {
      return list;
    }
    return list.filter((i: Invoice) => i.invoiceNumber.toLowerCase().includes(text.trim().toLowerCase())
    || i.custAccNumber?.toLowerCase().includes(text.trim().toLowerCase()));

  }

}
