package fr.laposte.blg.blinks.u11.listener;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractVersionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.OfferFilterRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ValuedOfferRepository;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.QueueMigrationService;
import fr.laposte.blg.blinks.u11.listener.contract.ContractFullService;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ContractListenerException;
import fr.laposte.blg.blinks.u11.mapper.ContractFullListenerMapper;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.kafka.receiver.ReceiverRecord;
import reactor.test.StepVerifier;
import reactor.util.function.Tuples;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.*;


class ContractFullServiceTest {

    @InjectMocks
    private ContractFullService contractFullService;

    @Mock
    private OfferFilterRepository offerFilterRepository;

    @Mock
    private SynchronizationSender synchronizationSender;

    @Mock
    private ContractVersionRepository contractVersionRepository;

    @Mock
    private ContractService contractService;

    @Mock
    private QueueMigrationService queueMigrationService;
    @Mock
    private ValuedOfferRepository valuedOfferRepository;
    @Mock
    private ErrorLogService errorLogService;
    @Mock
    private ContractFullListenerMapper contractFullListenerMapper;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void contractEligibleForSynchronizationTest() {
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setContractNumber("D-123456-1");

        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setAmendmentNumber(2);
        contractVersionEntity.setContract(contractEntity);
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        assertTrue(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.DEMANDE_DE_RESILIATION);
        assertTrue(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.ANNULE);
        assertFalse(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));

        contractVersionEntity.setStatus(ContractStatusEnum.INACTIF);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.RENOUVELE);
        assertTrue(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.RESILIE);
        assertTrue(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.AVENANT);
        assertTrue(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));

        contractVersionEntity.setStatus(ContractStatusEnum.EN_COURS_DE_CREATION);
        assertFalse(this.contractFullService.isContractVersionEligibleForSynchronization(contractVersionEntity));
    }

    @Test
    void offerEligibleForSynchronizationTest() {
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("358");

        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setContractNumber("D-123456-1");

        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setValuedOffer(valuedOfferEntity);
        contractVersionEntity.setAmendmentNumber(2);
        contractVersionEntity.setContract(contractEntity);

        OfferFilterEntity offerFilterEntity = OfferFilterEntity.builder()
                .offerOpsId(358L)
                .opsCode("0358").build();

        when(this.offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.just(offerFilterEntity));

        StepVerifier.create(this.contractFullService.isOfferOfContractEligibleForSynchronization(contractVersionEntity))
                .expectNext(true)
                .verifyComplete();

        verify(this.offerFilterRepository, times(1)).findFirstByOfferOpsId(anyLong());
    }

    @Test
    void offerNotEligibleForSynchronizationTest() {
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("358");

        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setContractNumber("D-123456-1");

        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setValuedOffer(valuedOfferEntity);
        contractVersionEntity.setAmendmentNumber(2);
        contractVersionEntity.setContract(contractEntity);

        when(this.offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.empty());

        StepVerifier.create(this.contractFullService.isOfferOfContractEligibleForSynchronization(contractVersionEntity))
                .expectNext(false)
                .verifyComplete();

        verify(this.offerFilterRepository, times(1)).findFirstByOfferOpsId(anyLong());
    }

    @Test
    void offerNotValidSynchronizationTest() {
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setContractNumber("D-123456-1");

        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setValuedOffer(valuedOfferEntity);
        contractVersionEntity.setAmendmentNumber(2);
        contractVersionEntity.setRevisionNumber(5);
        contractVersionEntity.setContract(contractEntity);

        assertThrows(ContractListenerException.class, () -> this.contractFullService.isOfferOfContractEligibleForSynchronization(contractVersionEntity));
    }

    @Test
    void triggerImmediateSynchronizationTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        contractVersionEntity.setContract(contractEntity);
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        StepVerifier.create(this.contractFullService.triggerImmediateSynchronization(contractVersionEntity, true, "topic", "key"))
                .expectNextMatches(Objects::nonNull
                )
                .verifyComplete();
    }

    @Test
    void purgeContractVersionTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        contractVersionEntity.setContract(contractEntity);
        when(this.contractVersionRepository.findByContractNumberAndByAmendmentNumber(anyString(), anyInt())).thenReturn(Mono.just(contractVersionEntity));
        when(this.contractVersionRepository.save(any(ContractVersionEntity.class))).thenReturn(Mono.just(contractVersionEntity));
        ConsumerRecord<String, gkContractFullOutV1> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "1322332323323232", new gkContractFullOutV1());
        ReceiverRecord<String, gkContractFullOutV1> receiverRecord = new ReceiverRecord<>(consumerRecord, null);
        StepVerifier.create(this.contractFullService.purgeContractVersion(receiverRecord))
                .expectSubscription()
                .verifyComplete();
        verify(this.contractVersionRepository, atLeastOnce()).save(any(ContractVersionEntity.class));
    }

    @Test
    void enqueueMigrationTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdValuedOffer(1L);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setOpsCode("001");
        contractVersionEntity.setContract(contractEntity);
        contractVersionEntity.setValuedOffer(valuedOfferEntity);
        QueueMigrationEntity queueMigrationEntity = QueueMigrationEntity.builder().idQueue(1L).idContract(1L).action(ActionEnum.create).dateSynchronizationExpected(Instant.now()).build();
        when(this.queueMigrationService.enQueueContract(anyLong(), any(ActionEnum.class), anyString())).thenReturn(Mono.just(queueMigrationEntity));
        StepVerifier.create(this.contractFullService.enqueueMigration(contractVersionEntity))
                .expectNext(queueMigrationEntity);
    }

    @Test
    void preconditionsToSaveAVersionTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        contractVersionEntity.setAmendmentNumber(0);
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdValuedOffer(1L);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setOpsCode("001");
        contractVersionEntity.setContract(contractEntity);
        contractVersionEntity.setValuedOffer(valuedOfferEntity);
        when(this.contractService.findByContractNumberAndAmendmentNumber(anyString(), anyInt())).thenReturn(Mono.just(contractVersionEntity));
        StepVerifier.create(this.contractFullService.preconditionsToSaveAVersion(Tuples.of(contractVersionEntity, new gkContractFullOutV1())))
                .expectSubscription();
    }

    @Test
    void isOfferOfContractEligibleUpdateTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdValuedOffer(1L);

        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setOpsCode("001");

        OfferFilterEntity offerFilterEntity = new OfferFilterEntity(1L, "001", "");

        contractVersionEntity.setValuedOffer(valuedOfferEntity);

        when(valuedOfferRepository.findByIdValuedOffer(anyLong())).thenReturn(Mono.just(valuedOfferEntity));
        when(offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.just(offerFilterEntity));

        StepVerifier.create(this.contractFullService.isOfferOfContractEligibleUpdate(contractVersionEntity))
                .expectNextMatches(value -> value)
                .verifyComplete();
    }

    @Test
    void getContractVersionByRumTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContractVersion(1L);
        when(contractVersionRepository.findByRum(anyString())).thenReturn(Flux.just(contractVersionEntity));
        StepVerifier.create(this.contractFullService.getContractVersionByRum("RUM"))
                .expectNextMatches(value -> Objects.equals(contractVersionEntity.getIdContractVersion(), value.getIdContractVersion()))
                .verifyComplete();
    }

    @Test
    void saveTest(){
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContractVersion(1L);
        when(contractVersionRepository.save(any(ContractVersionEntity.class))).thenReturn(Mono.just(contractVersionEntity));
        StepVerifier.create(this.contractFullService.save(contractVersionEntity))
                .expectNextMatches(value -> Objects.equals(contractVersionEntity.getIdContractVersion(), value.getIdContractVersion()))
                .verifyComplete();
    }

    @Test
    void buildContractVersionMessageTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 record = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        var output = contractFullService.buildContractVersionMessage(record.getContract().getContractVersionInformation());
        assertNotNull(output);
    }

    @Test
    void buildContractMessageTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 record = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        var output = contractFullService.buildContractMessage(record.getContract().getContractInformation());
        assertNotNull(output);
    }

    @Test
    void buildValuedOfferMessageTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 record = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        var output = contractFullService.buildValuedOfferMessage(record.getContract().getOffer());
        assertNotNull(output);
    }

    @Test
    void buildInvoiceInformationEntityMessageTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 record = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        contractFullService.buildInvoiceInformationEntityMessage(new InvoiceInformationEntityMessage(), record.getContract().getInvoiceInformation());
    }

    @Test
    void readODCContractTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 gk = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        ConsumerRecord<String, gkContractFullOutV1> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", gk);
        ReceiverRecord<String, gkContractFullOutV1> receiverRecord = new ReceiverRecord<>(consumerRecord, null);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        contractEntity.setCustAccNumber(1);
        contractEntity.setSubtype("type");
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdInvoiceInformation(1L);
        contractVersionEntity.setIdValuedOffer(1L);
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        contractVersionEntity.setAmendmentNumber(0);
        contractVersionEntity.setRevisionNumber(1);
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsCode("001");
        InvoiceInformationEntity invoiceInformationEntity = new InvoiceInformationEntity();
        invoiceInformationEntity.setIdInvoiceInformation(1L);
        invoiceInformationEntity.setIdAddressInvoice(1L);
        invoiceInformationEntity.setRum("RUM");
        OfferFilterEntity offerFilterEntity = new OfferFilterEntity(1L, "001", "");
        when(this.errorLogService.logError(any(ErrorLogEntity.class))).thenReturn(Mono.empty());
        when(this.contractFullListenerMapper.contractInformationAvroToContractEntity(any())).thenReturn(contractEntity);
        when(this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(any())).thenReturn(contractVersionEntity);
        when(this.contractFullListenerMapper.invoiceInformationODCToInvoiceInformationEntity(any())).thenReturn(invoiceInformationEntity);
        when(this.contractFullListenerMapper.offerAvroToValuedOfferEntity(any())).thenReturn(valuedOfferEntity);
        when(this.contractService.isContractVersionAmendmentSuperior(any())).thenReturn(Mono.just(true));
        when(this.contractService.checkIfContractIsNew(any())).thenReturn(Mono.zip(Mono.just(contractEntity), Mono.just(true)));
        when(this.contractService.save(any(ContractEntity.class), any(ContractMessage.class))).thenReturn(Mono.just(contractEntity));
        when(this.contractService.createOrUpdateContractVersionChain(any(ContractVersionEntity.class), any(ContractEntity.class), any(ContractVersionMessage.class),  any(ValuedOfferMessage.class),  any(InvoiceInformationEntityMessage.class))).thenReturn(Mono.just(contractVersionEntity));
        when(this.offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.just(offerFilterEntity));
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        when(errorLogService.removeAllLessRevisions(anyString(), anyInt(), anyInt())).thenReturn(Mono.just(1));
        StepVerifier.create( this.contractFullService.readODCContract(receiverRecord))
                .expectSubscription()
                .verifyComplete();
    }


    @Test
    void readODCContractThrowExceptionAtMessagePublishingTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 gk = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        ConsumerRecord<String, gkContractFullOutV1> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", gk);
        ReceiverRecord<String, gkContractFullOutV1> receiverRecord = new ReceiverRecord<>(consumerRecord, null);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        contractEntity.setCustAccNumber(1);
        contractEntity.setSubtype("type");
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdInvoiceInformation(1L);
        contractVersionEntity.setIdValuedOffer(1L);
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        contractVersionEntity.setAmendmentNumber(0);
        contractVersionEntity.setRevisionNumber(1);
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsCode("001");
        InvoiceInformationEntity invoiceInformationEntity = new InvoiceInformationEntity();
        invoiceInformationEntity.setIdInvoiceInformation(1L);
        invoiceInformationEntity.setIdAddressInvoice(1L);
        invoiceInformationEntity.setRum("RUM");
        OfferFilterEntity offerFilterEntity = new OfferFilterEntity(1L, "001", "");
        when(this.errorLogService.logError(any(ErrorLogEntity.class))).thenReturn(Mono.empty());
        when(this.contractFullListenerMapper.contractInformationAvroToContractEntity(any())).thenReturn(contractEntity);
        when(this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(any())).thenReturn(contractVersionEntity);
        when(this.contractFullListenerMapper.invoiceInformationODCToInvoiceInformationEntity(any())).thenReturn(invoiceInformationEntity);
        when(this.contractFullListenerMapper.offerAvroToValuedOfferEntity(any())).thenReturn(valuedOfferEntity);
        when(this.contractService.isContractVersionAmendmentSuperior(any())).thenReturn(Mono.just(true));
        when(this.contractService.checkIfContractIsNew(any())).thenReturn(Mono.zip(Mono.just(contractEntity), Mono.just(true)));
        when(this.contractService.save(any(ContractEntity.class), any(ContractMessage.class))).thenReturn(Mono.just(contractEntity));
        when(this.contractService.createOrUpdateContractVersionChain(any(ContractVersionEntity.class), any(ContractEntity.class), any(ContractVersionMessage.class),  any(ValuedOfferMessage.class),  any(InvoiceInformationEntityMessage.class))).thenReturn(Mono.just(contractVersionEntity));
        when(this.offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.just(offerFilterEntity));
        when(this.synchronizationSender.send(any())).thenThrow(new RuntimeException("Test error after trigger synchro"));
        when(errorLogService.removeAllLessRevisions(anyString(), anyInt(), anyInt())).thenReturn(Mono.just(1));
        StepVerifier.create( this.contractFullService.readODCContract(receiverRecord))
                .expectSubscription()
                .verifyComplete();
    }



    @Test
    void readODCContractThrowExceptionAddVersionProcessTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 gk = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        ConsumerRecord<String, gkContractFullOutV1> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", gk);
        ReceiverRecord<String, gkContractFullOutV1> receiverRecord = new ReceiverRecord<>(consumerRecord, null);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        contractEntity.setCustAccNumber(1);
        contractEntity.setSubtype("type");
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdInvoiceInformation(1L);
        contractVersionEntity.setIdValuedOffer(1L);
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        contractVersionEntity.setAmendmentNumber(0);
        contractVersionEntity.setRevisionNumber(1);
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsCode("001");
        InvoiceInformationEntity invoiceInformationEntity = new InvoiceInformationEntity();
        invoiceInformationEntity.setIdInvoiceInformation(1L);
        invoiceInformationEntity.setIdAddressInvoice(1L);
        invoiceInformationEntity.setRum("RUM");
        OfferFilterEntity offerFilterEntity = new OfferFilterEntity(1L, "001", "");
        when(this.errorLogService.logError(any(ErrorLogEntity.class))).thenReturn(Mono.empty());
        when(this.contractFullListenerMapper.contractInformationAvroToContractEntity(any())).thenReturn(contractEntity);
        when(this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(any())).thenReturn(contractVersionEntity);
        when(this.contractFullListenerMapper.invoiceInformationODCToInvoiceInformationEntity(any())).thenReturn(invoiceInformationEntity);
        when(this.contractFullListenerMapper.offerAvroToValuedOfferEntity(any())).thenReturn(valuedOfferEntity);
        when(this.contractService.isContractVersionAmendmentSuperior(any())).thenReturn(Mono.just(true));
        when(this.contractService.checkIfContractIsNew(any())).thenReturn(Mono.zip(Mono.just(contractEntity), Mono.just(true)));
        when(this.contractService.save(any(ContractEntity.class), any(ContractMessage.class))).thenReturn(Mono.just(contractEntity));
        when(this.contractService.createOrUpdateContractVersionChain(any(ContractVersionEntity.class), any(ContractEntity.class), any(ContractVersionMessage.class),  any(ValuedOfferMessage.class),  any(InvoiceInformationEntityMessage.class))).thenThrow(new RuntimeException("Test error on contractVersion saving process"));
        when(this.offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.just(offerFilterEntity));
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        when(errorLogService.removeAllLessRevisions(anyString(), anyInt(), anyInt())).thenReturn(Mono.just(1));
        StepVerifier.create( this.contractFullService.readODCContract(receiverRecord))
                .expectSubscription()
                .expectError();
    }

    @Test
    void readODCContractThrowExceptionAttmappingProcessTest() throws IOException {
        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeContractFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        gkContractFullOutV1 gk = jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), gkContractFullOutV1.class, gkContractFullOutV1.getClassSchema());
        ConsumerRecord<String, gkContractFullOutV1> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", gk);
        ReceiverRecord<String, gkContractFullOutV1> receiverRecord = new ReceiverRecord<>(consumerRecord, null);
        ContractEntity contractEntity = new ContractEntity();
        contractEntity.setIdContract(1L);
        contractEntity.setContractNumber("C-01");
        contractEntity.setCustAccNumber(1);
        contractEntity.setSubtype("type");
        ContractVersionEntity contractVersionEntity = new ContractVersionEntity();
        contractVersionEntity.setIdContract(1L);
        contractVersionEntity.setIdContractVersion(1L);
        contractVersionEntity.setIdInvoiceInformation(1L);
        contractVersionEntity.setIdValuedOffer(1L);
        contractVersionEntity.setStatus(ContractStatusEnum.VALIDE);
        contractVersionEntity.setSubstatus(ContractSubStatusEnum.VALIDE);
        contractVersionEntity.setAmendmentNumber(0);
        contractVersionEntity.setRevisionNumber(1);
        ValuedOfferEntity valuedOfferEntity = new ValuedOfferEntity();
        valuedOfferEntity.setOpsId("1");
        valuedOfferEntity.setIdValuedOffer(1L);
        valuedOfferEntity.setOpsCode("001");
        InvoiceInformationEntity invoiceInformationEntity = new InvoiceInformationEntity();
        invoiceInformationEntity.setIdInvoiceInformation(1L);
        invoiceInformationEntity.setIdAddressInvoice(1L);
        invoiceInformationEntity.setRum("RUM");
        OfferFilterEntity offerFilterEntity = new OfferFilterEntity(1L, "001", "");
        when(this.errorLogService.logError(any(ErrorLogEntity.class))).thenReturn(Mono.empty());
        when(this.contractFullListenerMapper.contractInformationAvroToContractEntity(any())).thenThrow(new RuntimeException("Test error on mapping process"));
        when(this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(any())).thenReturn(contractVersionEntity);
        when(this.contractFullListenerMapper.invoiceInformationODCToInvoiceInformationEntity(any())).thenReturn(invoiceInformationEntity);
        when(this.contractFullListenerMapper.offerAvroToValuedOfferEntity(any())).thenReturn(valuedOfferEntity);
        when(this.contractService.isContractVersionAmendmentSuperior(any())).thenReturn(Mono.just(true));
        when(this.contractService.checkIfContractIsNew(any())).thenReturn(Mono.zip(Mono.just(contractEntity), Mono.just(true)));
        when(this.contractService.save(any(ContractEntity.class), any(ContractMessage.class))).thenReturn(Mono.just(contractEntity));
        when(this.contractService.createOrUpdateContractVersionChain(any(ContractVersionEntity.class), any(ContractEntity.class), any(ContractVersionMessage.class),  any(ValuedOfferMessage.class),  any(InvoiceInformationEntityMessage.class))).thenReturn(Mono.just(contractVersionEntity));
        when(this.offerFilterRepository.findFirstByOfferOpsId(anyLong())).thenReturn(Mono.just(offerFilterEntity));
        when(this.synchronizationSender.send(any())).thenReturn(Mono.empty());
        when(errorLogService.removeAllLessRevisions(anyString(), anyInt(), anyInt())).thenReturn(Mono.just(1));
        StepVerifier.create( this.contractFullService.readODCContract(receiverRecord))
                .expectSubscription()
                .expectError();
    }





}
