package fr.laposte.blg.blinks.lib.common.entities.repositories;


import fr.laposte.blg.blinks.lib.common.entities.OfferSupervisionEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface OfferSupervisionRepository extends ReactiveCrudRepository<OfferSupervisionEntity, Long> {

   @Query("""
                     SELECT           
                     ops_code,
                     ops_label,
                     offer_activation_date,
                     count(DISTINCT (CASE WHEN error_listening IS NULL
                                     AND error_synchronization IS NULL
                                     AND is_synchronized=1
                                     THEN contract_synch
                                     END)) AS contract_synch,
                     count(          CASE WHEN error_listening IS NULL
                                     AND error_synchronization IS NULL
                                     AND is_synchronized=1
                                     THEN contract_version_synch
                                     END) AS contract_version_synch,
                     COUNT(DISTINCT (CASE WHEN (error_listening IS NOT NULL) THEN  CONCAT(contract_version_synch, amendment_number, revision_number) END)) as error_listening,
                     COUNT(DISTINCT (CASE WHEN (error_synchronization IS NOT NULL) THEN  contract_version_synch END)) as error_synchronization
                     FROM blg_contract_importer.offer_supervision group by ops_code
           """)
   Flux<OfferSupervisionEntity> countOfferContractsErrors();

    @Query("""
                      SELECT            
                      ops_code,
                      ops_label,
                      offer_activation_date,
                      count(DISTINCT (CASE WHEN error_listening IS NULL
                                      AND error_synchronization IS NULL
                                      AND is_synchronized=1
                                      THEN contract_synch 
                                      END)) AS contract_synch,
                      count(          CASE WHEN error_listening IS NULL
                                      AND error_synchronization IS NULL
                                      AND is_synchronized=1
                                      THEN contract_version_synch
                                      END) AS contract_version_synch,
                      COUNT(DISTINCT (CASE WHEN (error_listening IS NOT NULL) THEN  CONCAT(contract_version_synch, amendment_number, revision_number) END)) as error_listening,
                      COUNT(DISTINCT (CASE WHEN (error_synchronization IS NOT NULL) THEN  contract_version_synch END)) as error_synchronization
                      FROM blg_contract_importer.offer_supervision WHERE offer_activation_date IS NOT NULL group by ops_code
            """)
    Flux<OfferSupervisionEntity> countActiveOfferContractsErrors();

   @Query("""
             SELECT
               ro.ops_code AS `ops_code`,
                          `ro`.`ops_label` AS `ops_label`,
                          `ro`.`offer_activation_datetime` AS `offer_activation_date`,
                           0 as contract_synch,
                           0 AS `contract_version_synch`,
                          count(DISTINCT CASE
                              WHEN (`er`.`workflow_step` LIKE 'CONTRACT_%') THEN CONCAT(er.contract_number, er.amendment_number, er.revision_number)
                         END) AS `error_listening`,
                          0 AS `error_synchronization`
                      FROM blg_contract_importer.error_log er
                      JOIN refops ro on er.ops_code = ro.ops_code
                      AND er.contract_number NOT IN (select contract_number from contract)
                      GROUP BY ops_code
           """)
   Flux<OfferSupervisionEntity> getErrorsBeforeFirstInteg();

   @Query("""
           SELECT           
               fo.ops_code,
               ro.ops_label,
               ro.offer_activation_datetime AS offer_activation_date,
               0 AS contract_synch,
               0 AS contract_version_synch,
               count(DISTINCT CASE
               WHEN (`er`.`workflow_step` LIKE 'CONTRACT_%') THEN CONCAT(er.contract_number, er.amendment_number, er.revision_number) END) AS error_listening,
               0 AS error_synchronization
           FROM
               offer_filter fo
               LEFT JOIN refops ro ON fo.ops_code = ro.ops_code
               LEFT JOIN valued_offer vo ON fo.ops_code = vo.ops_code
               LEFT JOIN contract_version cv ON vo.id_valued_offer = cv.id_valued_offer
               LEFT JOIN error_log er ON fo.ops_code = er.ops_code
           WHERE
               cv.id_contract IS NULL
               group by ops_code""")
   Flux<OfferSupervisionEntity> getOffersWithoutContracts();


   @Query("Select COUNT(DISTINCT (CASE WHEN (error_synchronization IS NOT NULL) THEN  contract_version_synch END))" +
       " as error_synchronization FROM offer_supervision;")
   Mono<Long> countSynchronisationError();

}

