package fr.laposte.blg.blinks.u17.service;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.NotificationStatus;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import fr.laposte.blg.blinks.u17.apim.ApimServiceImpl;
import fr.laposte.blg.blinks.u17.util.SchedulerUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private static final String ERR_BUILD_BODY_MISSING_DATA = "U171001";
    private static final String ERR_APIM_CALL               = "U171002";
    private static final String ERR_PARSE_APIM_RESPONSE     = "U171003";
    private static final String ERR_NOTIFICATION_MODEL      = "U171004";

    private static final String SCHEDULER_NOTIFICATION_NAME = "scheduler_notification";
    private static final String FIELD_EMAILS = "emails";
    private static final String PARSE_ERROR_LOG = "Impossible de parser custom_params pour le scheduler '" + SCHEDULER_NOTIFICATION_NAME + "'";

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy 'à' HH:mm:ss");
    private static final ZoneId ZONE_PARIS = ZoneId.of("Europe/Paris");
    private static final String PATH_DELIMITER = "/";

    private final ApimServiceImpl apimService;
    private final SchedulerUtils schedulerUtils;
    private final ExportHistoryRepository exportHistoryRepository;
    private final SchedulerParamsRepository schedulerParamsRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${fr.laposte.apim.notification.command-path}")
    private String notificationCommandPath;

    @Value("${fr.laposte.apim.notification.query-path}")
    private String notificationQueryPath;

    @Value("${fr.laposte.app.env}")
    private String appEnv;

    @Data
    @AllArgsConstructor
    public static class EmailsResponse {
        private List<String> emails;
    }

    @Data
    public static class UpdateEmailsRequest {
        private List<String> add;
        private List<String> remove;
    }

    @Data
    @AllArgsConstructor
    private static class NotificationParams {
        private List<String> emails;
        private String partner;
        private String modelCode;
        private Integer modelVersion;
    }

    public Mono<Void> sendNotification(List<ExportHistoryEntity> exports, SchedulerParamsEntity schedulerParams) {
        if (exports == null || exports.isEmpty()) {
            log.debug("Aucun export à notifier");
            return Mono.empty();
        }

        String path = notificationCommandPath;

        NotificationParams params = extractNotificationParamsFromCustomParams(schedulerParams);

        return Flux.fromIterable(exports)
                .flatMap(export -> buildBody(export, params)
                        .flatMap(body -> {
                            log.info("Envoi notification pour l'export {} via APIM : {}", export.getIdExport(), path);
                            return apimService.post(path, body)
                                    .flatMap(responseBody -> handleApimSuccessResponse(export, responseBody))
                                    .onErrorResume(ex -> handleApimError(export, ex));
                        })
                )
                .then();
    }

    public Mono<Void> checkNotificationStatus(List<ExportHistoryEntity> exports) {
        log.info("checkNotificationStatus appelé pour {} export(s)", exports != null ? exports.size() : 0);
        if (exports == null || exports.isEmpty()) {
            return Mono.empty();
        }

        return Flux.fromIterable(exports)
                .flatMap(this::checkSingleNotificationStatus)
                .then();
    }

    private Mono<Void> checkSingleNotificationStatus(ExportHistoryEntity export) {
        String uuid = export.getNotificationUuid();
        if (uuid == null || uuid.isBlank()) {
            log.warn("Aucun uuid de notification pour l'export {} avec statut CREATED", export.getIdExport());
            return Mono.empty();
        }

        String basePath = notificationQueryPath;
        String path = basePath + PATH_DELIMITER + uuid;

        log.info("Contrôle du statut de la notification uuid={} pour l'export {} via APIM : {}", uuid, export.getIdExport(), path);

        return apimService.get(path)
                .flatMap(responseBody -> handleNotificationStatusResponse(export, responseBody))
                .onErrorResume(ex -> {
                    log.error("Erreur lors de l'appel APIM de contrôle de notification pour l'export {} : {}", export.getIdExport(), ex.getMessage(), ex);
                    return Mono.empty();
                });
    }

    private Mono<Void> handleNotificationStatusResponse(ExportHistoryEntity export, String responseBody) {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode eventsNode = root.get("events");

            if (eventsNode == null || !eventsNode.isArray()) {
                log.warn("Réponse APIM sans events pour l'export {} : {}", export.getIdExport(), responseBody);
                return Mono.empty();
            }

            NotificationEventsAnalysis analysis = analyzeNotificationEvents(eventsNode);

            if (analysis.hasValidationError()) {
                String validationErrorMessage = analysis.validationErrorMessage();
                log.info("Notification en erreur de validation pour l'export {} : {}", export.getIdExport(), validationErrorMessage);
                return exportHistoryRepository
                        .updateNotificationStatusWithErrorCode(export.getIdExport(), NotificationStatus.ERROR, ERR_NOTIFICATION_MODEL, validationErrorMessage)
                        .then();
            }

            if (analysis.hasSentOrDelivered()) {
                log.info("Notification marquée SENT pour l'export {} (uuid={})", export.getIdExport(), export.getNotificationUuid());
                return exportHistoryRepository
                        .updateNotificationStatusAndClearError(export.getIdExport(), NotificationStatus.SENT)
                        .then();
            }

            log.debug("Aucun changement de statut pour la notification de l'export {}", export.getIdExport());
            return Mono.empty();
        } catch (Exception e) {
            String message = "Impossible de parser la réponse APIM de contrôle de notification pour l'export " + export.getIdExport() + " : " + e.getMessage();
            log.warn(message, e);
            return Mono.empty();
        }
    }

    private record NotificationEventsAnalysis(boolean hasSentOrDelivered, String validationErrorMessage) {
        boolean hasValidationError() {
            return validationErrorMessage != null && !validationErrorMessage.isBlank();
        }
    }

    private NotificationEventsAnalysis analyzeNotificationEvents(JsonNode eventsNode) {
        boolean hasSentOrDelivered = false;
        String validationErrorMessage = null;

        for (JsonNode eventNode : eventsNode) {
            hasSentOrDelivered = updateSentOrDeliveredFlag(eventNode, hasSentOrDelivered);
            validationErrorMessage = extractValidationErrorMessage(eventNode, validationErrorMessage);
        }

        return new NotificationEventsAnalysis(hasSentOrDelivered, validationErrorMessage);
    }

    private boolean updateSentOrDeliveredFlag(JsonNode eventNode, boolean currentFlag) {
        if (currentFlag) {
            return true;
        }
        String type = eventNode.hasNonNull("type") ? eventNode.get("type").asText() : null;
        if (type == null) {
            return false;
        }
        return "SENT".equalsIgnoreCase(type) || "DELIVERED".equalsIgnoreCase(type);
    }


    private String extractValidationErrorMessage(JsonNode eventNode, String existingMessage) {
        if (existingMessage != null && !existingMessage.isBlank()) {
            return existingMessage;
        }
        String type = eventNode.hasNonNull("type") ? eventNode.get("type").asText() : null;
        if (!"ERROR".equalsIgnoreCase(type)) {
            return existingMessage;
        }
        String errorCode = eventNode.hasNonNull("errorCode") ? eventNode.get("errorCode").asText() : null;
        if (!"Error.Validation".equalsIgnoreCase(errorCode)) {
            return existingMessage;
        }
        return eventNode.hasNonNull("message") ? eventNode.get("message").asText() : existingMessage;
    }

    private NotificationParams extractNotificationParamsFromCustomParams(SchedulerParamsEntity schedulerParams) {
        List<String> emails = new ArrayList<>();
        String partner = null;
        String modelCode = null;
        Integer modelVersion = null;
        try {
            JsonNode jsonNode = schedulerUtils.mapStringToJson(schedulerParams.getCustomParams());

            // emails
            JsonNode emailsNode = jsonNode.get(FIELD_EMAILS);
            if (emailsNode != null && emailsNode.isArray()) {
                Iterator<JsonNode> it = emailsNode.elements();
                while (it.hasNext()) {
                    JsonNode node = it.next();
                    if (node.isTextual()) {
                        emails.add(node.asText());
                    }
                }
            }

            // données modele
            if (jsonNode.hasNonNull("partner")) {
                partner = jsonNode.get("partner").asText();
            }
            if (jsonNode.hasNonNull("code")) {
                modelCode = jsonNode.get("code").asText();
            }
            if (jsonNode.hasNonNull("version")) {
                modelVersion = jsonNode.get("version").asInt();
            }
        } catch (Exception e) {
            log.warn("Impossible de parser custom_params pour le scheduler {} : {}", schedulerParams.getSchedulerName(), e.getMessage());
        }
        return new NotificationParams(emails, partner, modelCode, modelVersion);
    }

    private Mono<String> buildBody(ExportHistoryEntity export, NotificationParams params) {
        List<String> errors = new ArrayList<>();

        if (export.getFileSendDate() == null) {
            errors.add("file_send_date manquant pour l'export " + export.getIdExport());
        }
        if (export.getDate() == null) {
            errors.add("file_date manquant pour l'export " + export.getIdExport());
        }
        if (export.getFileName() == null) {
            errors.add("file_name manquant pour l'export " + export.getIdExport());
        }
        if (export.getFileType() == null) {
            errors.add("file_type manquant pour l'export " + export.getIdExport());
        }
        if (export.getMessageCount() == null) {
            errors.add("message_count manquant pour l'export " + export.getIdExport());
        }
        if (params.getEmails() == null || params.getEmails().isEmpty()) {
            errors.add("Aucun destinataire email défini dans custom_params pour l'export " + export.getIdExport());
        }
        if (params.getPartner() == null || params.getPartner().isBlank()) {
            errors.add("partner manquant dans custom_params pour l'export " + export.getIdExport());
        }
        if (params.getModelCode() == null || params.getModelCode().isBlank()) {
            errors.add("code (modelCode) manquant dans custom_params pour l'export " + export.getIdExport());
        }
        if (params.getModelVersion() == null) {
            errors.add("version (modelVersion) manquant dans custom_params pour l'export " + export.getIdExport());
        }

        if (!errors.isEmpty()) {
            String errorMessage = String.join("; ", errors);
            log.warn("Impossible de construire le body pour l'export {} : {}", export.getIdExport(), errorMessage);
            return exportHistoryRepository
                    .updateNotificationStatusWithErrorCode(export.getIdExport(), NotificationStatus.ERROR, ERR_BUILD_BODY_MISSING_DATA, errorMessage)
                    .then(Mono.empty());
        }

        String body = buildBodyFromExport(export, params);
        return Mono.just(body);
    }

    // Body de la requête APIM
    private String buildBodyFromExport(ExportHistoryEntity export, NotificationParams params) {
        Double caHt = export.getCaHtHorsRelevesAndAcomptes();
        Double caTtc = export.getCaTtcHorsRelevesAndAcomptes();

        String exportDate = export.getDate() != null
                ? formatInstant(export.getDate())
                : "";

        Integer nbAcomptes = export.getNbAcomptes();
        Integer nbAvoirs = export.getNbAvoirs();
        Integer nbFactures = export.getNbNormalInvoices();
        Integer nbObjetsErreurs = export.getNbFailedInvoices();
        Integer nbObjetsExclus = export.getNbExcludedInvoices();
        Integer nbObjetsExportes = export.getNbInvoiceExportedInFile();
        Integer nbReleves = export.getNbReleves();

        String dateHeureDossierCft = export.getFileSendDate() != null
                ? formatInstant(export.getFileSendDate())
                : "";

        String env = resolveEnv();
        Integer nbObjetsTraites = export.getMessageCount();

        String partenaireBlinks = export.getFileType() != null
                ? export.getFileType().name()
                : "";

        String recipientsJson = buildRecipientsJson(params.getEmails());

        StringBuilder dataBuilder = new StringBuilder();
        dataBuilder.append("\"DATE_HEURE_DOSSIER_CFT\":\"").append(dateHeureDossierCft).append("\",");
        dataBuilder.append("\"ENV\":\"").append(env).append("\",");
        dataBuilder.append("\"EXPORT_DATE\":\"").append(exportDate).append("\",");

        if (caHt != null) {
            dataBuilder.append("\"CA_HT\":").append(caHt).append(",");
        }
        if (caTtc != null) {
            dataBuilder.append("\"CA_TTC\":").append(caTtc).append(",");
        }
        if (nbAcomptes != null) {
            dataBuilder.append("\"NB_ACOMPTES\":").append(nbAcomptes).append(",");
        }
        if (nbAvoirs != null) {
            dataBuilder.append("\"NB_AVOIRS\":").append(nbAvoirs).append(",");
        }
        if (nbFactures != null) {
            dataBuilder.append("\"NB_FACTURES\":").append(nbFactures).append(",");
        }
        if (nbObjetsErreurs != null) {
            dataBuilder.append("\"NB_OBJETS_ERREUR\":").append(nbObjetsErreurs).append(",");
        }
        if (nbObjetsExclus != null) {
            dataBuilder.append("\"NB_OBJETS_EXCLUS\":").append(nbObjetsExclus).append(",");
        }
        if (nbObjetsExportes != null) {
            dataBuilder.append("\"NB_OBJETS_EXPORTES\":").append(nbObjetsExportes).append(",");
        }
        if (nbObjetsTraites != null) {
            dataBuilder.append("\"NB_OBJETS_TRAITES\":").append(nbObjetsTraites).append(",");
        }
        if (nbReleves != null) {
            dataBuilder.append("\"NB_RELEVES\":\"").append(nbReleves).append("\",");
        }

        String fileName = export.getFileName() != null ? export.getFileName() : "";
        dataBuilder.append("\"NOM_FICHIER\":\"").append(fileName).append("\",");
        dataBuilder.append("\"PARTENAIRE_BLINKS\":\"").append(partenaireBlinks).append("\"");

        return "{" +
                "\"partner\":\"" + params.getPartner() + "\"," +
                "\"model\":{\"code\":\"" + params.getModelCode() + "\",\"version\":" + params.getModelVersion() + "}," +
                "\"recipients\":" + recipientsJson + "," +
                "\"data\":{" + dataBuilder + "}}" +
                "}";
    }

    private String buildRecipientsJson(List<String> emails) {
        return emails.stream()
                .map(email -> "{\"media\":\"EMAIL\",\"email\":\"" + email + "\"}")
                .collect(Collectors.joining(",", "[", "]"));
    }

    public String resolveEnv() {
        return switch (appEnv) {
            case "mar-sdev" -> "DEVELOPPEMENT";
            case "sloc" -> "LOCAL";
            case "mar-srec" -> "RECETTE";
            case "mar-sacc" -> "ACCOSTAGE";
            case "mar-sass" -> "ASSEMBLAGE";
            case "mar-sass1" -> "ASSEMBLAGE 1";
            case "mar-prod" -> "PRODUCTION";
            case "mar-prod1" -> "LAB";
            default -> appEnv;
        };
    }

    private Mono<Void> handleApimSuccessResponse(ExportHistoryEntity export, String responseBody) {
        try {
            JsonNode node = objectMapper.readTree(responseBody);
            JsonNode uuidNode = node.get("uuid");
            if (uuidNode != null && uuidNode.isTextual()) {
                String uuid = uuidNode.asText();
                return exportHistoryRepository
                        .updateNotificationStatusWithUuid(export.getIdExport(), NotificationStatus.CREATED, uuid)
                        .then();
            } else {
                log.warn("Réponse APIM sans uuid pour l'export {} : {}", export.getIdExport(), responseBody);
                return Mono.empty();
            }
        } catch (Exception e) {
            String message = "Impossible de parser la réponse APIM pour l'export " + export.getIdExport() + " : " + e.getMessage();
            log.warn(message, e);
            return exportHistoryRepository
                    .updateNotificationStatusWithErrorCode(export.getIdExport(), NotificationStatus.ERROR, ERR_PARSE_APIM_RESPONSE, message)
                    .then();
        }
    }

    private Mono<Void> handleApimError(ExportHistoryEntity export, Throwable ex) {
        String message = "Erreur lors de l'appel APIM pour l'export " + export.getIdExport() + " : " + ex.getMessage();
        log.error(message, ex);
        return exportHistoryRepository
                .updateNotificationStatusWithErrorCode(export.getIdExport(), NotificationStatus.ERROR, ERR_APIM_CALL, message)
                .then();
    }

    private String formatInstant(Instant instant) {
        ZonedDateTime zdt = instant.atZone(ZONE_PARIS);
        return DATE_TIME_FORMATTER.format(zdt);
    }

    public Mono<EmailsResponse> getEmails() {
        return loadSchedulerParams()
                .map(this::extractEmailsFromCustomParams)
                .map(EmailsResponse::new);
    }

    public Mono<EmailsResponse> updateEmails(UpdateEmailsRequest request) {
        return loadSchedulerParams()
                .flatMap(entity -> {
                    JsonNode jsonNode = parseCustomParamsToJsonNode(entity);
                    List<String> currentEmails = extractEmailsFromJson(jsonNode);

                    if (request.getAdd() != null) {
                        for (String email : request.getAdd()) {
                            if (email != null && !email.isBlank() && !currentEmails.contains(email)) {
                                currentEmails.add(email);
                            }
                        }
                    }

                    if (request.getRemove() != null) {
                        currentEmails.removeIf(email -> request.getRemove().contains(email));
                    }

                    ((com.fasterxml.jackson.databind.node.ObjectNode) jsonNode)
                            .set(FIELD_EMAILS, buildEmailsArrayNode(currentEmails));
                    entity.setCustomParams(jsonNode.toString());

                    return schedulerParamsRepository.save(entity)
                            .thenReturn(new EmailsResponse(currentEmails));
                });
    }

    private Mono<SchedulerParamsEntity> loadSchedulerParams() {
        return schedulerParamsRepository.findAllBySchedulerName(SCHEDULER_NOTIFICATION_NAME)
                .switchIfEmpty(Mono.error(new IllegalStateException("Scheduler '" + SCHEDULER_NOTIFICATION_NAME + "' introuvable")));
    }

    private List<String> extractEmailsFromCustomParams(SchedulerParamsEntity entity) {
        List<String> emails = new ArrayList<>();
        try {
            if (entity.getCustomParams() == null || entity.getCustomParams().isBlank()) {
                return emails;
            }
            JsonNode root = objectMapper.readTree(entity.getCustomParams());
            emails = extractEmailsFromJson(root);
        } catch (Exception e) {
            log.warn(PARSE_ERROR_LOG, e);
        }
        return emails;
    }

    private List<String> extractEmailsFromJson(JsonNode root) {
        List<String> emails = new ArrayList<>();
        JsonNode emailsNode = root.get(FIELD_EMAILS);
        if (emailsNode != null && emailsNode.isArray()) {
            Iterator<JsonNode> it = emailsNode.elements();
            while (it.hasNext()) {
                JsonNode node = it.next();
                if (node.isTextual()) {
                    emails.add(node.asText());
                }
            }
        }
        return emails;
    }

    private JsonNode parseCustomParamsToJsonNode(SchedulerParamsEntity entity) {
        try {
            if (entity.getCustomParams() != null && !entity.getCustomParams().isBlank()) {
                return objectMapper.readTree(entity.getCustomParams());
            }
        } catch (Exception e) {
            log.warn(PARSE_ERROR_LOG, e);
        }
        return objectMapper.createObjectNode();
    }

    private com.fasterxml.jackson.databind.node.ArrayNode buildEmailsArrayNode(List<String> emails) {
        com.fasterxml.jackson.databind.node.ArrayNode array = objectMapper.createArrayNode();
        emails.forEach(array::add);
        return array;
    }
}
