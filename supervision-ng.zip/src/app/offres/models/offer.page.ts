export class OfferPage {
    currentPage?: number;
    itemsOnPage?: number;
    currentOffset?: number;
    totalPages?: number;
    totalItems?: number;
}