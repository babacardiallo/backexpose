package fr.laposte.blg.blinks.u11.scheduler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.TimeUnit;


@Component
@EnableScheduling
@Slf4j
public class DatabaseCheckScheduler {
    private static final int UNO = 1;
    private static final int CINCO = 5;
    private static final String UP_STATUS = "UP";
    private static final String GET_URL_R2DBC = "http://localhost:8080/actuator/health/r2dbc/";
    @Autowired
    private HttpClientFactory httpClientFactory;


    @Scheduled(fixedDelay = CINCO, timeUnit = TimeUnit.SECONDS)
    public void shutDownAppWhenDbNotHealthy() throws IOException, InterruptedException {

        HttpClient client = httpClientFactory.create();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(GET_URL_R2DBC))
            .build();
        HttpResponse<String> response;
        response = client.send(request,
            HttpResponse.BodyHandlers.ofString());
        String dbStatus = response.body().substring(11, 13);
        log.debug("Database status from Actuator: {}", dbStatus);
        if (!UP_STATUS.equals(dbStatus)) {
            log.error("Connection validation failed with database, u11 will shutdown");
            System.exit(UNO);
        }
    }
}