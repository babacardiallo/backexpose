package fr.laposte.blg.blinks.u17.dto.organization;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
public class ImportOrganizationReportDto {

    @JsonProperty("status")
    String status;

    @JsonProperty("nbWarnings")
    @ToString.Include(name = "Nombre de warnings")
    String nbWarnings;

    @JsonProperty("nbSuccess")
    @ToString.Include(name = "Nombre d'organisations importé/mise à jour avec succès")
    String nbSuccess;

    @JsonProperty("nbEntitesTotalHandled")
    @ToString.Include(name = "Nombre total d'organisations traitées")
    String nbTotal;


}
