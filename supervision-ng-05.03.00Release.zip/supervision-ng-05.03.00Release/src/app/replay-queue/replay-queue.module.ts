import { UitPopupService } from '@cddng/ui-theme';
import { NgModule } from '@angular/core';
import { ReplayQueueRoutingModule } from './replay-queue-routing.module';
import { ReplayQueueComponent } from './replay-queue.component';
import { SharedModule } from '../shared/shared.module';
import { ReplayQueueTable } from './components/replay-queue-table.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { DatePipe } from '@angular/common';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ModalService } from 'ngx-modal-ease';

@NgModule({
    imports: [
        SharedModule,
        ReplayQueueRoutingModule,
        NgxDatatableModule,
        NgxPermissionsModule.forChild()
    ],
    providers: [UitPopupService, DatePipe, Location, ModalService],
    declarations: [ReplayQueueComponent, ReplayQueueTable],
    exports: [ReplayQueueComponent]
})
export class ReplayQueueModule { }