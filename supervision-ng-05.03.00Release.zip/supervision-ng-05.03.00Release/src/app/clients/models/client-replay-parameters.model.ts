export class ClientReplayParameters {
    coclico?: any;
    date?: Date;
    replayRefcom?: string;
}