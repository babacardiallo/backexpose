package fr.laposte.blg.blinks.u17.scheduler;

import java.io.IOException;
import java.nio.file.Path;

@FunctionalInterface
public interface OpenSslEncryptor {

    /**
     * @return le code retour du process (0 attendu)
     */
    int encrypt(Path inputFile, Path outputFile, String keyPath) throws IOException, InterruptedException;
}

