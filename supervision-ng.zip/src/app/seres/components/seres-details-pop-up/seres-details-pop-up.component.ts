import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { SeresTable } from "../../models/seres-table.model";
import { SeresService } from "../../service/seres.service";

@Component({
    selector: 'seres-details-pop-up-component',
    templateUrl: './seres-details-pop-up.component.html',
    styleUrls: ['./seres-details-pop-up.component.scss'],
    standalone: false
})

export class SeresDetailsPopUpComponent implements OnInit {

    seres: any;
    seresDetails: SeresTable = new SeresTable();
    name = 'SeresDetailsPopUpComponent';

    constructor(private modalService: ModalService, private seresService: SeresService, private snackBar: MatSnackBar, private datePipe: DatePipe) {
    }

    ngOnInit() {
        this.getSeresDetails(this.seres.id);
    }

    getSeresDetails(id: number): Promise<any> {
        return new Promise((resolve) => {
            this.seresService.getSeresDetails(id).subscribe((response:any)  => {
                this.seresDetails =  {
                    id: response.id,
                    invoiceNumber: response.invoiceNumber,
                    errorDate: this.formatDate(response.errorDate),
                    errorCode: response.errorCode,
                    errorMessage: response.errorMessage,
                    invoiceUrl: response.invoiceUrl
                };
            }
            );
        });
    }

    formatDate(date: any): string | null {
        return date ? this.datePipe.transform(date, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
    }

    close(){
        this.modalService.close(this.name);
    }
}
