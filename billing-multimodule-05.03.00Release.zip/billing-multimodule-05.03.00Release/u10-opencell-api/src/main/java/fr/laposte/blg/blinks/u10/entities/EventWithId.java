package fr.laposte.blg.blinks.u10.entities;

import org.springframework.data.rest.core.config.Projection;

import java.time.Instant;
import java.util.UUID;

@Projection(name = "withId", types = {Event.class})
public interface EventWithId {
    UUID getId();
    String getEventUuid();
    Instant getErrorDate();
    String getErrorCode();
    String getErrorMessage();
    String getKafkaMessage();
    Integer getNbRetry();
    String getReplayStatus();
    Integer getOffset();
    Integer getPartition();
    String getContractCode();
    String getCustAccNumber();
    String getOfferCode();
    String getProductCode();
    String getServiceCode();
    String getChargeCode();
    String getAnalysis();
    String getSolution();
}
