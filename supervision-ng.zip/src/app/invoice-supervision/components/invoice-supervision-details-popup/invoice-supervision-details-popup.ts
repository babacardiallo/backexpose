import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { ModalService } from "ngx-modal-ease";
import { InvoiceSupervisionDetailsModel } from "../../models/invoice-supervision-details.model";
import { InvoiceSupervisionTable } from "../../models/invoice-supervision-table.model";
import { InvoiceSupervisionService } from "../../service/invoice-supervision.service";

@Component({
    selector: 'invoice-supervision-details-popup-component',
    templateUrl: './invoice-supervision-details-popup.html',
    styleUrls: ['./invoice-supervision-details-popup.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: false
})

export class InvoiceSupervisionDetails implements OnInit {

    invoice: InvoiceSupervisionTable;
    idsInvoiceExport: number[] = new Array<number>();
    invoiceDetails: InvoiceSupervisionDetailsModel;


    constructor(private invoiceSupervisionService: InvoiceSupervisionService, private datePipe: DatePipe, private modalService: ModalService) {

    }

    async ngOnInit() {
        this.getNonNullExportIds(this.invoice);
        await this.getInvoiceDetails(this.invoice.idInvoice, this.idsInvoiceExport);
    }

    getNonNullExportIds(invoice: InvoiceSupervisionTable) {
        if (this.invoice.docaposteExportId != null) {
            this.idsInvoiceExport.push(this.invoice.docaposteExportId);
        }
        if (this.invoice.infocaExportId != null) {
            this.idsInvoiceExport.push(this.invoice.infocaExportId);
        }
        if (this.invoice.equinoxExportId != null) {
            this.idsInvoiceExport.push(this.invoice.equinoxExportId);
        }
    }

    async getInvoiceDetails(idInvoice: number, idsExport: number[]): Promise<any> {
        return new Promise((resolve) => {
            this.invoiceSupervisionService.getInvoiceDetails(idInvoice, idsExport).subscribe({
                next: (response: any) => {
                    this.invoiceDetails = <InvoiceSupervisionDetailsModel>{
                        support: response.support,
                        printFlag: response.printFlag,
                        isCredit: response.credit,
                        isRefundable: response.refundable,
                        isDownpayment: response.downpayment,
                        isStatement: response.statement,
                        isOpencellPdf: response.opencellPdf,
                        isDedicated: response.dedicated,
                        htAmount: response.htAmount,
                        amount: response.amount,
                        equinoxFileName: response.equinoxFileName,
                        docaposteFileName: response.docaposteFileName,
                        infocaFileName: response.infocaFileName,
                        equinoxTransferDate: this.formatDatePopup(response.equinoxTransfertDate),
                        infocaTransferDate: this.formatDatePopup(response.infocaTransfertDate),
                        docaposteTransferDate: this.formatDatePopup(response.docaposteTransfertDate),
                        equinoxTransferStatus: response.equinoxTransferStatus,
                        docaposteTransferStatus: response.docaposteTransferStatus,
                        infocaTransferStatus: response.infocaTransferStatus,
                        invoiceJson: response.invoiceJson != null ? JSON.parse(response.invoiceJson) : null,
                        mappingError: response.mappingError != null ? response.mappingError : null

                    }
                },
                complete: () => {
                    if (this.invoiceDetails.isStatement) {
                        this.invoiceDetails.type = "Relevé"
                    }
                    else if (this.invoiceDetails.isCredit) {
                        this.invoiceDetails.type = "Avoir"
                    }
                    else {
                        this.invoiceDetails.type = "Facture"
                    }
                    if (this.invoiceDetails.invoiceJson != null) {
                        this.invoiceDetails.invoiceJson = this.convertTimestampToISO(this.invoiceDetails.invoiceJson);
                    }
                    resolve(true);
                }
            });
        });
    }

    convertTimestampToISO(timestampedJson: any): any {
        const billingDates = ['endDate', 'startDate', 'expiryDate', 'paymentDate', 'calculationDate', 'lastDepositDate', 'consumptionRefDate'];

        if (Array.isArray(timestampedJson)) {
            return timestampedJson.map(item => this.convertTimestampToISO(item));
        }
        if (timestampedJson !== null && typeof timestampedJson === 'object') {
            const result: any = {};
            for (const [key, value] of Object.entries(timestampedJson)) {
                if ((key === 'contractVersionValidityEndDateTime' || key === 'contractVersionValidityStartDateTime') && value === null) {
                    result[key] = "";
                }
                else if (billingDates.includes(key) && typeof value === 'number') {
                    const ts = value < 1e12 ? value * 1000 : value;
                    result[key] = this.formatToISO8601(ts);
                }
                else if (typeof value === 'number' && key.toLowerCase().includes('date')) {
                    const ts = value < 1e12 ? value * 1000 : value;
                    result[key] = this.formatDateJson(ts);
                } else {
                    result[key] = this.convertTimestampToISO(value);
                }
            }
            return result;
        }
        return timestampedJson;
    }



    formatDatePopup(date: any) {
        return date ? this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
    }

    formatDateJson(timestamp: number): string | null {
        return this.datePipe.transform(timestamp, "yyyy-MM-dd'T'HH:mm:ss", undefined, 'fr-FR');
    }

    formatToISO8601(instant: number): string | null {
        return this.datePipe.transform(instant, 'yyyy-MM-ddTHH:mmZZZZZ', 'Europe/Paris');
    }

    close() {
        this.modalService.close();
    }

}