package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.ContractStatusEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractSubStatusEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationException;
import fr.laposte.bscc.billing.avro.billing.ContractOpencell;
import org.mapstruct.*;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

@Mapper
@DecoratedWith(ContractOpencellMapperDecorator.class)
public interface ContractOpencellMapper {

    @BeanMapping(ignoreByDefault = true)
    //Disable the implicit mapping when the property names are equals on the both side
    @Mappings(
            {
                    /* contractionInformation */
                    @Mapping(source = "contract.contractNumber", target = "contractInformation.contractNumber"),
                    @Mapping(source = "contract.type", target = "contractInformation.type"),
                    @Mapping(source = "contract.subtype", target = "contractInformation.subType"),
                    @Mapping(source = "contract.effectiveDatetime", target = "contractInformation.effectiveDateTime"),
                    @Mapping(source = "contract.renewalMode", target = "contractInformation.renewalMode"),
                    @Mapping(source = "contract.signatureDatetime", target = "contractInformation.signatureDateTime"),
                    @Mapping(source = "contract.custContractualAgreementReference", target = "contractInformation.custContractualAgreementReference"),
                    @Mapping(source = "contract.creationChannel", target = "contractInformation.creationChannel"),
                    @Mapping(source = "contract.comments", target = "contractInformation.comments"),
                    //Under this comment mappings : Managed in the decorator because invoiceInformation.type was landing in contractInformation.type with the automatic mapping.
                    @Mapping(target = "contractInformation.contractingCustRef2", ignore = true),
                    @Mapping(target = "contractInformation.custPurchaseOrderNumber", ignore = true),
                    @Mapping(target = "contractInformation.contractingCustRef1", ignore = true),
                    @Mapping(target = "contractInformation.marketNumber", ignore = true),
                    @Mapping(target = "contractInformation.custBusinessUnitRef", ignore = true),
                    @Mapping(target = "contractInformation.frameworkContractNumber", ignore = true),
                    @Mapping(target = "contractInformation.invoicingCustRef2", ignore = true),
                    @Mapping(target = "contractInformation.invoicingCustRef1", ignore = true),
                    @Mapping(target = "contractInformation.sirenNumber", ignore = true),
                    @Mapping(target = "contractInformation.companyName", ignore = true),
                    @Mapping(target = "contractInformation.siretNumber", ignore = true),
                    @Mapping(target = "contractInformation.routingCode", ignore = true),
                    @Mapping(target = "contractInformation.suffix", ignore = true),
                    @Mapping(target = "contractInformation.idRoutingCode", ignore = true),
                    /* contractVersionInformation */
                    @Mapping(source = "validityStartDatetime", target = "contractVersionInformation.validityStartDateTime"),
                    @Mapping(source = "validityEndDatetime", target = "contractVersionInformation.validityEndDateTime"),
                    @Mapping(source = "revisionNumber", target = "contractVersionInformation.versionNumber"),
                    @Mapping(source = "amendmentNumber", target = "contractVersionInformation.amendmentNumber"),
                    @Mapping(source = "status", target = "contractVersionInformation.status"),
                    @Mapping(source = "substatus", target = "contractVersionInformation.subStatus"),
                    @Mapping(source = "terminationDatetime", target = "contractVersionInformation.terminationDateTime"),
                    //Managed in the decorator because if term isn't an integer we get an error
                    @Mapping(target = "contractVersionInformation.term", ignore = true),
                    @Mapping(source = "category", target = "contractVersionInformation.category"),
                    @Mapping(source = "parentContractNumber", target = "contractVersionInformation.parentContractNumber"),
                    @Mapping(source = "parentAmendmentNumber", target = "contractVersionInformation.parentAmendmentNumber"),

                    /* invoiceInformation */
                    @Mapping(target = "invoiceInformation.sellersector", constant = ""), //@TODO Check data source
                    @Mapping(source = "invoiceInformationEntity.invoiceAddressNumber", target = "invoiceInformation.addressNumber"),
                    @Mapping(source = "invoiceInformationEntity.addressFacturation.name1", target = "invoiceInformation.name1"),
                    @Mapping(source = "invoiceInformationEntity.addressFacturation.add2", target = "invoiceInformation.add2"),
                    @Mapping(source = "invoiceInformationEntity.addressFacturation.add3", target = "invoiceInformation.add3"),
                    @Mapping(source = "invoiceInformationEntity.addressFacturation.add4", target = "invoiceInformation.add4"),
                    @Mapping(source = "invoiceInformationEntity.addressFacturation.add5", target = "invoiceInformation.add5"),
                    @Mapping(source = "invoiceInformationEntity.addressFacturation.add6", target = "invoiceInformation.add6"),
                    @Mapping(source = "invoiceInformationEntity.invoiceMode", target = "invoiceInformation.mode"),
                    @Mapping(source = "invoiceInformationEntity.sendingSupportLabel", target = "invoiceInformation.sendingSupportLabel"),
                    @Mapping(source = "invoiceInformationEntity.dedicatedInvoiceFlag", target = "invoiceInformation.dedicatedInvoiceFlag"),
                    @Mapping(source = "invoiceInformationEntity.inArrearsInvoiceFlag", target = "invoiceInformation.inArrearsInvoicingFlag"),
                    @Mapping(source = "invoiceInformationEntity.type", target = "invoiceInformation.type"),
                    @Mapping(target = "invoiceInformation.sector", constant = "980"),
                    @Mapping(source = "invoiceInformationEntity.bosco", target = "invoiceInformation.custInvoiceTermId"),
                    /* invoiceInformation.vatInformation */
                    @Mapping(source = "invoiceInformationEntity.vatDepositZoneCode", target = "invoiceInformation.vatInformation.VATdepositZoneCode"),
                    @Mapping(source = "invoiceInformationEntity.vatLiabilityFlag", target = "invoiceInformation.vatInformation.VATliabilityFlag"),
                    /* paymentInformation */
                    @Mapping(source = "invoiceInformationEntity.rum", target = "paymentInformation.RUM"),
                    @Mapping(source = "invoiceInformationEntity.mandate.iban", target = "paymentInformation.IBAN"),
                    @Mapping(source = "invoiceInformationEntity.mandate.bic", target = "paymentInformation.BIC"),
                    @Mapping(source = "invoiceInformationEntity.mandate.status", target = "paymentInformation.mandateStatus"),
                    @Mapping(source = "invoiceInformationEntity.invoicePeriodicityLabel", target = "paymentInformation.invoicePeriodicityLabel"),
                    @Mapping(source = "invoiceInformationEntity.paymentMeans", target = "paymentInformation.meansLabel"),
                    @Mapping(source = "invoiceInformationEntity.paymentPeriod", target = "paymentInformation.periodLabel"),
                    @Mapping(source = "invoiceInformationEntity.meansReference", target = "paymentInformation.meansReference"),
                    @Mapping(source = "invoiceInformationEntity.bankName", target = "paymentInformation.bankName"),
                    @Mapping(source = "invoiceInformationEntity.amount", target = "paymentInformation.amount"),
                    @Mapping(source = "contract.legalPersonEntity.compName", target = "paymentInformation.accountHolderName"), //BILLING-370
                    @Mapping(source = "invoiceInformationEntity.schedule", target = "paymentInformation.scheduleLabel"),
                    @Mapping(source = "invoiceInformationEntity.paymentCCId", target = "paymentInformation.paymentCCId"),
                    @Mapping(source = "invoiceInformationEntity.paymentCCDateTime", target = "paymentInformation.paymentCCDateTime"),
                    /* financialSecurityInformation */
                    @Mapping(source = "invoiceInformationEntity.financialSecurityMeans", target = "financialSecurityInformation.financialSecurityMeans"),
                    @Mapping(source = "invoiceInformationEntity.riskLevelColor", target = "financialSecurityInformation.riskLevelColor"),
                    @Mapping(source = "invoiceInformationEntity.validityStartDatetime", target = "financialSecurityInformation.validityStartDate"),
                    @Mapping(source = "invoiceInformationEntity.validityEndDatetime", target = "financialSecurityInformation.validityEndDate"),
                    @Mapping(source = "invoiceInformationEntity.depositPaymentFlag", target = "financialSecurityInformation.depositPaymentFlag"),
                    @Mapping(source = "invoiceInformationEntity.securityAmount", target = "financialSecurityInformation.securityAmount"),
                    @Mapping(source = "invoiceInformationEntity.securityCeiling", target = "financialSecurityInformation.securityCeiling"),
                    /* valuedOffer (managed in decorator) */
                    @Mapping(target = "valuedOffer", ignore = true)

            }

    )
    ContractOpencell contractVersionEntityToContractOpencell(ContractVersionEntity contractVersionEntity);


    default CharSequence mapStatus(ContractStatusEnum contractStatusEnum) {
        return switch (contractStatusEnum) {
            case VALIDE -> "Valide";
            case INACTIF -> "Inactif";
            case EN_COURS_DE_CREATION -> "En cours de création";
            default -> throw new SynchronizationException("Le status " + contractStatusEnum + "n'est pas valide.");
        };
    }

    default CharSequence mapSubStatus(ContractSubStatusEnum contractSubStatusEnum) {
        return switch (contractSubStatusEnum) {
            case EN_COURS_DE_CREATION -> "En cours de création";
            case EDITE -> "Edité";
            case A_VALIDER -> "A valider";
            case SIGNE -> "Signé";
            case VALIDE -> "Valide";
            case DEMANDE_DE_RESILIATION -> "Demande de résiliation";
            case ECHU -> "Échu";
            case EN_COURS_DE_RENOUVELLEMENT -> "En cours de renouvellement";
            case RESILIE -> "Résilié";
            case TERMINE -> "Terminé";
            case RENOUVELE -> "Renouvelé";
            case ANNULE -> "Annulé";
            case AVENANT -> "Avenant";
            default ->
                    throw new SynchronizationException("Le sous-status" + contractSubStatusEnum + "de contrat n'est pas autorisée");
        };
    }

    default String asString(Instant instant) {
        return instant != null ? ZonedDateTime.ofInstant(instant, ZoneId.of("Europe/Paris")).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) : null;
    }

    default Instant asInstant(String date) {
        return date != null && !date.isBlank() ? ZonedDateTime.parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toInstant() : null;
    }
}
