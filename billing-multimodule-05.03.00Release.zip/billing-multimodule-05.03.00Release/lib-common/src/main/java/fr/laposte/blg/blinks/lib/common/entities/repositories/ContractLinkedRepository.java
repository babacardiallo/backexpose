package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractLinkedEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ContractLinkedRepository extends ReactiveCrudRepository<ContractLinkedEntity, Long> {

    Flux<ContractLinkedEntity> findAllByIdContract(long idContract);
}
