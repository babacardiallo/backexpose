package fr.laposte.blg.blinks.u17.controller;


import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.MorningCheckMonthly;
import fr.laposte.blg.blinks.u17.dto.CalendarEventDto;
import fr.laposte.blg.blinks.u17.dto.MorningCheckDto;
import fr.laposte.blg.blinks.u17.dto.TransferIhmDto;
import fr.laposte.blg.blinks.u17.service.MorningCheckService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import org.checkerframework.common.value.qual.EnumVal;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/morning-check")
@CrossOrigin
@Data
@Validated
@OpenAPIDefinition(tags = {@Tag(name = "MorningCheckController")})
public class MorningCheckController {

    private final MorningCheckService morningCheckService;

    @GetMapping("/histories")
    @Operation(
            summary = "History des exports",
            description = "Service permettant de récupérer les histories des exports")
    Flux<MorningCheckDto> getHistories(
            @RequestParam(value = "date", required = false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate date
    ) {
        return this.morningCheckService.getExportHistories(date);
    }

    @PostMapping("/updateFileSent")
    @Operation(
            summary = "Mise à jour du status d'envoi du fichier",
            description = "Ce fichier permet de mettre à jour le status d'envoi du fichier")
    Mono<Integer> updateFileSentStatus(
            @RequestParam(value = "fileDate") @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME) LocalDateTime fileDate,
            @RequestParam(value = "fileSendDate") @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME) LocalDateTime fileSendDate,
            @EnumVal({"DOCAPOSTE", "INFOCA", "COEURFINANCE"}) @RequestParam(value = "fileType") FileType fileType
    ) {
        return this.morningCheckService.updateFileSendStatus(fileType, fileDate, fileSendDate);
    }



    @GetMapping("/monthlyTreatment")
    @Operation(
            summary = "Traitement du mois",
            description = "Service permettant de récupérer les résultats du traitement mensuel")
    Flux<CalendarEventDto> getMonthlyTreatment( @RequestParam(value = "year", required = false) Integer year, @RequestParam(value = "month", required = false) Integer month) {
        return this.morningCheckService.getMonthlyTreatment(year, month);
    }

    @GetMapping("/histories-daily-type")
    @Operation(
            summary = "History des exports",
            description = "Service permettant de récupérer les histories des exports")
    Mono<Map<FileType, List<MorningCheckDto>>> getHistoriesDaily(
            @RequestParam(value = "date", required = false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate date
    ) {
        return this.morningCheckService.getExportHistoriesDaily(date);
    }

    @GetMapping("/histories-monthly-type")
    @Operation(
            summary = "Traitements regroupés par mois",
            description = "Service permettant de récupérer la somme de touts les compteurs par mois")
    Mono<Map<FileType, MorningCheckMonthly>> getMonthlyMorningCheck(@RequestParam(value = "year", required = false) Integer year, @RequestParam(value = "month", required = false) Integer month) {
        return this.morningCheckService.getMonthlyMorningCheck(year, month);
    }

    @GetMapping("/status-file-transfer")
    @Operation(
            summary = "History des tranferts des fichiers du jour",
            description = "Service permettant de récupérer les tranferts des fichiers du jour")
    Flux<TransferIhmDto> getTransferStatusDuJour(
            @RequestParam(value = "date", required = false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate date
    ) {
        return this.morningCheckService.getTransferStatusDuJour(date);
    }

    @GetMapping("/status-file-transfer-monthly")
    @Operation(
            summary = "History des tranferts des fichiers par mois",
            description = "Service permettant de récupérer les tranferts des fichiers par mois")
    Flux<TransferIhmDto> getTransferStatusMonthly(
            @RequestParam(value = "year", required = false) Integer year, @RequestParam(value = "month", required = false) Integer month
    ) {
        return this.morningCheckService.getTransferStatusMonthly(year, month);
    }
}