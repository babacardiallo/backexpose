package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;


@Table("offer_errors_view")
@AllArgsConstructor
@Data
public class ContractErrorEntity {

    @Column("contract_number")
    private String contractNumber;

    @Column("revision_number")
    private String versionNumber;

    @Column("amendment_number")
    private String amendmentNumber;

    @Column("date_error")
    private Instant dateError;

    @Column("first_error_date")
    private Instant firstErrorDate;

    @Column("is_synchronized")
    private Boolean isSynchronized;

    @Column("previous_date_synchronization")
    private Instant previousDateSynchronization;

    @Column("workflow_step")
    private String workflowStep;

    @Column("error_message")
    private String errorMessage;

    @Column("ops_code")
    private String opsCode;
}
