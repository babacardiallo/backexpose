import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { ContratsDetailsPopUpComponent } from './components/contrats-details-pop-up/contrats-details-pop-up.component';
import { ContratsTableComponent } from './components/contrats-table.component';
import { ContratsRoutingModule } from './contrats-routing.module';
import { ContratsComponent } from './contrats.component';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CdkStepperModule } from "@angular/cdk/stepper";
import { ContratsReplayerPopUpComponent } from './components/contrats-replayer-pop-up/contrats-replayer-pop-up.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ModalService } from 'ngx-modal-ease';

@NgModule({
    imports: [
        SharedModule,
        ContratsRoutingModule,
        NgxDatatableModule,
        MatStepperModule,
        CdkStepperModule,
        MatSnackBarModule,
        NgxPermissionsModule.forChild()
    ],
    providers: [DatePipe, MatSnackBarModule, ModalService],
    declarations: [ContratsComponent, ContratsTableComponent, ContratsDetailsPopUpComponent, ContratsReplayerPopUpComponent],
    exports: [ContratsComponent]
})
export class ContratsModule { }
