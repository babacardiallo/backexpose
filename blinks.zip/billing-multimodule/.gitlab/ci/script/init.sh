#!/bin/bash
set -e

echo ""
echo "📦 [CI CONTEXT SNAPSHOT]"
echo ""
# 🎯 Pipeline Metadata
echo "📅 Pipeline ID        : $CI_PIPELINE_ID"
echo "⚙️ Pipeline source :  : $CI_PIPELINE_SOURCE"
echo "🏗️ Job Name           : $CI_JOB_NAME"
echo "-----"
# 📁 Git Metadata
echo "🔀 Commit SHA         : $CI_COMMIT_SHA"
echo "📌 Short SHA          : $CI_COMMIT_SHORT_SHA"
echo "📂 Branch / Tag       : $CI_COMMIT_REF_NAME"
echo "👤 Commit Author      : $GITLAB_USER_NAME"
echo "🧱 Selected Modules   : $TARGET_MODULES"
echo "🧱 Commit TAG         : $CI_COMMIT_TAG"
echo "🧱 Commit Branch      : $CI_COMMIT_REF_SLUG"
echo "-----"
# 🌐 Environment Configuration
set -e
echo "🔧 Initializing deployment environment..."
# Define the path to the env file based on the selected ENV_ID
ENV_FILE=".gitlab/ci/env/kube/${ENV_ID}.env"

# Check if the env file exists
if [ ! -f "$ENV_FILE" ]; then
  echo "❌ Environment file not found: $ENV_FILE"
  exit 1
fi

echo "📄 Loading $ENV_FILE"

# Load environment variables from the file
set -a
source "$ENV_FILE"
set +a

# Generate a .env.generated file by capturing all variables prefixed with APP_
echo "💾 Generating .env.generated from APP_ variables"
> .env.generated
for var in $(compgen -v | grep '^APP_'); do
  value="${!var}"
  clean_name="${var#APP_}"
  echo "${clean_name}=${value}" >> .env.generated
done

# Enrich .env.generated file
#echo "🔧 Generating IMAGE TAG NAME..."
#IMAGE_TAG="${CI_COMMIT_TAG:-${CI_COMMIT_REF_SLUG}-latest}"
#IMAGE_TAG="blabla"
#echo "IMAGE_TAG=$IMAGE_TAG"
#echo "IMAGE_TAG=$IMAGE_TAG" >> .env.generated

# Show the resulting variables
echo "✅ Available variables:"
cat .env.generated


