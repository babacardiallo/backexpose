CREATE OR REPLACE
VIEW `blg_contract_importer`.`customer_supervision` AS
    SELECT
        CONCAT(`lp`.`cust_acc_number`,
                `lp`.`id_legal_person`) AS `id`,
        `lp`.`cust_acc_number` AS `cust_acc_number`,
        `lp`.`id_legal_person` AS `id_legal_person`,
        CAST(`lp`.`type_code` AS CHAR (50) CHARSET UTF8MB4) AS `type`,
        `lp`.`marketing_type_code` AS `market_type`,
        `lp`.`comp_name` AS `name`,
        `lp`.`brand_name` AS `brand`,
        `lp`.`is_synchronized` AS `is_synchro`,
        `lp`.`date_synchronization` AS `date_last_synchronization`,
        MAX(`el`.`date_error`) AS `max_date_error`,
        CAST(`lp`.`cust_acc_number` AS CHAR (50) CHARSET UTF8MB4) AS `cust_acc_number_text`
    FROM
        (`blg_contract_importer`.`legal_person` `lp`
        LEFT JOIN `blg_contract_importer`.`error_log` `el` ON ((`lp`.`id_legal_person` = `el`.`id_legal_person`)))
    GROUP BY `lp`.`cust_acc_number`;

CREATE OR REPLACE
VIEW `blg_contract_importer`.`customer_details_supervision` AS
    SELECT
        `lp`.`cust_acc_number` AS `cust_acc_number`,
        `lp`.`id_legal_person` AS `id_legal_person`,
        `lp`.`siret_code` AS `siret_code`,
        `lp`.`legal_nature_code` AS `legal_nature_code`,
        `lp`.`legal_nature_name` AS `legal_nature_name`,
        `lp`.`establish_zone_code` AS `implantation_zone`,
        `lp`.`vat_number` AS `vat_number`,
        `lp`.`legal_person_json` AS `message`,
        `el`.`error_message` AS `error_message`
    FROM
        (`blg_contract_importer`.`legal_person` `lp`
        LEFT JOIN `blg_contract_importer`.`error_log` `el` ON (((`lp`.`id_legal_person` = `el`.`id_legal_person`)
            AND (`el`.`date_error` = (SELECT
                MAX(`e2`.`date_error`)
            FROM
                `blg_contract_importer`.`error_log` `e2`
            WHERE
                (`e2`.`id_legal_person` = `lp`.`id_legal_person`))))));