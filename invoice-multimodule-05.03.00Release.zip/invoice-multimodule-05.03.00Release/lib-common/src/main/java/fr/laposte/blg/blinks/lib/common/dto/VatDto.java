package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
@JsonPropertyOrder({
        "VATRate",
        "amountExcludingVAT",
        "amountIncludingVAT"
})
public class VatDto {
    @JsonProperty("VATRate")
    Double vatRate;
    Double amountExcludingVAT;
    Double amountIncludingVAT;
    Double amountVAT;
}
