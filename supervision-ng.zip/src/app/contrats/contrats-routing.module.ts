import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { ContratsComponent } from './contrats.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: ContratsComponent }
        ])],
    exports: [RouterModule]
})
export class ContratsRoutingModule { }
