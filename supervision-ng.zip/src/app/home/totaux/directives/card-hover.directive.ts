import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[card-hover]',
    standalone: false
})
export class CardHoverDirective {

      constructor(private el: ElementRef) { }

      @HostListener('mouseover') onMouseEnter() {
        this.highlight('#FFC000', true);

      }
      
      @HostListener('mouseout') onMouseLeave() {
        this.highlight('', false);

      }
      
      private highlight(color: string, isBoxShadow: boolean) {
        if(isBoxShadow){
            this.el.nativeElement.style.boxShadow='0 30px 30px 0 rgba(0, 0, 0, 0.2), 0 20px 20px 0 rgba(0, 0, 0, 0.19)';
            this.el.nativeElement.style.borderColor='gray';
        } else {
            this.el.nativeElement.style.boxShadow='0 10px 10px 0 rgba(0, 0, 0, 0.2), 0 1px 1px 0 rgba(0, 0, 0, 0.19)';
            this.el.nativeElement.style.borderColor='#FFC000';

        }
        this.el.nativeElement.style.backgroundColor = color;
      }

}