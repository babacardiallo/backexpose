package fr.laposte.blg.blinks.u11.listener;


import MD.LatestValue.LegalPerson;
import fr.laposte.blg.blinks.u11.config.ssl.SSLContextConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;
import reactor.kafka.sender.SenderResult;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Slf4j
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class LegalPersonInjectorITest {

    String topic = "gk_contractFull_fakeLoc_v1";
    KafkaSender<String, LegalPerson> kafkaProducer;


    @BeforeAll
    public void initKafka() throws IOException, InterruptedException {
        Properties props = configuration();
        SenderOptions<String, LegalPerson> producerOptions = SenderOptions.create(props);
        kafkaProducer = KafkaSender.create(producerOptions);
    }

    Properties configuration() throws IOException {
        SSLContextConfig store = new SSLContextConfig();
        store.trustSSL();
        Properties props = new Properties();
        InputStream input = this.getClass()
            .getClassLoader()
//                    .getResourceAsStream("conf/kafka/local/kafka-sloc-cap.properties");
            .getResourceAsStream("kafka/local/kafka-sloc.properties");
        props.load(input);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
//        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, GenericAvroSerializer.class);
        // props.put("proxy.port", Integer.parseInt("8080"));
        return props;
    }


    public Mono<SenderResult<Integer>> publishLegalPersonLikeRefPM(String key, LegalPerson legalPerson) throws IOException, InterruptedException {
        ProducerRecord<String, LegalPerson> record = new ProducerRecord<>(topic, key, legalPerson);
        SenderRecord<String, LegalPerson, Integer> message = SenderRecord.create(record, 1);
        return kafkaProducer.send(Mono.just(message))
            .next();
    }

    LegalPerson createLegalPerson() throws IOException {

        InputStream jsonFromFile = this.getClass().getClassLoader().getResourceAsStream("fakeLegalPersonFullJson.json");
        JsonAvroConverter jsonAvroConverter = new JsonAvroConverter();
        assert jsonFromFile != null;
        return jsonAvroConverter.convertToSpecificRecord(jsonFromFile.readAllBytes(), LegalPerson.class, LegalPerson.getClassSchema());
    }

    @Test
    public void testActiveManagedOffer() throws InterruptedException, IOException {
        var legalPerson = createLegalPerson();
        var key = "D-001-2";
        // WHEN the legalPerson is published
        publishLegalPersonLikeRefPM(key, legalPerson)
            .subscribe();
        Thread.sleep(5000);
    }
}


