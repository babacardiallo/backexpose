package fr.laposte.blg.blinks.u12.listener.exception;

import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;


public class SynchronizationMappingException extends SynchronizationContractException {

    /**
     * Constructs a new runtime exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this runtime exception's detail message.
     *
     * @param message               the detail message (which is saved for later retrieval
     *                              by the {@link #getMessage()} method).
     * @param cause                 the cause (which is saved for later retrieval by the
     *                              {@link #getCause()} method).  (A {@code null} value is
     *                              permitted, and indicates that the cause is nonexistent or
     *                              unknown.)
     * @param idContract
     * @param contractNumber
     * @param amendmentNumber
     * @param revisionNumber
     * @param contractVersionEntity
     * @since 1.4
     */
    public SynchronizationMappingException(String message, Throwable cause, Long idContract, String contractNumber, Integer amendmentNumber, Integer revisionNumber, ContractVersionEntity contractVersionEntity, String opsCode, CodeErrorEnum codeEroor) {
        super(message, cause, ErrorLogEntity.ErrorWorkflowStepEnum.MAPPING_CONTRACT_OPENCELL, idContract, contractNumber, amendmentNumber, revisionNumber, contractVersionEntity, opsCode, codeEroor);
    }

    public SynchronizationMappingException(String message) {
        super(message);
    }
}
