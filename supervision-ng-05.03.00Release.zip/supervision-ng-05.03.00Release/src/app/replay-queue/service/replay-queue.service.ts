import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ReplayQueueTableModel } from '../models/replay-queue-table.model';

@Injectable({
  providedIn: 'root',
})
export class ReplayQueueService {
  ngUnsubscribe$ = new Subject<void>();

  constructor(private http: HttpClient) {
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }
  httpOptionsTextResponse = {
    headers: new HttpHeaders({
      'Accept': 'text/plain, */*',
      'Content-Type': 'application/json'
    }),
    responseType: 'text' as 'json'
  }

  getReplayQueue(create: boolean, update: boolean, page: number, size: number, sort: string, order: string, filter: string): Observable<any> {
    let queryParams = new HttpParams()
      .set("create", create)
      .set("update", update)
      .set("page", page)
      .set("size", size)
      .set("sort", sort)
      .set("order", order)
      .set("filter", filter);
    return this.http.get<ReplayQueueTableModel[]>(environment.API_QUEUE_REJEUX_ALL + "?" + queryParams, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

}
