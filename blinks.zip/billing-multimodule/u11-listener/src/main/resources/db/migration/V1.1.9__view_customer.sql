CREATE OR REPLACE VIEW customer_supervision AS
SELECT lp.cust_acc_number,
       lp.id_legal_person,
       lp.type_code            as type,
       lp.marketing_type_code  as market_type,
       lp.comp_name            as name,
       lp.brand_name           as brand,
       lp.is_synchronized      as is_synchro,
       lp.date_synchronization as date_last_synchronization,
       MAX(`el`.`date_error`)  as max_date_error,
       lp.siret_code,
       lp.legal_nature_code,
       lp.legal_nature_name,
       lp.establish_zone_code  as implantation_zone,
       lp.vat_number,
       lp.legal_person_json    as message,
       el.error_message        as error_message,
       COUNT(addr.id_address)  as count_address

FROM legal_person lp
         LEFT JOIN error_log el on lp.id_legal_person = el.id_legal_person
         LEFT JOIN address addr on lp.id_legal_person = addr.id_legal_person

GROUP BY lp.cust_acc_number, error_message;