package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonPropertyOrder({
        "custAccNumber",
        "extension",
        "periodicityCode",
        "sectorCode",
        "periodicityLabel",
        "paymentMeanCode",
        "paymentMeanLabel",
        "paymentPeriodCode",
        "paymentPeriodLabel",
        "sendingSupportCode",
        "sendingSupportLabel",
        "SECode",
        "EJCode",
        "frameworkContractNumber",
        "custBusinessUnitRef",
        "contractingCustRef2",
        "businessTeamId",
        "businessTeamLongname",
        "marketNumber",
        "VATliabilityFlag",
        "receiverSiretCode",
        "efact",
        "uniqueMandateReference",
        "billingAddress",
})
public class BillingAccountDTO {
    String custAccNumber;
    String extension;
    String periodicityCode;
    String sectorCode;
    String periodicityLabel;
    String paymentMeanCode;
    String paymentMeanLabel;
    String paymentPeriodCode;
    String paymentPeriodLabel;
    String sendingSupportCode;
    String sendingSupportLabel;
    @JsonProperty("SECode")
    String seCode;
    @JsonProperty("EJCode")
    String ejCode;
    String frameworkContractNumber;
    String custBusinessUnitRef;
    String contractingCustRef2;
    String businessTeamId;
    String businessTeamLongname;
    String marketNumber;
    @JsonProperty("VATliabilityFlag")
    Boolean vatliabilityFlag;
    String receiverSiretCode;
    Boolean efact;
    UniqueMandateReferenceDto uniqueMandateReference;
    BillingAddressDto billingAddress;

}
