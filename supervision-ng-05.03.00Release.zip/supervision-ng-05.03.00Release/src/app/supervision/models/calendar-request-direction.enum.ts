export enum CalendarRequestDirection {
    NEXT = "NEXT",
    PREVIOUS = "PREVIOUS",
    CURRENT = "CURRENT",
    OTHER_DIRECTION = "OTHER_DIRECTION"
  }
  