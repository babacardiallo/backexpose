package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonPropertyOrder({
        "addressId",
        "name1",
        "add2",
        "add3",
        "add4",
        "add5",
        "add6",
        "add7"
})
public class AccountAdressDto {

    Integer addressId;
    String name1;
    String add2;
    String add3;
    String add4;
    String add5;
    String add6;
    String add7;
}
