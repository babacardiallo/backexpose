ALTER TABLE export_history
    ADD COLUMN is_file_empty boolean NOT NULL DEFAULT false,
    ADD COLUMN is_file_sent boolean NOT NULL DEFAULT false,
    MODIFY COLUMN export_status enum ('SUCCESS', 'FAILED', 'WARNING');