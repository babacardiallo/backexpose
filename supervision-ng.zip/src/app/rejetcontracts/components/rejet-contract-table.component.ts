
import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { UntypedFormControl, UntypedFormGroup } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { RejetContractPage } from "../models/rejet-contract-page";
import { RejetContractTableModel } from "../models/rejet-contract-table.model";
import { RejetContractService } from "../service/rejet-contract.service";
import { RejetContractDetailsComponent } from "./rejet-contract-details-pop-up/rejet-contract-details.component";
import { RejetContractSaisiePopupComponent } from "./rejet-contract-saisie-pop-pup/rejet-contract-saisie-pop-pup.component";
import * as XLSX from 'xlsx';
import { ModalService } from "ngx-modal-ease";

@Component({
    selector: 'rejet-contract-table',
    templateUrl: './rejet-contract-table.component.html',
    styleUrls: ['./rejet-contract-table.component.scss'],
    standalone: false
})

export class RejetContractTableComponent implements OnInit {

  @ViewChild(DatatableComponent) rejetContractTable: DatatableComponent;

  searchText: string = '';

  isPending: boolean = false;

  range: UntypedFormGroup;

  listRejetContracts = [];

  globalStartDate: any;

  globalEndDate: any;

  globalStatus = '';

  selectedCodeErreurs = new UntypedFormControl('');

  listErreurs = [];

  rejetContractPage: RejetContractPage = new RejetContractPage();

  M1_MODAL_PROPERTIES = {
    animation: 'enter-going-down',
    duration: '0.1s',
    easing: 'ease-out',
    padding: '1rem',
    width: '1800px',
    height: '100%'
  };

  constructor(private datePipe: DatePipe, private snackBar: MatSnackBar, private rejetContractService: RejetContractService, private modalService: ModalService) {

    this.rejetContractService.busService.subscribe(res => {
      if (res) {
        this.getListRejetContractByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate);
      }
    })
  }


  ngOnInit(): void {
    const today = new Date();
    let oneMonthAgo = new Date();
    oneMonthAgo = new Date(oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1));
    this.range = new UntypedFormGroup({
      start: new UntypedFormControl(oneMonthAgo),
      end: new UntypedFormControl(today),
    });
    this.globalStartDate = this.datePipe.transform(oneMonthAgo, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
    this.globalEndDate = this.datePipe.transform(today, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
    this.getListRejetContractByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate);
    this.getAllErrorsCode();
  }

  getListRejetContractByDate(page: number, size: number, sort: string, order: string, startDate: any, enDate: any) {
    this.rejetContractService.getListRejetContractByDate(page, size, sort, order, startDate, enDate, this.searchText, this.globalStatus, this.selectedCodeErreurs.value).subscribe({
      next: (response: any) => {
        this.listRejetContracts = response._embedded.rejetContracts.map((data: any) => {
          return {
            id: data.id,
            errorDate: this.formatDate(data.errorDate),
            contractNumber: data.contractNumber,
            custAccNumber: data.custAccNumber,
            errorCode: data.errorCode,
            errorMessage: data.errorMessage,
            status: data.status,
            nbRetry: data.nbRetry,
            offerCode: data.offerCode,
            versionNumber: data.versionNumber,
            amendmentNumber: data.amendmentNumber
          };
        });
        this.rejetContractPage.currentPage = response.page.number;
        this.rejetContractPage.itemsOnPage = response.page.size;
        this.rejetContractPage.totalItems = response.page.totalElements
        this.rejetContractPage.totalPages = response.page.totalPages
      },
      complete: () => {
      },

    })
  }


  formatDate(date: any) {
    return date ? this.datePipe.transform(date, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
  }

  onPageChange(event: any) {
    this.getListRejetContractByDate(event.offset, 10, this.rejetContractTable.sorts[0].prop, this.rejetContractTable.sorts[0].dir, this.globalStartDate, this.globalEndDate);
  }

  onSort(event: any) {
    this.getListRejetContractByDate(this.rejetContractPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.globalStartDate, this.globalEndDate);
    this.rejetContractTable.offset = this.rejetContractPage.currentPage!;
  }

  getAllErrorsCode() {
    this.rejetContractService.getAllCodeError().subscribe({
      next: (response: any) => {
        this.listErreurs = response;
      },
      complete: () => {
      },

    })
  }
  filter(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.getListRejetContractByDate(0, 10, "errorDate", "desc", this.globalStartDate, this.globalEndDate);
    }
  }

  selectedDate(event: any) {
    if (event.value) {
      this.globalStartDate = this.datePipe.transform(this.range.value.start, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
      this.globalEndDate = this.datePipe.transform(this.range.value.end, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
      this.getListRejetContractByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate)
    }
  }


  showPending() {
    if (this.isPending) {
      this.globalStatus = 'PENDING';
    } else {
      this.globalStatus = '';
    }
    this.getListRejetContractByDate(0, 10, "errorDate", "desc", this.globalStartDate, this.globalEndDate);
  }

  filterByErrorCode() {
    this.getListRejetContractByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate)
  }


  showPopupSaisie(event: Event) {
    this.modalService
    .open(RejetContractSaisiePopupComponent, {
      modal: {
        enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
        top: '65%'
      },
      overlay: {
        leave: 'fade-out 0.3s',
      },
      size: {
        padding: this.M1_MODAL_PROPERTIES.padding,
        width: '1200px',
        height: this.M1_MODAL_PROPERTIES.height
      },
      data: {
        content: '',
      }
    })
    .then((response) => console.log(response));
    event.stopPropagation();
  }

  updatePerimeter() {
    if (this.listRejetContracts.length < 1) {
      return;
    }
    this.rejetContractService.updateRejetContractFilteredPending().subscribe({
      next: (response) => {
      },
      complete: () => {
        this.snackBar.open("Les statuts des rejets sont passés à PENDING", 'Fermer', { duration: 8000 });
        this.getListRejetContractByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate)
      },
    })



  }

  showPopup(row: RejetContractTableModel, event: Event) {
    this.modalService
    .open(RejetContractDetailsComponent, {
      modal: {
        enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
      },
      overlay: {
        leave: 'fade-out 0.3s',
      },
      size: {
        padding: this.M1_MODAL_PROPERTIES.padding,
        width: this.M1_MODAL_PROPERTIES.width,
        height: this.M1_MODAL_PROPERTIES.height
      },
      data: {
        rejetContract: row,
      }
    })
    .then((response) => console.log(response));

  }

  exportRejetsContracts() {

    let dataToExport: any[];
    this.rejetContractService.getExportedRejetContracts().subscribe({
      next: (response: any) => {
        dataToExport = response.map((data: any) => {
          return <any>{
            id: data.id,
            contractNumber: data.contractNumber,
            amendmentNumber: data.amendmentNumber,
            versionNumber: data.versionNumber,
            custAccNumber: data.custAccNumber,
            offerCode: data.offerCode,
            meansCode: data.meansCode,
            periodCode: data.invoicePeriodicityCode,
            action: data.action,
            errorDate: this.formatDate(data.errorDate),
            status: data.status,
            nbRetry: data.nbRetry,
            errorCode: data.errorCode,
            errorMessage: data.errorMessage ? data.errorMessage.substring(0, 32767) : data.errorMessage,
            kafkaMessage: data.kafkaMessage ? data.kafkaMessage.substring(0, 32767) : data.kafkaMessage,
            offset: data.offset,
            partition: data.partition,
            analysis: data.analysis,
            solution: data.solution
          };
        })
      },
      complete: () => {
        const fileName = 'ExportRejetsContrats_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["ID rejet", "N° Contrat", "N° Avenant", "N° Révision", "N° Client", "Code offre", "Mode de paiement", "Périodicité", "Action", "Date erreur", "Status", "Nb retry", "Code erreur", "Message erreur", "Message json chargé", "Offset", "Partition", "Analyse", "Solution"]];
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport, {
          dateNF: 'dd/mm/yyyy à HH:MM:SS',
          cellDates: true
        });
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.sheet_add_aoa(ws, headers);
        XLSX.utils.book_append_sheet(wb, ws, 'Export');
        ws['!cols'] = [
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 25 },
          { wch: 22 },
          { wch: 50 },
          { wch: 200 },
          { wch: 200 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
          { wch: 50 },
        ];
        XLSX.writeFile(wb, fileName);
      },
    })
  }


  replayPendingRejetContract(e: Event) {
    let returnValue: string;
    this.rejetContractService.postReplayU3().subscribe({
      next: (response: string) => {
        returnValue = response;
      },
      complete: () => {
        if (returnValue == "Traitement lancé avec succès.") {
          this.snackBar.open("Les rejets contrats en PENDING ont été envoyés pour rejeu", 'Fermer', { duration: 5000 });
        }
        else {
          this.snackBar.open("Une erreur est survenue. Veuillez réessayer", 'Fermer', { duration: 5000 });
        }
      },
    })
  }


  formatDateExport(date: number) {
    return this.datePipe.transform(date, 'yyyyMMddHHmmSS', 'fr');
  }


}