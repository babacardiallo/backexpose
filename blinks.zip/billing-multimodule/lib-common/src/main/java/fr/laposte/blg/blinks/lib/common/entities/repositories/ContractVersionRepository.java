package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository("contractVersionEntityRepository")
public interface ContractVersionRepository extends ReactiveCrudRepository<ContractVersionEntity, Long> {

    Flux<ContractVersionEntity> findByIdContractOrderByAmendmentNumberAsc(long idContract);

    Mono<ContractVersionEntity> findByAmendmentNumberAndIdContract(int amendmentNumber, Long idContract);

    @Query("""
            SELECT cv.* FROM contract_version cv            
            INNER JOIN contract c ON cv.id_contract = c.id_contract
            WHERE cv.amendment_number = :amendmentNumber AND c.contract_number = :contractNumber""")
    Mono<ContractVersionEntity> findByContractNumberAndByAmendmentNumber(String contractNumber, int amendmentNumber);

    Mono<ContractVersionEntity> findFirstByIdContractAndIsSynchronized(long idContract, boolean isSynchronized);

    Mono<ContractVersionEntity> findFirstByIdContract(long idContract);

    @Query("""
            SELECT cv.* FROM contract_version cv            
                INNER JOIN invoice_information ii on cv.id_invoice_information = ii.id_invoice_information
                INNER JOIN address a on ii.id_address_invoice = a.id_address
                AND a.address_id_refpm = :refPmAddressId""")
    Flux<ContractVersionEntity> findContractVersionUsingRefPMAddressId(String refPmAddressId);

    Flux<ContractVersionEntity> findAllByIsSynchronizedTrue();

    @Transactional(readOnly = true)
    @Query("SELECT count(id_contract_version) from contract_version where is_synchronized = 1")
    Mono<Long> countVersionsSynched();

    @Query("""
            SELECT cv.* FROM contract_version cv       
            INNER JOIN invoice_information ii on cv.id_invoice_information = ii.id_invoice_information
            INNER JOIN mandate m on ii.id_mandate = m.id_mandate
            WHERE m.rum = :rum"""
    )
    Flux<ContractVersionEntity> findByRum(String rum);

    @Query("""
            SELECT cv.* FROM contract_version cv            
            INNER JOIN valued_offer vo on cv.id_valued_offer = vo.id_valued_offer
            INNER JOIN offer_filter ofl on vo.ops_id = ofl.offer_ops_id"""
    )
    Flux<ContractVersionEntity> findContractsVersionEligibleForSynchronisation();


    @Query("SELECT COUNT(ops_code) FROM offer_filter WHERE ops_code IN (SELECT ops_code FROM valued_offer WHERE id_valued_offer = :idValuedOffer)")
    Mono<Integer> ifOfferContractIsOpenForSynchronisation(@Param("idValuedOffer") Long idValuedOffer);

    @Transactional(readOnly = true)
    @Query("select count(id_contract_version) from contract_version")
    Mono<Long> countContractVersionIntegrated();
}
