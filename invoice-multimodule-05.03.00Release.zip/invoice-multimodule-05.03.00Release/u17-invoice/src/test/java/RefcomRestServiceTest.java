import fr.laposte.blg.blinks.lib.common.entities.organization.OrganizationEntity;
import fr.laposte.blg.blinks.lib.common.repositories.organization.OrganizationRepository;
import fr.laposte.blg.blinks.u17.dto.MoulinetteRefcomDto;
import fr.laposte.blg.blinks.u17.dto.RefcomDto;
import fr.laposte.blg.blinks.u17.mapper.RefcomMapper;
import fr.laposte.blg.blinks.u17.service.RefcomCommunicationService;
import fr.laposte.blg.blinks.u17.service.RefcomRestService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

    @RunWith(MockitoJUnitRunner.class)
    public class RefcomRestServiceTest {

        @Mock
        private OrganizationRepository organizationRepository;

        @Mock
        private OrganizationEntity organizationEntity;

        @Mock
        private RefcomCommunicationService refcomCommunicationService;

        @Mock
        private RefcomMapper refcomMapper;

        @InjectMocks
        private RefcomRestService refcomRestService;

        @Test
        public void testgetEntityCodes() throws Exception {
            LocalDate consultationDate = LocalDate.now();
            Long coclicoParam = 111111L;
            String coclico = "111111";
            String entityCode = "entityCode1";
            String regateCode = "regateCode1";
            MoulinetteRefcomDto moulinetteRefcomDto = new MoulinetteRefcomDto(coclico, entityCode, regateCode);
            RefcomDto refcomDto = new RefcomDto(coclico, entityCode, "ttId1", "ecId1", "20240313");
            organizationEntity = new OrganizationEntity(1L, "entityCode1", "regateCode1", null, null, null, null);

            when(refcomCommunicationService.fetchEntityCodes(eq(consultationDate), anyList()))
                    .thenReturn(Flux.just(refcomDto));
            when(refcomMapper.RefcomDtoToMoulinetteRefcomDto(refcomDto))
                    .thenReturn(moulinetteRefcomDto);
            when(organizationRepository.findByCode(entityCode))
                    .thenReturn(Mono.just(organizationEntity));

            Flux<MoulinetteRefcomDto> resultFlux = refcomRestService.getEntityCodes(consultationDate, Collections.singletonList(coclicoParam));
            List<MoulinetteRefcomDto> resultList = resultFlux.collectList().block();

            assertNotNull(resultList);
            assertEquals(1, resultList.size());
            assertEquals(moulinetteRefcomDto, resultList.get(0));
            assertEquals(regateCode, moulinetteRefcomDto.getRegateCode());
            verify(organizationRepository).findByCode(entityCode);

        }

        @Test
        public void processTest() {
            LocalDate consultationDate = LocalDate.now();
            Long coclicoParam = 111111L;
            String coclico = "111111";
            String entityCode = "entityCode1";
            String regateCode = "regateCode1";
            MoulinetteRefcomDto moulinetteRefcomDto = new MoulinetteRefcomDto(coclico, entityCode, regateCode);
            RefcomDto refcomDto = new RefcomDto(coclico, entityCode, "ttId1", "ecId1", "20240313");
            organizationEntity = new OrganizationEntity(1L, "entityCode1", "regateCode1", null, null, null, null);

            when(refcomCommunicationService.fetchEntityCodes(eq(consultationDate), anyList()))
                    .thenReturn(Flux.just(refcomDto));
            when(refcomMapper.RefcomDtoToMoulinetteRefcomDto(refcomDto))
                    .thenReturn(moulinetteRefcomDto);
            when(organizationRepository.findByCode(entityCode))
                    .thenReturn(Mono.just(organizationEntity));

            Flux<MoulinetteRefcomDto> resultFlux = refcomRestService.getEntityCodes(consultationDate, Collections.singletonList(coclicoParam));
            List<MoulinetteRefcomDto> resultList = resultFlux.collectList().block();

            refcomRestService.process(LocalDate.now(), List.of(1L, 2L));

        }
    }

