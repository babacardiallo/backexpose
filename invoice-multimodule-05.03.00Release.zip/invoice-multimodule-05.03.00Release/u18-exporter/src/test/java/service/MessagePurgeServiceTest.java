package service;

import fr.laposte.blg.blinks.u18.repository.CustomerAccountRepository;
import fr.laposte.blg.blinks.u18.service.impl.MessagePurgeServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class MessagePurgeServiceTest {

    @Mock
    private CustomerAccountRepository repository;
    @InjectMocks
    private MessagePurgeServiceImpl service;

    @Test
    void testPurgeData(){
        when(repository.deleteByCreatedBefore(any(Instant.class))).thenReturn(1);
        service.purgeMessagesOlderThan(Instant.now());
        verify(repository, atLeastOnce()).deleteByCreatedBefore(any(Instant.class));
    }
}
