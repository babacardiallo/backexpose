insert into scheduler_params VALUES(
2,
'scheduler_export',
'* 30 22 * * MON-FRI',
'/opt/app-root/src/donnees/export/',
'',
'',
1,
'{"equinox": 1, "docaposte": 2, "infoca": 3}',
300
);