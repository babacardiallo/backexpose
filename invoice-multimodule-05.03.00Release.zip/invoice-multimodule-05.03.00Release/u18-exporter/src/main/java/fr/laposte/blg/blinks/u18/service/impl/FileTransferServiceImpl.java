package fr.laposte.blg.blinks.u18.service.impl;

import fr.laposte.blg.blinks.u18.service.TransferService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

@Service
@Slf4j
public class FileTransferServiceImpl implements TransferService {


    @Override
    public void transferFiles(String exportDir, String transferDir, String archiveDir) {
        Path exportPath = Paths.get(exportDir);
        Path transferPath = Paths.get(transferDir);
        Path archivePath = Paths.get(archiveDir);
        try (Stream<Path> files = Files.list(exportPath)) {
            files.filter(Files::isRegularFile)
                 .forEach(file -> {
                     try {
                         if (!Files.exists(archivePath)) {
                             Files.createDirectories(archivePath);
                             log.info("Created archive directory: {}", archivePath);
                         }
                         Path target = transferPath.resolve(file.getFileName());

                         if (Files.exists(target)) {
                             log.warn("Target file '{}' already exists — skipping.", target.getFileName());
                             return;
                         }

                         Path archiveFile = archivePath.resolve(file.getFileName());
                         Files.copy(file, archiveFile, StandardCopyOption.REPLACE_EXISTING);
                         log.info("Copied file {} to archive: {}", file, archiveFile);

                         Files.move(file, target);
                         log.info("Moved file '{}' to transfer folder.", file.getFileName());
                     } catch (IOException e) {
                         log.error("Failed to move file '{}': {}", file.getFileName(), e.getMessage());
                     }
                 });
        } catch (IOException e) {
            log.error("Error reading export folder: {}", e.getMessage());
        }
    }
}
