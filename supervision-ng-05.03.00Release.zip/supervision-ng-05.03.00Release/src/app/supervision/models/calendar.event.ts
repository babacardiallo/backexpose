export class CalendarEvent {
    title?: string;
    start?: Date;
    end?: Date;
    color?: any;
    meta?: string;
}
  