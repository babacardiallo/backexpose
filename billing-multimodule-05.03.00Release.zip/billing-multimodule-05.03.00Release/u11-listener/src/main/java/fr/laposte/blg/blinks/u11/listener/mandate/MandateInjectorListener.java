package fr.laposte.blg.blinks.u11.listener.mandate;

import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@Data
@Slf4j
@ConfigurationProperties(prefix = "fr.laposte.billing.listener.mandate-inject.canal-suez")
@ConditionalOnProperty(value = "fr.laposte.billing.listener.mandate-inject.activated", havingValue = "true")
@Profile("mar-srec|mar-sdev|sloc")
public class MandateInjectorListener {
    private final MandateListenerService mandateListenerService;

    // Nom du topic à consommer
    String kafkaTopic;
    // Groupe de consommation
    String kafkaGroupId;


    @Autowired
    public MandateInjectorListener(MandateListenerService mandateListenerService) {
        this.mandateListenerService = mandateListenerService;
    }

    @PostConstruct
    public void init() {
        log.info("Kafka topic: {}", kafkaTopic);
        log.info("Kafka groupId: {}", kafkaGroupId);
        log.info("✅ KafkaListener actif sur topic: {}, groupId: {}", kafkaTopic, kafkaGroupId);
    }


    @KafkaListener(groupId = "${fr.laposte.billing.listener.mandate-inject.canal-suez.kafka-group-id}",
            topics = "${fr.laposte.billing.listener.mandate-inject.canal-suez.kafka-topic}", containerFactory = "stringValueConsumerFactory")
    public void onMessages(List<ConsumerRecord<String, String>> records, Acknowledgment ack) {
        int total = records.size();
        log.info("Kafka batch received: {} mandate from topic '{}'", total, kafkaTopic);
        AtomicInteger errorCount = new AtomicInteger(0);
        try {
            Flux.fromIterable(records)
                    .concatMap(message -> {
                        log.info("Record received: key={}, topic={}, partition={}, offset={}",
                                message.key(), message.topic(), message.partition(), message.offset());
                        return mandateListenerService.updateMandateIfExist(message)
                                .onErrorResume(throwable -> {
                                    errorCount.incrementAndGet();
                                    var errorMess = String.format("Error on Mandate Listener on mandate id: %s", message.key());
                                    log.error(errorMess, throwable);
                                    return Mono.empty();
                                });
                    })
                    .then()
                    .block();
            if (errorCount.get() > 0) {
                log.warn("Batch processing failed with {} errors — retrying individually {} records ))",
                        errorCount.get(), total);
                retryIndividually(records, ack);
            } else {
                ack.acknowledge();
                log.info("Batch processed and acknowledged successfully");
            }
        } catch (Exception error) {
            log.error("Unexpected error during batch processing — retrying individually ({} record(s))", total, error);
            retryIndividually(records, ack);
        }
    }

    private void retryIndividually(List<ConsumerRecord<String, String>> records, Acknowledgment ack) {
        Flux.fromIterable(records)
                .concatMap(message -> mandateListenerService.updateMandateIfExist(message)
                        .doOnSuccess(c -> {
                            log.info("Mandate key: {} is acknowledged successfully", message.key());
                            ack.acknowledge();
                        })
                        .doOnError(e -> log.error("Error processing mandate key={}", message.key(), e))
                        .onErrorResume(throwable -> Mono.empty())
                )
                .then()
                .block();
    }




}

