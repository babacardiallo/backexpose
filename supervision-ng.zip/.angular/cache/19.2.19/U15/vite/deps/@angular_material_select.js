import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger
} from "./chunk-BRWRKYC7.js";
import "./chunk-KP5ROBYH.js";
import "./chunk-5BSH2ABQ.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-I6VLJ4AV.js";
import "./chunk-AXCLBDTL.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-TIOIX5A3.js";
import "./chunk-6R3T6DT3.js";
import "./chunk-R4QB32YE.js";
import "./chunk-XU2CITAW.js";
import "./chunk-42CXJC7H.js";
import "./chunk-RRVAYXRT.js";
import "./chunk-NNKHXUIF.js";
import "./chunk-PBNTYZ45.js";
import "./chunk-GJJITPYH.js";
import "./chunk-42FJBLFI.js";
import "./chunk-JXBCBRYI.js";
import "./chunk-47P2XRX3.js";
import "./chunk-DG6N4IH3.js";
import "./chunk-QCLAAULS.js";
import "./chunk-MM3VFGIV.js";
import "./chunk-BXMHTHPX.js";
import "./chunk-2O4WY5GE.js";
import "./chunk-7GJX37TI.js";
import "./chunk-KHSJTTI4.js";
import "./chunk-5FJDMDII.js";
import "./chunk-7ZCWYKRT.js";
import "./chunk-I76JCCZG.js";
import "./chunk-5YUJUVVP.js";
import "./chunk-MRDQ76HR.js";
import "./chunk-RVYENV4D.js";
import "./chunk-ROQ5OQS3.js";
import "./chunk-S6ETTSTF.js";
import "./chunk-3GOMPWB5.js";
import "./chunk-NTD5R5GH.js";
import "./chunk-IJNFIFIC.js";
import "./chunk-FQZEMCZB.js";
import "./chunk-7IZRYL2Z.js";
import "./chunk-TXDUYLVM.js";

// node_modules/@angular/material/fesm2022/select.mjs
var matSelectAnimations = {
  // Represents
  // trigger('transformPanelWrap', [
  //   transition('* => void', query('@transformPanel', [animateChild()], {optional: true})),
  // ])
  /**
   * This animation ensures the select's overlay panel animation (transformPanel) is called when
   * closing the select.
   * This is needed due to https://github.com/angular/angular/issues/23302
   */
  transformPanelWrap: {
    type: 7,
    name: "transformPanelWrap",
    definitions: [{
      type: 1,
      expr: "* => void",
      animation: {
        type: 11,
        selector: "@transformPanel",
        animation: [{
          type: 9,
          options: null
        }],
        options: {
          optional: true
        }
      },
      options: null
    }],
    options: {}
  },
  // Represents
  // trigger('transformPanel', [
  //   state(
  //     'void',
  //     style({
  //       opacity: 0,
  //       transform: 'scale(1, 0.8)',
  //     }),
  //   ),
  //   transition(
  //     'void => showing',
  //     animate(
  //       '120ms cubic-bezier(0, 0, 0.2, 1)',
  //       style({
  //         opacity: 1,
  //         transform: 'scale(1, 1)',
  //       }),
  //     ),
  //   ),
  //   transition('* => void', animate('100ms linear', style({opacity: 0}))),
  // ])
  /** This animation transforms the select's overlay panel on and off the page. */
  transformPanel: {
    type: 7,
    name: "transformPanel",
    definitions: [{
      type: 0,
      name: "void",
      styles: {
        type: 6,
        styles: {
          opacity: 0,
          transform: "scale(1, 0.8)"
        },
        offset: null
      }
    }, {
      type: 1,
      expr: "void => showing",
      animation: {
        type: 4,
        styles: {
          type: 6,
          styles: {
            opacity: 1,
            transform: "scale(1, 1)"
          },
          offset: null
        },
        timings: "120ms cubic-bezier(0, 0, 0.2, 1)"
      },
      options: null
    }, {
      type: 1,
      expr: "* => void",
      animation: {
        type: 4,
        styles: {
          type: 6,
          styles: {
            opacity: 0
          },
          offset: null
        },
        timings: "100ms linear"
      },
      options: null
    }],
    options: {}
  }
};
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
