package fr.laposte.blg.blinks.lib.common.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("customer_details_supervision")
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDetailsSupervisionEntity {
    @Column("id_legal_person")
    private int idLegalPerson;
    @Column("cust_acc_number")
    private int custAccNumber;
    @Column("siret_code")
    private String siret;
    @Column("legal_nature_code")
    private String legalNatureCode;
    @Column("legal_nature_name")
    private String legalNatureName;
    @Column("implantation_zone")
    private String implantationCode;
    @Column("vat_number")
    private String vatNumber;
    @Column("error_message")
    private String errorMessage;
}
