package fr.laposte.blg.blinks.u14.service.producer;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;

import java.util.*;

@Slf4j
@Service
@Profile("mar-srec|mar-sdev|sloc")
public class KafkaLegalPersonInjectorProducer {

    @Value("${fr.laposte.topic.legal_person_injector}")
    String topic;

    @Resource(name = "kafkaConfig")
    Properties kafkaConfig;

    private KafkaSender<String, MD.LatestValue.LegalPerson> legalPersonKafkaSender;

    public KafkaLegalPersonInjectorProducer(KafkaSender<String, MD.LatestValue.LegalPerson> legalPersonKafkaSender) {
        this.legalPersonKafkaSender = legalPersonKafkaSender;
    }

    @PostConstruct
    void init() {
        SenderOptions<String, MD.LatestValue.LegalPerson> senderOptions = SenderOptions.create(kafkaConfig);
        legalPersonKafkaSender = KafkaSender.create(senderOptions);
    }

    public Mono<Void> sendLegalPersonToTopic(MD.LatestValue.LegalPerson legalPerson) {
        return legalPersonKafkaSender.send(Mono.just(legalPerson)
                        .map(message -> SenderRecord.create(new ProducerRecord<>(topic, message.getId().toString(), message), message)))
                .doOnTerminate(() -> log.info("LegalPerson {} published on topic {}", legalPerson.getId().toString(), topic))
                .then();
    }

}
