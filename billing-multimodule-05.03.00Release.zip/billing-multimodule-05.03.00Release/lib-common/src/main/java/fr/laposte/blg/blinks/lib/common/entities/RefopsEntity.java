package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table ("refops")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RefopsEntity {

    @Id
    @Column("offer_ops_id")
    private Long offerOpsId;

    @Column("ops_code")
    private String opsCode;

    @Column("ops_label")
    private String opsLabel;

    @Column("offer_technical_version")
    private String offerTechnicalVersion;

    @Column("offer_functional_version")
    private String offerFunctionalVersion;

    @Column("offer_version_creation_datetime")
    private Instant offerVersionCreationDatetime;

    @Column("offer_activation_datetime")
    private Instant offerActivationDatetime;

    @Column("data")
    private String data;

}
