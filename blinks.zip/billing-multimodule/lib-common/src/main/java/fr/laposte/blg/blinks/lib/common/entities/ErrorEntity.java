package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ErrorEntity {
    private String errorListening;
    private String errorSynch;
}