package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.*;

import java.util.List;
@Setter
@Getter
@Builder
@JsonPropertyOrder({
        "header",
        "invoiceHeader",
        "billingAccount",
        "customer",
        "contracts",
        "accountDetails"
})
@JacksonXmlRootElement(localName = "invoice")
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceDTO {
    HeaderDTO header;
    InvoiceHeaderDTO invoiceHeader;
    BillingAccountDTO billingAccount;
    CustomerDTO customer;
    @JacksonXmlElementWrapper(localName = "contracts")
    @JacksonXmlProperty(localName = "contract")
    List<ContractDTO> contracts;
    @JacksonXmlElementWrapper(localName = "accountDetails")
    @JacksonXmlProperty(localName = "accountDetail")
    List<AccountDetailsDTO> accountDetails;
    @JsonIgnore
    boolean isExport;
}
