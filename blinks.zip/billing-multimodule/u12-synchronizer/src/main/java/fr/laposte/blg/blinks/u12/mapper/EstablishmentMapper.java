package fr.laposte.blg.blinks.u12.mapper;

import fr.laposte.blg.blinks.lib.common.entities.EstablishmentEntity;
import fr.laposte.blg.blinks.u12.dto.EstablishmentDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface EstablishmentMapper {

    @Mapping(source = "codeRegate", target = "regateCode")
    @Mapping(source = "libelle", target = "label")
    @Mapping(target = "idEstablishment", ignore = true)
    EstablishmentEntity establishmentDTOToEstablishmentEntity(EstablishmentDTO establishmentDTO);
}
