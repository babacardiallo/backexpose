package fr.laposte.blg.blinks.u11.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ContractVersionInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class ContractFullListenerDecorator implements ContractFullListenerMapper {

    @Autowired
    @Qualifier("delegate")
    private ContractFullListenerMapper delegate;

    @Override
    public ContractVersionEntity contractVersionInformationAvroToContractVersionEntity(ContractVersionInformation contractVersionInformationODC) throws JsonProcessingException {
        ContractVersionEntity contractVersionEntity = delegate.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationODC);
        contractVersionEntity.setIsPurged(false);
        return contractVersionEntity;
    }



}
