package fr.laposte.blg.blinks.u12.okapi;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;

import java.util.List;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper=false) //To avoid warning from maven
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OkapiException extends RuntimeException {
    private String messageOkapi;
    private List<Location> locations;
    private Map<String, Object> extensions;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Location {
        private int line;
        private int column;
    }

    @Override
    public String getMessage() {
        return messageOkapi;
    }

    public static OkapiException fromGraphqlError(Map<String, Object> error) {
        String message = (String) error.get("message");
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> locationsList = objectMapper.convertValue(
                error.get("locations"),
                new TypeReference<>() {
                }
        );

        List<Location> locations = locationsList.stream()
                .map(location -> new Location((int) location.get("line"), (int) location.get("column")))
                .toList();

        Map<String, Object> extensions = objectMapper.convertValue(
                error.get("extensions"),
                new TypeReference<>() {
                }
        );

        return OkapiException.builder()
                .messageOkapi(message)
                .locations(locations)
                .extensions(extensions)
                .build();
    }
}
