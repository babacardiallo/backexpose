package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("establishment")
@Data
public class EstablishmentEntity {

    @Id
    @Column("id_establishment")
    private Long idEstablishment;

    @Column("regate_code")
    private String regateCode;

    @Column("label")
    private String label;
}
