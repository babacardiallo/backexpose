CREATE TABLE contract_version_message (
    id_contract_version_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_contract_version INT UNSIGNED default null,
    contract_version_information JSON,
    contract_consolidated JSON,
    contract_odc JSON,
    CONSTRAINT fk_contract_version_message_contract_version FOREIGN KEY (id_contract_version) REFERENCES blg_contract_importer.contract_version (id_contract_version) ON DELETE CASCADE ON UPDATE RESTRICT
);