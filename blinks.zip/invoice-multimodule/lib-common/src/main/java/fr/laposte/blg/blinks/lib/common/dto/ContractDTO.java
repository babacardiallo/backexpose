package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Setter
@Getter
@JsonPropertyOrder({
        "invoiceContractInfo",
        "linkedAccounts",
        "contractInvoiceLines"
})
@JacksonXmlRootElement(localName = "contract")
public class ContractDTO {
    InvoiceContractInfoDTO invoiceContractInfo;

    @JacksonXmlElementWrapper(localName = "linkedAccounts")
    @JacksonXmlProperty(localName = "linkedAccount")
    List<LinkedAccountDTO> linkedAccounts;

    @JacksonXmlElementWrapper(localName = "contractInvoiceLines")
    @JacksonXmlProperty(localName = "contractInvoiceLine")
    List<ContractInvoiceLineDto> contractInvoiceLines;

}
