export class ErrorOfferBean {

    constructor(
        public contractNumber?: string,
        public amendmentNumber?: string,
        public revisionNumber?: string,
        public dateError?: string | Date,
        public firstErrorDate?: string | Date,
        public hasBeenSyncOnce?: string,
        public isSynchronized?: boolean,
        public previousDateSynchronization?: string,
        public workflowStep?: string,
        public errorMessage?: string,
        public codeOps?: string,
        public libelleOps?: string,
    ) { }

}
