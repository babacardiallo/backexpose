CREATE TABLE blg_invoice.refcom_business_assignement_nomenclature (
	business_assignement_id int UNSIGNED NOT NULL    PRIMARY KEY,
	business_assignment_custaccnumber varchar(32)  NOT NULL    ,
	business_portfolio_id int UNSIGNED NOT NULL    ,
	business_assignment_start_date datetime  NOT NULL    ,
	business_assignment_end_date datetime
 ) engine=InnoDB;

CREATE INDEX idx_custaccnumber ON blg_invoice.refcom_business_assignement_nomenclature ( business_assignment_custaccnumber );

CREATE INDEX idx_portfolio ON blg_invoice.refcom_business_assignement_nomenclature ( business_portfolio_id );

CREATE TABLE blg_invoice.refcom_business_portfolio_com_changes (
	business_portfolio_id int UNSIGNED NOT NULL    PRIMARY KEY,
	business_portfolio_type_id int UNSIGNED NOT NULL    ,
	business_portfolio_start_date datetime  NOT NULL    ,
	business_portfolio_end_date datetime
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_business_portfolio_position_link (
	business_portfolio_link_position_id int  NOT NULL    PRIMARY KEY,
	business_position_id int UNSIGNED NOT NULL    ,
	business_portfolio_id int UNSIGNED NOT NULL    ,
	business_portfolio_link_type_id int UNSIGNED NOT NULL    ,
	business_portfolio_link_position_start_date datetime  NOT NULL    ,
	business_portfolio_link_position_end_date datetime
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_business_portfolio_team_link (
	business_portfolio_link_team_id int UNSIGNED NOT NULL    PRIMARY KEY,
	business_portfolio_id int UNSIGNED NOT NULL    ,
	business_team_id     int UNSIGNED NOT NULL    ,
	business_portfolio_link_type_id int UNSIGNED NOT NULL    ,
	business_portfolio_link_team_start_date datetime  NOT NULL    ,
	business_portfolio_link_team_end_date datetime
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_business_position_hierarchy (
	business_position_id int UNSIGNED NOT NULL    PRIMARY KEY,
	business_position_type_id int  NOT NULL    ,
	business_position_start_date datetime  NOT NULL    ,
	business_position_end_date date
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_business_position_link_territory (
	business_position_link_territory_id int  NOT NULL    PRIMARY KEY,
	business_territory_id int  NOT NULL    ,
	business_position_id int  NOT NULL    ,
	business_position_link_territory_start_date datetime  NOT NULL    ,
	business_position_link_territory_end_date datetime
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_business_team (
	business_team_id     int UNSIGNED NOT NULL    PRIMARY KEY,
	business_team_type_id int UNSIGNED NOT NULL    ,
	business_team_start_date datetime  NOT NULL    ,
	business_team_end_date datetime
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_business_territory_hierarchy (
	business_territory_id int UNSIGNED NOT NULL    PRIMARY KEY,
	business_territory_type_id int UNSIGNED NOT NULL    ,
	business_entity_code varchar(6)  NOT NULL    ,
	business_territory_start_date datetime  NOT NULL    ,
	business_territory_end_date datetime
 ) engine=InnoDB;

CREATE TABLE blg_invoice.refcom_team_assignment_link (
	business_team_link_position_id int UNSIGNED NOT NULL    PRIMARY KEY,
	business_position_id int UNSIGNED NOT NULL    ,
	business_team_id     int UNSIGNED NOT NULL    ,
	business_team_link_position_start_date datetime  NOT NULL    ,
	business_team_link_position_end_date datetime      ,
	business_position_is_manager boolean  NOT NULL
 ) engine=InnoDB;
