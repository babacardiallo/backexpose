package fr.laposte.blg.blinks.u11.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = {ContractFullListenerMapperImpl.class, ContractFullListenerMapperImpl_.class, ContractFullListenerMapperImpl.class, InstantMapper.class, ObjectMapper.class})
@Slf4j
class ContractFullListenerMapperTest {

    @Autowired
    private ContractFullListenerMapper contractFullListenerMapper;

    @Test
    void contractInformationAvroToContractEntityTest() {
        ContractInformation contractInformation = ContractInformation.newBuilder()
                .setContractId("D-123456-1-0")
                .setContractNumber("D-123456-1")
                .setType("Collecte et remise")
                .setSubType("Collecte et remise annuel")
                .setEffectiveDateTime("2019-09-02T00:00:00+02:00")
                .setCustAccNumber("46")
                .setOpportunityId("")
                .setLeadId("")
                .setRenewalMode("Tacite reconduction")
                .setManagementMode("Permanent")
                .setSourceQuoteId("1504390")
                .setSignatureDateTime("2018-10-02T11:40:46+02:00")
                .setLPActorId("XRBK074")
                .setSellerId("XRBK074")
                .setSalesAdvisorId("3563954")
                .setLPSignatoryId("pVRD601")
                .setCustomerSignatoryId("3563954")
                .setCustContractualAgreementReference("")
                .setCreationChannel("TV")
                .setComments("")
                .build();

        try {
            ContractEntity contractEntity = this.contractFullListenerMapper.contractInformationAvroToContractEntity(contractInformation);
            assertAll(() -> {
                assertNull(contractEntity.getIdContract());
                assertEquals(contractInformation.getContractNumber(), contractEntity.getContractNumber());
                assertEquals(contractInformation.getType().toString(), contractEntity.getType());
                assertEquals(contractInformation.getSubType().toString(), contractEntity.getSubtype());
                assertEquals(ZonedDateTime.parse(contractInformation.getEffectiveDateTime()).toInstant(), contractEntity.getEffectiveDatetime());
                assertEquals(Integer.parseInt(contractInformation.getCustAccNumber().toString()), contractEntity.getCustAccNumber());
                assertEquals(contractInformation.getRenewalMode(), contractEntity.getRenewalMode());
                assertEquals(contractInformation.getManagementMode().toString(), contractEntity.getManagementMode());
                assertEquals(ZonedDateTime.parse(contractInformation.getSignatureDateTime()).toInstant(), contractEntity.getSignatureDatetime());
            });
        } catch (JsonProcessingException e) {
            fail(e);
        }
    }

    @Test
    void contractVersionInformationAvroToContractVersionEntityTest() {
        ContractVersionInformation contractVersionInformation = ContractVersionInformation.newBuilder()
                .setValidityStartDateTime("2019-09-02T00:00:00+02:00")
                .setValidityEndDateTime("2021-09-01T00:00:00+02:00")
                .setContractVersionNumber("3")
                .setAmendmentNumber("2")
                .setStatus("Valide")
                .setSubStatus("Valide")
                .setTerminationDateTime("2021-10-02T00:00:00+02:00")
                .setTerminationReason("")
                .setCancellationDateTime("2021-08-02T00:00:00+02:00")
                .setCancellationReason("")
                .setTerm("Indéterminé")
                .setCategory("Contrat Simple")
                .setParentContractNumber("D-1504398-1")
                .setParentAmendmentNumber("1")
                .build();

        try {
            ContractVersionEntity contractVersionEntity = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformation);
            assertAll(() -> {
                assertNull(contractVersionEntity.getIdContractVersion());
                assertEquals(Integer.parseInt(contractVersionInformation.getAmendmentNumber().toString()), contractVersionEntity.getAmendmentNumber());
                assertEquals(Integer.parseInt(contractVersionInformation.getContractVersionNumber().toString()), contractVersionEntity.getRevisionNumber());
                assertEquals(ZonedDateTime.parse(contractVersionInformation.getValidityStartDateTime()).toInstant(), contractVersionEntity.getValidityStartDatetime());
                assertEquals(ZonedDateTime.parse(contractVersionInformation.getValidityEndDateTime()).toInstant(), contractVersionEntity.getValidityEndDatetime());
                assertEquals(ContractStatusEnum.VALIDE, contractVersionEntity.getStatus());
                assertEquals(ContractSubStatusEnum.VALIDE, contractVersionEntity.getSubstatus());
                assertEquals(ZonedDateTime.parse(contractVersionInformation.getTerminationDateTime()).toInstant(), contractVersionEntity.getTerminationDatetime());
                assertEquals(contractVersionInformation.getTerm().toString(), contractVersionEntity.getTerm());
                assertEquals(contractVersionInformation.getCategory().toString(), contractVersionEntity.getCategory());
                assertEquals(contractVersionInformation.getParentContractNumber().toString(), contractVersionEntity.getParentContractNumber());
                assertEquals(Integer.parseInt(contractVersionInformation.getParentAmendmentNumber().toString()), contractVersionEntity.getParentAmendmentNumber());
            });
        } catch (JsonProcessingException e) {
            fail(e);
        }
    }

    @Test
    void invoiceVersionInformationAvroToContractVersionEntityTest() {
        VATInformation vatInformation = VATInformation.newBuilder()
                .setVATdepositZoneCode("METROPOLE-CORSE-MONACO")
                .setVATLiabilityFlag("1")
                .build();

        InvoiceTermInformation invoiceTermInformation = InvoiceTermInformation.newBuilder()
                .setAddressNumber("1938957")
                .setMode("Décentralisé")
                .setPublicCustomerAmendment("SP1")
                .setSendingSupport("Papier")
                .setDedicatedInvoiceFlag("0")
                .setManager("3588989")
                .setSector("123")
                .setSafranSector("456")
                .setInArrearsInvoicingFlag("0")
                .setType("Standard")
                .setVATInformation(vatInformation)
                .setTBAContractFlag("1")
                .setCustInvoiceTermId("789")
                .build();

        PaymentTermInformation paymentTermInformation = PaymentTermInformation.newBuilder()
                .setSchedule("Mensuel")
                .setRUM("rhum")
                .setPeriod("Aucun")
                .setMeansReference("12")
                .setMeans("A préciser")
                .setBankName("BNP Paribas")
                .setAmount("540")
                .setInvoicePeriodicity("Mensuelle")
                .build();

        Exemption exemption = Exemption.newBuilder()
                .setExemptionFlag("0")
                .setExemptionDateTime("2021-10-02T00:00:00+02:00")
                .build();

        CustomerInformation customerInformation = CustomerInformation.newBuilder().build();
        FinancialSecurityInformation financialSecurityInformation = FinancialSecurityInformation.newBuilder().build();
        List<Comments> comments = List.of(
                Comments.newBuilder().setCommentType("type1").setCommentDescription("description1").build(),
                Comments.newBuilder().setCommentType("type2").setCommentDescription("description2").build()
        );

        InvoiceInformation invoiceInformation = InvoiceInformation.newBuilder()
                .setInvoiceTermInformation(invoiceTermInformation)
                .setPaymentTermInformation(paymentTermInformation)
                .setExemption(exemption)
                .setCustomerInformation(customerInformation)
                .setFinancialSecurityInformation(financialSecurityInformation)
                .setInvoicingComments(comments)
                .build();

        try {
            InvoiceInformationEntity invoiceInformationEntity = this.contractFullListenerMapper.invoiceInformationODCToInvoiceInformationEntity(invoiceInformation);
            assertAll(() -> {
                assertNull(invoiceInformationEntity.getIdInvoiceInformation());
                assertEquals(invoiceInformation.getPaymentTermInformation().getInvoicePeriodicity().toString(), invoiceInformationEntity.getInvoicePeriodicityLabel());
                assertEquals(invoiceInformation.getInvoiceTermInformation().getMode().toString(), invoiceInformationEntity.getInvoiceMode());
                assertEquals(invoiceInformation.getInvoiceTermInformation().getSendingSupport().toString(), invoiceInformationEntity.getSendingSupportLabel());
                assertEquals(invoiceInformation.getInvoiceTermInformation().getCustInvoiceTermId().toString(), invoiceInformationEntity.getBosco());
                assertEquals(this.contractFullListenerMapper.ChrFlagToBoolean(invoiceInformation.getInvoiceTermInformation().getDedicatedInvoiceFlag().toString()), invoiceInformationEntity.getDedicatedInvoiceFlag());
                assertEquals(this.contractFullListenerMapper.ChrFlagToBoolean(invoiceInformation.getInvoiceTermInformation().getInArrearsInvoicingFlag().toString()), invoiceInformationEntity.getInArrearsInvoiceFlag());
                assertEquals(invoiceInformation.getInvoiceTermInformation().getAddressNumber().toString(), invoiceInformationEntity.getInvoiceAddressNumber());
                assertEquals(invoiceInformation.getPaymentTermInformation().getMeans().toString(), invoiceInformationEntity.getPaymentMeans());
                assertEquals(invoiceInformation.getPaymentTermInformation().getPeriod().toString(), invoiceInformationEntity.getPaymentPeriod());
                assertEquals(invoiceInformation.getPaymentTermInformation().getRUM().toString(), invoiceInformationEntity.getRum());
                assertEquals(this.contractFullListenerMapper.ChrFlagToBoolean(invoiceInformation.getInvoiceTermInformation().getVATInformation().getVATLiabilityFlag().toString()), invoiceInformationEntity.getVatLiabilityFlag());
            });
        } catch (JsonProcessingException e) {
            fail(e);
        }
    }

    @Test
    void offerAvroToValuedOfferEntityTest() {
        Offer offer = Offer.newBuilder()
                .setOpsId("365")
                .setOpsCode("0365")
                .setOpsTechnicalVersion("1.0")
                .setOpsVersion("1")
                .setProducts(new ArrayList<>())
                .build();

        try {
            ValuedOfferEntity valuedOfferEntity = this.contractFullListenerMapper.offerAvroToValuedOfferEntity(offer);

            assertAll(() -> {
                assertEquals(offer.getOpsId(), valuedOfferEntity.getOpsId());
                assertEquals(offer.getOpsCode(), valuedOfferEntity.getOpsCode());});
        } catch (JsonProcessingException e) {
            fail(e);
        }
    }

    @Test
    void testConvertingInvoicingComments() {
        List<Comments> listOfComments = List.of(
                Comments.newBuilder().setCommentType("type1").setCommentDescription("description1").build(),
                Comments.newBuilder().setCommentType("type2").setCommentDescription("description2").build()
        );
        log.info(listOfComments.toString());
        assertEquals(listOfComments.toString(),
                "[{\"commentDescription\": \"description1\", \"commentType\": \"type1\"}, " +
                        "{\"commentDescription\": \"description2\", \"commentType\": \"type2\"}]");


    }


    @Test
    void contractVersionInformationAvroToContractVersionEntityTestAllStatusTest() {
        String[] listStatus = new String[]{"Valide", "Inactif", "En cours de création"};
        List<ContractVersionInformation> contractVersionInformationList = new ArrayList<>();
        for(String status : listStatus){
            contractVersionInformationList.add(ContractVersionInformation.newBuilder()
                    .setStatus(status)
                    .setSubStatus("Valide")
                    .setTerm("Indéterminé")
                    .setCategory("Contrat Simple")
                    .setParentContractNumber("D-1504398-1")
                    .setParentAmendmentNumber("1")
                    .setContractVersionNumber("3")
                    .setAmendmentNumber("2")
                    .build());
        }

        try {
            ContractVersionEntity contractVersionEntity0 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(0));
            ContractVersionEntity contractVersionEntity1 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(1));
            ContractVersionEntity contractVersionEntity2 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(2));
            assertEquals(ContractStatusEnum.VALIDE, contractVersionEntity0.getStatus());
            assertEquals(ContractStatusEnum.INACTIF, contractVersionEntity1.getStatus());
            assertEquals(ContractStatusEnum.EN_COURS_DE_CREATION, contractVersionEntity2.getStatus());
        } catch (JsonProcessingException e) {
            fail(e);
        }
    }

    @Test
    void contractVersionInformationAvroToContractVersionEntityTestAllSubStatusTest() {
        String[] listSubStatus = new String[]{"En cours de création",
                "Edité",
                "A valider",
                "Signé",
                "Valide",
                "Demande de résiliation",
                "Échu",
                "Echu",
                "En cours de renouvellement",
                "Résilié", "Terminé", "Renouvelé", "Annulé", "Avenant", "En attente signature client", "En attente signature poste"};
        List<ContractVersionInformation> contractVersionInformationList = new ArrayList<>();
        for(String subStatus : listSubStatus){
            contractVersionInformationList.add(ContractVersionInformation.newBuilder()
                    .setStatus("Valide")
                    .setSubStatus(subStatus)
                    .setTerm("Indéterminé")
                    .setCategory("Contrat Simple")
                    .setParentContractNumber("D-1504398-1")
                    .setParentAmendmentNumber("1")
                    .setContractVersionNumber("3")
                    .setAmendmentNumber("2")
                    .build());
        }

        try {
            ContractVersionEntity contractVersionEntity0 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(0));
            ContractVersionEntity contractVersionEntity1 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(1));
            ContractVersionEntity contractVersionEntity2 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(2));
            ContractVersionEntity contractVersionEntity3 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(3));
            ContractVersionEntity contractVersionEntity4 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(4));
            ContractVersionEntity contractVersionEntity5 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(5));
            ContractVersionEntity contractVersionEntity6 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(6));
            ContractVersionEntity contractVersionEntity7 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(7));
            ContractVersionEntity contractVersionEntity8 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(8));
            ContractVersionEntity contractVersionEntity9 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(9));
            ContractVersionEntity contractVersionEntity10 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(10));
            ContractVersionEntity contractVersionEntity11 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(11));
            ContractVersionEntity contractVersionEntity12 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(12));
            ContractVersionEntity contractVersionEntity13 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(13));
            ContractVersionEntity contractVersionEntity14 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(14));
            ContractVersionEntity contractVersionEntity15 = this.contractFullListenerMapper.contractVersionInformationAvroToContractVersionEntity(contractVersionInformationList.get(15));
            assertEquals(ContractSubStatusEnum.EN_COURS_DE_CREATION, contractVersionEntity0.getSubstatus());
            assertEquals(ContractSubStatusEnum.EDITE, contractVersionEntity1.getSubstatus());
            assertEquals(ContractSubStatusEnum.A_VALIDER, contractVersionEntity2.getSubstatus());
            assertEquals(ContractSubStatusEnum.SIGNE, contractVersionEntity3.getSubstatus());
            assertEquals(ContractSubStatusEnum.VALIDE, contractVersionEntity4.getSubstatus());
            assertEquals(ContractSubStatusEnum.DEMANDE_DE_RESILIATION, contractVersionEntity5.getSubstatus());
            assertEquals(ContractSubStatusEnum.ECHU, contractVersionEntity6.getSubstatus());
            assertEquals(ContractSubStatusEnum.ECHU, contractVersionEntity7.getSubstatus());
            assertEquals(ContractSubStatusEnum.EN_COURS_DE_RENOUVELLEMENT, contractVersionEntity8.getSubstatus());
            assertEquals(ContractSubStatusEnum.RESILIE, contractVersionEntity9.getSubstatus());
            assertEquals(ContractSubStatusEnum.TERMINE, contractVersionEntity10.getSubstatus());
            assertEquals(ContractSubStatusEnum.RENOUVELE, contractVersionEntity11.getSubstatus());
            assertEquals(ContractSubStatusEnum.ANNULE, contractVersionEntity12.getSubstatus());
            assertEquals(ContractSubStatusEnum.AVENANT, contractVersionEntity13.getSubstatus());
            assertEquals(ContractSubStatusEnum.EN_ATTENTE_SIGNATURE_CLIENT, contractVersionEntity14.getSubstatus());
            assertEquals(ContractSubStatusEnum.EN_ATTENTE_SIGNATURE_POSTE, contractVersionEntity15.getSubstatus());
        } catch (JsonProcessingException e) {
            fail(e);
        }
    }

    @Test
    void asIntegerTest(){
        CharSequence charSequence = "1";
        Integer value = contractFullListenerMapper.asInteger(charSequence);
        assertEquals(1, value);
    }

    @Test
    void bigDecimalTest(){
        CharSequence charSequence = "10";
        BigDecimal value = contractFullListenerMapper.asBigDecimal(charSequence);
        assertEquals(BigDecimal.valueOf(10), value);
    }

    @Test
    void mapInvoicingCommentsTest(){
        List<Comments> comments = new ArrayList<>();
        Comments com = new Comments();
        com.setCommentDescription("Test comment");
        comments.add(com);
        assertEquals(comments.toString(), contractFullListenerMapper.mapInvoicingComments(comments));
    }


}
