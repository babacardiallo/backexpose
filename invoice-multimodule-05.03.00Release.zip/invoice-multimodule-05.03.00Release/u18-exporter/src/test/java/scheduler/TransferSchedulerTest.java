package scheduler;

import fr.laposte.blg.blinks.u18.scheduler.TransferScheduler;
import fr.laposte.blg.blinks.u18.service.impl.FileTransferServiceImpl;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class TransferSchedulerTest {

    @Mock
    private FileTransferServiceImpl fileTransferService;

    @Test
    void transferRunTest(){
        SchedulerParamsEntity updatedParams = new SchedulerParamsEntity();
        updatedParams.setIsEnabled(true);
        updatedParams.setSchedulerName("scheduler_transfer");
        TransferScheduler transferScheduler = new TransferScheduler(fileTransferService, updatedParams);
        doNothing().when(fileTransferService).transferFiles(anyString(), anyString(),anyString());
        transferScheduler.run();
    }
}
