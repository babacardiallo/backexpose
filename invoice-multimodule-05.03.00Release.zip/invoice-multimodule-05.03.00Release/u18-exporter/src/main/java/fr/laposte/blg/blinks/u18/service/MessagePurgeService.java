package fr.laposte.blg.blinks.u18.service;

import java.time.Instant;

public interface MessagePurgeService {
    int purgeMessagesOlderThan(Instant threshold);
}
