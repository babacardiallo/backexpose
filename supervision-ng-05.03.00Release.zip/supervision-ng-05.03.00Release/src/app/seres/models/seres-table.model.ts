export class SeresTable {
    id?: number;
    invoiceNumber?: string;
    errorDate?: number | string | Date | null;
    errorCode?: string;
    errorMessage?: string;
    invoiceUrl?: string;
    printable?: string;
}