import { CalendarRequestDirection } from "./calendar-request-direction.enum";

export class CalendarRequest {
    direction?: CalendarRequestDirection;
    date: Date;
}
  