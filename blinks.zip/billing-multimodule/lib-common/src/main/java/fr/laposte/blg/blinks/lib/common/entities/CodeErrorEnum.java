package fr.laposte.blg.blinks.lib.common.entities;

public enum CodeErrorEnum {

    // Liste des codes d'erreurs pour le module U11
    U11001,
    U11002,
    U11003,
    U11004,
    U11005,
    U11006,
    U11007,
    // Liste des codes d'erreurs pour le module U12
    U12001,
    U12002,
    U12003,
    U12004,
    U12005,
    U12006,
    U12007,
    U12008,
    U12009
}
