

# Building image
📦 component used: shared-dsi/components/docker **

This component can be used in two cases:
- **Case 1 — Protected branch:** 👉 Builds and pushes a Docker image tagged with the branch name (e.g. `develop`)
- **Case 2 — Git Tag:** 👉 Pulls the `develop` image, re-tags it with the Git tag (e.g. `v1.0.0`), and pushes it
