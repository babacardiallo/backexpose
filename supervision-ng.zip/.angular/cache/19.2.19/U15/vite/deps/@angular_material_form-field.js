import {
  matFormFieldAnimations
} from "./chunk-NUVE4NLQ.js";
import {
  MatFormFieldModule
} from "./chunk-KP5ROBYH.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-TIOIX5A3.js";
import "./chunk-6R3T6DT3.js";
import "./chunk-NNKHXUIF.js";
import "./chunk-42FJBLFI.js";
import "./chunk-JXBCBRYI.js";
import "./chunk-47P2XRX3.js";
import "./chunk-DG6N4IH3.js";
import "./chunk-2O4WY5GE.js";
import "./chunk-KHSJTTI4.js";
import "./chunk-5FJDMDII.js";
import "./chunk-7ZCWYKRT.js";
import "./chunk-I76JCCZG.js";
import "./chunk-5YUJUVVP.js";
import "./chunk-MRDQ76HR.js";
import "./chunk-RVYENV4D.js";
import "./chunk-ROQ5OQS3.js";
import "./chunk-S6ETTSTF.js";
import "./chunk-3GOMPWB5.js";
import "./chunk-NTD5R5GH.js";
import "./chunk-IJNFIFIC.js";
import "./chunk-FQZEMCZB.js";
import "./chunk-7IZRYL2Z.js";
import "./chunk-TXDUYLVM.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
