import { Component } from "@angular/core";
import { Title } from "@angular/platform-browser";
import { NavigationEnd, Router } from "@angular/router";
import { filter } from "rxjs";
import { environment } from "../../environments/environment";

@Component({
    selector: 'invoice-supervision',
    templateUrl: './invoice-supervision.component.html',
    styleUrls: ['./invoice-supervision.component.scss'],
    standalone: false
})

export class InvoiceSupervisionComponent {
    appName = environment.appName;
    constructor(
        private router: Router,
        private titleService: Title,
    ) { }

    ngOnInit() {
        this.updateTitle();

        this.router.events
            .pipe(filter(event => event instanceof NavigationEnd))
            .subscribe(() => {
                this.updateTitle();
            });
    }

    private updateTitle() {
        this.titleService.setTitle("Factura : Recherche Factures");
    }

}