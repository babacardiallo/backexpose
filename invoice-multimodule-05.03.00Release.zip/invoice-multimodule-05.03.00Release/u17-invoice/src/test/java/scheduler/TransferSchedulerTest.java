package scheduler;

import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.u17.scheduler.TransferScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


class TransferSchedulerTest {

    @TempDir
    Path tempDir;

    Path exportDir;
    Path cftDir;
    Path archiveDir;

    @BeforeEach
    void setUpDirectories() throws IOException {
        exportDir = tempDir.resolve("export");
        cftDir = tempDir.resolve("cft");
        archiveDir = tempDir.resolve("archive");
        Files.createDirectories(exportDir);
        Files.createDirectories(cftDir);
        Files.createDirectories(archiveDir);
    }

    private SchedulerParamsEntity createSchedulerParamsEntity(Long id) {
        SchedulerParamsEntity params = new SchedulerParamsEntity();
        params.setId(id);
        params.setSchedulerName("scheduler-transfer");
        params.setCronExpression("0 * * * * *");
        params.setExportPath(exportDir.toString());
        params.setCftPath(cftDir.toString());
        params.setArchivePath(archiveDir.toString());
        params.setIsEnabled(true);
        return params;
    }

    private ExportHistoryEntity createExportHistoryEntity(Long id, FileType fileType, String fileName) {
        ExportHistoryEntity history = new ExportHistoryEntity();
        history.setIdExport(id);
        history.setFileType(fileType);
        history.setFileName(fileName);
        history.setDate(Instant.now());
        history.setTransferStatus(TransferStatus.NEW);
        return history;
    }

    @Test
    void testTransferSchedulerSuccess() throws IOException {
        String fileName = "testfile.txt";
        Path exportFile = exportDir.resolve(fileName);
        Files.write(exportFile, "dummy content".getBytes());

        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(1L);

        ExportHistoryEntity exportHistory = createExportHistoryEntity(100L, FileType.DOCAPOSTE, fileName);

        ExportHistoryRepository repository = Mockito.mock(ExportHistoryRepository.class);
        when(repository.findTopByTransferStatusInAndFileTypeInOrderByDateAsc(any(), any()))
                .thenReturn(Mono.just(exportHistory));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(repository).save(any(ExportHistoryEntity.class));

        TransferScheduler transferScheduler = new TransferScheduler(schedulerParams, repository, "/tmp/key.pem");

        transferScheduler.run();

        assertFalse(Files.exists(exportFile), "Source file should be moved from export directory");

        Path targetFile = cftDir.resolve("blg3aaaa.ws");
        assertTrue(Files.exists(targetFile), "Target file should exist in CFT directory");

        java.time.ZonedDateTime now = java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Paris"));
        String year = now.format(java.time.format.DateTimeFormatter.ofPattern("yyyy"));
        String month = now.format(java.time.format.DateTimeFormatter.ofPattern("MM"));
        Path organizedArchiveFile = archiveDir.resolve("DOCAPOSTE").resolve(year).resolve(month).resolve(fileName);
        assertTrue(Files.exists(organizedArchiveFile), "File should be copied to organized archive directory");

        // Verify that repository.save() was called with SUCCESS status and a non-null fileSendDate.
        ArgumentCaptor<ExportHistoryEntity> captor = ArgumentCaptor.forClass(ExportHistoryEntity.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        ExportHistoryEntity savedEntity = captor.getValue();
        assertEquals(TransferStatus.TRANSFERED, savedEntity.getTransferStatus(), "ExportHistory should be updated to TRANSFERED");
        assertNotNull(savedEntity.getFileSendDate(), "fileSendDate should be set");
    }

    @Test
    void testTransferSchedulerSourceMissing() {
        String fileName = "nonexistent.txt";

        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(2L);

        ExportHistoryEntity exportHistory = createExportHistoryEntity(101L, FileType.DOCAPOSTE, fileName);

        ExportHistoryRepository repository = Mockito.mock(ExportHistoryRepository.class);
        when(repository.findTopByTransferStatusInAndFileTypeInOrderByDateAsc(any(), any()))
                .thenReturn(Mono.just(exportHistory));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(repository).save(any(ExportHistoryEntity.class));

        TransferScheduler transferScheduler = new TransferScheduler(schedulerParams, repository, "/tmp/key.pem");
        transferScheduler.run();

        Path targetFile = cftDir.resolve("blg3aaaa.ws");
        assertFalse(Files.exists(targetFile), "Target file should not exist in CFT directory");

        ArgumentCaptor<ExportHistoryEntity> captor = ArgumentCaptor.forClass(ExportHistoryEntity.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        ExportHistoryEntity savedEntity = captor.getValue();
        assertEquals(TransferStatus.FAILED, savedEntity.getTransferStatus(), "ExportHistory should be updated to FAILED");
        assertEquals("U170012", savedEntity.getTransferErrorCode(), "Error code should be U170012");
    }

    @Test
    void testTransferSchedulerIOException() throws IOException {
        Files.deleteIfExists(archiveDir);
        Files.write(archiveDir, "dummy".getBytes());

        String fileName = "testfile.txt";
        Path exportFile = exportDir.resolve(fileName);
        Files.write(exportFile, "dummy content".getBytes());

        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(4L);
        ExportHistoryEntity exportHistory = createExportHistoryEntity(103L, FileType.DOCAPOSTE, fileName);

        ExportHistoryRepository repository = Mockito.mock(ExportHistoryRepository.class);
        when(repository.findTopByTransferStatusInAndFileTypeInOrderByDateAsc(any(), any()))
                .thenReturn(Mono.just(exportHistory));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(repository).save(any(ExportHistoryEntity.class));

        TransferScheduler transferScheduler = new TransferScheduler(schedulerParams, repository, "/tmp/key.pem");
        transferScheduler.run();

        Path targetFile = cftDir.resolve("blg3aaaa.ws");
        assertFalse(Files.exists(targetFile), "Target file should not exist due to IO exception");

        ArgumentCaptor<ExportHistoryEntity> captor = ArgumentCaptor.forClass(ExportHistoryEntity.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        ExportHistoryEntity savedEntity = captor.getValue();
        assertEquals(TransferStatus.FAILED, savedEntity.getTransferStatus(), "ExportHistory should be updated to FAILED");
        assertEquals("U170016", savedEntity.getTransferErrorCode(), "Error code should be U170016 for archive directory creation failure");
    }

    @Test
    void testTransferSchedulerUnhandledError() {
        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(5L);
        schedulerParams.setExportPath(null);

        ExportHistoryEntity exportHistory = createExportHistoryEntity(104L, FileType.DOCAPOSTE, "testfile.txt");

        ExportHistoryRepository repository = Mockito.mock(ExportHistoryRepository.class);
        when(repository.findTopByTransferStatusInAndFileTypeInOrderByDateAsc(any(), any()))
                .thenReturn(Mono.just(exportHistory));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(repository).save(any(ExportHistoryEntity.class));

        TransferScheduler transferScheduler = new TransferScheduler(schedulerParams, repository, "/tmp/key.pem");
        transferScheduler.run();

        ArgumentCaptor<ExportHistoryEntity> captor = ArgumentCaptor.forClass(ExportHistoryEntity.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        ExportHistoryEntity savedEntity = captor.getValue();
        assertEquals(TransferStatus.FAILED, savedEntity.getTransferStatus(), "ExportHistory should be updated to FAILED");
        assertEquals("U179999", savedEntity.getTransferErrorCode(), "Error code should be U17999");
    }

    @Test
    void testTransferSchedulerCoeurfinanceEncryptionFailure() throws IOException {
        String fileName = "cf.a3p";
        Path exportFile = exportDir.resolve(fileName);
        Files.write(exportFile, "dummy content".getBytes());

        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(10L);

        ExportHistoryEntity exportHistory = createExportHistoryEntity(200L, FileType.COEURFINANCE, fileName);

        ExportHistoryRepository repository = Mockito.mock(ExportHistoryRepository.class);
        when(repository.findTopByTransferStatusInAndFileTypeInOrderByDateAsc(any(), any()))
                .thenReturn(Mono.just(exportHistory));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(repository).save(any(ExportHistoryEntity.class));

        TransferScheduler transferScheduler = new TransferScheduler(
                schedulerParams,
                repository,
                "/tmp/key.pem",
                (Path in, Path out, String key) -> 12
        );

        transferScheduler.run();

        assertTrue(Files.exists(exportFile), "Source file should remain in export directory when encryption fails");

        Path targetFile = cftDir.resolve("blg1aaaa.a3p");
        assertFalse(Files.exists(targetFile), "Target file should not exist in CFT directory when encryption fails");

        ArgumentCaptor<ExportHistoryEntity> captor = ArgumentCaptor.forClass(ExportHistoryEntity.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        ExportHistoryEntity savedEntity = captor.getValue();
        assertEquals(TransferStatus.FAILED, savedEntity.getTransferStatus(), "ExportHistory should be updated to FAILED");
        assertEquals("U170018", savedEntity.getTransferErrorCode(), "Error code should be U170018 for OpenSSL encryption failure");
    }

    @Test
    void testTransferSchedulerCoeurfinanceEncryptionSuccess() throws IOException {
        String fileName = "cf.a3p";
        Path exportFile = exportDir.resolve(fileName);
        Files.write(exportFile, "dummy content".getBytes());

        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(11L);

        ExportHistoryEntity exportHistory = createExportHistoryEntity(201L, FileType.COEURFINANCE, fileName);

        ExportHistoryRepository repository = Mockito.mock(ExportHistoryRepository.class);
        when(repository.findTopByTransferStatusInAndFileTypeInOrderByDateAsc(any(), any()))
                .thenReturn(Mono.just(exportHistory));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(repository).save(any(ExportHistoryEntity.class));

        TransferScheduler transferScheduler = new TransferScheduler(
                schedulerParams,
                repository,
                "/tmp/key.pem",
                (Path in, Path out, String key) -> {
                    String plain = Files.readString(in);
                    Files.write(out, ("encrypted(" + plain + ")").getBytes());
                    return 0;
                }
        );

        transferScheduler.run();

        assertFalse(Files.exists(exportFile), "Source file should be removed from export directory after encrypted transfer");

        Path targetFile = cftDir.resolve("blg1aaaa.a3p");
        assertTrue(Files.exists(targetFile), "Encrypted target file should exist in CFT directory");

        String movedContent = Files.readString(targetFile);
        assertTrue(movedContent.startsWith("encrypted("), "CFT file should contain encrypted payload (simulated)");

        java.time.ZonedDateTime now = java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Paris"));
        String year = now.format(java.time.format.DateTimeFormatter.ofPattern("yyyy"));
        String month = now.format(java.time.format.DateTimeFormatter.ofPattern("MM"));
        Path organizedArchiveFile = archiveDir.resolve("COEURFINANCE").resolve(year).resolve(month).resolve(fileName);
        assertTrue(Files.exists(organizedArchiveFile), "File should be copied to organized archive directory");
        assertEquals("dummy content", Files.readString(organizedArchiveFile), "Archive file should remain unencrypted");

        ArgumentCaptor<ExportHistoryEntity> captor = ArgumentCaptor.forClass(ExportHistoryEntity.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        ExportHistoryEntity savedEntity = captor.getValue();
        assertEquals(TransferStatus.TRANSFERED, savedEntity.getTransferStatus(), "ExportHistory should be updated to TRANSFERED");
    }
}
