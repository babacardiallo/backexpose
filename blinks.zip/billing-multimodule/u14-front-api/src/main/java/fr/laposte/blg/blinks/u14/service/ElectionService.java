package fr.laposte.blg.blinks.u14.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.entities.ElectionFileSequence;
import fr.laposte.blg.blinks.lib.common.entities.LinkContractCoclicoMarket;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractSequenceElectionRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ElectionFileSequenceRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.LinkContractCoclicoMarketRepository;
import fr.laposte.blg.blinks.u14.controller.dto.*;
import fr.laposte.blg.blinks.u14.service.producer.KafkaElectionContractProducer;
import fr.laposte.blg.blinks.u14.utils.TrackExecutionTime;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


@Service
@Slf4j
@RequiredArgsConstructor
@Data
public class ElectionService {

    @Value("${fr.laposte.election.file.location}")
    private String advSource;

    private final ElectionFileSequenceRepository electionFileSequenceRepository;

    private final LinkContractCoclicoMarketRepository linkContractCoclicoMarketRepository;

    private final ContractSequenceElectionRepository contractSequenceElectionRepository;

    private final ContractRepository contractRepository;

    private final KafkaElectionContractProducer electionContractProducer;

    private String meansPrelevement = "prélèvement";

    private static String PREFIX_CR = "CR_ADV: ";

    @TrackExecutionTime
    public void process(String fileName) {
        String finalPath = advSource + fileName;
        Map<Integer, AdvRuleDto> rules = new HashMap<>();
        try(FileInputStream excelFile= new FileInputStream(finalPath);
            Workbook workbook = new XSSFWorkbook(excelFile)) {
            Sheet datatypeSheetAdv = workbook.getSheetAt(0);
            Row checkRow = datatypeSheetAdv.getRow(3);
            Cell checkCell = checkRow.getCell(1);
            String sequence = getCellValue(checkCell);
            if(this.checkIfFileSequenceExists(checkRow)){
                Map<String, String> clefs = new HashMap();
                clefs.put("sequence", sequence);
                clefs.put("error", "Le fichier a été déjà traité");
                log.error(PREFIX_CR + "Le fichier avec le numéro de séquence {} a été déjà traité, clefs: {}", sequence, clefs);
            } else {
                readAdvRules(rules, datatypeSheetAdv);
                readAdvData(sequence, datatypeSheetAdv);
                ElectionFileSequence electionFileSequence = new ElectionFileSequence();
                electionFileSequence.setFileSequence(Integer.parseInt(sequence));
                electionFileSequenceRepository.save(electionFileSequence).block();
            }

        } catch (Exception e) {
            log.error("Une erreur est survenue lors de la tentative de lecture de fichier", e);
        }

    }

    public void readAdvRules(Map<Integer, AdvRuleDto> rules,Sheet datatypeSheetAdv) {
        Row currentRow = datatypeSheetAdv.getRow(0);
        for (Cell cell : currentRow) {
            AdvRuleDto advRuleDto = new AdvRuleDto();
            advRuleDto.setIndex(cell.getColumnIndex());
            advRuleDto.setColumn(cell.getStringCellValue());
            rules.put(cell.getColumnIndex(), advRuleDto);
        }
        currentRow = datatypeSheetAdv.getRow(2);
        for (Cell cell : currentRow) {
            AdvRuleDto advRuleDto = rules.get(cell.getColumnIndex());
            advRuleDto.setRule(cell.getStringCellValue());
            rules.put(cell.getColumnIndex(), advRuleDto);
        }
    }

    public void readAdvData(String sequence, Sheet datatypeSheetAdv){
        int physicalRowNumber = datatypeSheetAdv.getPhysicalNumberOfRows();
        for (int i = 3; i < physicalRowNumber; i++){
            ElectionReportDto electionReportDto = new ElectionReportDto();
            electionReportDto.setSequence(sequence);
            int lineErrorsLength = 0;
            String means = "";
            Row currentRow = datatypeSheetAdv.getRow(i);
            String cellValue = getCellValue(currentRow.getCell(1));
            if(cellValue == null || cellValue.isBlank()){
                continue;
            }
            Iterator<Cell> cellIterator = currentRow.iterator();
            ExcelAdvDto excelAdvDto = new ExcelAdvDto();
            while (cellIterator.hasNext()) {
                Cell currentCell = cellIterator.next();
                switch (currentCell.getColumnIndex()) {
                    case 2 -> {
                        String value = getCellValue(currentCell);
                        if(value.isBlank()){
                            electionReportDto.getErrors().add("Le numéro du client est absent sur la ligne : " + (i+1));
                            lineErrorsLength++;
                        } else {
                            excelAdvDto.setCoclico(value);
                            electionReportDto.setCoclico(value);
                        }
                    }
                    case 3 -> {
                        String value = getCellValue(currentCell);
                        if(value.isBlank()){
                            electionReportDto.getErrors().add("Le numéro de marché est absent sur la ligne : " + (i+1));
                            lineErrorsLength++;
                        } else {
                            excelAdvDto.setMarketNumber(value);
                            electionReportDto.setMarketNumber(value);
                        }
                    }
                    case 4 -> excelAdvDto.setCommentAdv(getCellValue(currentCell));

                    case 5 -> {
                        String value = getCellValue(currentCell);
                        if(value.isBlank()){
                            electionReportDto.getErrors().add("La référence adresse factu est absent sur la ligne : " + (i+1));
                            lineErrorsLength++;
                        } else {
                            excelAdvDto.setRefAddressFactu(value);
                        }
                    }

                    case 6 -> {
                        String value = getCellValue(currentCell);
                        if(value.isBlank()){
                            electionReportDto.getErrors().add("Le moyen de paiement est absent sur la ligne : " + (i+1));
                            lineErrorsLength++;
                        } else {
                            means = value;
                            excelAdvDto.setMoyentPaiement(value);
                        }
                    }
                    case 7 -> {
                        String value = getCellValue(currentCell);
                        if(value.isBlank()){
                            electionReportDto.getErrors().add("Le délai de paiement est absent sur la ligne : " + (i+1));
                            lineErrorsLength++;
                        } else {
                            excelAdvDto.setDelaiPaiement(value);
                        }
                    }
                    case 8 -> {
                        String value = getCellValue(currentCell);
                        if(StringUtils.containsIgnoreCase(means, this.meansPrelevement)){
                            if(value.isBlank()){
                                electionReportDto.getErrors().add("Le rum est absent sur la ligne : " + (i+1));
                                lineErrorsLength++;
                            } else {
                                excelAdvDto.setRum(value);
                            }
                        } else {
                            excelAdvDto.setRum(value);
                        }
                    }
                    case 9 -> {
                        String value = getCellValue(currentCell);
                        if(StringUtils.containsIgnoreCase(means, this.meansPrelevement)){
                            if(value.isBlank()){
                                electionReportDto.getErrors().add("Le nom de la banque est absent sur la ligne : " + (i+1));
                                lineErrorsLength++;
                            } else {
                                excelAdvDto.setBankName(value);
                            }
                        } else {
                            excelAdvDto.setBankName(value);
                        }
                    }
                    case 10 ->  excelAdvDto.setNumeroBonCommande(getCellValue(currentCell));

                    case 11 ->  excelAdvDto.setRefSiteClientContractant(getCellValue(currentCell));

                }


            }
            if(lineErrorsLength > 0){
                logResult(electionReportDto);
                continue;
            }
            generateOdcMessageAndSendToTopic(excelAdvDto,electionReportDto);
            logResult(electionReportDto);
        }
    }



    public String getCellValue(Cell cell){
        DataFormatter dataFormatter = new DataFormatter();
        if(cell.getCellType() == CellType.NUMERIC){
            return dataFormatter.formatCellValue(cell);
        }
        if(cell.getCellType() == CellType.STRING){
            return cell.getStringCellValue();
        }

        if(cell.getCellType() == CellType.FORMULA){
            String value = "";
            switch (cell.getCachedFormulaResultType()) {
                case NUMERIC -> value = ""+(int)cell.getNumericCellValue();
                case STRING -> cell.getStringCellValue();
                default -> value = String.valueOf(cell.getRichStringCellValue());
            }
            return value;
        }
        return "";
    }
    private boolean checkIfFileSequenceExists(Row checkRow){
        Cell checkCell = checkRow.getCell(1);
        String value = getCellValue(checkCell);
        return Boolean.TRUE.equals(this.electionFileSequenceRepository.existsElectionFileSequenceByFileSequence(Integer.parseInt(value)).block());
    }

    public void generateOdcMessageAndSendToTopic(ExcelAdvDto excelAdvDto, ElectionReportDto electionReportDto){
        boolean isNewContract = false;
        Integer custAccNumber = Integer.parseInt(excelAdvDto.getCoclico());
        String contractNumber = linkContractCoclicoMarketRepository.getContractNumberBuyCoclicoAndMarketNumber(custAccNumber, excelAdvDto.getMarketNumber()).block();
        String contractId = contractNumber + "-0";
        if(contractNumber == null || contractNumber.isBlank()){
            Long sequenceNumber = contractSequenceElectionRepository.incrementSequenceContract()
                    .then(contractSequenceElectionRepository.getCurrentSequenceContract())
                    .switchIfEmpty(Mono.error(new RuntimeException("No sequence number for Contract Election")))
                    .block();
            contractNumber = ParamCommunConstant.PREFIX + this.generateSequence(sequenceNumber);
            contractId = ParamCommunConstant.PREFIX  + this.generateSequence(sequenceNumber) + "-0";
            isNewContract = true;
        }


        gkContractFullOutV1 contractFullOutV1 = new gkContractFullOutV1();
        ContractODC contract = new ContractODC();
        ContractInformation  contractInformation = new ContractInformation();
        ContractVersionInformation contractVersionInformation = new ContractVersionInformation();
        InvoiceInformation invoiceInformation = new InvoiceInformation();
        Offer valuedOffer = new Offer();
        setContractInformation(contractInformation, excelAdvDto, contractId, contractNumber, isNewContract);
        setContractVersionInformation(contractVersionInformation);
        setInvoiceInformation(invoiceInformation, excelAdvDto);

        contract.setContractInformation(contractInformation);
        contract.setContractVersionInformation(contractVersionInformation);
        contract.setInvoiceInformation(invoiceInformation);
        contract.setLinkedContracts(null);
        valuedOffer.setOpsId("9999");
        valuedOffer.setOpsVersion("1.0");
        valuedOffer.setOpsTechnicalVersion("1.00");
        valuedOffer.setOpsCode("9999");
        valuedOffer.setOfferCriteria(new ArrayList<>());
        valuedOffer.setProducts(new ArrayList<>());
        contract.setOffer(valuedOffer);
        contractFullOutV1.setContract(contract);
        String finalContractNumber = contractNumber;
        if(isNewContract){
            LinkContractCoclicoMarket linkContractCoclicoMarket = new LinkContractCoclicoMarket();
            linkContractCoclicoMarket.setCustAccNumber(Integer.parseInt(excelAdvDto.getCoclico()));
            linkContractCoclicoMarket.setMarketNumber(excelAdvDto.getMarketNumber());
            linkContractCoclicoMarket.setContractNumber(contractNumber);
            electionContractProducer.sendContractToTopic(contractFullOutV1)
                    .then(linkContractCoclicoMarketRepository.save(linkContractCoclicoMarket))
                    .doOnNext(linkContractCoclicoMarket1 -> {
                        electionReportDto.setContractNumber(finalContractNumber);
                        electionReportDto.setAction("CREATE");
                    })
                    .block();
        } else {
            electionContractProducer.sendContractToTopic(contractFullOutV1)
                    .thenReturn(new LinkContractCoclicoMarket())
                    .doOnNext(linkContractCoclicoMarket1 -> {
                        electionReportDto.setContractNumber(finalContractNumber);
                        electionReportDto.setAction("UPDATE");
                    })
                    .block();

        }
    }

    private void setContractInformation(ContractInformation contractInformation, ExcelAdvDto excelAdvDto, String contractId, String contractNumber, boolean isNewContract){
        contractInformation.setEvent(null);
        contractInformation.setContractId(contractId);
        contractInformation.setContractNumber(contractNumber);
        contractInformation.setType(ParamCommunConstant.TYPE);
        contractInformation.setTypeObject(null);
        contractInformation.setSubType(ParamCommunConstant.TYPE);
        contractInformation.setSubTypeObject(null);
        contractInformation.setEffectiveDateTime(ParamCommunConstant.DATE);
        contractInformation.setCustAccNumber(excelAdvDto.getCoclico());
        contractInformation.setOpportunityId("");
        contractInformation.setLeadId("");
        contractInformation.setRenewalMode(ParamCommunConstant.RENEWAL_MODE);
        contractInformation.setRenewalModeObject(null);
        contractInformation.setManagementMode(ParamCommunConstant.MANAGEMENT_MODE);
        contractInformation.setManagementModeObject(null);
        contractInformation.setSourceQuoteId(null);
        contractInformation.setSignatureDateTime(ParamCommunConstant.DATE);
        contractInformation.setLPActorId(null);
        contractInformation.setSellerId(null);
        contractInformation.setSalesAdvisorId(null);
        contractInformation.setLPSignatoryId(null);
        contractInformation.setCustomerSignatoryId(null);
        contractInformation.setCustContractualAgreementReference(ParamCommunConstant.TYPE);
        contractInformation.setCreationChannel(ParamCommunConstant.CREATION_CHANNEL);
        contractInformation.setComments(excelAdvDto.getCommentAdv());
    }

    private void setContractVersionInformation(ContractVersionInformation contractVersionInformation){
        contractVersionInformation.setValidityStartDateTime(ParamCommunConstant.DATE);
        contractVersionInformation.setValidityEndDateTime("");
        contractVersionInformation.setContractVersionNumber(ParamCommunConstant.CONTRACT_VERSION_NUMBER);
        contractVersionInformation.setAmendmentNumber(ParamCommunConstant.AMENDMENT_NUMBER);
        contractVersionInformation.setStatus(ParamCommunConstant.STATUS);
        contractVersionInformation.setStatusObject(null);
        contractVersionInformation.setSubStatus(ParamCommunConstant.STATUS);
        contractVersionInformation.setSubStatusObject(null);
        contractVersionInformation.setTerminationDateTime("");
        contractVersionInformation.setTerminationReason("");
        contractVersionInformation.setTerminationReasonObject(null);
        contractVersionInformation.setCancellationDateTime("");
        contractVersionInformation.setCancellationReason("");
        contractVersionInformation.setCancellationReasonObject(null);
        contractVersionInformation.setTerm(ParamCommunConstant.TERM);
        contractVersionInformation.setTermObject(null);
        contractVersionInformation.setCategory(ParamCommunConstant.CATEGORY);
        contractVersionInformation.setCategoryObject(null);
        contractVersionInformation.setParentContractNumber("");
        contractVersionInformation.setParentAmendmentNumber("");
        contractVersionInformation.setCentralizedRevenueFlag(ParamCommunConstant.CENTRALIZED_REVENUE_FLAG);
    }

    private void setInvoiceInformation(InvoiceInformation invoiceInformation, ExcelAdvDto excelAdvDto){
        InvoiceTermInformation invoiceTermInformation = new InvoiceTermInformation();
        PaymentTermInformation paymentTermInformation = new PaymentTermInformation();
        CustomerInformation customerInformation = new CustomerInformation();
        FinancialSecurityInformation financialSecurityInformation = new FinancialSecurityInformation();
        setInvoiceTermInformation(invoiceTermInformation, excelAdvDto);
        setPaymentTermInformation(paymentTermInformation, excelAdvDto);
        setCustomerInformation(customerInformation, excelAdvDto);
        setFinancialSecurityInformation(financialSecurityInformation);
        invoiceInformation.setInvoiceTermInformation(invoiceTermInformation);
        invoiceInformation.setPaymentTermInformation(paymentTermInformation);
        Exemption exemption = new Exemption();
        exemption.setExemptionFlag("0");
        exemption.setExemptionDateTime("");
        invoiceInformation.setExemption(exemption);
        invoiceInformation.setCustomerInformation(customerInformation);
        invoiceInformation.setFinancialSecurityInformation(financialSecurityInformation);
        ArrayList<Comments> commentsArrayList = new ArrayList<>();
        commentsArrayList.add(new Comments("", "reject"));
        commentsArrayList.add(new Comments("", "invoice"));
        commentsArrayList.add(new Comments("", "financialSecurity"));
        commentsArrayList.add(new Comments("", "derogation"));
        invoiceInformation.setInvoicingComments(commentsArrayList);
    }

    private void setInvoiceTermInformation(InvoiceTermInformation invoiceTermInformation, ExcelAdvDto excelAdvDto){
        invoiceTermInformation.setAddressNumber(excelAdvDto.getRefAddressFactu());
        invoiceTermInformation.setMode(ParamCommunConstant.MODE);
        invoiceTermInformation.setModeObject(null);
        invoiceTermInformation.setPublicCustomerAmendment(null);
        invoiceTermInformation.setPublicCustomerAmendmentObject(null);
        invoiceTermInformation.setSendingSupport(ParamCommunConstant.SUPPORT);
        invoiceTermInformation.setSendingSupportObject(null);
        invoiceTermInformation.setDedicatedInvoiceFlag(ParamCommunConstant.DEDICATED_INVOICE_FLAG);
        invoiceTermInformation.setManager("");
        invoiceTermInformation.setSector("");
        invoiceTermInformation.setSafranSector("");
        invoiceTermInformation.setInArrearsInvoicingFlag(ParamCommunConstant.IN_ARREARS_INVOICE_FLAG);
        invoiceTermInformation.setType(ParamCommunConstant.TYPE_INVOICE_TERM);
        invoiceTermInformation.setTypeObject(null);
        VATInformation vatInformation = new VATInformation();
        vatInformation.setVATdepositZoneCode(ParamCommunConstant.ZONE_DEPOT);
        vatInformation.setVatDepositZoneCodeObject(null);
        vatInformation.setVATLiabilityFlag(ParamCommunConstant.VAT_LIABILITY_FLAG);
        invoiceTermInformation.setVATInformation(vatInformation);
        invoiceTermInformation.setTBAContractFlag(ParamCommunConstant.TBA_CONTRACT_FLAG);
        invoiceTermInformation.setCustInvoiceTermId("");
    }


    private void setPaymentTermInformation(PaymentTermInformation paymentTermInformation, ExcelAdvDto excelAdvDto){
        paymentTermInformation.setSchedule("");
        paymentTermInformation.setScheduleObject(null);
        paymentTermInformation.setRUM(excelAdvDto.getRum());
        paymentTermInformation.setPeriod(excelAdvDto.getDelaiPaiement());
        paymentTermInformation.setPeriodObject(null);
        paymentTermInformation.setMeansReference("");
        paymentTermInformation.setMeans(excelAdvDto.getMoyentPaiement());
        paymentTermInformation.setMeansObject(null);
        paymentTermInformation.setBankName(excelAdvDto.getBankName());
        paymentTermInformation.setBankNameObject(null);
        paymentTermInformation.setAmount("");
        paymentTermInformation.setInvoicePeriodicity(ParamCommunConstant.PERIODICITE);
        paymentTermInformation.setPeriodObject(null);
    }

    private void setCustomerInformation(CustomerInformation customerInformation, ExcelAdvDto excelAdvDto){
        customerInformation.setLocalContractNumber("");
        customerInformation.setFrameworkContractNumber("");
        customerInformation.setCustPurchaseOrderNumber(excelAdvDto.getNumeroBonCommande());
        customerInformation.setCustBusinessUnitRef("");
        customerInformation.setContractingCustRef1(excelAdvDto.getRefSiteClientContractant());
        customerInformation.setContractingCustRef2("");
        customerInformation.setInvoicingCustRef1("");
        customerInformation.setInvoicingCustRef2("");
        customerInformation.setMarketNumber(excelAdvDto.getMarketNumber());
        customerInformation.setBatchNumber("");
        customerInformation.setBatchId("");
        customerInformation.setTariffExemption("");
        customerInformation.setCustomerIndex(null);
        customerInformation.setIndexRef(null);
        customerInformation.setTariffExemptionFormula("");
        customerInformation.setSafeguardClause(null);
        customerInformation.setDeadlineClause(null);
        customerInformation.setTariffStandardIncreaseFlag(true);
    }

    private void setFinancialSecurityInformation(FinancialSecurityInformation financialSecurityInformation){
        financialSecurityInformation.setFinancialSecurityMeans(null);
        financialSecurityInformation.setFinancialSecurityMeansObject(null);
        financialSecurityInformation.setRiskLevelColor(null);
        financialSecurityInformation.setRiskLevelColorObject(null);
        financialSecurityInformation.setValidityStartDateTime("");
        financialSecurityInformation.setValidityEndDateTime("");
        financialSecurityInformation.setMonthlyRevenueRatio("");
        financialSecurityInformation.setDepositPaymentFlag("0");
        financialSecurityInformation.setSecurityAmount("");
        financialSecurityInformation.setSecurityCeiling("");
        financialSecurityInformation.setInvoiceBlockFlag("0");
    }

    private void logResult(ElectionReportDto electionReportDto){
        var electionKibanaLogDto = new ElectionKibanaLogDto();
        electionKibanaLogDto.setSequenceFichierElection(electionReportDto.getSequence());
        electionKibanaLogDto.setCoclicoElection(electionReportDto.getCoclico());
        electionKibanaLogDto.setMarketNumberElection(electionReportDto.getMarketNumber());
        if(electionReportDto.getErrors().isEmpty()){
            electionKibanaLogDto.setContractNumberElection(electionReportDto.getContractNumber());
            electionKibanaLogDto.setActionElection(electionReportDto.getAction());
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            JsonNode node = objectMapper.convertValue(electionKibanaLogDto, JsonNode.class);
            log.info(Markers.append(ElectionKibanaCst.SEQUENCE, node)
                            .and(Markers.append(ElectionKibanaCst.COCLICO, electionReportDto.getCoclico()))
                            .and(Markers.append(ElectionKibanaCst.MARKET_NUMBER, electionReportDto.getMarketNumber()))
                            .and(Markers.append(ElectionKibanaCst.CONTRACT_NUMBER, electionReportDto.getContractNumber()))
                            .and(Markers.append(ElectionKibanaCst.MODE, electionReportDto.getAction()))
                            .and(Markers.append(ElectionKibanaCst.CLEFS, node))
                    , PREFIX_CR + "Numéro séquence: {}, Numéro client: {}, Numéro marché: {}, Numéro de contrat généré: {}, mode: {}, clefs: {}",
                    electionReportDto.getSequence(), electionReportDto.getCoclico(), electionReportDto.getMarketNumber(), electionReportDto.getContractNumber(), electionReportDto.getAction(), node);
        } else {
            for(String error:electionReportDto.getErrors()){
                electionKibanaLogDto.setErrorMessageElection(error);
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.registerModule(new JavaTimeModule());
                JsonNode node = objectMapper.convertValue(electionKibanaLogDto, JsonNode.class);
                log.error(Markers.append(ElectionKibanaCst.SEQUENCE, node)
                                .and(Markers.append(ElectionKibanaCst.COCLICO, electionReportDto.getCoclico()))
                                .and(Markers.append(ElectionKibanaCst.MARKET_NUMBER, electionReportDto.getMarketNumber()))
                                .and(Markers.append(ElectionKibanaCst.ERROR, error))
                                .and(Markers.append(ElectionKibanaCst.CLEFS, node))
                        , PREFIX_CR + "Numéro séquence: {}, Numéro client: {}, Numéro marché: {}, erreur: {}, clefs: {}",
                        electionReportDto.getSequence(), electionReportDto.getCoclico(), electionReportDto.getMarketNumber(), error, node);
            }
        }
    }


    private String generateSequence(Long sequenceNumber){
        return String.format("%05d", sequenceNumber);
    }

}
