package fr.laposte.blg.blinks.u17.controller;

import fr.laposte.blg.blinks.u17.dto.SeresReplayDto;
import fr.laposte.blg.blinks.u17.service.SeresReplayRestService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/seres-replay")
@OpenAPIDefinition(tags = {@Tag(name = "SeresReplayController")})
public class SeresReplayController {

    private final SeresReplayRestService seresReplayRestService;

    @GetMapping("/all-code-errors")
    Flux<Integer> getAllCodeErrors() {
        return seresReplayRestService.getAllCodeErrors();
    }

    @GetMapping("/all")
    @Operation(
            summary = "Liste des rejets seres",
            description = "Retourne tous les  rejets seres")
    Mono<Page<SeresReplayDto>> getSeresReplay(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "replayDate") String sort,
            @RequestParam(defaultValue = "desc") String order,
            @RequestParam Instant startDate,
            @RequestParam Instant endDate,
            @RequestParam (defaultValue = "") List<String> errorCodes,
            @RequestParam(defaultValue = "") String filter,
            @RequestParam(defaultValue = "0") boolean noPrintableOnly

    ) {
        Sort sortOrder = order.equals("desc") ? Sort.by(Sort.Direction.DESC, sort) : Sort.by(Sort.Direction.ASC, sort);
        sortOrder = sortOrder.and(Sort.by(Sort.Direction.ASC, "id"));
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        return seresReplayRestService.getAllSeresReplay(startDate, endDate, errorCodes, filter, noPrintableOnly, pageable);
    }

    @GetMapping("/details/{id}")
    @Operation(
            summary = "Détails d'un rejet seres",
            description = "Retourne les détails sur un rejet seres")
    Mono<SeresReplayDto> getDetails(@PathVariable("id") Long id) {
        return seresReplayRestService.getSeresReplayById(id);
    }

    @GetMapping("/export")
    @Operation(
            summary = "Exporte la liste des rejets seres",
            description = "Exporte la liste des rejets seres")
    Flux<SeresReplayDto> export(
            @RequestParam Instant startDate,
            @RequestParam Instant endDate,
            @RequestParam(defaultValue = "") List<String> errorCodes,
            @RequestParam(defaultValue = "") String filter,
            @RequestParam(defaultValue = "0") boolean noPrintableOnly
    ) {
        return seresReplayRestService.exportAllSeresReplay(startDate, endDate, errorCodes, filter, noPrintableOnly);
    }

}
