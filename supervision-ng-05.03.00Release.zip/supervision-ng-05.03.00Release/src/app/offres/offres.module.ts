import { OffreErrorDetailPopUpComponent } from './components/offre-error-detail-pop-up/offre-error-detail-pop-up.component';
import { UitPopupService } from '@cddng/ui-theme';
import { NgModule } from '@angular/core';
import { OffresRoutingModule } from './offres-routing.module';
import { OffresComponent } from './offres.component';
import { SharedModule } from '../shared/shared.module';
import { OffresTableComponent } from './components/offres-table.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { OffresAjoutPopUpComponent } from './components/offres-ajout-pop-up/offres-ajout-pop-up.component';
import { DatePipe } from '@angular/common';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ModalService } from 'ngx-modal-ease';

@NgModule({
    imports: [
        SharedModule,
        OffresRoutingModule,
        NgxDatatableModule,
        NgxPermissionsModule.forChild()
    ],
    providers: [UitPopupService, DatePipe, Location, ModalService],
    declarations: [OffresComponent, OffresTableComponent, OffreErrorDetailPopUpComponent, OffresAjoutPopUpComponent],
    exports: [OffresComponent]
})
export class OffresModule { }