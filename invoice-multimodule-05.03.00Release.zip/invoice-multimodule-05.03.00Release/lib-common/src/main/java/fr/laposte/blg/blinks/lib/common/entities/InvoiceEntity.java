package fr.laposte.blg.blinks.lib.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("invoice")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceEntity {

    @Id
    @Column("id_invoice")
    private Long idInvoice;

    @Column("invoice_number")
    private String invoiceNumber;

    @Column("reference_number")
    private String reference;

    @Column("billrun_id")
    private String billrunId;

    @Column("billrun_date")
    private Instant billrunDate;

    @Column("docaposte_export_id")
    private Long docaposteExportId;

    @Column("docaposte_avis_paiement_export_id")
    private Long docaposteAvisPaiementExportId;

    @Column("infoca_export_id")
    private Long infocaExportId;

    @Column("coeurfinance_export_id")
    private Long coeurfinanceExportId;

    @Column("created")
    private Instant created;

    @Column("updated")
    private Instant updated;

    @Column("client")
    private Integer client;

    @Column("docaposte_export_status")
    private InvoiceStatusEnum docaposteExportStatus;

    @Column("docaposte_avis_paiement_export_status")
    private InvoiceStatusEnum docaposteAvisPaiementExportStatus;

    @Column("infoca_export_status")
    private InvoiceStatusEnum infocaExportStatus;

    @Column("coeurfinance_export_status")
    private InvoiceStatusEnum coeurfinanceExportStatus;

    @Column("docaposte_error_message")
    private String docaposteErrorMessage;

    @Column("docaposte_avis_paiement_error_message")
    private String docaposteAvisPaiementErrorMessage;

    @Column("docaposte_error_code")
    private String docaposteErrorCode;

    @Column("docaposte_avis_paiement_error_code")
    private String docaposteAvisPaiementErrorCode;

    @Column("infoca_error_message")
    private String infocaErrorMessage;

    @Column("infoca_error_code")
    private String infocaErrorCode;

    @Column("coeurfinance_error_message")
    private String coeurfinanceErrorMessage;

    @Column("coeurfinance_error_code")
    private String coeurfinanceErrorCode;

    @Column("credit_flag")
    private Boolean creditFlag;

    @Column("downpayment_flag ")
    private Boolean downPaymentFlag;

    @Column("statement_flag ")
    private Boolean statementFlag;

    @Column("avispaiement_flag  ")
    private Boolean avisPaymentFlag;

}
