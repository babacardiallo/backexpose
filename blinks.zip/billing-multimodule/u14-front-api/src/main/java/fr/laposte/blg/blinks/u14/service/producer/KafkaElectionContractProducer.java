package fr.laposte.blg.blinks.u14.service.producer;

import fr.laposte.blg.blinks.u14.service.ContractOfferBuilderService;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;
import reactor.kafka.sender.SenderRecord;

import java.util.Properties;

@Slf4j
@Service
public class KafkaElectionContractProducer {
    private final ContractOfferBuilderService contractOfferBuilderService;
    @Value("${fr.laposte.topic.contract_election}")
    String topic;
    @Resource(name = "kafkaConfig")
    Properties kafkaConfig;
    private KafkaSender<String, fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1> contractSender;

    public KafkaElectionContractProducer(ContractOfferBuilderService contractOfferBuilderService) {
        this.contractOfferBuilderService = contractOfferBuilderService;
    }

    @PostConstruct
    void init() {
        SenderOptions<String, fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1> senderOptions = SenderOptions.create(kafkaConfig);
        contractSender = KafkaSender.create(senderOptions);
    }

    public Mono<Void> sendContractToTopic(fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1 contract) {
        return contractSender.send(Mono.just(contract)
                        .map(contractOfferBuilderService::buildContract)
                        .map(message -> SenderRecord.create(new ProducerRecord<>(topic, message.getContract().getContractInformation().getContractNumber().toString(), message), message)))
                .doOnNext(message -> log.info("contract published in {}: {}", topic, contract))
                .then();
    }

}
