package fr.laposte.blg.blinks.u12.listener.exception;

import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)

public class NoSynchronizationRequiredException extends RuntimeException {
    private ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum;
    private Long idContract;

    /**
     * Constructs a new runtime exception with the specified detail message.
     * The cause is not initialized, and may subsequently be initialized by a
     * call to {@link #initCause}.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the {@link #getMessage()} method.
     */
    public NoSynchronizationRequiredException(String message) {
        super(message);
    }

    /**
     * Constructs a new runtime exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this runtime exception's detail message.
     *
     * @param message          the detail message (which is saved for later retrieval
     *                         by the {@link #getMessage()} method).
     * @param cause            the cause (which is saved for later retrieval by the
     *                         {@link #getCause()} method).  (A {@code null} value is
     *                         permitted, and indicates that the cause is nonexistent or
     *                         unknown.)
     * @param workflowStepEnum step at which the exception was thrown
     * @since 1.4
     */
    public NoSynchronizationRequiredException(String message, Throwable cause, ErrorLogEntity.ErrorWorkflowStepEnum workflowStepEnum, Long idContract) {
        super(message, cause);
        this.workflowStepEnum = workflowStepEnum;
        this.idContract = idContract;
    }
}
