CREATE OR REPLACE VIEW `contract_supervision` AS
    SELECT
        `co`.`contract_number` AS `contract_number`,
        `cv`.`amendment_number` AS `amendment_number`,
        `cv`.`revision_number` AS `revision_number`,
        `cv`.`status` AS `status`,
        `cv`.`substatus` AS `substatus`,
        `co`.`type` AS `type`,
        `co`.`subtype` AS `subtype`,
        `vo`.`ops_code` AS `ops_code`,
        `ro`.`ops_label` AS `ops_label`,
        `cv`.`is_synchronized` AS `is_synchronized`,
        `cv`.`date_synchronization` AS `date_synchronization`,
        `cv`.`previous_date_synchronization` AS `previous_date_synchronization`,
        MAX(`el`.`date_error`) AS `first_error_date`,
        `el`.`error_message` AS `error_message`,
        `ii`.`invoice_address_number` AS `invoice_address_number`,
        `ii`.`dedicated_invoice_flag` AS `dedicated_invoice_flag`,
        `ii`.`invoice_periodicity_label` AS `invoice_periodicity_label`,
        `ii`.`sending_support_label` AS `sending_support_label`,
        `ii`.`payment_means` AS `payment_means`,
        `ii`.`rum` AS `rum`,
        `ii`.`cust_purchase_order_number` AS `cust_purchase_order_number`,
        `ii`.`contracting_cust_ref1` AS `contracting_cust_ref1`,
        `ii`.`market_number` AS `market_number`,
        `cv`.`contract_consolidated` AS `contract_consolidated`,
        `cv`.`offset_num_consolidated` AS `offset_num_consolidated`,
        `cv`.`partition_num_consolidated` AS `partition_num_consolidated`,
        `cv`.`contract_odc_json` AS `contract_odc_json`,
        `cv`.`offset_num` AS `offset`,
        `cv`.`partition_num` AS `partition`
    FROM
        (((((`contract_version` `cv`
        JOIN `contract` `co` ON ((`cv`.`id_contract` = `co`.`id_contract`)))
        JOIN `valued_offer` `vo` ON ((`cv`.`id_valued_offer` = `vo`.`id_valued_offer`)))
        JOIN `invoice_information` `ii` ON ((`cv`.`id_invoice_information` = `ii`.`id_invoice_information`)))
        LEFT JOIN `error_log` `el` ON (((`co`.`contract_number` = `el`.`contract_number`)
            AND (`el`.`workflow_step` LIKE '%SYNCHRONIZATION%'))))
        LEFT JOIN `refops` `ro` ON ((`vo`.`ops_code` = `ro`.`ops_code`)))
    GROUP BY `co`.`contract_number` , `cv`.`amendment_number` , `el`.`error_message`