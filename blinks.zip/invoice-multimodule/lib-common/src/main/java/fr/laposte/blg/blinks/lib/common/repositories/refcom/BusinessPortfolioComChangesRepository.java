package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessPortfolioComChanges;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessPortfolioComChangesRepository extends ReactiveCrudRepository<BusinessPortfolioComChanges, Long> {

    Mono<BusinessPortfolioComChanges> findByBusinessPortfolioId(Long businessPortfolioId);

}
