package fr.laposte.blg.blinks.lib.common.entities;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

@Table("contract")
@Data
@Accessors(chain = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ContractEntity {
    @Id
    @Column("id_contract")
    private Long idContract;
    @Column("contract_number")
    @NotBlank
    private String contractNumber;
    @Column("type")
    @NotBlank
    private String type;
    @Column("subtype")
    @NotBlank
    private String subtype;
    @Column("effective_datetime")
    @NotNull
    @Past
    private Instant effectiveDatetime;
    @Column("cust_acc_number")
    @NotNull
    @Digits(fraction = 0, integer = 10)
    private Integer custAccNumber;
    @Column("id_legal_person")
    private Long idLegalPerson; //FK to LegalPersonEntity
    @Transient
    private LegalPersonEntity legalPersonEntity;
    @Column("renewal_mode")
    private String renewalMode;
    @Column("management_mode")
    private String managementMode;
    @Column("signature_datetime")
    private Instant signatureDatetime;
    @Column("creation_channel")
    private String creationChannel;
    @Column("comments")
    private String comments;
    @Column("cust_contractual_agreement_reference")
    private String custContractualAgreementReference;

    @Transient
    @Singular
    private List<ContractVersionEntity> contractVersionEntities;
    //Permettra de récupérer les données de facturation sur le contrat d'affranchissement par exemple lorsque this
    //mentionne en pérodicité "référence contrat d'affranchissement"
    //A voir si on utiliserait pas plutot une liste de Contract mais ne pas oublier qu'une api de contrat n'existe pas à ce jour
    @Transient
    private List<ContractLinkedEntity> contractLinkedEntities;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContractEntity contract = (ContractEntity) o;
        return Objects.equals(idContract, contract.idContract) &&
            Objects.equals(contractNumber, contract.contractNumber) &&
            Objects.equals(type, contract.type) &&
            Objects.equals(subtype, contract.subtype) &&
            Objects.equals(effectiveDatetime, contract.effectiveDatetime) &&
            Objects.equals(custAccNumber, contract.custAccNumber) &&
            Objects.equals(renewalMode, contract.renewalMode) &&
            Objects.equals(managementMode, contract.managementMode) &&
            Objects.equals(signatureDatetime, contract.signatureDatetime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idContract, contractNumber, type, subtype, effectiveDatetime, custAccNumber, renewalMode, managementMode, signatureDatetime);
    }
}
