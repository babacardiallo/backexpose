package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class ContractErrorDTO {

    private String contractNumber;
    private String revisionNumber;
    private String amendmentNumber;
    private Instant dateError;
    private Instant firstErrorDate;
    private Boolean isSynchronized;
    private Instant previousDateSynchronization;
    private String workflowStep;
    private String errorMessage;
    private String codeOps;

}
