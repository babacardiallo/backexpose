package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Repository
public interface ErrorLogRepository extends ReactiveCrudRepository<ErrorLogEntity, Long> {

    public Mono<Void> deleteByContractNumberAndAmendmentNumberAndRevisionNumberLessThanEqual(String contractNumber, int amendmentNumber, int revisionNumber);

    public Mono<Void> deleteByIdLegalPerson(Long idLegalPerson);
    public Mono<Void> deleteByCustAccNumberAndWorkflowStepEquals(Long custAccNumber, ErrorLogEntity.ErrorWorkflowStepEnum workflow);
    public Mono<Void> deleteByIdContractAndWorkflowStepEquals(Long custAccNumber, ErrorLogEntity.ErrorWorkflowStepEnum workflow);

    @Transactional(readOnly = true)
    @Query("""
            select count(distinct concat(contract_number, amendment_number))            
            from error_log
            where contract_number is not null AND workflow_step like 'SYNCHRONIZATION%';""")
    Mono<Long> countSynchronisationError();

    @Query("""
            SELECT contract_number, amendment_number, date_error, revision_number, error_message, contract_odc_json, offset_num, partition_num
            FROM (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        ORDER BY revision_number DESC, date_error DESC
                    ) AS rn
                FROM error_log el
                WHERE
                    el.contract_number = :contractNumber
                    AND el.amendment_number = :amendmentNumber
                    AND el.revision_number > :revisionNumber
            ) sub
            WHERE rn = 1;""")
    Mono<ErrorLogEntity> oneContractSuperiorRevError(@Param("contractNumber") String contractNumber, @Param("amendmentNumber") Integer amendmentNumber, @Param("revisionNumber") Integer revisionNumber);

    @Query("SELECT * FROM error_log where contract_number = :contractNumber AND amendment_number = :amendmentNumber AND workflow_step like '%SYNCHRONIZATION%'")
    Mono<ErrorLogEntity> findByContractNumberAndAmendmentNumberSynchro(String contractNumber, int amendmentNumber);

    @Query("""
            WITH cte AS (
                SELECT
                    er.*,
                    CASE WHEN er.amendment_number IS NOT NULL THEN
                         ROW_NUMBER() OVER (
                           PARTITION BY er.contract_number, er.amendment_number
                           ORDER BY er.revision_number DESC, date_error desc
                         )
                         ELSE NULL
                    END AS rn
                FROM error_log er
                WHERE (
                       er.workflow_step LIKE '%CONTRACT_LISTENING%'
                    OR er.workflow_step LIKE '%CONTRACT_POST_LISTENING_PUBLISHING%'
                  )
            )
            SELECT *
            FROM cte
            WHERE rn = 1 OR rn IS NULL""")
    Flux<ErrorLogEntity> getAllIntegrationErrors();

    @Query("""
            WITH cte AS (
                SELECT
                    er.*,
                    CASE WHEN er.amendment_number IS NOT NULL THEN
                         ROW_NUMBER() OVER (
                           PARTITION BY er.contract_number, er.amendment_number
                           ORDER BY er.revision_number DESC, date_error desc
                         )
                         ELSE NULL
                    END AS rn
                FROM error_log er
                WHERE er.contract_number IN (:contractNumbers)
                  AND (
                       er.workflow_step LIKE '%CONTRACT_LISTENING%'
                    OR er.workflow_step LIKE '%CONTRACT_POST_LISTENING_PUBLISHING%'
                  )
            )
            SELECT *
            FROM cte
            WHERE rn = 1 OR rn IS NULL""")
    Flux<ErrorLogEntity> getAllIntegrationErrorsByContractNumber(List<String> contractNumbers);

    @Modifying
    @Query("DELETE FROM error_log WHERE contract_number = :contractNumber AND amendment_number = :amendmentNumber AND revision_number <= :revisionNumber" +
            " AND (workflow_step LIKE '%CONTRACT_LISTENING%' OR workflow_step LIKE '%CONTRACT_POST_LISTENING_PUBLISHING%')")
    Mono<Integer> removeAllLessRevisions(String contractNumber, int amendmentNumber, int revisionNumber);

}
