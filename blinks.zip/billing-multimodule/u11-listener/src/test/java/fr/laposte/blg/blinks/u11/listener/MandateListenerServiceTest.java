package fr.laposte.blg.blinks.u11.listener;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceInformationEntity;
import fr.laposte.blg.blinks.lib.common.entities.MandateEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.MandateRepository;
import fr.laposte.blg.blinks.lib.common.sender.SynchronizationSender;
import fr.laposte.blg.blinks.u11.listener.contract.ContractFullService;
import fr.laposte.blg.blinks.u11.listener.contract.dto.MandateDTO;
import fr.laposte.blg.blinks.u11.listener.mandate.MandateListenerService;
import fr.laposte.blg.blinks.u11.mapper.MandateMapper;
import fr.laposte.bscc.billing.avro.Synchronization;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.kafka.receiver.ReceiverRecord;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MandateListenerServiceTest {

    static final String TEST_RUM = "COU9175996";
    static final String TEST_RUM2 = "MCCOU3288003";
    static final long TEST_ID = 1L;
    public static final MandateEntity MANDATE_ENTITY = new MandateEntity()
        .setIdMandate(TEST_ID)
        .setRum(TEST_RUM2)
        .setStatus("valid")
        .setIban("TEST")
        .setBic("TEST2");
    static String mandate1;
    static String mandate2;
    static String mandate3;
    ConsumerRecord<String, String> mandate1ToTopic = new ConsumerRecord<>("test-topic", 0, 1, "00001", mandate1);
    ConsumerRecord<String, String> mandate2ToTopic = new ConsumerRecord<>("test-topic", 0, 2, "00002", mandate2);
    ReceiverRecord<String, String> mandate1FromTopic = new ReceiverRecord<>(mandate1ToTopic, null);
    ReceiverRecord<String, String> mandate2FromTopic = new ReceiverRecord<>(mandate2ToTopic, null);
    @InjectMocks
    private MandateListenerService listenerServiceUnderTest;
    @Mock
    private MandateRepository mandateRepository;
    @Mock
    private MandateMapper mandateMapper;
    @Mock
    private ContractFullService contractService;
    @Mock
    private SynchronizationSender synchronizationSender;

    @BeforeAll
    public static void initData() throws IOException {
        mandate1 = Files.readString(Path.of("src/test/resources/fakeMandate1.json"));
        mandate2 = Files.readString(Path.of("src/test/resources/fakeMandate2.json"));
        mandate3 = Files.readString(Path.of("src/test/resources/fakeMandateValid.json"));
    }

    private static Stream<Arguments> generateTest() {
        return Stream.of(
            Arguments.of("fakeMandate1.json", "MCCOU3288003", "CRLYFRPP", "FR3330002005500000157841Z25", "OBSOLETE"),
            Arguments.of("fakeMandate2.json", "MCCOU5609742", "CEPAFRPP333", "FR7613335003010477685361362", "COMPLIANT"),
            Arguments.of("fakeMandateValid.json", "MCCOU9150866", "CEPAFRPP333", "FR7613335003010477685361362", "Valid"));
    }

    private static MandateEntity generateDbOutMandate() {
        return new MandateEntity()
            .setIdMandate(TEST_ID)
            .setRum(TEST_RUM)
            .setIban("FR7610107001011234567890129")
            .setBic("CEPAFRPP333")
            .setStatus("OBSOLETE");
    }

    @ParameterizedTest
    @MethodSource("generateTest")
    void whenUsingJsonAnnotationWithFakeMandate1_thenOk(String filename, String rum, String bic, String iban, String status) throws IOException {
        Path filePath = Path.of("src/test/resources/" + filename);
        String jsonData = Files.readString(filePath);

        MandateDTO mandateDTO = new ObjectMapper()
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .readerFor(MandateDTO.class)
            .readValue(jsonData);

        assertEquals(mandateDTO.getRum(), rum);
        assertEquals(mandateDTO.getBic(), bic);
        assertEquals(mandateDTO.getIban(), iban);
        assertEquals(mandateDTO.getStatus(), status);
    }

    @Test
    void whenUpdateMandateWithExistingOneAndIsEligibleForSync_thenUpdate() {

        ContractVersionEntity[] contracts_version = {
            new ContractVersionEntity().setIdContract(1L)
                .setInvoiceInformationEntity(new InvoiceInformationEntity()
                .setIdMandate(1L)
                .setMandate(new MandateEntity().setIdMandate(1L))),
            new ContractVersionEntity().setIdContract(2L)
                .setInvoiceInformationEntity(new InvoiceInformationEntity()
                .setIdMandate(2L)
                .setMandate(new MandateEntity().setIdMandate(2L))),
            new ContractVersionEntity().setIdContract(3L)
                .setInvoiceInformationEntity(new InvoiceInformationEntity()
                .setIdMandate(3L)
                .setMandate(new MandateEntity().setIdMandate(3L))),
        };
        when(mandateRepository.findByRum(TEST_RUM2))
            .thenReturn(Mono.just(generateDbOutMandate()));
        when(mandateMapper.mandateToMandateEntity(any(), any()))
            .thenReturn(MANDATE_ENTITY);
        when(mandateRepository.save(any()))
            .thenReturn(Mono.just(MANDATE_ENTITY));
        when(contractService.getContractVersionByRum(anyString()))
            .thenReturn(Flux.fromArray(contracts_version));
        when(contractService.save(any(ContractVersionEntity.class)))
            .thenAnswer(inv -> Mono.just(inv.getArgument(0)));
        when(contractService.isOfferOfContractEligibleUpdate(any()))
                .thenReturn(Mono.just(Boolean.TRUE));
        when(synchronizationSender.send(any()))
            .thenReturn(Mono.empty());

        StepVerifier.create(listenerServiceUnderTest.updateMandateIfExist(mandate1FromTopic))
            .expectComplete()
            .verify();

        verify(mandateRepository, atLeastOnce()).save(any(MandateEntity.class));
        verify(contractService, atLeastOnce()).save(any(ContractVersionEntity.class));
        verify(synchronizationSender, atLeastOnce()).send(any(Synchronization.class));
    }

    @Test
    void whenUpdateMandateWithNoExistingOne_thenNothing() {

        when(this.mandateRepository.findByRum("MCCOU5609742"))
            .thenReturn(Mono.empty());
        StepVerifier.create(listenerServiceUnderTest.updateMandateIfExist(mandate2FromTopic))
            .verifyComplete();

        verify(mandateRepository, never()).save(any(MandateEntity.class));
        verify(contractService, never()).save(any(ContractVersionEntity.class));
        verify(synchronizationSender, never()).send(any(Synchronization.class));
    }
}
