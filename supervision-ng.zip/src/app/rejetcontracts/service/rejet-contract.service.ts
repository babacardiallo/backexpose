import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';


@Injectable({
  providedIn: 'root',
})
export class RejetContractService {
  ngUnsubscribe$ = new Subject<void>();

  public busService: Observable<boolean>;

  private _busService: Subject<boolean> = new Subject();


  private criteria: string = '';

  private projection: string = '&projection=withId';


  constructor(private http: HttpClient) {
    this.busService = this._busService.asObservable();
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }

  headers = new HttpHeaders({
    'Accept': 'text/plain, */*',
    'Content-Type': 'application/json',
    'Authorization': 'Basic ' + btoa('opencell.admin:opencell.admin')
  });

  getListRejetContractByDate(page: number, size: number, sort: string, order: string, startDate: any, endDate: any, filter: string, status: string, errorsCode: []): Observable<any> {
    this.criteria = '';
    let url = environment.API_REJET_CONTRACT_ALL_BY_DATE + "&page=" + page + "&size=" + size + "&sort=" + sort + "," + order + "&startDate=" + startDate + "&endDate=" + endDate;
    this.criteria = "?startDate=" + startDate + "&endDate=" + endDate;
    if (filter != '') {
      url = url + "&filter=" + filter
    }
    if (status != '') {
      url = url + "&status=" + status
    }
    if (errorsCode.length > 0) {
      errorsCode.forEach(err => {
        url = url + "&errors=" + err;
      })
    }
    return this.http.get<any>(url, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getAllCodeError(): Observable<any> {
    return this.http.get<any>(environment.API_REJET_CONTRACT_CODE_ERROR, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  getRejetContractDetails(id: string): Observable<any> {
    let url = environment.API_REJET_CONTRACT_ONE_BY_ID + "?id=" + id;
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  updateRejetContractPending(id: string): Observable<any> {
    let url = environment.API_REJET_CONTRACT_ONE_UPDATE_PENDING + "?id=" + id;
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  updateRejetContractFilteredPending(): Observable<any> {
    let url = environment.API_REJET_CONTRACT_FILTER_UPDATE_PENDING + this.criteria;
    return this.http.post<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  updateRejetContractSelectedPending(ids: any[]): Observable<any> {
    let url = environment.API_REJET_CONTRACT_SELECTED_UPDATE_PENDING;
    ids.forEach((id, index) => {
      if (index == 0) {
        url = url + "?ids=" + id;
      } else {
        url = url + "&ids=" + id;
      }
    })
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  emitLoadRjc() {
    this._busService.next(true);
  }

  getExportedRejetContracts(): Observable<any> {
    let url = environment.API_REJET_CONTRACT_EXPORTED + this.criteria;
    return this.http.get<any>(url, this.httpOptions)
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  postReplayU3(): Observable<any> {
    return this.http.post<void>(environment.API_POST_REPLAY_U3, null, { headers: this.headers, responseType: 'text' as 'json' }).pipe(takeUntil(this.ngUnsubscribe$));
  }

}