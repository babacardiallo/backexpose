export class StatModel {
    index: number = 0;
    label?: string = '';
    value?: number = 0;
}