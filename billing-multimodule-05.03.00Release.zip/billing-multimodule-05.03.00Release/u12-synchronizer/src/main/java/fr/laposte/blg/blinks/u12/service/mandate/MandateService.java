package fr.laposte.blg.blinks.u12.service.mandate;

import fr.laposte.blg.blinks.u12.dto.MandateDTO;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public interface MandateService {

    Mono<MandateDTO> fetchMandate(String rum);

}
