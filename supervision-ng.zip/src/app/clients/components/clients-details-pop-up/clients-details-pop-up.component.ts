import { Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { ClientsTable } from "../../models/clients-table.model";
import { ClientsService } from "../../service/clients.service";
import { ClientTableDetail } from "../../models/client-table-detail.model";
import { ClientDetailContracts } from "../../models/client-table-detail-contracts.model";
import { ClientAddress } from "../../models/client-detail-adress.model";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { DatePipe } from "@angular/common";
import { ClientsReplayerPopUpComponent } from "../clients-replayer-pop-up/clients-replayer-pop-up.component";
import { ContratsTable } from "../../../contrats/models/contrats-table.model";
import { ModalService } from "ngx-modal-ease";

export class ClientDetailPopUpModel {
  client: ClientsTable;
}

@Component({
    selector: 'clients-details-pop-up-component',
    templateUrl: './clients-details-pop-up.component.html',
    styleUrls: ['./clients-details-pop-up.component.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: false
})

export class ClientsDetailsPopUpComponent  implements OnInit, OnDestroy {
  @ViewChild(DatatableComponent) clientContract: DatatableComponent;
  @ViewChild(DatatableComponent) clientAddress: DatatableComponent;
  client: any;
  filteredContracts: ClientDetailContracts[];
  filtered: ClientAddress[];
  stringsToSortBy = ['PRINCIPALE', 'FACTURATION', 'PRESTATION'];

  isClientMessageExpanded: boolean = false;
  clientMessageExpandTitle = 'Tout déplier';
  adressSort: number;
  noSynchroDate = "Jamais synchronisé";
  noError = "Aucune erreur";
  M1_MODAL_PROPERTIES = {
    animation: 'enter-going-down',
    duration: '0.1s',
    easing: 'ease-out',
    padding: '1rem',
    width: '1000px',
    height: '60%'
  };
  name = 'ClientsDetailsPopUpComponent';

  constructor(private clientsService: ClientsService, private datePipe: DatePipe, private modalService: ModalService) {
  }

  ngOnInit(): void {
    this.client.clientDetail = new ClientTableDetail();
    this.client.clientDetailContrat = [];
    this.client.clientAddress = [];
    this.getCustomerBycoclico();
    this.getAddress();
    this.getContracts();
  }

  ngOnDestroy(): void {
    this.clientsService.ngUnsubscribe$.next();
    this.clientsService.ngUnsubscribe$.complete();
  }

  getCustomerBycoclico(): void {
    this.clientsService.getClientDetail(this.client.custAccNumber).subscribe({
      next: (response: any) => {
        this.client.clientDetail = response;
      },
      complete: () => {
        this.client.clientDetail.message = this.client.clientDetail.message != null ? JSON.parse(this.client.clientDetail.message) : null;
      },
    })
  }

  showDate() {
    if (this.client.isSynchronized) {
      return `${this.formatDatePopup(this.client.dateSynchronization)} - Aucune erreur`;
    } else if (!this.client.isSynchronized) {
      if (this.client.dateSynchronization !== null && this.client.dateError === null) {
        return `${this.formatDatePopup(this.client.dateSynchronization)} - Aucune erreur`;
      } else if (this.client.dateSynchronization !== null && this.client.dateError !== null) {
        return `${this.formatDatePopup(this.client.dateSynchronization)} - ${this.formatDatePopup(this.client.dateError)}`;
      } else if (this.client.dateSynchronization === null && this.client.dateError !== null) {
        return `Jamais synchronisé - ${this.formatDatePopup(this.client.dateError)}`;
      } else {
        return "Jamais synchronisé - Aucune erreur";
      }
    }
    return "Impossible de récupérer les date de synchronisation ou d'erreur";
  }

  getAddress(): void {
    this.clientsService.getClientAddress(this.client.idLegalPerson).subscribe({
      next: (response: any) => {
        this.client.clientAddress = response.map((data: any) => {
          if (data.addressType == "PRINCIPALE") {
            this.adressSort = 1;
          } else if (data.addressType == "FACTURATION") {
            this.adressSort = 2;
          } else if (data.addressType == "PRESTATION") {
            this.adressSort = 3;
          } else {
            this.adressSort = 4;
          }
          return <ClientAddress>{
            addressIdRefPM: data.addressIdRefPM,
            name1: data.name1,
            addressType: data.addressType,
            add1: data.add1,
            add2: data.add2,
            add3: data.add3,
            add4: data.add4,
            add5: data.add5,
            add6: data.add6,
            add7: data.add7,
            addressSort: this.adressSort,
          };
        })
        this.filtered = this.client.clientAddress;
      },
      complete: () => {
        this.getMultiSort();
      },
    })
  }

  getContracts(): void {
    this.clientsService.getClientContracts(this.client.custAccNumber).subscribe({
      next: (response: any) => {
        this.client.clientDetailContrat = response.map((data: any) => {
          return <ClientDetailContracts>{
            contractNumber: data.contractNumber,
            amendmentNumber: data.amendmentNumber,
            revisionNumber: data.revisionNumber,
            subType: data.subType,
            isSynchronized: data.synchronized,
            synchronisationDate: data.synchronisationDate ? new Date(data.synchronisationDate * 1000) : null,
            fistDateError: data.fistDateError ? new Date(data.fistDateError * 1000) : null,
            opsCode: data.opsCode,
          };
        })
        this.filteredContracts = this.client.clientDetailContrat;
      },
      complete: () => {
      },
    })
  }

  updateFilterContracts(event: Event) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value.toLowerCase();
    const columnsNb = this.client.clientDetailContrat.length;
    this.client.clientDetailContrat = this.filteredContracts.filter(function (item: any) {
      if (item.contractNumber?.toString().toLowerCase().indexOf(val) !== -1 ||
        item.opsCode?.toString().toLowerCase().indexOf(val) !== -1 || !val) {
        return true;
      }
    });
    this.clientContract.offset = 0;
  }

  updateFilter(event: Event) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value.toLowerCase();
    this.client.clientAddress = this.filtered.filter(function (item: any) {
      if (item.addressIdRefPM?.toString().toLowerCase().indexOf(val) !== -1 ||
        item.addressType?.toString().toLowerCase().indexOf(val) !== -1 ||
        item.add6?.toString().toLowerCase().indexOf(val) !== -1 || !val) {
        return true;
      }
    });
    this.clientAddress.offset = 0;
  }

  getMultiSort() {
    this.client.clientAddress.sort((propA: ClientAddress, propB: ClientAddress) => {
      let indexA = 0;
      if (propA.addressType != null) {
        indexA = this.stringsToSortBy.indexOf(propA.addressType);
      }
      let indexB = 0;
      if (propB.addressType != null) {
        indexB = this.stringsToSortBy.indexOf(propB.addressType);
      }
      if (indexA > indexB) {
        return 1;
      } else if (indexA < indexB) {
        return -1;
      }
      return 0;
    });
  }

  showReplayerPopup(client: ClientsTable, event: Event) {
    this.modalService
    .open(ClientsReplayerPopUpComponent, {
      modal: {
        enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
        top: '30%'
      },
      overlay: {
        leave: 'fade-out 0.3s',
      },
      size: {
        padding: this.M1_MODAL_PROPERTIES.padding,
        width: this.M1_MODAL_PROPERTIES.width,
        height: this.M1_MODAL_PROPERTIES.height
      },
      data: {
        client: client
      },
    })
    .then((response) => console.log(response));

  }


  formatDateTable(date: number) {
    return date ? this.datePipe.transform(date * 1000, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
  }

  formatDatePopup(date: any) {
    return date ? this.datePipe.transform(date, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
  }

  moreOrLessClientJson() {
    this.isClientMessageExpanded = !this.isClientMessageExpanded;
    if (this.isClientMessageExpanded) {
      this.clientMessageExpandTitle = 'Tout plier'
    } else {
      this.clientMessageExpandTitle = 'Tout déplier'
    }
  }
  
  close() {
    this.modalService.close(this.name);
  }
}
