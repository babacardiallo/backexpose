package fr.laposte.blg.blinks.lib.common.service;

import fr.laposte.blg.blinks.lib.common.entities.ContractEntity;
import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.QueueSynchronizationRepository;
import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class QueueService {

    private final QueueSynchronizationRepository queueSynchronizationRepository;

    private final ContractService contractService;

    private final LegalPersonService legalPersonService;

    public Mono<QueueSynchronizationEntity> enQueueContract(Long idContract, ActionEnum actionEnum) {
        return enQueueContract(idContract, Instant.now(), actionEnum);
    }

    public Mono<QueueSynchronizationEntity> enQueueContract(Long idContract, Instant dateSynchronizationExpected, ActionEnum actionEnum) {

        QueueSynchronizationEntity queueSynchronizationEntity = QueueSynchronizationEntity.builder().dateSynchronizationExpected(dateSynchronizationExpected)
            .action(actionEnum)
            .idContract(idContract)
            .refcomReplay(false)
            .build();
        return
            findQueueSynchronizationByIdContract(idContract)
                .map(queueSynchronizationEntity1 -> queueSynchronizationEntity.setIdQueue(queueSynchronizationEntity1.getIdQueue()))
                .defaultIfEmpty(queueSynchronizationEntity)
                .flatMap(queueSynchronizationRepository::save);
    }

    public Mono<QueueSynchronizationEntity> enQueueContract(String contractNumber, Instant dateSynchronizationExpected, ActionEnum actionEnum) {

        return
            contractService.findContractByContractNumberWithVersions(contractNumber, false)
                .map(ContractEntity::getIdContract)
                .flatMap(idContract -> enQueueContract(idContract, dateSynchronizationExpected, actionEnum));
    }

    public Mono<QueueSynchronizationEntity> enQueueCustomerByCoclico(int coclico, Instant dateSynchronizationExpected, ActionEnum actionEnum) {

        return
            legalPersonService.findLegalPersonByCoclico(coclico, false)
                .map(legalPersonEntity -> legalPersonEntity.getIdLegalPerson())
                .flatMap(idLegalPerson -> enQueueCustomerByIdLegalPerson(idLegalPerson, dateSynchronizationExpected, actionEnum, false));
    }

    public Mono<QueueSynchronizationEntity> enQueueCustomerByIdLegalPerson(long idLegalPerson, Instant dateSynchronizationExpected, ActionEnum actionEnum, Boolean refcomReplay) {

        QueueSynchronizationEntity queueSynchronizationEntity = QueueSynchronizationEntity.builder().dateSynchronizationExpected(dateSynchronizationExpected)
                .action(actionEnum)
                .idLegalPerson(idLegalPerson)
                .refcomReplay(refcomReplay)
                .build();

        return
            findQueueSynchronizationByIdLegalPerson(idLegalPerson)
                .map(queueSynchronizationEntity1 -> queueSynchronizationEntity.setIdQueue(queueSynchronizationEntity1.getIdQueue()))
                .defaultIfEmpty(queueSynchronizationEntity)
                .flatMap(queueSynchronizationRepository::save);
    }


    public Mono<Boolean> isContractAlreadyQueued(Long idContract) {
        return queueSynchronizationRepository
            .existsQueueSynchronizationEntityByIdContract(idContract);
    }

    public Mono<QueueSynchronizationEntity> findQueueSynchronizationByIdContract(long idContract) {
        return queueSynchronizationRepository
            .findQueueSynchronizationEntityByIdContract(idContract);
    }

    public Mono<QueueSynchronizationEntity> findQueueSynchronizationByIdLegalPerson(long idLegalPerson) {
        return queueSynchronizationRepository
            .findQueueSynchronizationEntityByIdLegalPerson(idLegalPerson);
    }

    public Flux<QueueSynchronizationEntity> findEntitiesToSynchronizeImmediately() {
        return queueSynchronizationRepository
            .findAllByDateSynchronizationExpectedBeforeNow();
    }

    public Mono<Void> deleteQueueSynchronizationById(Long idQueueSynchronization) {
        return queueSynchronizationRepository.deleteByIdQueue(idQueueSynchronization);
    }

}
