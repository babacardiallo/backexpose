package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.SeresReplayEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

public interface SeresReplayEntityRepository extends ReactiveCrudRepository<SeresReplayEntity, Long> {

    @Query("SELECT DISTINCT error_code FROM seres_replay ORDER BY error_code asc")
    Flux<Integer> getAllCodeErrors();

    // methodes pour l'affichage

    Flux<SeresReplayEntity> findAllByErrorDateBetween(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetween(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate);

    Flux<SeresReplayEntity> findAllByErrorDateBetweenAndErrorCodeIn(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndErrorCodeIn(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes);

    Flux<SeresReplayEntity> findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("errors") String errors, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("errors") String errors);

    Flux<SeresReplayEntity> findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, @Param("errors") String errors, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLike(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, @Param("errors") String errors);


    // methodes pour l'export

    Flux<SeresReplayEntity> findAllByErrorDateBetweenOrderByErrorDateDesc(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate);

    Flux<SeresReplayEntity> findAllByErrorDateBetweenAndErrorCodeInOrderByErrorDateDesc(@Param("startDate") Instant startDate, @Param("endDate") Instant endDate, @Param("codes") List<String> codes);

    Flux<SeresReplayEntity> findAllByErrorDateBetweenAndInvoiceNumberLikeOrErrorDateBetweenAndErrorMessageLikeOrderByErrorDateDesc(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("errors") String errors);

    Flux<SeresReplayEntity> findAllByErrorDateBetweenAndErrorCodeInAndInvoiceNumberLikeOrErrorDateBetweenAndErrorCodeInAndErrorMessageLikeOrderByErrorDateDesc(@Param("startDate1") Instant startDate1, @Param("endDate1") Instant endDate1, @Param("codes1") List<String> codes1, @Param("invoiceNumber") String invoiceNumber, @Param("startDate2") Instant startDate2, @Param("endDate2") Instant endDate2, @Param("codes2") List<String> codes2, @Param("errors") String errors);

}
