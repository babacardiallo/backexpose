package fr.laposte.blg.blinks.u12.service.customer;

import fr.laposte.blg.blinks.lib.common.entities.CodeErrorEnum;
import fr.laposte.blg.blinks.lib.common.entities.ErrorLogEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonEntity;
import fr.laposte.blg.blinks.lib.common.entities.LegalPersonMessage;
import fr.laposte.blg.blinks.lib.common.service.ErrorLogService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.lib.common.service.QueueService;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationLegalPersonException;
import fr.laposte.blg.blinks.u12.mapper.CustomerOpencellMapperImpl_;
import fr.laposte.blg.blinks.u12.service.ImportService;
import fr.laposte.blg.blinks.u12.utils.DataGeneratorTestUtils;
import fr.laposte.bscc.billing.avro.ActionEnum;
import fr.laposte.bscc.billing.avro.billing.OpencellActionEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class CustomerSyncServiceTest {

    @InjectMocks
    private CustomerSyncService customerSyncService;

    @Mock
    private ImportService importService;
    @Mock
    ErrorLogService errorLogService;

    @Mock
    private LegalPersonService legalPersonService;

    @Mock
    private QueueService queueService;

    @Mock
    private RefComCommunicationService refComCommunicationService;

    @Spy
    private CustomerOpencellMapperImpl_ customerOpencellMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void synchronizeCustomerTest() {

        LegalPersonEntity legalPersonEntity = DataGeneratorTestUtils.generateLegalPersonEntity();

        LegalPersonEntity oldLegalPersonEntity = new LegalPersonEntity();
        oldLegalPersonEntity.setIdLegalPerson(3L);
        oldLegalPersonEntity.setCustAccNumber(1111111);

        LegalPersonMessage legalPersonMessage = new LegalPersonMessage();


        when(this.legalPersonService.findLegalPersonByIdLegalPerson(anyLong(), anyBoolean())).thenReturn(Mono.just(oldLegalPersonEntity));
        when(this.importService.fetchLegalPerson(anyInt())).thenReturn(Mono.zip(Mono.just(legalPersonEntity), Mono.just(legalPersonMessage)));
        when(this.legalPersonService.save(any(), anyBoolean())).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));
        when(this.importService.fetchBusinessTeam(anyInt(), Mockito.any(LegalPersonEntity.class), Mockito.any(LocalDate.class))).thenReturn(Mono.just(legalPersonEntity));
        when(this.legalPersonService.saveLegalPersonMessage(any(), any())).thenReturn(Mono.just(legalPersonEntity));

        StepVerifier.create(this.customerSyncService.synchronize(3, false))
                .expectNextMatches(contractConsolidated -> contractConsolidated != null &&
                        contractConsolidated.getContractOpencell() == null &&
                        contractConsolidated.getCustomerOpencell() != null &&
                        contractConsolidated.getCustomerOpencell().getCustomerInformation().getCustAccNumber().equals("1111111") &&
                        contractConsolidated.getAction().equals(OpencellActionEnum.UPDATE_CUSTOMER)
                        && contractConsolidated.getCustomerOpencell().getCustomerInformation().getBusinessTeamId()==null
                        && contractConsolidated.getCustomerOpencell().getCustomerInformation().getBusinessTeamLongname()==null)
                .verifyComplete();
    }

    @Test
    void synchronize_legalPersonAlreadySynchronized() {
        LegalPersonEntity legalPerson = new LegalPersonEntity();
        legalPerson.setCustAccNumber(1111111);
        legalPerson.setBusinessTeamLongName("SomeTeam");
        legalPerson.setSynchronized(true);
        when(legalPersonService.findLegalPersonByIdLegalPerson(anyLong(), anyBoolean())).thenReturn(Mono.just(legalPerson));
        StepVerifier.create(customerSyncService.synchronize(3, false)).verifyComplete();
        verify(importService, never()).fetchBusinessTeam(anyInt(), any(), any());
    }

    @Test
    void synchronize_legalPersonNotFound() {
        when(legalPersonService.findLegalPersonByIdLegalPerson(anyLong(), anyBoolean())).thenReturn(Mono.empty());
        StepVerifier.create(customerSyncService.synchronize(3, false)).verifyComplete();
        verify(importService, never()).fetchBusinessTeam(anyInt(), any(), any());
    }

    @Test
    void synchronize_businessTeamMissing_callsFetchBusinessTeam() {
        LegalPersonEntity legalPerson = new LegalPersonEntity();
        legalPerson.setCustAccNumber(1111111);
        legalPerson.setBusinessTeamLongName(null);
        legalPerson.setSynchronized(false);
        when(legalPersonService.findLegalPersonByIdLegalPerson(eq(3L), anyBoolean())).thenReturn(Mono.just(legalPerson));
        when(importService.fetchBusinessTeam(eq(legalPerson.getCustAccNumber()), eq(legalPerson), any(LocalDate.class))).thenReturn(Mono.just(legalPerson));

        StepVerifier.create(customerSyncService.synchronize(3, false))
                .assertNext(cc -> {
                    assertNotNull(cc);
                    assertNull(cc.getContractOpencell());
                    assertNotNull(cc.getCustomerOpencell());
                    assertEquals(String.valueOf(legalPerson.getCustAccNumber()), cc.getCustomerOpencell().getCustomerInformation().getCustAccNumber());
                    assertEquals(OpencellActionEnum.UPDATE_CUSTOMER, cc.getAction());
                })
                .verifyComplete();
        verify(importService, times(1)).fetchBusinessTeam(eq(legalPerson.getCustAccNumber()), eq(legalPerson), any(LocalDate.class));
    }

    @Test
    void synchronize_businessTeamPresent_noFetchBusinessTeam() {
        LegalPersonEntity legalPerson = new LegalPersonEntity();
        legalPerson.setCustAccNumber(2222222);
        legalPerson.setBusinessTeamLongName("ExistingTeam");
        legalPerson.setSynchronized(false);
        when(legalPersonService.findLegalPersonByIdLegalPerson(eq(3L), anyBoolean())).thenReturn(Mono.just(legalPerson));

        StepVerifier.create(customerSyncService.synchronize(3, false))
                .assertNext(cc -> {
                    assertNotNull(cc);
                    assertNull(cc.getContractOpencell());
                    assertNotNull(cc.getCustomerOpencell());
                    assertEquals(String.valueOf(2222222), cc.getCustomerOpencell().getCustomerInformation().getCustAccNumber());
                    assertEquals(OpencellActionEnum.UPDATE_CUSTOMER, cc.getAction());
                })
                .verifyComplete();
        verify(importService, never()).fetchBusinessTeam(anyInt(), any(), any());
    }

    @Test
    void synchronize_refcomReplayTrue_forcesFetchBusinessTeam() {
        LegalPersonEntity legalPerson = new LegalPersonEntity();
        legalPerson.setCustAccNumber(3333333);
        legalPerson.setBusinessTeamLongName("ExistingTeam");
        legalPerson.setSynchronized(false);
        when(legalPersonService.findLegalPersonByIdLegalPerson(eq(3L), anyBoolean())).thenReturn(Mono.just(legalPerson));
        when(importService.fetchBusinessTeam(eq(legalPerson.getCustAccNumber()), eq(legalPerson), any(LocalDate.class))).thenReturn(Mono.just(legalPerson));

        StepVerifier.create(customerSyncService.synchronize(3, true))
                .assertNext(cc -> {
                    assertNotNull(cc);
                    assertNull(cc.getContractOpencell());
                    assertNotNull(cc.getCustomerOpencell());
                    assertEquals(String.valueOf(3333333), cc.getCustomerOpencell().getCustomerInformation().getCustAccNumber());
                    assertEquals(OpencellActionEnum.UPDATE_CUSTOMER, cc.getAction());
                })
                .verifyComplete();
        verify(importService, times(1)).fetchBusinessTeam(eq(legalPerson.getCustAccNumber()), eq(legalPerson), any(LocalDate.class));
    }

    @Test
    void synchronize_fetchBusinessTeamError_logsErrorAndReturnsEmpty() {
        LegalPersonEntity legalPerson = new LegalPersonEntity();
        legalPerson.setCustAccNumber(5555555);
        legalPerson.setBusinessTeamLongName(null);
        legalPerson.setSynchronized(false);

        when(legalPersonService.findLegalPersonByIdLegalPerson(eq(3L), anyBoolean()))
                .thenReturn(Mono.just(legalPerson));
        SynchronizationLegalPersonException syncEx = new SynchronizationLegalPersonException("error");
        syncEx.setCoclico(5555555L);
        syncEx.setWorkflowStepEnum(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER);
        when(importService.fetchBusinessTeam(eq(legalPerson.getCustAccNumber()), eq(legalPerson), any(LocalDate.class)))
                .thenReturn(Mono.error(syncEx));

        ArgumentCaptor<ErrorLogEntity> errorLogCaptor = ArgumentCaptor.forClass(ErrorLogEntity.class);
        when(errorLogService.logError(errorLogCaptor.capture())).thenReturn(Mono.empty());
        when(queueService.enQueueCustomerByIdLegalPerson(anyLong(), eq(Instant.now()), eq(ActionEnum.update), eq(false))).thenReturn(Mono.empty());

        StepVerifier.create(customerSyncService.synchronize(3, false)).verifyError();
        var capturedErrorLog = errorLogCaptor.getAllValues();
        assertEquals(2, capturedErrorLog.size());
        ErrorLogEntity firstError = capturedErrorLog.get(0);
        ErrorLogEntity secondError = capturedErrorLog.get(1);

        assertTrue(firstError.getErrorMessage().contains("[CLIENT: 5555555]error Error on BusinessAssignment API"));
        assertEquals(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER, firstError.getWorkflowStep());
        assertEquals(3L, firstError.getIdLegalPerson().longValue());
        assertEquals(5555555L, firstError.getCustAccNumber().longValue());
        assertEquals(CodeErrorEnum.U12002, firstError.getCodeError());


        assertEquals(ErrorLogEntity.ErrorWorkflowStepEnum.SYNCHRONIZATION_CUSTOMER, secondError.getWorkflowStep());
        assertEquals(3L, secondError.getIdLegalPerson().longValue());
        assertEquals(5555555L, secondError.getCustAccNumber().longValue());
        assertTrue(secondError.getErrorMessage().contains("[CLIENT: 5555555]"));
        assertEquals(CodeErrorEnum.U12002, secondError.getCodeError());
    }

}
