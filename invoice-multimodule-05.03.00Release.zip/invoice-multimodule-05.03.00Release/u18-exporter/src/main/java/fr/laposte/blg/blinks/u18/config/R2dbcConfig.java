package fr.laposte.blg.blinks.u18.config;

import io.asyncer.r2dbc.mysql.MySqlConnectionConfiguration;
import io.asyncer.r2dbc.mysql.MySqlConnectionFactory;
import io.r2dbc.pool.ConnectionPool;
import io.r2dbc.pool.ConnectionPoolConfiguration;
import io.r2dbc.spi.ConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;

import java.time.Duration;

@Configuration
public class R2dbcConfig {

    @Value("${fr.laposte.datasource.host}")
    private String host;
    @Value("${fr.laposte.datasource.db-name}")
    private String dbName;
    @Value("${fr.laposte.datasource.port}")
    private String port;
    @Value("${fr.laposte.datasource.username}")
    private String username;
    @Value("${fr.laposte.datasource.password}")
    private String password;

    @Bean
    public ConnectionFactory connectionFactory() {
        // Base MySQL R2DBC connection factory
        MySqlConnectionFactory delegate = MySqlConnectionFactory.from(
                MySqlConnectionConfiguration.builder()
                        .host(host)
                        .port(Integer.parseInt(port))
                        .username(username)
                        .password(password)
                        .database(dbName)
                        .connectTimeout(Duration.ofSeconds(10))
                        .build()
        );

        ConnectionPoolConfiguration poolConfig = ConnectionPoolConfiguration.builder(delegate)
                .initialSize(5)
                .maxSize(20)
                .maxIdleTime(Duration.ofMinutes(30))
                .build();

        return new ConnectionPool(poolConfig);
    }

    @Bean
    public R2dbcEntityTemplate r2dbcEntityTemplate(ConnectionFactory connectionFactory) {
        return new R2dbcEntityTemplate(connectionFactory);
    }

}