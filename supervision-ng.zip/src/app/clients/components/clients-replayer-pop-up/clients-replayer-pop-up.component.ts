import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { ModalService } from "ngx-modal-ease";
import { takeUntil } from "rxjs";
import { atLeastOne } from "../../../consts/consts";
import { ReplayReport } from "../../../replayer/models/replay-report.model";
import { ClientReplayParameters } from "../../models/client-replay-parameters.model";
import { ClientsTable } from "../../models/clients-table.model";
import { ClientsService } from "../../service/clients.service";

@Component({
    selector: 'clients-replayer-pop-up-component',
    templateUrl: './clients-replayer-pop-up.component.html',
    styleUrls: ['./clients-replayer-pop-up.component.scss'],
    standalone: false
})

export class ClientsReplayerPopUpComponent implements OnInit {
    client: ClientsTable;
    dateDisabled: boolean;
    selectedDate: string;
    popupForm: UntypedFormGroup;
    replayReport: ReplayReport;
    clientReplayParameters: ClientReplayParameters = new ClientReplayParameters();
    name = 'ClientsReplayerPopUpComponent';

    constructor(private clientsService: ClientsService, private formBuilder: UntypedFormBuilder, private datePipe: DatePipe, private snackBar: MatSnackBar, private modalService: ModalService) {
    }

    ngOnInit(): void {
        this.initForm();
        this.subscribeForm();
    }

    ngOnDestroy(): void {
        this.clientsService.ngUnsubscribe$.next();
        this.clientsService.ngUnsubscribe$.complete();
    }

    initForm() {
        this.popupForm = this.formBuilder.group({
            date: new UntypedFormControl(''),
            dateDisabled: new UntypedFormControl(),
            replayRefcom: new UntypedFormControl(),
        }, {
            validator: [atLeastOne(Validators.required, ['date', 'dateDisabled'])],
        });
    }

    subscribeForm() {
        this.popupForm.get('dateDisabled')?.valueChanges.pipe(takeUntil(this.clientsService.ngUnsubscribe$)).subscribe({
            next: (disableBoolean) => {
                if (disableBoolean) {
                    this.popupForm.controls['date'].setValue(null, { emitEvent: false });
                    this.popupForm.get('date')?.disable();
                }
                else {
                    this.popupForm.get('date')?.enable();
                    this.popupForm.controls['dateDisabled'].setValue(null, { emitEvent: false });
                }
            }
        });
    }

    confirm(): void {
        this.clientReplayParameters.coclico = [this.client.custAccNumber];
        this.clientReplayParameters.date = this.popupForm.get('date')?.value;
        this.clientReplayParameters.replayRefcom = this.popupForm.get('replayRefcom')?.value;
        this.replayClient();
        this.close();
    }

    replayClient() {
        let replayRefcom = this.clientReplayParameters.replayRefcom ? 'true' : 'false';
        if (this.clientReplayParameters.coclico) {
            if (!this.clientReplayParameters.date) {
                this.clientsService.replayClientUnit(this.clientReplayParameters.coclico, replayRefcom)
                    .subscribe({
                        next: (response: any) => {
                            this.replayReport = response;
                            if (this.replayReport.nbSuccess = "1") {
                                this.snackBar.open(`Succès du rejeu pour le client : ${this.client.custAccNumber} au plus tôt`, 'Fermer', { duration: 5000 });
                            }
                            else {
                                this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
                            }
                        },
                        error: (response: any) => {
                            this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
                        }
                    });
            }
            else {
                this.clientsService.replayClientUnit(this.clientReplayParameters.coclico, replayRefcom, this.formatDate(this.clientReplayParameters.date)!)
                    .subscribe({
                        next: (response: any) => {
                            this.replayReport = response;
                            if (this.replayReport.nbSuccess = "1") {
                                this.snackBar.open(`Succès du rejeu pour le client : ${this.client.custAccNumber} pour le ${this.clientReplayParameters.date}`, 'Fermer', { duration: 5000 });
                            }
                            else {
                                this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
                            }
                        },
                        error: (response: any) => {
                            this.snackBar.open('Une erreur est survenue : ' + JSON.stringify(response), 'Fermer', { duration: 5000 });
                        }
                    });
            }
        }
        else {
            this.snackBar.open('Impossible de récupérer le numéro de contrat');
        }
    }

    formatDate(date: Date | string) {
        return this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm:ss', 'fr');
    }

    close() {
        this.modalService.close(this.name);
    }
}