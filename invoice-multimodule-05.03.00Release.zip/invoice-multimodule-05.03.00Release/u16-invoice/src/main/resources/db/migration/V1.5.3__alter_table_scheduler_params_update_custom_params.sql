UPDATE scheduler_params SET custom_params = '{
                                                "code": "FACTURA_NOTIFICATION_MAIL_EXPORTS_BLINKS",
                                                "emails": [
                                                    "tom.stefanutti@laposte.fr"
                                                ],
                                                "infoca": 0,
                                                "equinox": 0,
                                                "partner": "FACTURA",
                                                "version": 2,
                                                "docaposte": 0,
                                                "docaposte_avis_paiement": 0
                                            }'
WHERE scheduler_name = "scheduler_notification" AND module = "u17";