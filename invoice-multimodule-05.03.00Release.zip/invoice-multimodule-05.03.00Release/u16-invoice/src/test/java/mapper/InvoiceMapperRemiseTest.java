package mapper;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import fr.laposte.blg.blinks.u16.mapper.GenericMapper;
import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.lib.common.dto.InvoiceDTO;
import fr.laposte.blg.blinks.u16.mapper.InvoiceAvroToDtoMapper;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class InvoiceMapperRemiseTest {
    private static Invoice source;
    private static InvoiceDTO destination;
    @InjectMocks
    private static GenericMapper genericMapper = GenericMapper.INSTANCE;

    @BeforeAll
    static void init() throws IOException {
        InvoiceAvroToDtoMapper mapper = Mappers.getMapper(InvoiceAvroToDtoMapper.class);
        ReflectionTestUtils.setField(mapper, "genericMapper", genericMapper);
        File src = new File("src/test/resources/invoice_remise_v9_test.json");
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
        source = objectMapper.readValue(src, Invoice.class);
        destination = mapper.avroToDto(source);
    }

    @Test
    @DisplayName("Test champs de remise : Tax fuel")
    void givenInvoiceAvroForRemise_whenMaps_thenTaxFuelOK() {
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getFuelTax(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getFuelTax());
    }

    @Test
    @DisplayName("Test champs de remise : ContactInvoiceLine")
    void givenInvoiceAvroForRemise_whenMaps_thenContractInvoiceLineOK() {
        assertNotNull(source.getContracts().get(0).getContractInvoiceLines().get(0));
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getNumber(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getNumber());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getToDisplay(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getToDisplay());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getDisplayPriority(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getDisplayPriority());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getAttachedNumber(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getAttachedNumber());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getConsumerAccountCode(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getConsumerAccountCode());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getCoclicoEmitterCode(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getCoclicoEmitterCode());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getDepositCustAccNumber(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getDepositCustAccNumber());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getExternalRef(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getExternalRef());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getType(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getType());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountLineType(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountLineType());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountedAccountingCode(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountedAccountingCode());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getFuelTax(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getFuelTax());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getProductCode(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getProductCode());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getNumber(),
                destination.getContracts().get(0).getContractInvoiceLines().get(0).getNumber());

        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getServiceCode(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getServiceCode());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getAccountingCode(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getAccountingCode());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getLabel(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getLabel());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getComment(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getComment());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getQuantity(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getQuantity());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getUnitPrice(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getUnitPrice());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getExcludingTaxAmount(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getExcludingTaxAmount());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getVATCode(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getVatCode());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getVATAmount(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getVatAmount());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getVATRate(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getVatRate());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getStampingCode(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getStampingCode());
        assertNotNull(source.getContracts().get(0).getContractInvoiceLines().get(0).getServiceDate());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getRegateCode(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getRegateCode());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getAddressId(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getAddressId());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountRate(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountRate());
        assertEquals(source.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountedAmount(), destination.getContracts().get(0).getContractInvoiceLines().get(0).getDiscountedAmount());
    }

    @Test
    @DisplayName("Test champs de remise : discountLineType and ")
    void givenInvoiceAvroForRemise_whenMaps_thenDiscountLineTypeOK() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDiscountLineType(),
                destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDiscountLineType());

    }

    @Test
    void givenInvoiceAvroForRemise_whenMaps_thenDiscountedAccountingCodeOK() {
        assertEquals(source.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDiscountedAccountingCode(),
                destination.getContracts().get(0).getLinkedAccounts().get(0).getInvoiceLines().get(0).getDiscountedAccountingCode());

    }



}

