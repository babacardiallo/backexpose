import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { environment } from '../../environments/environment';
import { OffresComponent } from './offres.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: '', component: OffresComponent}
        ])],
    exports: [RouterModule]
})
export class OffresRoutingModule { }
