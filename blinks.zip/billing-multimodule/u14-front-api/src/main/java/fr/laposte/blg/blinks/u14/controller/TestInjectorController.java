package fr.laposte.blg.blinks.u14.controller;

import MD.LatestValue.Address;
import fr.laposte.blg.blinks.u14.service.producer.KafkaLegalPersonAddressInjectorProducer;
import fr.laposte.blg.blinks.u14.service.producer.KafkaLegalPersonInjectorProducer;
import fr.laposte.blg.blinks.u14.service.producer.KafkaMandateInjectorProducer;
import fr.laposte.blg.blinks.u14.service.producer.KafkaTestContractProducer;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.gkContractFullOutV1;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import reactor.core.publisher.Mono;

@Controller
@Profile("mar-srec|mar-sdev|sloc")
@RequestMapping("/api-test/inject")
public class TestInjectorController {
    private final KafkaTestContractProducer contractProducer;
    private final KafkaLegalPersonInjectorProducer kafkaLegalPersonInjectorProducer;
    private final KafkaLegalPersonAddressInjectorProducer kafkaLegalPersonAddressInjectorProducer;
    private final KafkaMandateInjectorProducer kafkaMandateInjectorProducer;



    public TestInjectorController(KafkaTestContractProducer contractProducer, KafkaLegalPersonInjectorProducer kafkaLegalPersonInjectorProducer,
                                  KafkaLegalPersonAddressInjectorProducer kafkaLegalPersonAddressInjectorProducer, KafkaMandateInjectorProducer kafkaMandateInjectorProducer) {
        this.contractProducer = contractProducer;
        this.kafkaLegalPersonInjectorProducer = kafkaLegalPersonInjectorProducer;
        this.kafkaLegalPersonAddressInjectorProducer = kafkaLegalPersonAddressInjectorProducer;
        this.kafkaMandateInjectorProducer = kafkaMandateInjectorProducer;
    }

    @PostMapping("/push-contract")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Void> postToTopicContract(@RequestBody gkContractFullOutV1 contract) {
        return contractProducer.sendContractToTopic(contract);
    }

    @PostMapping("/push-legal-person")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Void> postToTopicLegalPerson(@RequestBody MD.LatestValue.LegalPerson legalPerson) {
        return kafkaLegalPersonInjectorProducer.sendLegalPersonToTopic(legalPerson);
    }

    @PostMapping("/push-legal-person-address")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Void> postToTopicLegalPersonAddress(@RequestBody Address address) {
        return kafkaLegalPersonAddressInjectorProducer.sendLegalPersonAddressToTopic(address);
    }

    @PostMapping("/push-mandate")
    @ResponseStatus(HttpStatus.OK)
    public Mono<Void> postMandateToTopic(@RequestBody String mandate) {
        return kafkaMandateInjectorProducer.sendMandateToTopic(mandate);
    }
}
