package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonPropertyOrder({
        "regateCode",
        "regateLabel",
        "excludingTaxTotalAmount"
})
public class ServiceEstablishmentDto {
    String regateCode;
    String regateLabel;
    Double excludingTaxTotalAmount;
}
