package fr.laposte.blg.blinks.u14.controller.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatDto {
    private Integer index;
    private String label;
    private Long value;
}
