package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractVersionMessage;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface ContractVersionMessageRepository extends ReactiveCrudRepository<ContractVersionMessage, Long> {

    @Query("SELECT contract_version_information from contract_version_message where id_contract_version = :id")
    Mono<String> getContractVersionInformationMessage(long id);

    @Query("SELECT contract_consolidated from contract_version_message where id_contract_version = :id")
    Mono<String> getContractConsolidatedMessage(long id);

    @Query("SELECT contract_odc from contract_version_message where id_contract_version = :id")
    Mono<String> getOdcContractMessage(long id);

    Mono<ContractVersionMessage> findByIdContractVersion(long id);

}
