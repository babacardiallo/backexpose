CREATE OR REPLACE VIEW blg_contract_importer.offer_errors_view AS
SELECT c.contract_number,
       cv.revision_number,
       cv.amendment_number,
       er.date_error,
       cv.is_synchronized,
       er.workflow_step,
       er.error_message,
       fo.ops_code
FROM blg_contract_importer.error_log er
INNER JOIN blg_contract_importer.contract c ON c.id_contract = er.id_contract
OR c.contract_number = er.contract_number
INNER JOIN blg_contract_importer.contract_version cv ON cv.id_contract = c.id_contract
INNER JOIN blg_contract_importer.valued_offer vo ON vo.id_valued_offer = cv.id_valued_offer
INNER JOIN blg_contract_importer.offer_filter fo ON fo.offer_ops_id = vo.ops_id;