package fr.laposte.blg.blinks.u10.entities;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(name = "rejection_u3", schema = "rejection")
public class RejetContract {

    @Id
    UUID id;
    @Column(name = "error_date")
    Instant errorDate;
    @Column(name = "contract_number")
    String contractNumber;
    @Column(name = "cust_acc_number")
    String custAccNumber;
    @Column(name = "error_code")
    String errorCode;
    @Column(name = "error_message")
    String errorMessage;
    @Column(name = "kafka_message")
    String kafkaMessage;
    @Column(name = "nb_retry")
    Integer nbRetry;
    @Column(name = "status")
    String status;
    @Column(name = "offset_message")
    Integer offset;
    @Column(name = "partition")
    Integer partition;
    @Column(name = "offer_code")
    String offerCode;
    @Column(name = "action")
    String action;
    @Column(name = "version_number")
    String versionNumber;
    @Column(name = "amendment_number")
    String amendmentNumber;
    @Column(name = "means_code")
    String meansCode;
    @Column(name = "invoice_periodicity_code")
    String invoicePeriodicityCode;
    @Column(name = "analysis")
    String analysis;
    @Column(name = "solution")
    String solution;

}

