package service;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import fr.laposte.bscc.avro.invoicing.Invoice;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceMessageEntity;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoice;
import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoiceStatus;
import fr.laposte.blg.blinks.lib.common.exceptions.CodeError;
import fr.laposte.blg.blinks.lib.common.exceptions.WorkFlowStep;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.lib.common.repositories.RejectedInvoiceRepository;
import fr.laposte.blg.blinks.u16.mapper.InvoiceAvroToDtoMapper;
import fr.laposte.blg.blinks.u16.service.InvoiceService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InvoiceServiceTest {
    private static Invoice invoiceFromMessage;
    @InjectMocks
    private InvoiceService invoiceService;
    @Mock
    private InvoiceRepository invoiceRepository;
    @Mock
    private InvoiceAvroToDtoMapper invoiceAvroToDtoMapper;
    @Mock
    private InvoiceMessageRepository invoiceMessageRepository;
    @Mock
    private RejectedInvoiceRepository rejectedInvoiceRepository;

    @BeforeAll
    static void init() throws IOException {
        File src = new File("src/test/resources/invoice_cip_v6_test.json");
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
        invoiceFromMessage = mapper.readValue(src, Invoice.class);

    }

    @Test
    void whenReceiveCipMessage_shouldMapEntity() {
        InvoiceEntity data = invoiceService.invoiceToInvoiceEntity(invoiceFromMessage).getT1();
        assertEquals(invoiceFromMessage.getInvoiceHeader().getInvoiceNumber(), data.getInvoiceNumber());
        assertEquals(invoiceFromMessage.getInvoiceHeader().getInvoiceNumber().toString(), data.getReference());
        assertEquals(invoiceFromMessage.getHeader().getBillrunCode(), data.getBillrunId());
        assertEquals(LocalDateTime.parse(invoiceFromMessage.getInvoiceHeader().getBillingDate().getCalculationDate(), DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant(), data.getBillrunDate());
        assertNotNull(data.getCreated());
        assertNotNull(data.getUpdated());
        assertEquals(Integer.parseInt(invoiceFromMessage.getBillingAccount().getCustAccNumber().toString()), data.getClient());
    }

    @Test
    void whenReceiveOkInvoice_shouldSave() {
        InvoiceEntity invoiceEntity = InvoiceEntity.builder().idInvoice(1L).build();
        InvoiceMessageEntity invoiceMessageEntity = InvoiceMessageEntity.builder().idInvoice(1L).build();

        when(invoiceRepository.save(any(InvoiceEntity.class))).thenReturn(Mono.just(invoiceEntity));
        when(invoiceMessageRepository.save(any())).thenReturn(Mono.just(invoiceMessageEntity));

        InvoiceService spyService = Mockito.spy(invoiceService);

        StepVerifier.create(spyService.saveInvoice(invoiceFromMessage))
                .expectNext(invoiceEntity)
                .verifyComplete();

        verify(spyService, times(1)).invoiceToInvoiceEntity(invoiceFromMessage);
    }

    @Test
    void whenReceiveInvoiceAlreadyPresent_shouldReject() {

        DataIntegrityViolationException dataIntegrityViolationException = new DataIntegrityViolationException("invoice already exists");
        when(invoiceRepository.save(any())).thenReturn(Mono.error(dataIntegrityViolationException));
        when(rejectedInvoiceRepository.save(any())).thenReturn(Mono.just(RejectedInvoice.builder().build()));

        StepVerifier.create(invoiceService.saveInvoice(invoiceFromMessage))
                .verifyComplete();

        ArgumentCaptor<RejectedInvoice> rejectedInvoiceArgumentCaptor = ArgumentCaptor.forClass(RejectedInvoice.class);
        verify(rejectedInvoiceRepository, times(1)).save(rejectedInvoiceArgumentCaptor.capture());
        RejectedInvoice captured = rejectedInvoiceArgumentCaptor.getValue();
        assertEquals(CodeError.U16004, captured.getErrorCode());
        assertEquals(RejectedInvoiceStatus.REJECTED, captured.getStatus());
        assertEquals(WorkFlowStep.INVOICE_LISTENING_SAVING_INVOICE_THAT_ALREADY_EXISTS, captured.getWorkFlowStep());

    }

    @Test
    void whenUnknownException_shouldReject() {
        RuntimeException runtimeException = new RuntimeException("Unknown Error");
        when (invoiceRepository.save(any())).thenReturn(Mono.error(runtimeException));
        when (rejectedInvoiceRepository.save(any())).thenReturn(Mono.just(RejectedInvoice.builder().build()));
        StepVerifier.create(invoiceService.saveInvoice(invoiceFromMessage))
                .verifyComplete();
        ArgumentCaptor<RejectedInvoice> rejectedInvoiceArgumentCaptor = ArgumentCaptor.forClass(RejectedInvoice.class);
        verify(rejectedInvoiceRepository, times(1)).save(rejectedInvoiceArgumentCaptor.capture());
        RejectedInvoice captured = rejectedInvoiceArgumentCaptor.getValue();

        assertEquals(CodeError.U16999, captured.getErrorCode());
        assertEquals(RejectedInvoiceStatus.REJECTED, captured.getStatus());
        assertEquals(WorkFlowStep.INVOICE_LISTENING, captured.getWorkFlowStep());

    }
}
