ALTER TABLE export_history
    ADD COLUMN nb_invoices_exported_in_file INT,
    ADD COLUMN nb_normal_invoices INT,
    ADD COLUMN nb_acomptes INT,
    ADD COLUMN nb_avoirs INT,
    ADD COLUMN nb_releves INT,
    ADD COLUMN ca_invoices DOUBLE NULL,
    ADD COLUMN ca_invoices_hors_releves DOUBLE NULL;