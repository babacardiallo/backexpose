package fr.laposte.blg.blinks.u11.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.u11.listener.contract.exception.ContractListenerException;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.*;
import org.mapstruct.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Mapper(uses = InstantMapper.class)
@DecoratedWith(ContractFullListenerDecorator.class)
public interface ContractFullListenerMapper {

    @Mappings({
            @Mapping(target = "idContract", ignore = true), //as it's an internal Primary key
            @Mapping(source = "contractNumber", target = "contractNumber"),
            @Mapping(source = "subType", target = "subtype"),
            @Mapping(source = "effectiveDateTime", target = "effectiveDatetime"),
            @Mapping(source = "custAccNumber", target = "custAccNumber"),
            @Mapping(source = "renewalMode", target = "renewalMode"),
            @Mapping(source = "managementMode", target = "managementMode"),
            @Mapping(source = "signatureDateTime", target = "signatureDatetime"),
            @Mapping(target = "idLegalPerson", ignore = true), //fetched with createOrFetchCustomerChain
            @Mapping(target = "legalPersonEntity", ignore = true), //fetched with createOrFetchCustomerChain
            @Mapping(target = "contractVersionEntities", ignore = true),
            @Mapping(target = "contractLinkedEntities", ignore = true)
    })
    ContractEntity contractInformationAvroToContractEntity(ContractInformation contractInformationAvro) throws JsonProcessingException;

    default String toString(CharSequence charSequence) {
        return (charSequence != null) ? charSequence.toString() : null;
    }

    default BigDecimal asBigDecimal(CharSequence charSequence) {
        return charSequence != null && !charSequence.toString().equals("") ? new BigDecimal(charSequence.toString()) : null;
    }

    default Integer asInteger(CharSequence charSequence) {
        return charSequence != null && !charSequence.toString().equals("") ? Integer.parseInt(charSequence.toString()) : null;
    }

    @Mappings({
            @Mapping(source = "amendmentNumber", target = "amendmentNumber"),
            @Mapping(source = "contractVersionNumber", target = "revisionNumber"),
            @Mapping(source = "validityStartDateTime", target = "validityStartDatetime"),
            @Mapping(source = "validityEndDateTime", target = "validityEndDatetime"),
            @Mapping(source = "status", target = "status"), //A voir avec les enums
            @Mapping(source = "subStatus", target = "substatus"),
            @Mapping(source = "terminationDateTime", target = "terminationDatetime"),
            @Mapping(source = "term", target = "term"),
            @Mapping(source = "category", target = "category"),
            @Mapping(source = "parentContractNumber", target = "parentContractNumber"),
            @Mapping(target = "parentAmendmentNumber", expression = "java(contractVersionInformationODC.getParentAmendmentNumber().toString().isEmpty() ? null : Integer.parseInt(contractVersionInformationODC.getParentAmendmentNumber().toString()))"), //TODO Hack necessary because field is an empty String instead of int in avro schema, ask ODC why
            @Mapping(target = "idContractVersion", ignore = true),
            @Mapping(target = "idValuedOffer", ignore = true),
            @Mapping(target = "valuedOffer", ignore = true),
            @Mapping(target = "idInvoiceInformation", ignore = true),
            @Mapping(target = "idContract", ignore = true),
            @Mapping(target = "contract", ignore = true),
            @Mapping(target = "dateSynchronization", ignore = true),
            @Mapping(target = "isSynchronized", ignore = true),
            @Mapping(target = "isPurged", ignore = true), // set to false by default in decorator. true if purged from ODC.
            @Mapping(target = "previousDateSynchronization", ignore = true)
    })
    ContractVersionEntity contractVersionInformationAvroToContractVersionEntity(ContractVersionInformation contractVersionInformationODC) throws JsonProcessingException;

    @Mappings({
            @Mapping(source = "paymentTermInformation.invoicePeriodicity", target = "invoicePeriodicityLabel"),
            @Mapping(source = "invoiceTermInformation.mode", target = "invoiceMode"),
            @Mapping(source = "invoiceTermInformation.sendingSupport", target = "sendingSupportLabel"),
            @Mapping(source = "invoiceTermInformation.custInvoiceTermId", target = "bosco"),
            @Mapping(source = "invoiceTermInformation.dedicatedInvoiceFlag", target = "dedicatedInvoiceFlag", qualifiedByName = "chrFlagToBoolean"),
            @Mapping(source = "invoiceTermInformation.inArrearsInvoicingFlag", target = "inArrearsInvoiceFlag", qualifiedByName = "chrFlagToBoolean"),
            @Mapping(source = "invoiceTermInformation.addressNumber", target = "invoiceAddressNumber"),
            @Mapping(source = "invoiceTermInformation.type", target = "type"),
            @Mapping(source = "paymentTermInformation.means", target = "paymentMeans"),
            @Mapping(source = "paymentTermInformation.meansReference", target = "meansReference"),
            @Mapping(source = "paymentTermInformation.period", target = "paymentPeriod"),
            @Mapping(source = "paymentTermInformation.RUM", target = "rum"),
            @Mapping(source = "invoiceTermInformation.VATInformation.VATLiabilityFlag", target = "vatLiabilityFlag", qualifiedByName = "chrFlagToBoolean"),
            @Mapping(source = "invoiceTermInformation.VATInformation.VATdepositZoneCode", target = "vatDepositZoneCode"),
            @Mapping(source = "paymentTermInformation.bankName", target = "bankName"),
            @Mapping(source = "paymentTermInformation.amount", target = "amount"),
            @Mapping(source = "financialSecurityInformation.financialSecurityMeans", target = "financialSecurityMeans"),
            @Mapping(source = "financialSecurityInformation.riskLevelColor", target = "riskLevelColor"),
            @Mapping(source = "financialSecurityInformation.validityStartDateTime", target = "validityStartDatetime"),
            @Mapping(source = "financialSecurityInformation.validityEndDateTime", target = "validityEndDatetime"),
            @Mapping(source = "financialSecurityInformation.depositPaymentFlag", target = "depositPaymentFlag", qualifiedByName = "chrFlagToBoolean"),
            @Mapping(source = "financialSecurityInformation.securityAmount", target = "securityAmount"),
            @Mapping(source = "financialSecurityInformation.securityCeiling", target = "securityCeiling"),
            @Mapping(source = "customerInformation.custPurchaseOrderNumber", target = "custPurchaseOrderNumber"),
            @Mapping(source = "customerInformation.contractingCustRef1", target = "contractingCustRef1"),
            @Mapping(source = "customerInformation.marketNumber", target = "marketNumber"),
            @Mapping(target = "idInvoiceInformation", ignore = true),
            @Mapping(target = "idAddressInvoice", ignore = true),
            @Mapping(target = "addressFacturation", ignore = true),
            @Mapping(source = "customerInformation.frameworkContractNumber", target = "frameworkContractNumber"),
            @Mapping(source = "customerInformation.custBusinessUnitRef", target = "custBusinessUnitRef"),
            @Mapping(source = "customerInformation.contractingCustRef2", target = "contractingCustRef2"),
            @Mapping(source = "customerInformation.invoicingCustRef2", target = "invoicingCustRef2"),
            @Mapping(source = "paymentTermInformation.schedule", target = "schedule"),
            @Mapping(source = "customerInformation.invoicingCustRef1", target = "invoicingCustRef1"),
            @Mapping(source = "paymentTermInformation.paymentCCId", target = "paymentCCId"),
            @Mapping(source = "paymentTermInformation.paymentCCDateTime", target = "paymentCCDateTime"),
            //invoicingCustRef2Object
            @Mapping(source = "customerInformation.invoicingCustRef2Object.siren", target = "siren"),
            @Mapping(source = "customerInformation.invoicingCustRef2Object.raisonSociale", target = "raisonSociale"),
            @Mapping(source = "customerInformation.invoicingCustRef2Object.siret", target = "siret"),
            @Mapping(source = "customerInformation.invoicingCustRef2Object.codeRoutage", target = "codeRoutage"),
            @Mapping(source = "customerInformation.invoicingCustRef2Object.suffixe", target = "suffixe"),
            @Mapping(source = "customerInformation.invoicingCustRef2Object.identifiantCodeRoutage", target = "identifiantCodeRoutage")
    })
    InvoiceInformationEntity invoiceInformationODCToInvoiceInformationEntity(fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.InvoiceInformation invoiceInformationODC) throws JsonProcessingException;


    @Mappings({
            @Mapping(source = "opsCode", target = "opsCode"),
            @Mapping(source = "opsId", target = "opsId"),
            @Mapping(target = "idValuedOffer", ignore = true)
    })
    ValuedOfferEntity offerAvroToValuedOfferEntity(Offer valuedOfferAvro) throws JsonProcessingException;

    @Mappings({
            @Mapping(source = "linkedContractNumber", target = "linkedContractNumber"),
            @Mapping(source = "linkType", target = "linkType")
            //TODO Gérer les liens contrats pour le topic consolidé
    })
    ContractLinkedEntity linkedContractAvroToContractLinked(LinkedContracts linkedContracts);

    List<ContractLinkedEntity> linkedContractsAvroToContractsLinked(List<LinkedContracts> linkedContracts);


    default ContractStatusEnum mapStatus(String statusFromODC) {
        return switch (statusFromODC) {
            case "Valide" -> ContractStatusEnum.VALIDE;
            case "Inactif" -> ContractStatusEnum.INACTIF;
            case "En cours de création" -> ContractStatusEnum.EN_COURS_DE_CREATION;
            default -> throw new ContractListenerException("Le statut " + statusFromODC + " n'est pas valide.");
        };
    }

    default ContractSubStatusEnum mapSubStatus(String subStatusFromODC) {
        return switch (subStatusFromODC) {
            case "En cours de création" -> ContractSubStatusEnum.EN_COURS_DE_CREATION;
            case "Edité" -> ContractSubStatusEnum.EDITE;
            case "A valider" -> ContractSubStatusEnum.A_VALIDER;
            case "Signé" -> ContractSubStatusEnum.SIGNE;
            case "Valide" -> ContractSubStatusEnum.VALIDE;
            case "Demande de résiliation" -> ContractSubStatusEnum.DEMANDE_DE_RESILIATION;
            case "Échu", "Echu" -> ContractSubStatusEnum.ECHU;
            case "En cours de renouvellement" -> ContractSubStatusEnum.EN_COURS_DE_RENOUVELLEMENT;
            case "Résilié" -> ContractSubStatusEnum.RESILIE;
            case "Terminé" -> ContractSubStatusEnum.TERMINE;
            case "Renouvelé" -> ContractSubStatusEnum.RENOUVELE;
            case "Annulé" -> ContractSubStatusEnum.ANNULE;
            case "Avenant" -> ContractSubStatusEnum.AVENANT;
            case "En attente signature client" -> ContractSubStatusEnum.EN_ATTENTE_SIGNATURE_CLIENT;
            case "En attente signature poste" -> ContractSubStatusEnum.EN_ATTENTE_SIGNATURE_POSTE;
            default -> throw new ContractListenerException("Le sous-statut" + subStatusFromODC + " de contrat n'est pas autorisé");
        };
    }

    default String mapInvoicingComments(List<Comments> comments) {
        return comments.toString();
    }

    @Named("chrFlagToBoolean")
    default Boolean ChrFlagToBoolean(CharSequence chr) {
        var str = Optional.ofNullable(chr).map(CharSequence::toString).orElse("false");
        return switch (str) {
            case "1", "true", "TRUE" -> Boolean.TRUE;
            default -> Boolean.FALSE;
        };
    }

}
