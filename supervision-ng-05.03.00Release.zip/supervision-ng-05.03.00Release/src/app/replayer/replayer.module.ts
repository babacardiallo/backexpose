import { NgModule } from '@angular/core';
import { ReplayerContractComponent } from './components/replayer-contract/replayer-contract.component';
import { ReplayerRoutingModule } from "./replayer-routing.module";
import { MatTabsModule } from "@angular/material/tabs";
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { ReplayerComponent } from "./replayer.component";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { DatePipe } from "@angular/common";
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { ReplayerClientsComponent } from './components/replayer-contract/replayer-clients/replayer-clients.component';
import { Title } from '@angular/platform-browser';
import { NgxPermissionsModule } from 'ngx-permissions';



@NgModule({

  imports: [
    SharedModule,
    ReplayerRoutingModule,
    NgxDatatableModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    NgxPermissionsModule.forChild()
  ],
  providers: [DatePipe, MatSnackBarModule, Title],
  declarations: [ReplayerComponent, ReplayerContractComponent, ReplayerClientsComponent],

  exports: [ReplayerComponent]


})
export class ReplayerModule { }
