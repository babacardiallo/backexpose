import { Injectable } from '@angular/core';
import { AuthOidcService } from '@cddng/auth-oidc-apim';

@Injectable({
  providedIn: 'root',
})
export class AuthCheckService {

    constructor(private authService: AuthOidcService) {}

    checkAuthenticatedUser(): Promise<any> {
        return new Promise(resolve => {
            this.authService.sessionChanged$.subscribe(auth => {
                if(auth){
                    const user: any = this.authService.getAuthenticatedUserFromJwt();
                    resolve(user);
                }
              });
        });
    }

    checkAuthToken(): Promise<any> {
        return new Promise(resolve => {
            this.authService.sessionChanged$.subscribe(auth => {
                if(auth){
                    const user: any = this.authService.getIdToken();
                    resolve(user);
                }
              });
        });
    }
}