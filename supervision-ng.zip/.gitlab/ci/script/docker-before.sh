#!/bin/sh

set -e

echo "🧾 Job environment info:"
echo " >> MODULE=${MODULE}"
echo " >> CI_JOB_NAME=$CI_JOB_NAME"
echo " >> CI_PIPELINE_ID=$CI_PIPELINE_ID"
echo " >> CI_PROJECT_PATH=$CI_PROJECT_PATH"
echo " >> CI_COMMIT_BRANCH=$CI_COMMIT_BRANCH"
echo " >> CI_COMMIT_SHA=$CI_COMMIT_SHA"
echo " >> CI_JOB_STAGE=$CI_JOB_STAGE"
echo " >> CI_SERVER_URL=$CI_SERVER_URL"

SCRIPT_DIR="$(dirname "$(realpath "$0")")"
REPO_ROOT="$(realpath "$SCRIPT_DIR/../../../")"
cd "$REPO_ROOT"

# Vérifier que le dossier dist existe
if [ ! -d "dist" ]; then
  echo "❌ dist/ folder not found. Make sure the Angular build job have generated the dist folder."
  exit 1
fi
#Remove if present
rm -rf docker-context
echo "🗂️ Creating docker-context directory..."
mkdir -p docker-context
#Copy necessary files dans folders for the docker build
echo "🗂️ Copying necessary files dans folders for docker build in docker-context directory..."
cp .gitlab/ci/docker/Dockerfile docker-context/Dockerfile
cp .gitlab/ci/docker/nginx.conf docker-context/nginx.conf
cp -r dist docker-context/

echo "🧾 Build context content:"
find docker-context -type f -exec ls -lh {} \;
