package fr.laposte.blg.blinks.u11.mapper;

import MD.LatestValue.Address;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class AddressListenerDecorator implements AddressListenerMapper {

    @Autowired
    @Qualifier("delegate")
    private AddressListenerMapper delegate;

    @Override
    public AddressEntity addressToAddressEntity(Address address) {
        AddressEntity addressEntity = this.delegate.addressToAddressEntity(address);
        addressEntity.setAddressJson(address.toString());
        return addressEntity;
    }

}
