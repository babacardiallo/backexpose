import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { Action } from 'rxjs/internal/scheduler/Action';
import { ReplayQueueTableModel } from '../models/replay-queue-table.model';
import { ReplayQueuePage } from '../models/replay-queue.page';
import { ReplayQueueService } from '../service/replay-queue.service';

@Component({
    selector: 'replay-queue-table-component',
    templateUrl: './replay-queue-table.component.html',
    styleUrls: ['./replay-queue-table.component.scss'],
    standalone: false
})

export class ReplayQueueTable implements OnInit, OnDestroy {
  @ViewChild(DatatableComponent) replayQueueTable: DatatableComponent;
  queueList: ReplayQueueTableModel[];
  queuePage: ReplayQueuePage = new ReplayQueuePage();
  create: boolean = true;
  update: boolean = true;
  searchText = '';

  constructor(private service: ReplayQueueService) {
  }

  ngOnInit(): void {
    this.getReplayQueue(true, true, 0, 10, 'id', 'desc', '');
  }

  ngOnDestroy(): void {
    this.service.ngUnsubscribe$.next();
    this.service.ngUnsubscribe$.complete();
  }

  getReplayQueue(create: boolean, update: boolean, page: number, size: number, sort: string, order: string, filter: string): void {
    this.service.getReplayQueue(create, update, page, size, sort, order, filter).subscribe({
      next: (response: any) => {
        this.queueList = response.content.map((data: any) => {
          return <ReplayQueueTableModel>{
            id: data.id,
            idContract: data.idContract,
            idLegalPerson: data.idLegalPerson,
            contractNumber: data.contractNumber,
            custAccNumber: data.custAccNumber,
            opsCode: data.opsCode,
            dateSynchronizationExpected: data.dateSynchronizationExpected ? new Date(data.dateSynchronizationExpected * 1000) : null,
            action: data.action,
            refcomReplay: data.refcomReplay ? "Oui" : "Non"
          };
        })
        this.queuePage = {
          currentPage: response.pageable.pageNumber,
          itemsOnPage: response.pageable.pageSize,
          currentOffset: response.pageable.offset,
          totalPages: response.totalPages,
          totalItems: response.totalElements
        };
      },
      complete: () => {
      },
    });
  }

  updateFilter(event: KeyboardEvent) {
    if (!event.target) {
      return null;
    }
    const val = (event.target as HTMLInputElement).value;
    if (event.key === 'Enter') {
      this.getReplayQueue(this.create, this.update, 0, 10, 'id', 'desc', val);
    }
  }

  switchIsActive(changed: 'create' | 'update') {
    if (!this.create && !this.update) {
      if (changed === 'create') {
        this.update = true;
      }
      else {
        this.create = true;
      }
    }
    this.getReplayQueue(this.create, this.update, 0, 10, 'id', 'desc', this.searchText);
  }

  onPageChange(event: any) {
    this.getReplayQueue(this.create, this.update, event.offset, 10, this.replayQueueTable.sorts[0].prop, this.replayQueueTable.sorts[0].dir, this.searchText);
  }

  onSort(event: any) {
    this.getReplayQueue(this.create, this.update, this.queuePage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.searchText);
    this.replayQueueTable.offset = this.queuePage.currentPage!;
  }

}