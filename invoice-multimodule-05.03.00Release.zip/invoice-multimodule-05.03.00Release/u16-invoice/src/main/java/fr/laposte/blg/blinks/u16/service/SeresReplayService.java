package fr.laposte.blg.blinks.u16.service;


import fr.laposte.blg.blinks.lib.common.entities.SeresOkEntity;
import fr.laposte.blg.blinks.lib.common.entities.SeresReplayEntity;
import fr.laposte.blg.blinks.lib.common.repositories.SeresOkRepository;
import fr.laposte.blg.blinks.lib.common.repositories.SeresReplayEntityRepository;
import fr.seres.avro.laposte.paktole.invoicing.PaktoleResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Service
@Slf4j
public class SeresReplayService {

    private final SeresReplayEntityRepository seresReplayEntityRepository;

    private final SeresOkRepository seresOkRepository;

    public SeresReplayService(SeresReplayEntityRepository seresReplayEntityRepository, SeresOkRepository seresOkRepository){
        this.seresReplayEntityRepository = seresReplayEntityRepository;
        this.seresOkRepository = seresOkRepository;
    }

    public Mono<SeresReplayEntity> saveSeresReplay(PaktoleResponse paktoleResponse) {
      if(paktoleResponse.getCode()!=0){
          SeresReplayEntity seresReplayEntity = new SeresReplayEntity();
          seresReplayEntity.setInvoiceNumber(paktoleResponse.getInvoice().toString());
          seresReplayEntity.setErrorCode(paktoleResponse.getCode());
          seresReplayEntity.setErrorMessage(paktoleResponse.getErrors().toString());
          seresReplayEntity.setInvoiceUrl(paktoleResponse.getUrl().toString());
          seresReplayEntity.setErrorDate(LocalDateTime.parse(paktoleResponse.getDate().toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.of("Europe/Paris")).toInstant());
          return seresReplayEntityRepository.save(seresReplayEntity);
      } else {
          SeresOkEntity seresOkEntity = new SeresOkEntity();
          seresOkEntity.setInvoiceNumber(paktoleResponse.getInvoice().toString());
          seresOkEntity.setErrorCode(paktoleResponse.getCode());
          seresOkEntity.setErrorMessage(paktoleResponse.getErrors().toString());
          seresOkEntity.setInvoiceUrl(paktoleResponse.getUrl().toString());
          seresOkEntity.setErrorDate(LocalDateTime.parse(paktoleResponse.getDate().toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.of("Europe/Paris")).toInstant());
          return seresOkRepository.save(seresOkEntity).then(Mono.empty());
      }
    }
}
