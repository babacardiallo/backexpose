package fr.laposte.blg.blinks.lib.common.entities;

public enum TransferStatus {
    NEW, TRANSFERED, FAILED, NO_FILE
}
