package fr.laposte.blg.blinks.lib.common.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReplayDto {

    private String contract_number;
    private String subtype;
    private String ops_code;
    Integer countContract;
}
