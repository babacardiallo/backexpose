package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ErrorEntity;
import fr.laposte.blg.blinks.lib.common.entities.RefopsEntity;
import fr.laposte.blg.blinks.lib.common.entities.RefopsOfferFilter;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;

public interface RefopsRepository extends ReactiveCrudRepository <RefopsEntity, Long> {
    @Query("UPDATE refops SET offer_activation_datetime = :dateActivation WHERE ops_code = :codeOps")
    Mono<RefopsEntity> setActivationDate(String codeOps, Instant dateActivation);

    Mono<RefopsEntity> findByOpsCode(String opsCode);

    @Query("UPDATE refops SET offer_activation_datetime = NULL WHERE ops_code = :codeOps")
    Mono<RefopsEntity> setActivationDateToNull(String codeOps);

    @Query("SELECT * FROM refops rf WHERE rf.ops_code IN (SELECT ops_code FROM offer_filter)")
    Flux<RefopsEntity> getAllActivesOffers();

    @Query("""
            SELECT            
                    COUNT(CASE
                    WHEN (er.workflow_step IS NOT NULL AND er.workflow_step LIKE 'CONTRACT_%')
                    THEN CONCAT(er.contract_number, er.amendment_number, er.revision_number)
                    END) AS `error_listening`,
                    COUNT(DISTINCT (CASE
                             WHEN (er.workflow_step IS NOT NULL AND er.workflow_step LIKE '%SYNCHRONIZATION%')
                    THEN CONCAT(er.contract_number, er.amendment_number)
                          END)) AS `error_synch`
                        FROM error_log er where ops_code = :opsCode""")
    Mono<ErrorEntity> countOfferErrorListeningAndSynchro(@Param("opsCode") String opsCode);


    @Query("SELECT COUNT(DISTINCT c.contract_number) FROM contract c WHERE c.id_contract IN (SELECT cv.id_contract FROM contract_version cv WHERE cv.is_synchronized=1 AND cv.id_valued_offer IN (SELECT vo.id_valued_offer FROM valued_offer vo WHERE vo.ops_code= :opsCode));")
    Mono<Long> countOfferErrorNbContractSynchronized(@Param("opsCode") String opsCode);

    @Query("SELECT COUNT(cv.id_contract_version) FROM contract_version cv WHERE cv.is_synchronized=1 AND cv.id_valued_offer IN (SELECT vo.id_valued_offer FROM valued_offer vo WHERE vo.ops_code= :opsCode);")
    Mono<Long> countOfferErrorNbContractVersionSynchronized(@Param("opsCode") String opsCode);



    @Query("SELECT COUNT(DISTINCT c.contract_number) FROM contract c WHERE c.id_contract IN (SELECT cv.id_contract FROM contract_version cv WHERE cv.id_valued_offer IN (SELECT vo.id_valued_offer FROM valued_offer vo WHERE vo.ops_code= :opsCode));")
    Mono<Long> countNbContractIntegrated(@Param("opsCode") String opsCode);

    @Query("SELECT COUNT(cv.id_contract_version) FROM contract_version cv WHERE cv.id_valued_offer IN (SELECT vo.id_valued_offer FROM valued_offer vo WHERE vo.ops_code= :opsCode);")
    Mono<Long> countNbContractVersionIntegrated(@Param("opsCode") String opsCode);

    Flux<RefopsEntity> findAllByOpsCodeLikeOrOpsLabelLike(String filter1, String filter2, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByOpsCodeLikeOrOpsLabelLike(String filter1, String filter2);

    Flux<RefopsEntity> findAllBy(@Param("pageable") Pageable pageable);

    Flux<RefopsEntity> findAllByOpsCodeIn(List<String> opsCodes, @Param("pageable") Pageable pageable);

    Flux<RefopsEntity> findAllByOpsCodeInAndOpsCodeLike(List<String> opsCodes, String filter, @Param("pageable") Pageable pageable);

    Flux<RefopsEntity> findAllByOpsCodeIn(List<String> opsCodes);

    Flux<RefopsEntity> findAllByOpsCodeInAndOpsCodeLike(List<String> opsCodes, String filter);

    Flux<RefopsEntity> findAllByOpsCodeLikeOrOpsLabelLike(String filter1, String filter2);

    @Query("SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM offer_filter ofFil LEFT JOIN refops ref ON ofFil.ops_code = ref.ops_code")
    Flux<RefopsOfferFilter> getAllOfferFilter();

    @Query("SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM offer_filter ofFil LEFT JOIN refops ref ON ofFil.ops_code = ref.ops_code WHERE ofFil.ops_code LIKE :filter OR ref.ops_label LIKE :filter")
    Flux<RefopsOfferFilter> getAllOfferFilterWhithFilter(@Param("filter") String filter);

    @Query("SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM offer_filter ofFil LEFT JOIN refops ref ON ofFil.ops_code = ref.ops_code ORDER BY ref.offer_activation_datetime asc")
    Flux<RefopsOfferFilter> getAllOfferFilterWithOrderAsc();

    @Query("SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM offer_filter ofFil LEFT JOIN refops ref ON ofFil.ops_code = ref.ops_code ORDER BY ref.offer_activation_datetime desc")
    Flux<RefopsOfferFilter> getAllOfferFilterWithOrderDesc();

    @Query("SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM offer_filter ofFil LEFT JOIN refops ref ON ofFil.ops_code = ref.ops_code WHERE ofFil.ops_code LIKE :filter OR ref.ops_label LIKE :filter ORDER BY ref.offer_activation_datetime asc")
    Flux<RefopsOfferFilter> getAllOfferFilterWhithOrderAscAndFilter(@Param("filter") String filter);

    @Query("SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM offer_filter ofFil LEFT JOIN refops ref ON ofFil.ops_code = ref.ops_code WHERE ofFil.ops_code LIKE :filter OR ref.ops_label LIKE :filter ORDER BY ref.offer_activation_datetime desc")
    Flux<RefopsOfferFilter> getAllOfferFilterWhithOrderDescAndFilter(@Param("filter") String filter);

    @Query("SELECT ref.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref LEFT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code" +
            " UNION SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref RIGHT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code")
    Flux<RefopsOfferFilter> getAllRefops();

    @Query("""
            SELECT * FROM (SELECT ref.ops_code, ref.ops_label, ref.offer_activation_datetime FROM          
             refops ref LEFT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code
             UNION SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref RIGHT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code) refOf
             WHERE refOf.ops_code LIKE :filter OR  refOf.ops_label LIKE :filter""")
    Flux<RefopsOfferFilter> getAllRefopsWithFilter(@Param("filter") String filter);

    @Query("""
            SELECT * FROM (SELECT ref.ops_code, ref.ops_label, ref.offer_activation_datetime FROM
             refops ref LEFT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code
             UNION SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref RIGHT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code) refOf
             ORDER BY refOf.offer_activation_datetime asc""")
    Flux<RefopsOfferFilter> getAllRefopsWithOrderAsc();

    @Query("""
            SELECT * FROM (SELECT ref.ops_code, ref.ops_label, ref.offer_activation_datetime FROM 
             refops ref LEFT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code
             UNION SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref RIGHT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code) refOf
             ORDER BY refOf.offer_activation_datetime desc""")
    Flux<RefopsOfferFilter> getAllRefopsWithOrderDesc();

    @Query("""
            SELECT * FROM (SELECT ref.ops_code, ref.ops_label, ref.offer_activation_datetime FROM
             refops ref LEFT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code
             UNION SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref RIGHT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code) refOf
             WHERE refOf.ops_code LIKE :filter OR  refOf.ops_label LIKE :filter ORDER BY refOf.offer_activation_datetime asc""")
    Flux<RefopsOfferFilter> getAllRefopsWithFilterAndOrderAsc(@Param("filter") String filter);

    @Query("""
            SELECT * FROM (SELECT ref.ops_code, ref.ops_label, ref.offer_activation_datetime FROM
             refops ref LEFT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code
             UNION SELECT ofFil.ops_code, ref.ops_label, ref.offer_activation_datetime FROM refops ref RIGHT JOIN offer_filter ofFil ON ref.ops_code = ofFil.ops_code) refOf
             WHERE refOf.ops_code LIKE :filter OR  refOf.ops_label LIKE :filter ORDER BY refOf.offer_activation_datetime desc""")
    Flux<RefopsOfferFilter> getAllRefopsWithFilterAndOrderdesc(@Param("filter") String filter);
}
