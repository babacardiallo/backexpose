package fr.laposte.blg.blinks.u11.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.laposte.blg.blinks.lib.common.entities.RefopsEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.RefopsRepository;
import fr.laposte.blg.blinks.u11.listener.refops.RefopsListenerService;
import fr.laposte.blg.blinks.u11.mapper.RefopsListenerMapper;
import fr.laposte.r5.uk.kafka.avro.viewoscar.Oscar;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Mono;
import reactor.kafka.receiver.ReceiverRecord;
import reactor.test.StepVerifier;

import java.time.Instant;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


class RefopsListenerServiceTest {
    @InjectMocks
    private RefopsListenerService refopsListenerService;
    @Mock
    private RefopsListenerMapper refopsListenerMapper;
    @Mock
    private RefopsRepository refopsRepository;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void readRefopsOfferFoundTest() throws JsonProcessingException {
        Oscar refops = new Oscar();
        refops.setOfferCode("001");
        refops.setOfferName("manger");
        refops.setOfferTechnicalVersion("1.0");
        refops.setOfferFunctionalVersion("1.0");

        RefopsEntity refopsEntity = new RefopsEntity();
        refopsEntity.setOfferOpsId(1L);
        refopsEntity.setOpsLabel("manger");
        refopsEntity.setOfferTechnicalVersion("1.0");
        refopsEntity.setOfferFunctionalVersion("1.0");
        refopsEntity.setOfferVersionCreationDatetime(Instant.now());
        refopsEntity.setData("{}");

        ConsumerRecord<String, Oscar> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", refops);
        ReceiverRecord<String, Oscar> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        when(this.refopsListenerMapper.refopsToRefopsEntity(any(Oscar.class))).thenReturn(refopsEntity);
        when(this.refopsRepository.findByOpsCode(refopsEntity.getOpsCode())).thenReturn(Mono.just(refopsEntity));
        when(this.refopsRepository.save(any(RefopsEntity.class))).thenAnswer( i -> Mono.just(i.getArgument(0)));

        StepVerifier.create(this.refopsListenerService.readRefopsOffer(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.refopsRepository, atLeastOnce()).save(any(RefopsEntity.class));

    }

    @Test
    void readRefopsOfferNotFoundTest() throws JsonProcessingException {
        Oscar refops = new Oscar();
        refops.setOfferCode("001");
        refops.setOfferName("manger");
        refops.setOfferTechnicalVersion("1.0");
        refops.setOfferFunctionalVersion("1.0");

        RefopsEntity refopsEntity = new RefopsEntity();
        refopsEntity.setOfferOpsId(1L);
        refopsEntity.setOpsLabel("manger");
        refopsEntity.setOfferTechnicalVersion("1.0");
        refopsEntity.setOfferFunctionalVersion("1.0");
        refopsEntity.setOfferVersionCreationDatetime(Instant.now());
        refopsEntity.setData("{}");

        ConsumerRecord<String, Oscar> consumerRecord = new ConsumerRecord<>("topic", 0, 1, "86845", refops);
        ReceiverRecord<String, Oscar> receiverRecord = new ReceiverRecord<>(consumerRecord, null);

        when(this.refopsListenerMapper.refopsToRefopsEntity(any(Oscar.class))).thenReturn(refopsEntity);
        when(this.refopsRepository.findByOpsCode(refopsEntity.getOpsCode())).thenReturn(Mono.empty());
        when(this.refopsRepository.save(any(RefopsEntity.class))).thenAnswer( i -> Mono.just(i.getArgument(0)));

        StepVerifier.create(this.refopsListenerService.readRefopsOffer(receiverRecord))
                .expectSubscription()
                .verifyComplete();

        verify(this.refopsRepository, atLeastOnce()).save(any(RefopsEntity.class));

    }
}
