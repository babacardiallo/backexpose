package fr.laposte.blg.blinks.u18.service;


public interface FileWriterService {
    /**
     * Exporte les messages non encore envoyés dans un fichier NDJSON
     * et les marque comme exportés.
     */
    void exportPendingMessagesToNdjson(String outputFolder);
}
