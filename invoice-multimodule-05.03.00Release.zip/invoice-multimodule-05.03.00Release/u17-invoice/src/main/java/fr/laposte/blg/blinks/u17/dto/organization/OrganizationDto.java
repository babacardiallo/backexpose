package fr.laposte.blg.blinks.u17.dto.organization;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class OrganizationDto {
    /**
     * Code ROC - peut être inutile
     */
    @JsonProperty("CODE")
    private String code;
    /**
     * Code Regate
     */
    @JsonProperty("CODE_REGATE")
    private String codeRegate;

    /**
     * Date de création
     */
    @JsonProperty("DATE_CREATION")
    private LocalDate creationDate;

    /**
     * Date de modification
     */
    @JsonProperty("DATE_MODIFICATION")
    private LocalDate modificationDate;
    /**
     * Date de désactivation
     */
    @JsonProperty("DATE_DESACTIVATION")
    private LocalDate deactivationDate;
    /**
     * Date de fermeture
     */
    @JsonProperty("DATE_FERMETURE")
    private LocalDate closingDate;


}
