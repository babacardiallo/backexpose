CREATE TABLE blg_invoice.customer_profit_center
(
    id              int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    coclico         int  NOT NULL,
    entity_code     varchar(20),
    profit_center   varchar(20),
    created         datetime default CURRENT_TIMESTAMP,
    updated         datetime default CURRENT_TIMESTAMP
);