package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.CustomerInvoice;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceStatusEnum;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.List;
import java.util.Set;

@Repository
public interface InvoiceRepository extends ReactiveCrudRepository<InvoiceEntity, Long> {

    @Query("SELECT * from invoice where infoca_export_id is NULL AND infoca_export_status = 'NEW' AND (id_invoice BETWEEN :minId AND :maxId) order by reference_number asc")
    Flux<InvoiceEntity> findByInfocaExportIdIsNullAndIdBetweenOrderByReferenceAsc(Long minId, Long maxId);

    @Query("SELECT * from invoice where docaposte_export_id is NULL AND docaposte_export_status = 'NEW' AND (id_invoice BETWEEN :minId AND :maxId) order by reference_number asc")
    Flux<InvoiceEntity> findByDocaposteExportIdIsNullAndIdBetweenOrderByReferenceAsc(Long minId, Long maxId);

    @Query("SELECT * from invoice where docaposte_avis_paiement_export_id is NULL AND docaposte_avis_paiement_export_status = 'NEW' AND (id_invoice BETWEEN :minId AND :maxId) order by reference_number asc")
    Flux<InvoiceEntity> findByDocaposteAvispaiementExportIdIsNullAndIdBetweenOrderByReferenceAsc(Long minId, Long maxId);

    @Query("SELECT * from invoice where coeurfinance_export_id is NULL AND coeurfinance_export_status = 'NEW' AND (id_invoice BETWEEN :minId AND :maxId) order by reference_number asc")
    Flux<InvoiceEntity> findByCoeurfinanceExportIdIsNullAndIdBetweenOrderByReferenceAsc(Long minId, Long maxId);

    @Query("UPDATE invoice SET docaposte_export_id = :docaposteExportId WHERE id_invoice = :id")
    Mono<InvoiceEntity> updateDocaposteExportIdById(long docaposteExportId, long id);

    @Query("UPDATE invoice SET docaposte_avis_paiement_export_id = :docaposteAvisPaiementExportId WHERE id_invoice = :id")
    Mono<InvoiceEntity> updateDocaposteAvisPaiementExportIdById(long docaposteAvisPaiementExportId, long id);

    @Modifying
    @Query("UPDATE invoice SET coeurfinance_export_id = :docaposteExportId WHERE id_invoice = :id")
    Mono<Integer> updateCoeurfinanceExportIdById(long coeurfinanceExportId, long id);

    @Modifying
    @Query("UPDATE invoice SET infoca_export_id = :infocaExportId WHERE id_invoice = :id")
    Mono<Integer> updateInfocaExportIdById(long infocaExportId, long id);

    @Modifying
    @Query("update blg_invoice.invoice inv\n" +
            " set coeurfinance_export_id = NULL," +
            "coeurfinance_export_status = 'NEW', " +
            "coeurfinance_error_message = NULL," +
            "coeurfinance_error_code = NULL" +
            " where\n" +
            " inv.invoice_number in (:numInvoices)")
    Mono<Boolean> prepareExportCoeurfinance(Set<String> numInvoices);

    @Modifying
    @Query("update blg_invoice.invoice inv\n" +
            " set infoca_export_id = NULL," +
            "infoca_export_status = 'NEW', " +
            "infoca_error_message = NULL," +
            "infoca_error_code = NULL" +
            " where\n" +
            " inv.invoice_number in (:numInvoices)")
    Mono<Boolean> prepareExportInfoca(Set<String> numInvoices);

    @Modifying
    @Query("update blg_invoice.invoice inv\n" +
            " set docaposte_export_id = NULL," +
            "docaposte_export_status = 'NEW', " +
            "docaposte_error_message = NULL," +
            "docaposte_error_code = NULL" +
            " where\n" +
            " inv.invoice_number in (:numInvoices)")
    Mono<Boolean> prepareExportDocaposte(Set<String> numInvoices);

    Flux<InvoiceEntity> findAllByCreatedGreaterThanEqual(@Param("pageable")Pageable pageable, @Param("created") Instant created);

    Flux<InvoiceEntity> findAllByCreatedGreaterThanEqualAndInvoiceNumberLike(@Param("pageable")Pageable pageable, @Param("created") Instant created, @Param("filter") String filter);

    @Query("SELECT * FROM invoice JOIN invoice_message ON invoice.id_invoice = invoice_message.id_invoice" +
            " WHERE (invoice.created >= :created AND (invoice.invoice_number LIKE :filter OR :filter IS NULL) AND JSON_EXTRACT(invoice_message.message, \"$.invoiceHeader.printFlag\" ) = TRUE)" +
            " ORDER BY invoice.id_invoice ASC, :sort :order LIMIT :limit OFFSET :offset")
    Flux<InvoiceEntity> getByCriteriaDocaposte(@Param("created") Instant created, @Param("filter") String filter,
                                               @Param("sort") String sort, @Param("order") String order, @Param("limit") int limit, @Param("offset") int offset);

    @Query("SELECT * FROM invoice JOIN invoice_message ON invoice.id_invoice = invoice_message.id_invoice" +
            " WHERE (invoice.created >= :created AND (invoice.invoice_number LIKE :filter OR :filter IS NULL) AND JSON_EXTRACT(invoice_message.message, \"$.invoiceHeader.printFlag\" ) = FALSE)" +
            " ORDER BY invoice.id_invoice ASC, :sort :order LIMIT :limit OFFSET :offset")
    Flux<InvoiceEntity> getByCriteriaSeres(@Param("created") Instant created, @Param("filter") String filter,
                                           @Param("sort") String sort, @Param("order") String order, @Param("limit") int limit, @Param("offset") int offset);


    Mono<Long> countAllByCreatedGreaterThanEqual(@Param("created") Instant created);


    Mono<Long> countAllByCreatedGreaterThanEqualAndInvoiceNumberLike(@Param("created") Instant created, @Param("filter") String filter);


    @Query("SELECT COUNT(*) FROM invoice JOIN invoice_message ON invoice.id_invoice = invoice_message.id_invoice" +
            " WHERE (invoice.created >= :created AND (invoice.invoice_number LIKE :filter OR :filter IS NULL) AND JSON_EXTRACT(invoice_message.message, \"$.invoiceHeader.printFlag\" ) = TRUE)")
    Mono<Long> countByCriteriaDocaposte(@Param("created") Instant created, @Param("filter") String filter);

    @Query("SELECT COUNT(*) FROM invoice JOIN invoice_message ON invoice.id_invoice = invoice_message.id_invoice" +
            " WHERE (invoice.created >= :created AND (invoice.invoice_number LIKE :filter OR :filter IS NULL) AND JSON_EXTRACT(invoice_message.message, \"$.invoiceHeader.printFlag\" ) = FALSE)")
    Mono<Long> countByCriteriaSeres(@Param("created") Instant created, @Param("filter") String filter);



    Flux<InvoiceEntity> findAllByDocaposteExportIdIsNullAndDocaposteExportStatusEqualsOrInfocaExportIdIsNullAndInfocaExportStatusEqualsOrCoeurfinanceExportIdIsNullAndCoeurfinanceExportStatusEquals(InvoiceStatusEnum docaposteExportStatus, InvoiceStatusEnum infocaExportStatus, InvoiceStatusEnum coeurfinanceExportStatus, @Param("pageable") Pageable pageable);

    Mono<Long> countAllByDocaposteExportIdIsNullAndDocaposteExportStatusEqualsOrInfocaExportIdIsNullAndInfocaExportStatusEqualsOrCoeurfinanceExportIdIsNullAndCoeurfinanceExportStatusEquals(InvoiceStatusEnum docaposteExportStatus, InvoiceStatusEnum infocaExportStatus, InvoiceStatusEnum coeurfinanceExportStatus);

    @Query("SELECT * FROM blg_invoice.invoice where invoice_number in (:numInvoices)")
    Flux<InvoiceEntity> getAllInvoicesExported(Set<String> numInvoices);

    @Query("SELECT client, count(*) FROM blg_invoice.invoice WHERE client IN (:clientIds) GROUP BY client")
    Flux<CustomerInvoice> getCustomerNbInvoices(@Param("clientIds") List<Integer> clientIds);

    @Query("SELECT count(*) from invoice" +
            " WHERE credit_flag = FALSE" +
            " AND statement_flag = FALSE")
    Mono<Long> getNbInvoices();

    @Query("SELECT count(*) from invoice" +
            " WHERE credit_flag = TRUE" +
            " AND statement_flag = FALSE")
    Mono<Long> getNbAvoirs();

    @Query("SELECT count(*) from invoice" +
            " WHERE statement_flag = TRUE")
    Mono<Long> getNbReleves();

    @Query("SELECT count(*) FROM blg_invoice.invoice where" +
            " docaposte_export_id IS NOT NULL")
    Mono<Long> countExportedInvoicesToDocaposte();

    @Query("SELECT count(*) FROM blg_invoice.invoice where" +
            " infoca_export_id  IS NOT NULL")
    Mono<Long> countExportedInvoicesToInfoca();

    @Query("SELECT count(*) FROM blg_invoice.invoice where" +
            " coeurfinance_export_id   IS NOT NULL")
    Mono<Long> countExportedInvoicesToCoeurfinance();

    @Query("SELECT message from invoice WHERE id_invoice = :id")
    Mono<String> getMessage(long id);

    @Modifying
    @Query("UPDATE invoice SET docaposte_export_status = :status WHERE id_invoice = :id")
    Mono<Integer> updateDocaposteExportStatusById(InvoiceStatusEnum status, long id);

    @Modifying
    @Query("UPDATE invoice SET docaposte_avis_paiement_export_status = :status WHERE id_invoice = :id")
    Mono<Integer> updateDocaposteAvispaiementExportStatusById(InvoiceStatusEnum status, long id);

    @Modifying
    @Query("UPDATE invoice SET infoca_export_status = :status WHERE id_invoice = :id")
    Mono<Integer> updateInfocaExportStatusById(InvoiceStatusEnum status, long id);

    @Modifying
    @Query("UPDATE invoice SET coeurfinance_export_status = :status WHERE id_invoice = :id")
    Mono<Integer> updateCoeurfinanceExportStatusById(InvoiceStatusEnum status, long id);

    @Modifying
    @Query("UPDATE invoice SET docaposte_error_message = :errorMessage WHERE id_invoice = :id")
    Mono<Integer> updateDocaposteErrorMessageById(String errorMessage, long id);

    @Modifying
    @Query("UPDATE invoice SET docaposte_avis_paiement_error_message = :errorMessage WHERE id_invoice = :id")
    Mono<Integer> updateDocaposteAvisPaiementErrorMessageById(String errorMessage, long id);

    @Modifying
    @Query("UPDATE invoice SET infoca_error_message = :errorMessage WHERE id_invoice = :id")
    Mono<Integer> updateInfocaErrorMessageById(String errorMessage, long id);

    @Modifying
    @Query("UPDATE invoice SET coeurfinance_error_message = :errorMessage WHERE id_invoice = :id")
    Mono<Integer> updateCoeurfinanceErrorMessageById(String errorMessage, long id);

    @Modifying
    @Query("UPDATE invoice SET docaposte_error_code = :errorCode WHERE id_invoice = :id")
    Mono<Integer> updateDocaposteErrorCodeById(String errorCode, long id);

    @Modifying
    @Query("UPDATE invoice SET docaposte_avis_paiement_error_code = :errorCode WHERE id_invoice = :id")
    Mono<Integer> updateDocaposteAvisPaiementErrorCodeById(String errorCode, long id);

    @Modifying
    @Query("UPDATE invoice SET infoca_error_code = :errorCode WHERE id_invoice = :id")
    Mono<Integer> updateInfocaErrorCodeById(String errorCode, long id);

    @Modifying
    @Query("UPDATE invoice SET coeurfinance_error_code = :errorCode WHERE id_invoice = :id")
    Mono<Integer> updateCoeurfinanceErrorCodeById(String errorCode, long id);

    @Modifying
    @Query("UPDATE invoice set docaposte_export_id = NULL, docaposte_export_STATUS = 'NEW', docaposte_error_message = NULL, docaposte_error_code = NULL where docaposte_export_id IS NOT NULL AND docaposte_export_status = 'FAILED'")
    Mono<Integer> processFailedDocaposte();

    @Modifying
    @Query("UPDATE invoice set infoca_export_id = NULL, infoca_export_STATUS = 'NEW', infoca_error_message = NULL, infoca_error_code = NULL where infoca_export_id IS NOT NULL AND infoca_export_status = 'FAILED'")
    Mono<Integer> processFailedInfoca();

    @Modifying
    @Query("UPDATE invoice set coeurfinance_export_id = NULL, coeurfinance_export_STATUS = 'NEW', coeurfinance_error_message = NULL, coeurfinance_error_code = NULL where coeurfinance_export_id IS NOT NULL AND coeurfinance_export_status = 'FAILED'")
    Mono<Integer> processFailedCoeurfinance();

    @Modifying
    @Query("UPDATE invoice set docaposte_export_id = NULL, docaposte_export_STATUS = 'NEW', docaposte_error_message = NULL, docaposte_error_code = NULL where docaposte_export_status = 'FAILED' and invoice_number IN (:invoices)")
    Mono<Integer> processFailedDocaposteIn(@Param("invoices") List<String> invoices);

    @Modifying
    @Query("UPDATE invoice set infoca_export_id = NULL, infoca_export_STATUS = 'NEW', infoca_error_message = NULL, infoca_error_code = NULL where infoca_export_status = 'FAILED' and invoice_number IN (:invoices)")
    Mono<Integer> processFailedInfocaIn(@Param("invoices") List<String> invoices);

    @Modifying
    @Query("UPDATE invoice set coeurfinance_export_id = NULL, coeurfinance_export_STATUS = 'NEW', coeurfinance_error_message = NULL, coeurfinance_error_code = NULL where coeurfinance_export_status = 'FAILED' and invoice_number IN (:invoices)")
    Mono<Integer> processFailedCoeurfinanceIn(@Param("invoices") List<String> invoices);

    @Query("SELECT MIN(id_invoice) from invoice where (infoca_export_id is NULL AND infoca_export_status = 'NEW') OR (docaposte_export_id is NULL AND docaposte_export_status = 'NEW') OR (coeurfinance_export_id is NULL AND coeurfinance_export_status = 'NEW') OR (docaposte_avis_paiement_export_id is NULL AND docaposte_avis_paiement_export_status = 'NEW')")
    Mono<Long> getMinIdForProcess();

    @Query("SELECT MAX(id_invoice) from invoice where (infoca_export_id is NULL AND infoca_export_status = 'NEW') OR (docaposte_export_id is NULL AND docaposte_export_status = 'NEW') OR (coeurfinance_export_id is NULL AND coeurfinance_export_status = 'NEW') OR (docaposte_avis_paiement_export_id is NULL AND docaposte_avis_paiement_export_status = 'NEW')")
    Mono<Long> getMaxIdForProcess();

    @Query("SELECT MAX(id_invoice) from invoice")
    Mono<Long> getMaxId();

    @Modifying
    @Query("DELETE FROM invoice WHERE updated < :purgeDate and (coeurfinance_export_status != 'FAILED' and infoca_export_status != 'FAILED' and docaposte_export_status != 'FAILED')")
    Mono<Long> deleteByUpdatedBefore(@Param("purgeDate") Instant purgeDate);

}