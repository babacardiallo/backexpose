package fr.laposte.blg.blinks.u12.apim;

public class ConnexionException extends RuntimeException {
    public ConnexionException(String reasonPhrase) {
        super(reasonPhrase);
    }
}
