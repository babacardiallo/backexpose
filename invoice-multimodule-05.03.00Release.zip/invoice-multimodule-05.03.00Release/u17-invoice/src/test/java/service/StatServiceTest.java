package service;

import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.service.StatService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class StatServiceTest {
    @InjectMocks
    private StatService statService;
    @Mock
    private InvoiceRepository invoiceRepository;

    @Test
    void getTotauxTest(){
        Mockito.when(invoiceRepository.getNbInvoices()).thenReturn(Mono.just(1L));
        Mockito.when(invoiceRepository.getNbAvoirs()).thenReturn(Mono.just(1L));
        Mockito.when(invoiceRepository.getNbReleves()).thenReturn(Mono.just(1L));
        Mockito.when(invoiceRepository.countExportedInvoicesToDocaposte()).thenReturn(Mono.just(1L));
        Mockito.when(invoiceRepository.countExportedInvoicesToInfoca()).thenReturn(Mono.just(1L));
        Mockito.when(invoiceRepository.countExportedInvoicesToCoeurfinance()).thenReturn(Mono.just(1L));
        statService.getTotaux();
    }
}
