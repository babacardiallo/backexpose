import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DailySupervisionComponent } from './daily-supervision.component';

describe('DailySupervisionComponent', () => {
  let component: DailySupervisionComponent;
  let fixture: ComponentFixture<DailySupervisionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DailySupervisionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DailySupervisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
