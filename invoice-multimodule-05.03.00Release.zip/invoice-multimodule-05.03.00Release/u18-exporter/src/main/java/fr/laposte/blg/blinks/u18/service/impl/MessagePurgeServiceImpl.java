package fr.laposte.blg.blinks.u18.service.impl;

import fr.laposte.blg.blinks.u18.repository.CustomerAccountRepository;
import fr.laposte.blg.blinks.u18.service.MessagePurgeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class MessagePurgeServiceImpl implements MessagePurgeService {

    private final CustomerAccountRepository repository;

    public int purgeMessagesOlderThan(Instant threshold) {
        return repository.deleteByCreatedBefore(threshold);
    }
}
