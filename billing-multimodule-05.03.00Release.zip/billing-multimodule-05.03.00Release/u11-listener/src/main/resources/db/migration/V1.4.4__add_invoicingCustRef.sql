ALTER TABLE invoice_information
    ADD COLUMN invoicing_cust_ref2 varchar(255);