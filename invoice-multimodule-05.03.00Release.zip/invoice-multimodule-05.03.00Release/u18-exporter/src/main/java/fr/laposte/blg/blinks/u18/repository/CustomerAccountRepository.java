package fr.laposte.blg.blinks.u18.repository;

import fr.laposte.blg.blinks.u18.entity.CustomerAccountMessage;
import fr.laposte.blg.blinks.u18.entity.MessageStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Repository
public interface CustomerAccountRepository extends CrudRepository<CustomerAccountMessage, UUID> {

    List<CustomerAccountMessage> findAllByStatus(MessageStatus status);

    int deleteByCreatedBefore(Instant created);

    Page<CustomerAccountMessage> findAllByStatus(MessageStatus status, Pageable pageable);

}
