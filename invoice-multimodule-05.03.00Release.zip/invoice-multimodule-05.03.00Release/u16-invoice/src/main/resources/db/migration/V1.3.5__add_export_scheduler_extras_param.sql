ALTER TABLE scheduler_params
ADD execution_order JSON DEFAULT NULL,
ADD waiting_delay INT DEFAULT NULL;

ALTER TABLE export_process
ADD execution_sequence INT DEFAULT NULL;

