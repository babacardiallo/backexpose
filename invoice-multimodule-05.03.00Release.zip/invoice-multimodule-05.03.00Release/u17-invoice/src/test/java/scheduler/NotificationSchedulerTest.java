package scheduler;

import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.NotificationStatus;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.u17.scheduler.NotificationScheduler;
import fr.laposte.blg.blinks.u17.service.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationSchedulerTest {

    @Mock
    private ExportHistoryRepository exportHistoryRepository;
    @Mock
    private NotificationService notificationService;

    private SchedulerParamsEntity schedulerParams;
    private NotificationScheduler notificationScheduler;

    @BeforeEach
    void setUp() {
        schedulerParams = new SchedulerParamsEntity();
        schedulerParams.setId(1L);
        schedulerParams.setSchedulerName("scheduler_notification");

        // Utilise une durée d'attente nulle pour accélérer les tests unitaires
        notificationScheduler = new NotificationScheduler(exportHistoryRepository, schedulerParams, notificationService, Duration.ZERO);
    }

    @Test
    void run_shouldProcessNewAndCreatedNotifications() {
        ExportHistoryEntity newExport = new ExportHistoryEntity();
        newExport.setIdExport(1L);
        ExportHistoryEntity createdExport = new ExportHistoryEntity();
        createdExport.setIdExport(2L);

        when(exportHistoryRepository.findAllByNotificationStatusIn(NotificationStatus.NEW))
                .thenReturn(Flux.just(newExport));
        when(exportHistoryRepository.findAllByNotificationStatusIn(NotificationStatus.CREATED))
                .thenReturn(Flux.just(createdExport));

        when(notificationService.sendNotification(anyList(), any(SchedulerParamsEntity.class)))
                .thenReturn(Mono.empty());
        when(notificationService.checkNotificationStatus(anyList()))
                .thenReturn(Mono.empty());

        notificationScheduler.run();

        verify(notificationService).sendNotification(anyList(), any(SchedulerParamsEntity.class));
        verify(notificationService).checkNotificationStatus(anyList());
    }

    @Test
    void run_shouldHandleNoNewExports() {
        when(exportHistoryRepository.findAllByNotificationStatusIn(NotificationStatus.NEW))
                .thenReturn(Flux.empty());
        when(exportHistoryRepository.findAllByNotificationStatusIn(NotificationStatus.CREATED))
                .thenReturn(Flux.empty());

        notificationScheduler.run();

        verify(notificationService, never()).sendNotification(anyList(), any(SchedulerParamsEntity.class));
        verify(notificationService, never()).checkNotificationStatus(anyList());
    }
}
