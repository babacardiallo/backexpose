package fr.laposte.blg.blinks.lib.common.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonPropertyOrder({
        "custAccNumber",
        "name",
        "brandName",
        "typeCode",
        "typeLabel",
        "advPortfolioCode",
        "siretCode",
        "CVATNO",
        "billingTypology"
})
public class CustomerInformationDTO {
    String custAccNumber;
    String name;
    String brandName;
    String typeCode;
    String typeLabel;
    String advPortfolioCode;
    String siretCode;
    @JsonProperty("CVATNO")
    String cvatno;
    String billingTypology;
}
