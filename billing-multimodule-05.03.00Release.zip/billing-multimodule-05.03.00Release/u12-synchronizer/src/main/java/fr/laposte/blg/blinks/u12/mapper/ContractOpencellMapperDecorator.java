package fr.laposte.blg.blinks.u12.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.laposte.blg.blinks.lib.common.entities.ContractVersionEntity;
import fr.laposte.blg.blinks.u12.mapper.enumeration.*;
import fr.laposte.bscc.billing.avro.billing.*;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.Offer;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.OfferProduct;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ProductPrice;
import fr.laposte.bscc.odyssee.schema.gk.contract.full.out.v1.ProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ContractOpencellMapperDecorator implements ContractOpencellMapper {

    @Autowired
    @Qualifier("delegate")
    private ContractOpencellMapper delegate;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public ContractOpencell contractVersionEntityToContractOpencell(ContractVersionEntity contractVersionEntity) {
        //TODO add contractEstablishment
        ContractOpencell contractOpencell = this.delegate.contractVersionEntityToContractOpencell(contractVersionEntity);

        contractOpencell.getContractInformation().setCustPurchaseOrderNumber(contractVersionEntity.getInvoiceInformationEntity().getCustPurchaseOrderNumber());
        contractOpencell.getContractInformation().setContractingCustRef1(contractVersionEntity.getInvoiceInformationEntity().getContractingCustRef1());
        contractOpencell.getContractInformation().setMarketNumber(contractVersionEntity.getInvoiceInformationEntity().getMarketNumber());
        contractOpencell.getContractInformation().setContractingCustRef2(contractVersionEntity.getInvoiceInformationEntity().getContractingCustRef2());
        contractOpencell.getContractInformation().setCustBusinessUnitRef(contractVersionEntity.getInvoiceInformationEntity().getCustBusinessUnitRef());
        contractOpencell.getContractInformation().setFrameworkContractNumber(contractVersionEntity.getInvoiceInformationEntity().getFrameworkContractNumber());
        contractOpencell.getContractInformation().setInvoicingCustRef2(contractVersionEntity.getInvoiceInformationEntity().getInvoicingCustRef2());
        contractOpencell.getContractInformation().setInvoicingCustRef1(contractVersionEntity.getInvoiceInformationEntity().getInvoicingCustRef1());
        //invoicingCustRef2Object
        contractOpencell.getContractInformation().setSirenNumber(contractVersionEntity.getInvoiceInformationEntity().getSiren());
        contractOpencell.getContractInformation().setCompanyName(contractVersionEntity.getInvoiceInformationEntity().getRaisonSociale());
        contractOpencell.getContractInformation().setSiretNumber(contractVersionEntity.getInvoiceInformationEntity().getSiret());
        contractOpencell.getContractInformation().setRoutingCode(contractVersionEntity.getInvoiceInformationEntity().getCodeRoutage());
        contractOpencell.getContractInformation().setSuffix(contractVersionEntity.getInvoiceInformationEntity().getSuffixe());
        contractOpencell.getContractInformation().setIdRoutingCode(contractVersionEntity.getInvoiceInformationEntity().getIdentifiantCodeRoutage());

        try {
            int term = Integer.parseInt(contractVersionEntity.getTerm());
            contractOpencell.getContractVersionInformation().setTerm(term);
        } catch (NumberFormatException nfe) {
            contractOpencell.getContractVersionInformation().setTerm(0);
        }

        if (contractOpencell.getInvoiceInformation() != null && contractOpencell.getInvoiceInformation().getSendingSupportLabel() != null) {
            contractOpencell.getInvoiceInformation().setSendingSupportCode(SendingSupportEnum.getCode(contractOpencell.getInvoiceInformation().getSendingSupportLabel().toString()));
        }
        if (contractOpencell.getPaymentInformation() != null && contractOpencell.getPaymentInformation().getInvoicePeriodicityLabel() != null) {
            contractOpencell.getPaymentInformation().setInvoicePeriodicityCode(InvoicePeriodicityEnum.getCode(contractOpencell.getPaymentInformation().getInvoicePeriodicityLabel().toString()));
        }
        if (contractOpencell.getPaymentInformation() != null && contractOpencell.getPaymentInformation().getMeansLabel() != null) {
            contractOpencell.getPaymentInformation().setMeansCode(MeansEnum.getCode(contractOpencell.getPaymentInformation().getMeansLabel().toString()));
        }
        if (contractOpencell.getPaymentInformation() != null && contractOpencell.getPaymentInformation().getPeriodLabel() != null) {
            contractOpencell.getPaymentInformation().setPeriodCode(PeriodEnum.getCode(contractOpencell.getPaymentInformation().getPeriodLabel().toString()));
        }

        if (contractOpencell.getPaymentInformation() != null && contractOpencell.getPaymentInformation().getScheduleLabel() != null) {
            contractOpencell.getPaymentInformation().setScheduleCode(ScheduleEnum.getCode(contractOpencell.getPaymentInformation().getScheduleLabel().toString()));
        }
        return contractOpencell;
    }


    public OfferInformation contractOfferToOfferInformation(Offer offer) {
        List<ProductInformation> productList = new ArrayList<>();
        if (offer.getProducts() != null) {
            for (OfferProduct product : offer.getProducts()) {
                List<ServiceInformation> serviceInformationList = new ArrayList<>();
                List<ProductPrices> productPriceList = new ArrayList<>();
                if (product.getProductService() != null) {
                    for (ProductService service : product.getProductService()) {
                        serviceInformationList.add(ServiceInformation.newBuilder().setServiceCode(service.getServiceCode()).build());
                    }
                }
                if (product.getProductPrices() != null) {
                    for (ProductPrice price : product.getProductPrices()) {
                        productPriceList.add(ProductPrices.newBuilder()
                            .setProrata(price.getProrata())
                            .setInclusingTaxUnitPrice(price.getInclusingTaxUnitPrice())
                            .setChargeDescription(price.getChargeDescription())
                            .build());
                    }
                }

                productList.add(ProductInformation.newBuilder()
                    .setProductCode(product.getProductCode())
                    .setProductPrices(productPriceList)
                    .setServiceInformation(serviceInformationList)
                    .build());
            }
        }
        return OfferInformation.newBuilder()
            .setOpsId(Integer.parseInt(offer.getOpsId().toString()))
            .setOpsCode(offer.getOpsCode())
            .setOpsVersion(offer.getOpsVersion())
            .setProductInformation(productList)
            .build();
    }
}
