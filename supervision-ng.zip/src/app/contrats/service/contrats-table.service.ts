import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ContractDetails } from '../models/contract-details.model';
import { ContratsRevisionError } from '../models/contrats-revision-error';
import { ContratsTable } from '../models/contrats-table.model';

@Injectable({
    providedIn: 'root',
})
export class ContratsTableService {
    ngUnsubscribe$ = new Subject<void>();

    constructor(private http: HttpClient) { }
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            
        }),
    }
    httpOptionsTextResponse = {
        headers: new HttpHeaders({
            'Accept': 'text/plain, */*',
            'Content-Type': 'application/json'
        }),
        responseType: 'text' as 'json'
    }

    getContracts(isActiveOffers: boolean, errors: boolean, isNotSynchronized: boolean, page: number, size: number, sort: string, order: string): Observable<ContratsTable[]> {
        let api: string;
        isActiveOffers ? api = environment.API_CONTRACT_SUPERVISION_ACTIVE : api = environment.API_CONTRACT_SUPERVISION_ALL + "?";
        let queryParams = new HttpParams()
            .set("errors", errors)
            .set("isNotSynchronized", isNotSynchronized)
            .set("page", page)
            .set("size", size)
            .set("sort", sort)
            .set("order", order);
        return this.http.get<ContratsTable[]>(api + queryParams, this.httpOptions)
            .pipe(takeUntil(this.ngUnsubscribe$));
    }

    getContractsExport(): Observable<ContratsTable[]> {
        return this.http.get<ContratsTable[]>(environment.API_CONTRACT_EXPORT_SYNCHED, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
    }

    getContractDetails(contractNumber: string, amendmentNumber: number): Observable<ContractDetails> {
        let queryParams = new HttpParams()
            .set("contractNumber", contractNumber)
            .set("amendementNumber", amendmentNumber);
        return this.http.get<ContractDetails>(environment.API_CONTRACT_SUPERVISION_DETAILS + queryParams, this.httpOptions)
            .pipe(takeUntil(this.ngUnsubscribe$));
    }

    getSuperiorRevErrors(showAll: boolean, page: number, size: number, sort: string, order: string, contractNumber: string, custAccNumber: string, offers: string[]): Observable<ContratsRevisionError[]> {
        let queryParams = new HttpParams()
            .set("showAll", showAll)
            .set("page", page)
            .set("size", size)
            .set("sort", sort)
            .set("order", order)
        if (contractNumber != null && contractNumber != '') {
            queryParams = queryParams.set("contractNumber", contractNumber);
        }
        if (custAccNumber != null && custAccNumber != '') {
            queryParams = queryParams.set("custAccNumber", custAccNumber);
        }
        if (offers != null && offers.length != 0) {
            queryParams = queryParams.set("offers", offers.join(','));
        }
        return this.http.get<any[]>(environment.API_CONTRACT_SUPERIOR_REVISION_ERROR + "?" + queryParams, this.httpOptions)
            .pipe(takeUntil(this.ngUnsubscribe$));
    }

    getSuperiorRevErrorOneContract(contractNumber: string, amendementNumber: number, revisionNumber: number): Observable<ContratsRevisionError> {
        let queryParams = new HttpParams()
            .set("contractNumber", contractNumber)
            .set("amendmentNumber", amendementNumber)
            .set("revisionNumber", revisionNumber);
        return this.http.get<ContratsRevisionError>(environment.API_ONE_CONTRACT_SUPREV_ERROR + queryParams, this.httpOptions)
            .pipe(takeUntil(this.ngUnsubscribe$));
    }

    replayContractUnit(contractNumber: string, method: string, date?: string): Observable<unknown> {
        let queryParams = new HttpParams()
            .set("action", method)
            .set("contract-number", contractNumber);

        if (date) {
            queryParams = queryParams.set("date-synchronization-expected", date);
        }
        return this.http.post(environment.API_CONTRACT_REPLAY_UNIT + queryParams, null, this.httpOptionsTextResponse)
            .pipe(takeUntil(this.ngUnsubscribe$));
    }

    getFilteredContracts(errors: boolean, isNotSynchronized: boolean, showAll: boolean, page: number, size: number, sort: string, order: string, contractNumber: string, custAccNumber: string, offers: string[]): Observable<ContratsRevisionError[]> {
        let queryParams = new HttpParams()
            .set("errors", errors)
            .set("isNotSynchronized", isNotSynchronized)
            .set("page", page)
            .set("size", size)
            .set("sort", sort)
            .set("order", order)
            .set("showAll", showAll);

        if (contractNumber != null && contractNumber != '') {
            queryParams = queryParams.set("contractNumber", contractNumber);
        }
        if (custAccNumber != null && custAccNumber != '') {
            queryParams = queryParams.set("custAccNumber", custAccNumber);
        }
        if (offers != null && offers.length != 0) {
            queryParams = queryParams.set("offers", offers.join(','));
        }
        return this.http.get<ContratsTable[]>(environment.API_CONTRACT_FILTER + queryParams, this.httpOptions)
            .pipe(takeUntil(this.ngUnsubscribe$));
    }

    getOffersList() {
        return this.http.get(environment.API_OFFERS_LIST, this.httpOptions);
    }


}