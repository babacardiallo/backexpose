INSERT INTO blg_invoice.file_sequence(sequence_name, current_sequence)
VALUES ('INFOCA', 0);