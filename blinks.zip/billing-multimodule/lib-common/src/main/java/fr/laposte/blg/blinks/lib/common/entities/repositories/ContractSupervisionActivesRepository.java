package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractSuperiorRevError;
import fr.laposte.blg.blinks.lib.common.entities.ContractSupervisionActivesEntity;
import fr.laposte.blg.blinks.lib.common.entities.ReplayDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;

public interface ContractSupervisionActivesRepository extends ReactiveCrudRepository<ContractSupervisionActivesEntity, String> {

    Flux<ContractSupervisionActivesEntity> findAllBy(@Param("pageable") Pageable pageable);

    Flux<ContractSupervisionActivesEntity> findAllByIsSynchronizedFalse(@Param("pageable") Pageable pageable);

    Mono<Long> countAllByIsSynchronizedFalse();

    Flux<ContractSupervisionActivesEntity> findByCustAccNumberBeforeSynchronisation(int coclico);

    @Query("""
            SELECT *
            
              FROM (
                            SELECT *,
                                    ROW_NUMBER() OVER(PARTITION BY contract_number) rn
                                FROM blg_contract_importer.contract_supervision_actives
                               WHERE is_synchronized = 1
            
                          ) a
            WHERE rn = 1""")
    Flux<ContractSupervisionActivesEntity> findAllContractByIsSynchronizedTrue();


    Flux<ContractSupervisionActivesEntity> findAllByFirstErrorDateIsNotNull(@Param("pageable") Pageable pageable);

    Flux<ContractSupervisionActivesEntity> findAllByFirstErrorDateIsNotNullAndIsSynchronizedFalse(@Param("pageable") Pageable pageable);

    Mono<Long> countAllByFirstErrorDateIsNotNull();

    Mono<Long> countAllByFirstErrorDateIsNotNullAndIsSynchronizedFalse();

    @Query("SELECT COUNT(*) FROM blg_contract_importer.contract_supervision_actives WHERE first_error_date IS NOT NULL AND is_synchronized = 0 AND (contract_number LIKE :filter OR ops_code LIKE :filter OR ops_label LIKE :filter)")
    Mono<Long> countAllByFirstErrorDateIsNotNullAndIsSynchronizedFalseAndContractNumberLikeOrOpsCodeLikeOrOpsLabelLike(@Param("filter") String filter);

    @Query("SELECT COUNT(*) FROM blg_contract_importer.contract_supervision_actives WHERE first_error_date IS NOT NULL AND (contract_number LIKE :filter OR ops_code LIKE :filter OR ops_label LIKE :filter)")
    Mono<Long> countAllByFirstErrorDateIsNotNullAndContractNumberLikeOrOpsCodeLikeOrOpsLabelLike(@Param("filter") String filter);


    @Query("""
            SELECT contract_number,            
            MAX(subtype) AS subtype,
            MAX(ops_code) AS ops_code,
            COUNT(contract_number) AS countContract  FROM contract_supervision_actives
            GROUP BY contract_number;""")
    Flux<ReplayDto> getByCriteria();

    @Query("SELECT * from contract_supervision_actives where is_synchronized=1")
    Flux<ContractSupervisionActivesEntity> findAllContractsSynchronized();

    @Query(
            """
                    SELECT * FROM (                    
                      SELECT
                        cs.id,
                        cs.id_contract,
                        cs.contract_number,
                        cs.amendment_number,
                        cs.revision_number,
                        er.revision_number AS superior_revision_error,
                        er.offset_num,
                        er.partition_num,
                        er.error_message,
                        er.date_error,
                        cs.status,
                        cs.substatus,
                        cs.type,
                        cs.subtype,
                        cs.ops_code,
                        cs.ops_label,
                        cs.is_synchronized,
                        cs.last_date_synchronization,
                        cs.first_error_date,
                        cs.cust_acc_number,
                        cs.cust_acc_number_before_synchronisation,
                        ROW_NUMBER() OVER (
                          PARTITION BY cs.id
                          ORDER BY er.date_error DESC
                        ) AS rn
                      FROM blg_contract_importer.contract_supervision_actives cs
                      INNER JOIN (
                        SELECT contract_number, amendment_number, MAX(revision_number) AS max_revision_number
                        FROM error_log
                        GROUP BY contract_number, amendment_number
                      ) max_er
                        ON cs.contract_number = max_er.contract_number
                       AND cs.amendment_number = max_er.amendment_number
                      INNER JOIN error_log er
                        ON er.contract_number = max_er.contract_number
                       AND er.amendment_number = max_er.amendment_number
                       AND er.revision_number = max_er.max_revision_number
                      WHERE er.revision_number > cs.revision_number
                    ) ranked_data
                    WHERE rn = 1
                      AND (:contractNumber IS NULL OR ranked_data.contract_number = :contractNumber)
                      AND (:custAccNumber  IS NULL OR ranked_data.cust_acc_number = :custAccNumber)
                      AND (:offers         IS NULL OR ranked_data.ops_code IN (:offers))"""
    )
    Flux<ContractSuperiorRevError> contractSuperiorRevError(
            @Param("contractNumber") String contractNumber,
            @Param("custAccNumber")  String custAccNumber,
            @Param("offers")         List<String> offers,
            Pageable pageable
    );

    @Query(
            """
                    SELECT count(1) FROM (                    
                      SELECT
                        cs.id,
                        cs.id_contract,
                        cs.contract_number,
                        er.date_error,
                        cs.ops_code,
                        cs.cust_acc_number,
                        ROW_NUMBER() OVER (
                          PARTITION BY cs.id
                          ORDER BY er.date_error DESC
                        ) AS rn
                      FROM blg_contract_importer.contract_supervision_actives cs
                      INNER JOIN (
                        SELECT contract_number, amendment_number, MAX(revision_number) AS max_revision_number
                        FROM error_log
                        GROUP BY contract_number, amendment_number
                      ) max_er
                        ON cs.contract_number = max_er.contract_number
                       AND cs.amendment_number = max_er.amendment_number
                      INNER JOIN error_log er
                        ON er.contract_number = max_er.contract_number
                       AND er.amendment_number = max_er.amendment_number
                       AND er.revision_number = max_er.max_revision_number
                      WHERE er.revision_number > cs.revision_number
                    ) ranked_data
                    WHERE rn = 1
                      AND (:contractNumber IS NULL OR ranked_data.contract_number = :contractNumber)
                      AND (:custAccNumber  IS NULL OR ranked_data.cust_acc_number = :custAccNumber)
                      AND (:offers         IS NULL OR ranked_data.ops_code IN (:offers))"""
    )
    Mono<Long> countContractSuperiorRevError(
            @Param("contractNumber") String contractNumber,
            @Param("custAccNumber")  String custAccNumber,
            @Param("offers") List<String> offers
    );

}
