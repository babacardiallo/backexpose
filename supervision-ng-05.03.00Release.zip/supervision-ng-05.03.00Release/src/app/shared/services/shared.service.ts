import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SharedService {


  localPermissions = ['ADMIN', 'CONS', 'ADV'];

  connectedUserData: any;

  displayLocalRole = 'ADMIN';

  constructor() {

  }



}