export class OffresTable {
    codeOps?: string;
    labelOps?: string;
    offerActivationDate?: string | Date;
    contractsSynch?: string;
    versionsSynch?: string;
    contractIntegrated?: string;
    contractVersionIntegrated?: string;
    errorsListening?: string;
    errorsSynch?: string;
    isActiveOffer?: boolean;

}
