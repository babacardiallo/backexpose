import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-data-table-component',
    templateUrl: './data-table-component.component.html',
    styleUrls: ['./data-table-component.component.scss'],
    standalone: false
})
export class DataTableComponentComponent implements OnInit {
  conctrats = new Contrats("exp contrat" , "1" ,"xxxx", "proxi" ,"valid");
  list :Contrats[] =[];
  constructor(){
  this.list [0]= this.conctrats;
}

ngOnInit(): void {
}

}

export class Contrats {

  constructor(
      public contrat?: String,
      public version?: String,
      public cocli?: String,
      public offre?: String,
      public status?: String,

  ) {

  }
}
