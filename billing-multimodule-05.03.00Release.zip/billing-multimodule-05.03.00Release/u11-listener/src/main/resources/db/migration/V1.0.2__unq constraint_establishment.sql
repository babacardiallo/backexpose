DROP INDEX idx_establishment_regate_code ON blg_contract_importer.establishment;

ALTER TABLE blg_contract_importer.establishment
ADD CONSTRAINT unq_establishment UNIQUE (regate_code);