import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { UntypedFormControl, UntypedFormGroup } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { SeresService } from "../service/seres.service";
import { SeresPage } from "../models/seres-page";
import { SeresTable } from "../models/seres-table.model";
import { SeresDetailsPopUpComponent } from "./seres-details-pop-up/seres-details-pop-up.component";
import * as XLSX from 'xlsx';
import { ModalService } from "ngx-modal-ease";


@Component({
    selector: 'seres-table',
    templateUrl: './seres-table.component.html',
    styleUrls: ['./seres-table.component.scss'],
    standalone: false
})

export class SeresTableComponent implements OnInit {

  @ViewChild(DatatableComponent) seresTable: DatatableComponent;

  searchText: string = '';
  range: UntypedFormGroup;
  seresPage: SeresPage = new SeresPage();
  listSeres: SeresTable[];
  globalStartDate: any;
  globalEndDate: any;
  globalStatus = '';
  selectedCodeErreurs = new UntypedFormControl('');
  listErreurs = [];
  noPrintableOnly = false;

  M1_MODAL_PROPERTIES = {
    animation: 'enter-going-down',
    duration: '0.1s',
    easing: 'ease-out',
    padding: '1rem',
    width: '1800px',
    height: '100%'
  };


  constructor(private seresService: SeresService, private datePipe: DatePipe, private snackBar: MatSnackBar, private modalService: ModalService) {

  }
  ngOnInit(): void {
    const today = new Date();
    let oneMonthAgo = new Date();
    oneMonthAgo = new Date(oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1));
    this.range = new UntypedFormGroup({
      start: new UntypedFormControl(oneMonthAgo),
      end: new UntypedFormControl(today),
    });
    this.globalStartDate = this.datePipe.transform(oneMonthAgo, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
    this.globalEndDate = this.datePipe.transform(today, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
    this.getListSeresByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate, this.noPrintableOnly);
    this.getAllErrorsCode();
  }

  siwtchToNoPrintable(){
    this.getListSeresByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate, this.noPrintableOnly);
  }


  getListSeresByDate(page: number, size: number, sort: string, order: string, startDate: any, enDate: any, noPrintableOnly: boolean): Promise<any> {
    return new Promise((resolve) => {
      this.seresService.getListSeresByDate(page, size, sort, order, startDate, enDate, this.searchText, this.globalStatus, this.selectedCodeErreurs.value, noPrintableOnly).subscribe({
        next: (response: any) => {
          this.listSeres = response.content.map((data: any) => {
            return <SeresTable>{
              id: data.id,
              invoiceNumber: data.invoiceNumber,
              errorDate: this.formatDate(data.errorDate),
              errorCode: data.errorCode,
              errorMessage: data.errorMessage,
              invoiceUrl: data.invoiceUrl,
              printable: data.printable
            };
          })
          this.seresPage = {
            currentPage: response.pageable.pageNumber,
            itemsOnPage: response.pageable.pageSize,
            currentOffset: response.pageable.offset,
            totalPages: response.totalPages,
            totalItems: response.totalElements
          }
        },
        complete: () => {
          resolve(true);
        },
      });
    });
  }

  filter(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.getListSeresByDate(0, 10, "errorDate", "desc", this.globalStartDate, this.globalEndDate, this.noPrintableOnly);
    }
  }

  selectedDate(event: any) {
    if (event.value) {
      this.globalStartDate = this.datePipe.transform(this.range.value.start, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
      this.globalEndDate = this.datePipe.transform(this.range.value.end, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
      this.getListSeresByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate,this.noPrintableOnly)
    }
  }

  onPageChange(event: any) {
    this.getListSeresByDate(event.offset, 10, this.seresTable.sorts[0].prop, this.seresTable.sorts[0].dir, this.globalStartDate, this.globalEndDate,this.noPrintableOnly);
  }

  onSort(event: any) {
    this.getListSeresByDate(this.seresPage.currentPage!, 10, event.sorts[0].prop, event.sorts[0].dir, this.globalStartDate, this.globalEndDate, this.noPrintableOnly);
    this.seresTable.offset = this.seresPage.currentPage!;
  }

  showPopup(row: SeresTable, event: Event) {
    this.modalService
    .open(SeresDetailsPopUpComponent, {
      modal: {
        enter: `${this.M1_MODAL_PROPERTIES.animation} ${this.M1_MODAL_PROPERTIES.duration} ${this.M1_MODAL_PROPERTIES.easing}`,
      },
      overlay: {
        leave: 'fade-out 0.3s',
      },
      size: {
        padding: this.M1_MODAL_PROPERTIES.padding,
        width: this.M1_MODAL_PROPERTIES.width,
        height: this.M1_MODAL_PROPERTIES.height
      },
      data: {
        seres: row,
      }
    })
    .then((response) => console.log(response));
    event.stopPropagation();
  }

  formatDate(date: any) {
    return date ? this.datePipe.transform(date, 'dd/MM/yyyy à HH:mm:ss', 'fr') : null;
  }


  getAllErrorsCode() {
    this.seresService.getAllCodeErrorSeres().subscribe({
      next: (response: any) => {
        this.listErreurs = response;
      },
      complete: () => {
      },

    })
  }

  filterByErrorCode() {
    this.getListSeresByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate, this.noPrintableOnly)
  }

  exportSeres() {
    let dataToExport: any[];
    this.seresService.getSeresExport(this.globalStartDate, this.globalEndDate, this.searchText, this.selectedCodeErreurs.value, this.noPrintableOnly).subscribe({
      next: (response: any) => {
        dataToExport = response.map((data: any) => {
          return <any>{
            id: data.id,
            invoiceNumber: data.invoiceNumber,
            errorDate: this.formatDate(data.errorDate),
            errorCode: data.errorCode,
            errorMessage: data.errorMessage,
            invoiceUrl: data.invoiceUrl
          };
        })
      },
      complete: () => {
        dataToExport.forEach((seres: SeresTable) => {
          delete seres.id;
        });
        const fileName = 'ExportRejetsSERES_' + this.formatDateExport(Date.now()) + '.xlsx';
        const headers = [["N° facture", "Date erreur", "Code erreur", "Message erreur", "URL facture"]];
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport, {
          dateNF: 'dd/mm/yyyy à HH:MM:SS',
          cellDates: true
        });
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.sheet_add_aoa(ws, headers);
        XLSX.utils.book_append_sheet(wb, ws, 'Export');
        ws['!cols'] = [
          { wch: 20 },
          { wch: 20 },
          { wch: 20 },
          { wch: 150 },
          { wch: 100 },
        ];
        XLSX.writeFile(wb, fileName);
      },
    });
  }

  formatDateExport(date: number) {
    return this.datePipe.transform(date, 'yyyyMMddHHmmSS', 'fr');
  }

  onDateKeyUp(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      if (this.range.value.start && this.range.value.end) {
        this.globalStartDate = this.datePipe.transform(this.range.value.start, 'yyyy-MM-ddT00:00:00', 'fr') + "Z";
        this.globalEndDate = this.datePipe.transform(this.range.value.end, 'yyyy-MM-ddT23:59:59', 'fr') + "Z";
        this.getListSeresByDate(0, 10, 'errorDate', 'desc', this.globalStartDate, this.globalEndDate, this.noPrintableOnly);
      }
    }

  }


}