package fr.laposte.blg.blinks.u17.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Component
@Slf4j
public class DateUtil {

    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    private static final ZoneId ZONE_ID = ZoneId.of("Europe/Paris");
    private static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    private static final String DD_MM_YYYY_HH_MM = "dd-MM-yyyy HH:mm";
    private static final String YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";


    public String yyyyMMddHHmm() {
        return yyyyMMddHHmm(Instant.now());
    }

    public String yyyyMMddDash(Instant toDate) {
        if (toDate == null)
            return Constant.EMPTY;
        var formatter = DateTimeFormatter.ofPattern(YYYY_MM_DD)
                .withZone(ZONE_ID);
        return formatter.format(toDate);
    }

    public String yyyyMMddDash(LocalDate toDate) {
        if (toDate == null)
            return Constant.EMPTY;
        var formatter = DateTimeFormatter.ofPattern(YYYY_MM_DD)
                .withZone(ZONE_ID);
        return formatter.format(toDate);
    }

    public String yyyyMMdd(Instant toDate) {
        if (toDate == null)
            toDate = Instant.now();
        var formatter = DateTimeFormatter.ofPattern("yyyyMMdd")
                .withZone(ZONE_ID);
        return formatter.format(toDate);
    }

    public String yyyyMMddLocal(LocalDate toDate) {
        if (toDate == null)
            return Constant.EMPTY;
        var formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        return formatter.format(toDate);
    }

    public String yyyyMMddHHmm(Instant toDate) {
        if (toDate == null)
            toDate = Instant.now();
        var fm = DateTimeFormatter.ofPattern("yyyyMMddHHmm")
                .withZone(ZONE_ID);
        return fm.format(toDate);
    }

    public static String yyyyMMddHHmmSS(Instant toDate) {
        if (toDate == null)
            toDate = Instant.now();
        var fm = DateTimeFormatter.ofPattern(YYYY_MM_DD_HH_MM_SS)
                .withZone(ZONE_ID);
        return fm.format(toDate);
    }


    public static String yyyyMMddHHmmSSMorningCheck(Instant toDate) {
        if (toDate == null)
           return "";
        var fm = DateTimeFormatter.ofPattern(YYYY_MM_DD_HH_MM_SS)
                .withZone(ZONE_ID);
        return fm.format(toDate);
    }

    public static String ddMMyyyyHHmm(Instant toDate) {
        if (toDate == null)
           return "";
        var fm = DateTimeFormatter.ofPattern(DD_MM_YYYY_HH_MM)
                .withZone(ZONE_ID);
        return fm.format(toDate);
    }
    public static String yyyyMMddHm(Instant toDate) {
        if (toDate == null)
            return "";
        var fm = DateTimeFormatter.ofPattern(YYYY_MM_DD_HH_MM)
                .withZone(ZONE_ID);
        return fm.format(toDate);
    }
}
