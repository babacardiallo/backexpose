package fr.laposte.blg.blinks.lib.common.dto;

import fr.laposte.blg.blinks.lib.common.entities.RejectedInvoiceStatus;
import fr.laposte.blg.blinks.lib.common.exceptions.CodeError;
import fr.laposte.blg.blinks.lib.common.exceptions.WorkFlowStep;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RejectedInvoiceToLog {

    private String invoiceNumber;

    private CodeError errorCode;

    private String errorMessage;

    private RejectedInvoiceStatus status;

    private Instant errorDate;

    private Instant replayedDate;

    private WorkFlowStep workFlowStep;
}
