package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.LinkContractCoclicoMarket;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface LinkContractCoclicoMarketRepository extends ReactiveCrudRepository<LinkContractCoclicoMarket, Long> {


    @Query("SELECT contract_number FROM link_coclico_market_contract WHERE cust_acc_number = :coclico AND market_number = :marketNumber")
    Mono<String> getContractNumberBuyCoclicoAndMarketNumber(@Param("coclico") Integer coclico, @Param("marketNumber") String marketNumber);
}
