package fr.laposte.blg.blinks.u17.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransferIhmDto {
    private Long id;
    private String type;
    private String name;
    private String generationDate;
    private String transferDate;
    private String status;
    private String errorCode;
    private String errorMessage;
}
