package service;

import fr.laposte.blg.blinks.u18.service.*;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.SchedulerParamsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.Instant;
import java.util.concurrent.ScheduledFuture;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class SchedulerServiceTest {

    @Mock
    private TaskScheduler taskScheduler;

    @Mock
    private SchedulerParamsRepository schedulerParamsRepository;

    @Mock
    private ScheduledFuture<?> scheduledFuture;
    private SchedulerService schedulerService;
    private SchedulerParamsEntity schedulerParams;
    @Mock
    private MessagePurgeService messagePurgeService;
    @Mock
    private FilePurgeService filePurgeService;
    @Mock
    private FileWriterService fileWriterService;
    @Mock
    private TransferService transferService;

    @BeforeEach
    void setup() {
        when(schedulerParamsRepository.findAllByIsEnabledAndModule(anyBoolean(), anyString())).thenReturn(Flux.empty());
        lenient().doReturn(scheduledFuture)
                .when(taskScheduler)
                .schedule(any(Runnable.class), any(CronTrigger.class));

        schedulerParams = new SchedulerParamsEntity();
        schedulerParams.setId(1L);
        schedulerParams.setSchedulerName("scheduler_transfer");
        schedulerParams.setCronExpression("0 * * * * *");
        schedulerParams.setExportPath("/export");
        schedulerParams.setCftPath("/cft");
        schedulerParams.setArchivePath("/archive");
        schedulerParams.setModule("u18");
        schedulerParams.setIsEnabled(true);

        schedulerService = new SchedulerService(taskScheduler, schedulerParamsRepository, messagePurgeService, filePurgeService, fileWriterService,transferService);
    }

    @Test
    void testUpdateSchedulerParams() {
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParams));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(schedulerParamsRepository).save(any(SchedulerParamsEntity.class));

        SchedulerParamsEntity updatedParams = new SchedulerParamsEntity();
        updatedParams.setCronExpression("0 0 * * * *");
        updatedParams.setExportPath("/newExport");
        updatedParams.setCftPath("/newCft");
        updatedParams.setArchivePath("/newArchive");
        updatedParams.setIsEnabled(true);
        updatedParams.setSchedulerName("scheduler_transfer");

        Mono<SchedulerParamsEntity> updateMono = schedulerService.updateTask(1L, updatedParams);
        StepVerifier.create(updateMono)
                .assertNext(updatedEntity -> {
                    assertEquals("0 0 * * * *", updatedEntity.getCronExpression());
                    assertEquals("/newExport", updatedEntity.getExportPath());
                    assertEquals("u18", updatedEntity.getModule());
                    verify(taskScheduler).schedule(any(Runnable.class), any(CronTrigger.class));
                })
                .verifyComplete();

        Mono<SchedulerParamsEntity> disableMono = schedulerService.cancelTask(1L);
        StepVerifier.create(disableMono)
                .assertNext(disabledEntity -> {
                    assertFalse(disabledEntity.getIsEnabled());
                    verify(scheduledFuture).cancel(false);
                })
                .verifyComplete();

        schedulerParams.setIsEnabled(false);
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParams));
        Mono<SchedulerParamsEntity> enableMono = schedulerService.enableTask(1L);
        StepVerifier.create(enableMono)
                .assertNext(enabledEntity -> {
                    assertTrue(enabledEntity.getIsEnabled());
                    verify(taskScheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
                })
                .verifyComplete();
    }

    @Test
    void testRunOnceFailBecauseWeProvidedBadModule() {
        SchedulerParamsEntity schedulerParamsFake = new SchedulerParamsEntity();
        schedulerParamsFake.setId(1L);
        schedulerParamsFake.setSchedulerName("scheduler_transfer");
        schedulerParamsFake.setCronExpression("0 * * * * *");
        schedulerParamsFake.setExportPath("/export");
        schedulerParamsFake.setCftPath("/cft");
        schedulerParamsFake.setArchivePath("/archive");
        schedulerParamsFake.setModule("u17");
        schedulerParamsFake.setIsEnabled(true);
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParamsFake));

        Mono<Void> runOnceMono = schedulerService.runOnce(1L);
        StepVerifier.create(runOnceMono)
                .verifyComplete();

    }

    @Test
    void testRunOnceSuccess() {
        when(schedulerParamsRepository.findById(1L)).thenReturn(Mono.just(schedulerParams));
        doReturn(scheduledFuture)
                .when(taskScheduler)
                .schedule(any(Runnable.class), any(Instant.class));

        Mono<Void> runOnceMono = schedulerService.runOnce(1L);
        StepVerifier.create(runOnceMono)
                .verifyComplete();

        verify(taskScheduler, times(1)).schedule(any(Runnable.class), any(Instant.class));
    }

    @Test
    void testRunOnceNotFound() {
        when(schedulerParamsRepository.findById(2L)).thenReturn(Mono.empty());

        Mono<Void> runOnceMono = schedulerService.runOnce(2L);
        StepVerifier.create(runOnceMono)
                .verifyComplete();

        verify(taskScheduler, never()).schedule(any(Runnable.class), any(Instant.class));
    }


}
