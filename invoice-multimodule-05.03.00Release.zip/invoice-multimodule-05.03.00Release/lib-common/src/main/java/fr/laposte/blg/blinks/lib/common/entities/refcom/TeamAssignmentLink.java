package fr.laposte.blg.blinks.lib.common.entities.refcom;

import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Table("refcom_team_assignment_link")
@Data
@Accessors(chain = true)
public class TeamAssignmentLink implements Disposable, Persistable<Long> {
    @Id
    @Column("business_team_link_position_id")
    private Long businessTeamLinkPositionId;
    @Column("business_position_id")
    private Long businessPositionId;
    @Column("business_team_id")
    private int businessTeamId;
    @Column("business_team_link_position_start_date")
    private Instant businessTeamLinkPositionStartDate;
    @Column("business_team_link_position_end_date")
    private Instant businessTeamLinkPositionEndDate;
    @Column("business_position_is_manager")
    private Boolean businessPositionIsManager;
    @Transient
    private boolean isPersisted = false;

    @Override
    public boolean isActive() {
        return
                ObjectUtils.isNotEmpty(businessTeamLinkPositionStartDate) &&
                        businessTeamLinkPositionStartDate.isBefore(Instant.now())
                        && (
                        ObjectUtils.isEmpty(businessTeamLinkPositionEndDate)
                                || businessTeamLinkPositionEndDate.isAfter(Instant.now())
                );
    }

    /**
     * Returns the id of the entity.
     *
     * @return the id. Can be {@literal null}.
     */
    @Override
    public Long getId() {
        return businessTeamLinkPositionId;
    }


    /**
     * Returns if the {@code Persistable} is new or was persisted already.
     *
     * @return if {@literal true} the object is new.
     */
    @Override
    public boolean isNew() {
        return !isPersisted();
    }
}
