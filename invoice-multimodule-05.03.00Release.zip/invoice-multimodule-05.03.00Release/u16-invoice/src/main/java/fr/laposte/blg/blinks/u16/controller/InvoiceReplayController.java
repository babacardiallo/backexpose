package fr.laposte.blg.blinks.u16.controller;


import fr.laposte.blg.blinks.lib.common.dto.ReplayReportDto;
import fr.laposte.blg.blinks.u16.service.InvoiceReplayService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api-invoice/replay")
@OpenAPIDefinition(tags = {@Tag(name = "InvoiceReplayController")})
@ComponentScan
public class InvoiceReplayController {

    private final InvoiceReplayService invoiceReplayService;

    @PostMapping("/all")
    @Operation(
            summary = "Rejeu de toutes les factures rejetées",
            description = "Service de rejeu de factures")
    public Mono<ReplayReportDto> replayAllRejectedInvoices() {
        return invoiceReplayService.replayAllRejectedInvoices();
    }

    @PostMapping("/by-invoice-numbers")
    @Operation(
            summary = "Rejeu des factures rejetées",
            description = "Service de rejeu de factures")
    public Mono<ReplayReportDto> replayRejectedInvoicesByInvoiceNumbers(@RequestBody List<String> invoiceNumbers) {
        return invoiceReplayService.replayInvoices(invoiceNumbers);
    }

    @PostMapping("/purge")
    @Operation(
            summary = "Purge des factures rejetées",
            description = "Service de purge de factures")
    public Mono<String> purge() {
        return invoiceReplayService.purge();
    }
}
