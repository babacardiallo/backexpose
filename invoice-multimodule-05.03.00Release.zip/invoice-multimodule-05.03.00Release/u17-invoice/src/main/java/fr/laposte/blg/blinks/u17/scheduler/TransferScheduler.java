package fr.laposte.blg.blinks.u17.scheduler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.FileType;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.entities.TransferStatus;
import fr.laposte.blg.blinks.lib.common.repositories.ExportHistoryRepository;
import fr.laposte.blg.blinks.u17.dto.TransferKibanaCst;
import fr.laposte.blg.blinks.u17.dto.TransferKibanaDto;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.marker.Markers;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@Slf4j
@EnableScheduling
public class TransferScheduler implements Runnable {

    private static final String OPENSSL_ENCRYPTION_FAILED = "U170018";

    private final SchedulerParamsEntity schedulerParams;
    private final ExportHistoryRepository exportHistoryRepository;
    private final OpenSslEncryptor openSslEncryptor;

    private final String coeurfinanceEncryptionKeyPath;

    public TransferScheduler(SchedulerParamsEntity schedulerParams,
                             ExportHistoryRepository exportHistoryRepository,
                             String coeurfinanceEncryptionKeyPath) {
        this(schedulerParams, exportHistoryRepository, coeurfinanceEncryptionKeyPath, TransferScheduler::defaultOpenSslEncrypt);
    }

    public TransferScheduler(SchedulerParamsEntity schedulerParams,
                             ExportHistoryRepository exportHistoryRepository,
                             String coeurfinanceEncryptionKeyPath,
                             OpenSslEncryptor openSslEncryptor) {
        this.schedulerParams = schedulerParams;
        this.exportHistoryRepository = exportHistoryRepository;
        this.coeurfinanceEncryptionKeyPath = coeurfinanceEncryptionKeyPath;
        this.openSslEncryptor = openSslEncryptor;
    }

    @Override
    public void run() {
        log.info("Starting TransferScheduler job for scheduler: {}", schedulerParams.getSchedulerName());

        List<TransferStatus> statuses = Arrays.asList(TransferStatus.NEW, TransferStatus.FAILED);
        Collection<FileType> fileTypes = Arrays.asList(FileType.COEURFINANCE, FileType.DOCAPOSTE, FileType.INFOCA, FileType.DOCAPOSTE_AVIS_PAIEMENT);

        exportHistoryRepository
                .findTopByTransferStatusInAndFileTypeInOrderByDateAsc(statuses, fileTypes)
                .subscribe(this::processExportHistory,
                        error -> log.error("Error fetching export history record", error));
    }

    private Path createArchivePath(Path baseArchivePath, FileType fileType) {
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
        String year = now.format(DateTimeFormatter.ofPattern("yyyy"));
        String month = now.format(DateTimeFormatter.ofPattern("MM"));

        String flowName = fileType.name();

        return baseArchivePath.resolve(flowName).resolve(year).resolve(month);
    }

    private boolean ensureArchiveDirectoryExists(Path organizedArchivePath, ExportHistoryEntity exportHistoryEntity) {
        if (!Files.exists(organizedArchivePath)) {
            try {
                Files.createDirectories(organizedArchivePath);
                log.info("Created organized archive directory: {}", organizedArchivePath);
            } catch (IOException e) {
                String errMsg = "Failed to create organized archive directory: " + organizedArchivePath;
                log.error(errMsg, e);
                updateFailure(exportHistoryEntity, errMsg, "U170016");
                return false;
            }
        }
        return true;
    }

    private void processExportHistory(ExportHistoryEntity exportHistoryEntity) {
        try {
            String targetFileName;
            switch (exportHistoryEntity.getFileType()) {
                case DOCAPOSTE -> targetFileName = "blg3aaaa.ws";
                case COEURFINANCE -> targetFileName = "blg1aaaa.a3p";
                case INFOCA -> targetFileName = "blg2aaaa.is";
                case DOCAPOSTE_AVIS_PAIEMENT -> targetFileName = "blg3aaaa.ws";
                default -> {
                    String errMsg = "Unsupported file type:" + exportHistoryEntity.getFileType();
                    log.error(errMsg);
                    updateFailure(exportHistoryEntity, errMsg, "U170015");
                    return;
                }
            }

            Path exportPath = Paths.get(schedulerParams.getExportPath());
            Path cftPath = Paths.get(schedulerParams.getCftPath());
            Path baseArchivePath = Paths.get(schedulerParams.getArchivePath());

            Path organizedArchivePath = createArchivePath(baseArchivePath, exportHistoryEntity.getFileType());

            String originalFileName = exportHistoryEntity.getFileName();
            Path sourceFile = exportPath.resolve(originalFileName);
            Path targetFile = cftPath.resolve(targetFileName);

            if (!Files.exists(sourceFile)) {
                String errMsg = "Source file not found in export path: " + sourceFile;
                log.error(errMsg);
                updateFailure(exportHistoryEntity, errMsg, "U170012");
                return;
            }

            if (Files.exists(targetFile)) {
                String errMsg = "Target file already exists in CFT path: " + targetFile;
                log.error(errMsg);
                updateFailure(exportHistoryEntity, errMsg, "U170013");
                return;
            }

            if (!ensureArchiveDirectoryExists(organizedArchivePath, exportHistoryEntity)) {
                return;
            }

            Path archiveFile = organizedArchivePath.resolve(originalFileName);
            Files.copy(sourceFile, archiveFile, StandardCopyOption.REPLACE_EXISTING);
            log.info("Copied file {} to organized archive: {}", sourceFile, archiveFile);

            if (exportHistoryEntity.getFileType().equals(FileType.INFOCA)) {
                String etzFileName = originalFileName.replaceAll(".is", ".etz");
                String etzTargetFileName = targetFileName.replaceAll(".is", ".etz");
                Path etzSourceFile = exportPath.resolve(etzFileName);
                Path etzArchiveFile = organizedArchivePath.resolve(etzFileName);
                Path etzTargetFile = cftPath.resolve(etzTargetFileName);

                if (Files.exists(etzTargetFile)) {
                    String errMsg = "etz target file already exists in CFT path: " + etzTargetFile;
                    log.error(errMsg);
                    updateFailure(exportHistoryEntity, errMsg, "U170013");
                    return;
                }
                Files.copy(sourceFile, etzSourceFile, StandardCopyOption.REPLACE_EXISTING);
                log.info("InfoCA source file {} is cloned to etz file: {}", sourceFile, etzSourceFile);

                Files.copy(etzSourceFile, etzArchiveFile, StandardCopyOption.REPLACE_EXISTING);
                log.info("Copied etz file {} to organized archive: {}", etzSourceFile, etzArchiveFile);

                Files.move(etzSourceFile, etzTargetFile);
                log.info("Moved etz file {} to CFT path with new name: {}", etzSourceFile, etzTargetFile);
            }

            if (exportHistoryEntity.getFileType().equals(FileType.COEURFINANCE)) {
                String keyPath = resolveEncryptionKeyPath();

                Path encryptedTempFile = exportPath.resolve(originalFileName + ".enc");

                log.info("Encryption starting on file '{}'", originalFileName);
                Instant encryptionStart = Instant.now();

                int exitCode;
                try {
                    exitCode = openSslEncryptor.encrypt(sourceFile, encryptedTempFile, keyPath);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    safeDeleteIfExists(encryptedTempFile);
                    String errMsg = "Encryption interrupted for file: " + sourceFile;
                    log.warn(errMsg, ie);
                    updateFailure(exportHistoryEntity, errMsg, "U170019");
                    return;
                }

                Duration elapsed = Duration.between(encryptionStart, Instant.now());
                log.info("Encryption finished for file '{}' - took {} ms", originalFileName, elapsed.toMillis());

                if (exitCode != 0) {
                    safeDeleteIfExists(encryptedTempFile);
                    String errMsg = "OpenSSL encryption failed (exitCode=" + exitCode + ") for file: " + sourceFile;
                    log.error(errMsg);
                    updateFailure(exportHistoryEntity, errMsg, OPENSSL_ENCRYPTION_FAILED);
                    return;
                }

                Files.move(encryptedTempFile, targetFile);
                log.info("Moved encrypted file {} to CFT path with new name: {}", encryptedTempFile, targetFile);

                safeDeleteIfExists(sourceFile);
            } else {
                Files.move(sourceFile, targetFile);
                log.info("Moved file {} to CFT path with new name: {}", sourceFile, targetFile);
            }

            exportHistoryEntity.setTransferStatus(TransferStatus.TRANSFERED);
            exportHistoryEntity.setFileSendDate(ZonedDateTime.now(ZoneId.of("Europe/Paris")).toInstant());
            exportHistoryEntity.setTransferErrorCode(null);
            exportHistoryEntity.setTransferErrorMessage(null);
            exportHistoryRepository.save(exportHistoryEntity)
                    .subscribe(saved -> log.info("Updated export history as SUCCESS: {}", saved),
                            error -> log.error("Error updating export history", error));
        } catch (IOException e) {
            String errMsg = "IOException during file processing: " + e.getMessage();
            log.error(errMsg, e);
            updateFailure(exportHistoryEntity, errMsg, "U170014");
        } catch (Exception e) {
            String errMsg = "Unhandled error during transfer" + e.getMessage();
            log.error(errMsg, e);
            updateFailure(exportHistoryEntity, errMsg, "U179999");
        }
        this.logTransferKibana(exportHistoryEntity);

    }

    private String resolveEncryptionKeyPath() {
        if (coeurfinanceEncryptionKeyPath == null || coeurfinanceEncryptionKeyPath.isBlank()) {
            throw new IllegalStateException("Missing property fr.laposte.coeurfinance.encryption.keypath (COEURFINANCE_ENCRYPTION_KEY_PATH)");
        }
        return coeurfinanceEncryptionKeyPath.trim();
    }

    private static int defaultOpenSslEncrypt(Path inputFile, Path outputFile, String keyPath) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(
                "openssl",
                "cms",
                "-encrypt",
                "-aes-256-cbc",
                "-in",
                inputFile.toAbsolutePath().toString(),
                "-stream",
                "-binary",
                "-outform",
                "DER",
                "-out",
                outputFile.toAbsolutePath().toString(),
                "-recip",
                keyPath
        );

        pb.redirectErrorStream(true);
        Process process = pb.start();

        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append(System.lineSeparator());
            }
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            log.error("OpenSSL returned non-zero exit code: {}. Output: {}", exitCode, output);
        }
        return exitCode;
    }

    private void safeDeleteIfExists(Path path) {
        if (path == null) {
            return;
        }
        try {
            Files.deleteIfExists(path);
        } catch (Exception e) {
            log.warn("Failed to delete file: {}", path, e);
        }
    }

    private void updateFailure(ExportHistoryEntity entity, String errorMessage, String errorCode) {
        entity.setTransferStatus(TransferStatus.FAILED);
        entity.setTransferErrorMessage(errorMessage);
        entity.setTransferErrorCode(errorCode);
        exportHistoryRepository.save(entity)
                .subscribe(saved -> log.info("Updated export history with failure: {}", saved),
                        error -> log.error("Error updating export history", error));
        this.logTransferKibana(entity);
    }

    private void logTransferKibana(ExportHistoryEntity exportHistoryEntity) {
        if (exportHistoryEntity != null) {
            var transferKibana = new TransferKibanaDto();
            transferKibana.setExportId(exportHistoryEntity.getIdExport());
            transferKibana.setFileType(exportHistoryEntity.getFileType());
            transferKibana.setTransferDate(exportHistoryEntity.getFileSendDate());
            transferKibana.setTransferStatus(exportHistoryEntity.getTransferStatus());
            transferKibana.setTransferErrorCode(exportHistoryEntity.getTransferErrorCode());
            transferKibana.setTransferErrorMessage(exportHistoryEntity.getTransferErrorMessage());
            transferKibana.setFileName(exportHistoryEntity.getFileName());
            transferKibana.setFileDate(exportHistoryEntity.getDate());
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            JsonNode node = objectMapper.convertValue(transferKibana, JsonNode.class);
            log.info(Markers.append(TransferKibanaCst.TRANSFERKEYS, node), "File transfer for {} {}: {}", transferKibana.getFileType(), transferKibana.getTransferStatus(), node);
        }
    }
}
