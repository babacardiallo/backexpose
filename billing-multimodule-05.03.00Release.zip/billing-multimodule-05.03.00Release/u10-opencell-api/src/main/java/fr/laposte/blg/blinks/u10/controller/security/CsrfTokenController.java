package fr.laposte.blg.blinks.u10.controller.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class CsrfTokenController {

    @GetMapping("/csrf/token")
    public String csrfToken(HttpServletRequest request) {
        HttpSession session = request.getSession(true);

        CsrfToken token = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
        log.info("token ID: {}", token.getToken());
        if (session != null) {
            log.info("session ID: {}", session.getId());
        }
        return token.getToken();
    }
}
