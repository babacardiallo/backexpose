package fr.laposte.blg.blinks.u17.controller;


import fr.laposte.blg.blinks.u17.service.SourceOrganizationService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.concurrent.atomic.AtomicBoolean;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/batch")
@OpenAPIDefinition(tags = {@Tag(name = "BatchController")})
public class BatchController {

    private final SourceOrganizationService sourceOrganizationService;

    private AtomicBoolean isRunning = new AtomicBoolean(false);


    @PostMapping("/update-profit-center")
    @Operation(
            summary = "Met à jour les centres de profit",
            description = "Permet de mettre à jour les centres de profit")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<String> updateProfitCenter(
            @RequestParam(defaultValue = "0") int choppedSize,
            @RequestParam(required = false) String referencedDate,
            @RequestParam(defaultValue = "forAll") String preference
    ) {
        if (preference.equals("forEmpty")) {
            if (!isRunning.get()) {
                isRunning.set(true);
                Mono.fromRunnable(() -> sourceOrganizationService.fetchAndUpdateEntityCodeForNullProfitCenter(choppedSize))
                        .subscribeOn(Schedulers.boundedElastic())
                        .doOnTerminate(() -> isRunning.set(false))
                        .subscribe();
                return ResponseEntity.accepted().body("Début du batch de mise à jour les centres de profit");
            } else {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("Un batch est déjà en cours");
            }
        }
        if (preference.equals("forOld")) {
            if (!isRunning.get()) {
                isRunning.set(true);
                Mono.fromRunnable(() -> sourceOrganizationService.fetchAndUpdateEntityCodeByDate(referencedDate, choppedSize))
                        .subscribeOn(Schedulers.boundedElastic())
                        .doOnTerminate(() -> isRunning.set(false))
                        .subscribe();
                return ResponseEntity.accepted().body("Début du batch de mise à jour les centres de profit");
            } else {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("Un batch est déjà en cours");
            }
        }
        if (preference.equals("forAll")) {
            if (!isRunning.get()) {
                isRunning.set(true);
                Mono.fromRunnable(() -> sourceOrganizationService.fetchAndUpdateEntityCode(choppedSize))
                        .subscribeOn(Schedulers.boundedElastic())
                        .doOnTerminate(() -> isRunning.set(false))
                        .subscribe();
                return ResponseEntity.accepted().body("Début du batch de mise à jour les centres de profit");
            } else {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("Un batch est déjà en cours");
            }
        }
        return null;
    }

}
