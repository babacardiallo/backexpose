package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.QueueSynchronizationSupervisionEntity;
import fr.laposte.blg.blinks.lib.common.entities.repositories.QueueSynchronizationSupervisionRepository;
import fr.laposte.blg.blinks.u14.controller.dto.QueueSupervisionDto;
import fr.laposte.bscc.billing.avro.ActionEnum;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;

@Service
@RequiredArgsConstructor
@Data
public class QueueRestService {

    private final QueueSynchronizationSupervisionRepository queueSynchronizationSupervisionRepository;

    public Mono<Page<QueueSupervisionDto>> getAllByCriteria(boolean create, boolean update, String filter, Pageable pageable){
        if(create && update){
            if(filter==null || filter.equals("")) {
                return queueSynchronizationSupervisionRepository.findAllBy(pageable)
                        .map(this::mapToQueueSupervisionDto)
                        .collectList()
                        .zipWith(queueSynchronizationSupervisionRepository.countAllBy())
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            } else {
                List<ActionEnum> actionEnums = List.of(ActionEnum.create, ActionEnum.update);
                filter ="%"+filter+"%";
                return queueSynchronizationSupervisionRepository.findAllByActionInAndContractNumberLikeOrActionInAndOpsCodeLikeOrActionInAndCustAccNumberLike(actionEnums, filter, actionEnums, filter, actionEnums, filter, pageable)
                        .map(this::mapToQueueSupervisionDto)
                        .collectList()
                        .zipWith(queueSynchronizationSupervisionRepository.countAllByActionInAndContractNumberLikeOrActionInAndOpsCodeLikeOrActionInAndCustAccNumberLike(actionEnums, filter,actionEnums, filter, actionEnums, filter))
                        .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
            }
        } else {
            if(!create && !update){
                return Mono.empty();
            } else {
                ActionEnum actionEnum;
                if(create){
                   actionEnum = ActionEnum.create;
                } else {
                   actionEnum = ActionEnum.update;
                }
                if(filter==null || filter.equals("")){
                    return queueSynchronizationSupervisionRepository.findAllByAction(actionEnum, pageable)
                            .map(this::mapToQueueSupervisionDto)
                            .collectList()
                            .zipWith(queueSynchronizationSupervisionRepository.countAllByAction(actionEnum))
                            .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
                } else {
                    filter ="%"+filter+"%";
                    return queueSynchronizationSupervisionRepository.findAllByActionEqualsAndContractNumberLikeOrActionEqualsAndOpsCodeLikeOrActionEqualsAndCustAccNumberLike(actionEnum, filter, actionEnum, filter, actionEnum, filter, pageable)
                            .map(this::mapToQueueSupervisionDto)
                            .collectList()
                            .zipWith(queueSynchronizationSupervisionRepository.countAllByActionEqualsAndContractNumberLikeOrActionEqualsAndOpsCodeLikeOrActionEqualsAndCustAccNumberLike(actionEnum, filter, actionEnum, filter, actionEnum, filter))
                            .map(p -> new PageImpl<>(p.getT1(), pageable, p.getT2()));
                }

            }
        }
    }

    public Mono<QueueSupervisionDto> getOne(Long id){
        return queueSynchronizationSupervisionRepository.findById(id).map(this::mapToQueueSupervisionDto);
    }

    private QueueSupervisionDto mapToQueueSupervisionDto(QueueSynchronizationSupervisionEntity queue) {
        return new QueueSupervisionDto(
                queue.getIdQueue(),
                queue.getIdContract(),
                queue.getIdLegalPerson(),
                queue.getDateSynchronizationExpected(),
                queue.getAction().toString(),
                queue.getRefcomReplay(),
                queue.getContractNumber(),
                queue.getOpsCode(),
                queue.getCustAccNumber()
        );
    }
}
