import {Injectable} from "@angular/core";
import {Observable, Subject} from "rxjs";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import {SupervisionTable} from "../models/supervision-table.model";
import {environment} from '../../../environments/environment';
import {takeUntil} from "rxjs/operators";
import { CalendarEvent } from "../models/calendar.event";

@Injectable({
  providedIn: 'root',
})
export class SupervisionService {

  ngUnsubscribe$ = new Subject<void>();

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    
  });

  constructor(private http: HttpClient) {
  }

  getHistories(date: string): Observable<SupervisionTable[]> {
    let queryParams = new HttpParams().append("date", date);
    return this.http.get<SupervisionTable[]>(environment.API_MORNING_CHECK, {headers: this.headers, params: queryParams})
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getMonthlyTreatment(year?: number, month?: number): Observable<CalendarEvent[]> {
    let api = environment.API_MORNING_CHECK_MONTH_TREATEMENT 
    if(year){
        api =  environment.API_MORNING_CHECK_MONTH_TREATEMENT + '?year=' + year + "&month="+month;
    }
    return this.http.get<CalendarEvent[]>(api, {headers: this.headers})
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getDailyListTreatment(date: string): Observable<any> {
    let queryParams = new HttpParams().append("date", date);
    return this.http.get<CalendarEvent[]>(environment.API_MORNING_CHECK_LIST_DIALY, {headers: this.headers, params: queryParams})
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getDailyFileTransfer(date: string): Observable<any> {
    let queryParams = new HttpParams().append("date", date);
    return this.http.get<CalendarEvent[]>(environment.API_MORNING_CHECK_FILE_TRANSFER, {headers: this.headers, params: queryParams})
      .pipe(takeUntil(this.ngUnsubscribe$));
  }
}
