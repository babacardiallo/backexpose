package fr.laposte.blg.blinks.u12.mapper.enumeration;

import lombok.AllArgsConstructor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
public enum ScheduleEnum {

    ECH_FAC_10("10", "Annuel"),
    ECH_FAC_20("20", "Trimestriel"),
    ECH_FAC_30("30", "Semestriel"),
    ECH_FAC_40("40", "Mensuel");

    private static final Map<String, String> BY_LABEL = new HashMap<>();

    static {
        Arrays.stream(values()).forEach(e -> BY_LABEL.put(e.label, e.code));
    }

    private String code;
    private String label;

    public static String getCode(String label) {
        return BY_LABEL.get(label);
    }
}
