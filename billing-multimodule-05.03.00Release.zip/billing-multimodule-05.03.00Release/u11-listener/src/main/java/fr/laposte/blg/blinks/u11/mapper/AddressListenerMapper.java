package fr.laposte.blg.blinks.u11.mapper;

import MD.LatestValue.Address;
import fr.laposte.blg.blinks.lib.common.entities.AddressEntity;
import fr.laposte.blg.blinks.lib.common.entities.AddressType;
import fr.laposte.blg.blinks.u11.listener.address.exception.AddressListenerException;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Mapper
@DecoratedWith(AddressListenerDecorator.class)
public interface AddressListenerMapper {

    @Mapping(source = "refpmAdressId", target = "addressIdRefPM")
    @Mapping(target = "idLegalPerson", ignore = true)
    @Mapping(source = "custAccNumber", target = "custAccNumber")
    @Mapping(source = "addressType", target = "addressType")
    @Mapping(source = "name1", target = "name1")
    @Mapping(source = "add2", target = "add2")
    @Mapping(source = "add3", target = "add3")
    @Mapping(source = "add4", target = "add4")
    @Mapping(source = "add5", target = "add5")
    @Mapping(source = "add6", target = "add6")
    @Mapping(source = "add7", target = "add7")
    @Mapping(source = "CDateTime", target = "creationDatetime")
    @Mapping(source = "MDateTime", target = "modificationDatetime")
    @Mapping(target = "addressJson", ignore = true)
    @Mapping(target = "idAddress", ignore = true)
    @Mapping(target = "legalPersonEntity", ignore = true)
    AddressEntity addressToAddressEntity(Address address);


    default AddressType addressTypeMapper(CharSequence type) {
        /**
         * Référence : Contrat d'interface - CLIENTS ET INTERLOCUTEURS - REFPM
         * ADR_CLI_05	Pour la diffusion SUEZ, Le champ type_adresse peut contenir: P (prestations) ou F (Facturation)
         */
        return switch (type.toString()) {
            case "F" -> AddressType.FACTURATION;
            case "P" -> AddressType.PRESTATION;
            default -> throw new AddressListenerException("addressType from topic message is not correct");
        };
    }

    default String toString(CharSequence charSequence) {
        return (charSequence != null) ? charSequence.toString() : null;
    }

    default Instant asInstant(String date) {
        return date != null && !date.isBlank() ? LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant() : null;
    }
}
