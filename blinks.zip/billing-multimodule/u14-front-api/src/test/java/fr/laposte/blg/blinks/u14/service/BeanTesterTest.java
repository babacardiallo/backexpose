package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.u14.controller.dto.OfferSupervisionDto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.meanbean.lang.Factory;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;

@ExtendWith(MockitoExtension.class)
class BeanTesterTest {


    @Test
    @DisplayName("Tests all DTO")
    void testDTOs(){
        org.meanbean.test.BeanTester beanTester = new org.meanbean.test.BeanTester();
        beanTester.getFactoryCollection().addFactory(Instant.class, new InstantFactory());
        beanTester.testBean(OfferSupervisionDto.class);
    }

    static class InstantFactory implements Factory<Instant>{

        @Override
        public Instant create() {
            return Instant.now();
        }
    }
}
