ALTER TABLE invoice
ADD docaposte_export_status VARCHAR(32) default 'NEW',
ADD infoca_export_status VARCHAR(32) default 'NEW',
ADD equinox_export_status VARCHAR(32) default 'NEW',
ADD docaposte_error_message TEXT default NULL,
ADD docaposte_error_code VARCHAR(32) default NULL,
ADD infoca_error_message TEXT default NULL,
ADD infoca_error_code VARCHAR(32) default NULL,
ADD equinox_error_message TEXT default NULL,
ADD equinox_error_code VARCHAR(32) default NULL;
