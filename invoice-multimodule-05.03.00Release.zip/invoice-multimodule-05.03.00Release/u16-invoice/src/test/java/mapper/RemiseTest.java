import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import fr.laposte.blg.blinks.lib.common.entities.InvoiceEntity;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceMessageRepository;
import fr.laposte.blg.blinks.u16.mapper.InvoiceAvroToDtoMapper;
import fr.laposte.blg.blinks.u16.service.InvoiceService;
import fr.laposte.bscc.avro.invoicing.Invoice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class RemiseTest {
    Invoice invoiceFromMessage;
    InvoiceEntity data = new InvoiceEntity();
    @InjectMocks
    InvoiceService serviceUnderTest;

    File src;

    @Mock
    private InvoiceAvroToDtoMapper invoiceAvroToDtoMapper;

    @Mock
    private InvoiceMessageRepository invoiceMessageRepository;


    @BeforeEach
    void init() throws IOException {
        src = new File("src/test/resources/invoice_remise_v9_test.json");
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
        invoiceFromMessage = mapper.readValue(src, Invoice.class);

    }

    @Test
    void whenReceiveRemiseMessage_shouldMapEntity() {
        data = serviceUnderTest.invoiceToInvoiceEntity(invoiceFromMessage).getT1();
        assertEquals(invoiceFromMessage.getInvoiceHeader().getInvoiceNumber(), data.getInvoiceNumber());
        assertEquals(invoiceFromMessage.getInvoiceHeader().getInvoiceNumber().toString(), data.getReference());
        assertEquals(invoiceFromMessage.getHeader().getBillrunCode(), data.getBillrunId());
        assertEquals(LocalDateTime.parse(invoiceFromMessage.getInvoiceHeader().getBillingDate().getCalculationDate(), DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.of("Europe/Paris")).toInstant(), data.getBillrunDate());
        assertNotNull(data.getCreated());
        assertNotNull(data.getUpdated());
        assertEquals(Integer.parseInt(invoiceFromMessage.getBillingAccount().getCustAccNumber().toString()), data.getClient());
    }
}

