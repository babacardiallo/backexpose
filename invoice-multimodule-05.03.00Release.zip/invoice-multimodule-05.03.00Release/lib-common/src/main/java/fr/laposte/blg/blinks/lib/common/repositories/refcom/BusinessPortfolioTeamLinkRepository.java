package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessPortfolioTeamLink;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessPortfolioTeamLinkRepository extends ReactiveCrudRepository<BusinessPortfolioTeamLink, Long> {

    Mono<BusinessPortfolioTeamLink> findByBusinessPortfolioLinkTeamId(Long businessPortfolioTeamLinkId);

    @Query("SELECT l.* from refcom_business_portfolio_team_link l WHERE business_portfolio_id = :businessPortfolioId AND business_portfolio_link_type_id = 1 AND business_portfolio_link_team_start_date <= NOW() AND (business_portfolio_link_team_end_date IS NULL OR business_portfolio_link_team_end_date > NOW())")
    Mono<BusinessPortfolioTeamLink> findAvailableActiveLinkForOnePortfolio(Long businessPortfolioId);

}
