package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class ContractVersionSupervisionDto {
    private String contractNumber;
    private Integer amendmentNumber;
    private Integer revisionNumber;
    private String subType;
    private boolean isSynchronized;
    private Instant synchronisationDate;
    private Instant fistDateError;
    private String opsCode;
    }
