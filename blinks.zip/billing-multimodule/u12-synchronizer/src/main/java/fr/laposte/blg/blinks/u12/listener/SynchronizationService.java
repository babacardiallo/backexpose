package fr.laposte.blg.blinks.u12.listener;

import fr.laposte.blg.blinks.lib.common.service.ContractService;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u12.listener.exception.SynchronizationException;
import fr.laposte.blg.blinks.u12.service.contract.ContractSyncService;
import fr.laposte.blg.blinks.u12.service.customer.CustomerSyncService;
import fr.laposte.bscc.billing.avro.Synchronization;
import fr.laposte.bscc.billing.avro.billing.ContractConsolidated;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Data
@Slf4j
@RequiredArgsConstructor
public class SynchronizationService {

    private final ContractSyncService contractSynchronizationService;

    private final CustomerSyncService customerSyncService;

    private final ContractService contractService;

    private final LegalPersonService legalPersonService;

    public Flux<ContractConsolidated> readSynchronizationCommand(Synchronization value) {

        var entityType = value.getType();
        var action = value.getAction();
        var internalId = value.getInternalId();
        var refcomReplay = value.getRefcomReplay();

        return switch (entityType) {
            case contract -> contractSynchronizationService.synchronize(internalId, action);
            case customer -> customerSyncService.synchronize(internalId, refcomReplay).flux();
            default -> Flux.error(new SynchronizationException("Entity type to synchronize unknown : " + entityType));
        };
    }

    public Mono<ContractConsolidated> markSynchronized(ContractConsolidated contractConsolidated, RecordMetadata recordMetadata) {
        return Mono.justOrEmpty(contractConsolidated.getContractOpencell())
                .flatMap(contractOpencell -> this.contractService.markVersionSynchronized(contractOpencell, recordMetadata))
                .then(Mono.justOrEmpty(contractConsolidated.getCustomerOpencell())
                        .flatMap(customerOpencell -> this.legalPersonService.markLegalPersonSynchronized(customerOpencell.getCustomerInformation().getCustAccNumber().toString()))
                        .thenReturn(contractConsolidated));
    }

    public String getMessageKey(ContractConsolidated contractConsolidated) {
            return contractConsolidated.getCustomerOpencell().getCustomerInformation().getCustAccNumber().toString();
    }

}
