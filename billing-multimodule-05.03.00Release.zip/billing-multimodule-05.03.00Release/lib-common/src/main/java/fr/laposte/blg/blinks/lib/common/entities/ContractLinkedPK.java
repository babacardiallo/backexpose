package fr.laposte.blg.blinks.lib.common.entities;

import lombok.Data;
import org.springframework.data.relational.core.mapping.Column;

import java.io.Serializable;
import java.util.Objects;

@Data
public class ContractLinkedPK implements Serializable {
    @Column("id_contract")
    private Long idContract;
    @Column("linked_contract_number")
    private String linkedContractNumber;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContractLinkedPK that = (ContractLinkedPK) o;
        return Objects.equals(idContract, that.idContract) &&
                Objects.equals(linkedContractNumber, that.linkedContractNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idContract, linkedContractNumber);
    }
}
