CREATE TABLE legal_person_message (
    id_legal_person_message INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_legal_person INT UNSIGNED default null,
    legal_person_json JSON,
    CONSTRAINT fk_legal_person_message_legal_person FOREIGN KEY (id_legal_person) REFERENCES blg_contract_importer.legal_person (id_legal_person) ON DELETE CASCADE ON UPDATE RESTRICT
);