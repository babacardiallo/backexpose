import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CalendarView } from 'angular-calendar';
import { CalendarRequest } from '../../models/calendar-request';
import { CalendarRequestDirection } from '../../models/calendar-request-direction.enum';

@Component({
  selector: 'calendar-action',
  templateUrl: './calendar-action.component.html',
  styleUrl: './calendar-action.component.scss',
  standalone: false
})
export class CalendarActionComponent implements OnInit {

  @Input() selected!: Date;
  @Input() view!: CalendarView;
  @Input() displayMonthMode!: boolean;
  @Output() onMonthChange = new EventEmitter<CalendarRequest>();
  @Output() only = new EventEmitter<CalendarRequest>();
  displayMonth: string = '';

  constructor() {}

  
  ngOnInit(): void {
  }

  nextMonth() {  
    this.onMonthChange.emit({date: this.selected, direction: CalendarRequestDirection.NEXT});
  }

  previousMonth() {
    this.onMonthChange.emit({date: this.selected, direction: CalendarRequestDirection.PREVIOUS});
  }

  currentMonth() {
    this.onMonthChange.emit({date: this.selected, direction: CalendarRequestDirection.CURRENT});
  }

  onSelectedDateChange() {
    this.onMonthChange.emit({date: this.selected, direction: CalendarRequestDirection.OTHER_DIRECTION});
  }

  getDisplayedMonth(): string{
    if(this.displayMonthMode){
      return "Mois en cours";
    } else {
      return  "Aujourd'hui";
    }
  }

  selectMonth(event: Date, datepicker: any) {
    this.selected = event;
    datepicker.close();
    this.onMonthChange.emit({date: this.selected, direction: CalendarRequestDirection.OTHER_DIRECTION});
    
  }


}
