import {Injectable } from '@angular/core';

@Injectable()
export class Constants {
    public readonly API_ENDPOINT_OFFERS_SUPERVISION = 'http://localhost:8084/api/offer/list-offer-supervision';
}