import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { environment } from '../../../environments/environment';


@Injectable({
  providedIn: 'root',
})
export class EdrService {
  ngUnsubscribe$ = new Subject<void>();

  public busService: Observable<boolean>;

  private _busService: Subject<boolean> = new Subject();


  private criteria: string = '';


  private projection: string = '&projection=withId';

  constructor(private http: HttpClient) {
    this.busService = this._busService.asObservable();
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      
    }),
  }


  headers = new HttpHeaders({
    'Accept': 'text/plain, */*',
    'Content-Type': 'application/json',
    'Authorization': 'Basic ' + btoa('opencell.admin:opencell.admin')
  });

  getListEdrs(page: number, size: number, sort: string, order: string): Observable<any> {
    return this.http.get<any>(environment.API_EDR_ALL + "&page=" + page + "&size=" + size + "&sort=" + sort + "," + order, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getListEdrsByDate(page: number, size: number, sort: string, order: string, startDate: any, endDate: any, filter: string, status: string, errorsCode: []): Observable<any> {
    this.criteria = '';
    let url = environment.API_EDR_ALL_BY_DATE + "&page=" + page + "&size=" + size + "&sort=" + sort + "," + order + "&startDate=" + startDate + "&endDate=" + endDate;
    this.criteria = "?startDate=" + startDate + "&endDate=" + endDate;
    if (filter != '') {
      url = url + "&filter=" + filter
    }
    if (status != '') {
      url = url + "&status=" + status
    }
    if (errorsCode.length > 0) {
      errorsCode.forEach(err => {
        url = url + "&errors=" + err;
      })
    }
    return this.http.get<any>(url, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }

  getEdrDetails(id: string): Observable<any> {
    let url = environment.API_EDR_ONE_BY_ID + "?id=" + id;
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  updateEdrPending(id: string): Observable<any> {
    let url = environment.API_EDR_ONE_UPDATE_PENDING + "?id=" + id;
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  postReplayPendings(): Observable<any> {
    return this.http.post<void>(environment.API_POST_REPLAY_EDR, null, { headers: this.headers, responseType: 'text' as 'json' }).pipe(takeUntil(this.ngUnsubscribe$));
  }

  getAllCodeError(): Observable<any> {
    return this.http.get<any>(environment.API_GET_ALL_CODE_ERROR, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  updateEdrFilteredPending(): Observable<any> {
    let url = environment.API_EDR_FILTER_UPDATE_PENDING + this.criteria;
    return this.http.post<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  updateEdrSelectedPending(ids: any[]): Observable<any> {
    let url = environment.API_EDR_SELECTED_UPDATE_PENDING;
    ids.forEach((id, index) => {
      if (index == 0) {
        url = url + "?ids=" + id;
      } else {
        url = url + "&ids=" + id;
      }
    })
    return this.http.get<any>(url, this.httpOptions).pipe(takeUntil(this.ngUnsubscribe$));
  }

  emitLoadEdr() {
    this._busService.next(true);
  }


  getExportedEdr(): Observable<any> {
    let url = environment.API_EDR_EXPORTED + this.criteria;
    return this.http.get<any>(url, this.httpOptions)
      // unsubscribe à l'appel de ngUnsubscribe
      .pipe(takeUntil(this.ngUnsubscribe$));
  }


}
