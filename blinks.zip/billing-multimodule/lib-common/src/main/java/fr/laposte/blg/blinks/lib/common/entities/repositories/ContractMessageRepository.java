package fr.laposte.blg.blinks.lib.common.entities.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ContractMessage;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;


@Repository
public interface ContractMessageRepository extends ReactiveCrudRepository<ContractMessage, Long> {

    @Query("SELECT contract_information from contract_message where id_contract = :id")
    Mono<String> getContractMessage(long id);

    Mono<ContractMessage> findByIdContract(long id);
}
