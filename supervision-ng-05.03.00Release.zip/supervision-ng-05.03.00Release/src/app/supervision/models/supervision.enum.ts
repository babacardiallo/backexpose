export enum Treatment {
  SUCCESS = "SUCCESS",
  WARNING = "WARNING",
  FAILED = "FAILED"
}
