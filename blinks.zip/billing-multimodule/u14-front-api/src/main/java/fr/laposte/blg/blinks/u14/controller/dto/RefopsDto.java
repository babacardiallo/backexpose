package fr.laposte.blg.blinks.u14.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class RefopsDto {
    private String opsCode;
    private String opsLabel;
    private Instant offerActivationDatetime;
}