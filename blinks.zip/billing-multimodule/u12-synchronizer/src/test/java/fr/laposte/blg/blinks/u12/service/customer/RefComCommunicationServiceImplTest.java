package fr.laposte.blg.blinks.u12.service.customer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import reactor.test.StepVerifier;

import java.time.LocalDate;
import java.util.Objects;


@SpringBootTest
@ActiveProfiles("test")
class RefComCommunicationServiceImplTest {

    @Autowired
    RefComCommunicationService refComCommunicationService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void fetchTeamCodeAndName() {

        StepVerifier.create(refComCommunicationService.fetchTeamCodeAndName(27, LocalDate.now()))
                .expectNextMatches(Objects::nonNull)
                .verifyComplete();

    }
}
