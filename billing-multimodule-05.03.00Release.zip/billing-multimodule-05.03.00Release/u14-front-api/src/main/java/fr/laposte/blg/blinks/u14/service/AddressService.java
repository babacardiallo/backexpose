package fr.laposte.blg.blinks.u14.service;

import fr.laposte.blg.blinks.lib.common.entities.repositories.AddressRepository;
import fr.laposte.blg.blinks.u14.controller.dto.AddressDTO;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
public class AddressService {

    private final AddressRepository repository;

    public AddressService(AddressRepository repository) {
        this.repository = repository;
    }

    public Flux<AddressDTO> getAddress(Long idLegalPeron) {
        return repository.findByIdLegalPerson(idLegalPeron)
            .map(address -> new AddressDTO(
                address.getIdAddress(),
                address.getAddressIdRefPM(),
                address.getIdLegalPerson(),
                address.getCustAccNumber(),
                address.getCreationDatetime(),
                address.getModificationDatetime(),
                address.getName1(),
                address.getAdd2(),
                address.getAdd3(),
                address.getAdd4(),
                address.getAdd5(),
                address.getAdd6(),
                address.getAdd7(),
                address.getAddressJson(),
                address.getAddressType()
            ));
    }
}
