package fr.laposte.blg.blinks.lib.common.repositories.refcom;

import fr.laposte.blg.blinks.lib.common.entities.refcom.BusinessPortfolioPositionLink;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface BusinessPortfolioPositionLinkRepository extends ReactiveCrudRepository<BusinessPortfolioPositionLink, Long> {

    Mono<BusinessPortfolioPositionLink> findByBusinessPortfolioLinkPositionId(Long businessPortfolioPositionLinkId);

    @Query("SELECT * from refcom_business_portfolio_position_link WHERE business_portfolio_id = :businessPortfolioId AND business_portfolio_link_type_id = 1 AND business_portfolio_link_position_start_date < NOW() AND (business_portfolio_link_position_end_date IS NULL OR business_portfolio_link_position_end_date > NOW()) ")
    Mono<BusinessPortfolioPositionLink> findAvailableActiveLinkForOnePortfolio(Long businessPortfolioId);


}
