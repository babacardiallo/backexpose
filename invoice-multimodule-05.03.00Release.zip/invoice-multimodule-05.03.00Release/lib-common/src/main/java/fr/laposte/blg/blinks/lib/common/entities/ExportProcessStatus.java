package fr.laposte.blg.blinks.lib.common.entities;

public enum ExportProcessStatus {
    NEW, RUNNING, SUCCESS, FAILED
}
