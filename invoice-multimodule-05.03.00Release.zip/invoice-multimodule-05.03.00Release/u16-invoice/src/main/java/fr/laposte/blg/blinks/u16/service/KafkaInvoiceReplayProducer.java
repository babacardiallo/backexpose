package fr.laposte.blg.blinks.u16.service;


import fr.laposte.bscc.avro.invoicing.Invoice;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
public class KafkaInvoiceReplayProducer {

    @Value("${fr.laposte.invoice.listener.invoice-replay.canal-suez.kafka-topic}")
    String topic;
    @Autowired
    private KafkaTemplate<String, Invoice> kafkaTemplate;

    public Mono<CompletableFuture<SendResult<String, Invoice>>> sendInvoiceToTopic(Invoice invoice) {
        return Mono.just(this.kafkaTemplate.send(topic, invoice.getInvoiceHeader().getInvoiceNumber().toString(), invoice));
    }
}
