package fr.laposte.blg.blinks.u12.service;

import fr.laposte.blg.blinks.lib.common.entities.*;
import fr.laposte.blg.blinks.lib.common.entities.repositories.ContractRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.EstablishmentRepository;
import fr.laposte.blg.blinks.lib.common.entities.repositories.MandateRepository;
import fr.laposte.blg.blinks.lib.common.service.LegalPersonService;
import fr.laposte.blg.blinks.u12.dto.EstablishmentDTO;
import fr.laposte.blg.blinks.u12.dto.LegalPersonDTO;
import fr.laposte.blg.blinks.u12.dto.MandateDTO;
import fr.laposte.blg.blinks.u12.dto.RefEquipeCommerciale;
import fr.laposte.blg.blinks.u12.mapper.EstablishmentMapperImpl;
import fr.laposte.blg.blinks.u12.mapper.LegalPersonViewMapperImpl_;
import fr.laposte.blg.blinks.u12.mapper.MandateDTOMapperImpl;
import fr.laposte.blg.blinks.u12.service.customer.LegalPersonCommunicationService;
import fr.laposte.blg.blinks.u12.service.customer.RefComCommunicationService;
import fr.laposte.blg.blinks.u12.service.establishment.EstablishmentService;
import fr.laposte.blg.blinks.u12.service.mandate.MandateService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ImportServiceTest {

    @InjectMocks
    ImportService importServiceToTest;

    @Mock
    LegalPersonService legalPersonService;

    @Mock
    LegalPersonCommunicationService legalPersonCommunicationService;

    @Mock
    RefComCommunicationService refComCommunicationService;

    @Mock
    MandateRepository mandateRepository;

    @Mock
    ContractRepository contractRepository;

    @Mock
    MandateService mandateService;

    @Mock
    EstablishmentRepository establishmentRepository;

    @Mock
    EstablishmentService establishmentService;

    @Spy
    LegalPersonViewMapperImpl_ legalPersonViewMapper;

    @Spy
    MandateDTOMapperImpl mandateDTOMapper;

    @Spy
    EstablishmentMapperImpl establishmentMapper;


    @BeforeEach
    void beforeEach() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createOrFetchCustomerChain_withAnExistingFKCustomer() {
        Mockito.when(legalPersonService.findLegalPersonByIdLegalPerson(Mockito.anyLong(), Mockito.anyBoolean()))
            .thenReturn(Mono.just(new LegalPersonEntity().setIdLegalPerson(1L).setCustAccNumber(23)));
        Mockito.when(this.legalPersonService.save(any(), anyBoolean())).thenReturn(Mono.just(new LegalPersonEntity().setBusinessTeamId(1).setBusinessTeamLongName("team").setIdLegalPerson(1L).setCustAccNumber(23)));


        ContractEntity contractEntity = new ContractEntity().setIdLegalPerson(1L).setCustAccNumber(23);

        Mockito.when(contractRepository.save(any()))
            .thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        RefEquipeCommerciale refEquipeCommerciale = new RefEquipeCommerciale(1, "team");
        when(this.refComCommunicationService.fetchTeamCodeAndName(anyInt(),Mockito.any(LocalDate.class))).thenReturn(Mono.just(refEquipeCommerciale));

        StepVerifier.create(importServiceToTest.createOrFetchCustomerChain(contractEntity))
            .assertNext(legalPersonEntity -> {
                assertEquals(1L, legalPersonEntity.getIdLegalPerson());
                assertEquals(refEquipeCommerciale.getBusinessTeamId(), legalPersonEntity.getBusinessTeamId());
                assertEquals(refEquipeCommerciale.getBusinessTeamLongName(), legalPersonEntity.getBusinessTeamLongName());
            })
            .verifyComplete();

        verify(this.legalPersonService, times(1)).findLegalPersonByIdLegalPerson(anyLong(), anyBoolean());
        verify(this.legalPersonCommunicationService, times(0)).fetchLegalPerson(anyInt());
        verify(this.legalPersonService, times(0)).findLegalPersonByCoclico(anyInt(), anyBoolean());
        verify(this.legalPersonService, times(1)).save(any(LegalPersonEntity.class), anyBoolean());

    }

    @Test
    void createOrFetchCustomerChain_withoutAnExistingFKCustomerButWithExistingCustomer() {

        ContractEntity contractEntity = new ContractEntity().setIdLegalPerson(1L).setCustAccNumber(23);

        Mockito.when(legalPersonService.findLegalPersonByIdLegalPerson(Mockito.anyLong(), Mockito.anyBoolean()))
            .thenReturn(Mono.empty());

        Mockito.when(legalPersonService.findLegalPersonByCoclico(anyInt(), anyBoolean()))
            .thenReturn(
                Mono.just(new LegalPersonEntity()
                    .setIdLegalPerson(1L)
                    .setCustAccNumber(23)
                ));
        Mockito.when(this.legalPersonService.save(any(), anyBoolean())).thenReturn(Mono.just(new LegalPersonEntity().setBusinessTeamId(1).setBusinessTeamLongName("team").setIdLegalPerson(1L).setCustAccNumber(23)));


        Mockito.when(contractRepository.save(any()))
            .thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        RefEquipeCommerciale refEquipeCommerciale = new RefEquipeCommerciale(1, "team");
        when(this.refComCommunicationService.fetchTeamCodeAndName(anyInt(),Mockito.any(LocalDate.class))).thenReturn(Mono.just(refEquipeCommerciale));

        StepVerifier.create(importServiceToTest.createOrFetchCustomerChain(contractEntity))
            .assertNext(legalPersonEntity -> {
                assertEquals(1L, legalPersonEntity.getIdLegalPerson());
                assertEquals(refEquipeCommerciale.getBusinessTeamId(), legalPersonEntity.getBusinessTeamId());
                assertEquals(refEquipeCommerciale.getBusinessTeamLongName(), legalPersonEntity.getBusinessTeamLongName());
            })
            .verifyComplete();

        verify(this.legalPersonService, times(1)).findLegalPersonByIdLegalPerson(anyLong(), anyBoolean());
        verify(this.legalPersonCommunicationService, times(0)).fetchLegalPerson(anyInt());
        verify(this.legalPersonService, times(1)).findLegalPersonByCoclico(anyInt(), anyBoolean());
        verify(this.legalPersonService, times(1)).save(any(LegalPersonEntity.class), anyBoolean());
    }

    @Test
    void createOrFetchCustomerChain_withoutCustomer() {
        ContractEntity contractEntity = new ContractEntity().setIdLegalPerson(1L).setCustAccNumber(23);
        RefEquipeCommerciale refEquipeCommerciale = new RefEquipeCommerciale(1, "team");

        Mockito.when(legalPersonService.findLegalPersonByIdLegalPerson(Mockito.anyLong(), Mockito.anyBoolean()))
                .thenReturn(Mono.empty());

        Mockito.when(legalPersonService.findLegalPersonByCoclico(anyInt(), anyBoolean()))
                .thenReturn(Mono.empty());

        LegalPersonDTO legalPersonDTO = new LegalPersonDTO()
                .setCustAccNumber("23")
                .setCustTypeCode("0");
        Mockito.when(legalPersonCommunicationService.fetchLegalPerson(anyInt()))
                .thenReturn(Mono.just(legalPersonDTO));

        Mockito.when(refComCommunicationService.fetchTeamCodeAndName(anyInt(), Mockito.any(LocalDate.class)))
                .thenReturn(Mono.just(refEquipeCommerciale));

        Mockito.when(legalPersonService.save(any(LegalPersonEntity.class), anyBoolean()))
                .thenAnswer(invocation -> {
                    LegalPersonEntity entity = invocation.getArgument(0);
                    return Mono.just(entity.setIdLegalPerson(1L));
                });

        Mockito.when(legalPersonService.saveLegalPersonMessage(any(LegalPersonEntity.class), any(LegalPersonMessage.class)))
                .thenReturn(Mono.empty());

        Mockito.when(contractRepository.save(any(ContractEntity.class)))
                .thenAnswer(invocation -> Mono.just(invocation.getArgument(0)));

        StepVerifier.create(importServiceToTest.createOrFetchCustomerChain(contractEntity).log())
                .assertNext(legalPersonEntity -> {
                    assertEquals(1L, legalPersonEntity.getIdLegalPerson());
                    assertEquals(23, legalPersonEntity.getCustAccNumber());
                    assertEquals(refEquipeCommerciale.getBusinessTeamId(), legalPersonEntity.getBusinessTeamId());
                    assertEquals(refEquipeCommerciale.getBusinessTeamLongName(), legalPersonEntity.getBusinessTeamLongName());
                })
                .verifyComplete();

        verify(legalPersonService, times(1)).findLegalPersonByIdLegalPerson(anyLong(), anyBoolean());
        verify(legalPersonService, times(1)).findLegalPersonByCoclico(anyInt(), anyBoolean());
        verify(legalPersonCommunicationService, times(1)).fetchLegalPerson(anyInt());
        verify(legalPersonService, times(2)).save(any(LegalPersonEntity.class), anyBoolean());
        verify(legalPersonService, times(1)).saveLegalPersonMessage(any(LegalPersonEntity.class), any(LegalPersonMessage.class));
        verify(refComCommunicationService, times(1)).fetchTeamCodeAndName(anyInt(), any(LocalDate.class));
    }

    @Test
    void mandateAlreadyExistsTest() {
        MandateEntity mandateEntity = new MandateEntity();
        mandateEntity.setRum("12");
        when(this.mandateRepository.findFirstByRum(anyString())).thenReturn(Mono.just(mandateEntity));

        StepVerifier.create(this.importServiceToTest.findOrFetchMandate("12"))
            .expectSubscription()
            .expectNext(mandateEntity)
            .verifyComplete();

        verify(this.mandateService, times(0)).fetchMandate(anyString());
    }

    @Test
    void mandateNotFoundTest() {
        MandateDTO mandateDTO = new MandateDTO();
        mandateDTO.setRum("12");
        mandateDTO.setBic("bic");
        mandateDTO.setIban("iban");
        mandateDTO.setStatus("valide");

        when(this.mandateRepository.findFirstByRum(anyString())).thenReturn(Mono.empty());
        when(this.mandateService.fetchMandate(anyString())).thenReturn(Mono.just(mandateDTO));
        when(this.mandateRepository.save(any())).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));

        StepVerifier.create(this.importServiceToTest.findOrFetchMandate("12"))
            .expectSubscription()
            .expectNextMatches(mandateEntity -> mandateEntity.getIdMandate() == null
                && mandateEntity.getBic().equals(mandateDTO.getBic())
                && mandateEntity.getRum().equals(mandateDTO.getRum())
                && mandateEntity.getIban().equals(mandateDTO.getIban())
                && mandateEntity.getStatus().equals(mandateDTO.getStatus())
            )
            .verifyComplete();

        verify(this.mandateService, times(1)).fetchMandate(anyString());
        verify(this.mandateRepository, times(1)).save(any());
    }

    @Test
    void establishmentAlreadyExistsTest() {
        EstablishmentEntity establishmentEntity = new EstablishmentEntity();
        establishmentEntity.setRegateCode("777777");
        establishmentEntity.setLabel("MON ETABLISSEMENT");
        establishmentEntity.setIdEstablishment(10L);
        when(this.establishmentRepository.findByRegateCode(anyString())).thenReturn(Mono.just(establishmentEntity));

        StepVerifier.create(this.importServiceToTest.findOrFetchEstablishment("777777"))
            .expectSubscription()
            .expectNext(establishmentEntity)
            .verifyComplete();

        verify(this.establishmentService, times(0)).fetchEstablishment(anyString());
    }

    @Test
    void establishmentNotFoundTest() {
        EstablishmentDTO establishmentDTO = new EstablishmentDTO();
        establishmentDTO.setLibelle("MON ETABLISSMENT");
        establishmentDTO.setCodeRegate("777777");

        when(this.establishmentRepository.findByRegateCode(anyString())).thenReturn(Mono.empty());
        when(this.establishmentService.fetchEstablishment(anyString())).thenReturn(Mono.just(establishmentDTO));
        when(this.establishmentRepository.save(any())).thenAnswer(invocationOnMock -> Mono.just(invocationOnMock.getArgument(0)));

        StepVerifier.create(this.importServiceToTest.findOrFetchEstablishment("777777"))
            .expectSubscription()
            .expectNextMatches(establishmentEntity -> establishmentEntity != null
                && establishmentEntity.getIdEstablishment() == null
                && establishmentDTO.getCodeRegate().equals(establishmentEntity.getRegateCode())
                && establishmentDTO.getLibelle().equals(establishmentEntity.getLabel())
            )
            .verifyComplete();

        verify(this.establishmentService, times(1)).fetchEstablishment(anyString());
        verify(this.establishmentRepository, times(1)).save(any());
    }


    @Test
    void fetchBusinessTeamTest() {
        RefEquipeCommerciale refEquipeCommerciale = new RefEquipeCommerciale(1, "team");
        when(this.refComCommunicationService.fetchTeamCodeAndName(anyInt(), Mockito.any(LocalDate.class))).thenReturn(Mono.just(refEquipeCommerciale));
        when(this.legalPersonService.save(any(), anyBoolean())).thenReturn(Mono.just(new LegalPersonEntity().setBusinessTeamId(1).setBusinessTeamLongName("team")));
        StepVerifier.create(this.importServiceToTest.fetchBusinessTeam(1, new LegalPersonEntity(), LocalDate.now()))
                .expectSubscription()
                .expectNextMatches(legalPersonEntity ->
                        legalPersonEntity != null
                                && legalPersonEntity.getBusinessTeamId() == refEquipeCommerciale.getBusinessTeamId()
                                && legalPersonEntity.getBusinessTeamLongName().equals(refEquipeCommerciale.getBusinessTeamLongName())
                )
                .verifyComplete();
    }
}