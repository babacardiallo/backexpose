package fr.laposte.blg.blinks.lib.common.repositories;

import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcessStatus;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ExportProcessRepository extends ReactiveCrudRepository<ExportProcess, Long> {
    @Modifying
    @Query("DELETE FROM export_process WHERE export_process_status = 'SUCCESS'")
    Mono<Integer> deleteSuccessProcess();

    Flux<ExportProcess> findAllByExportProcessStatusOrderByExecutionSequenceAsc(ExportProcessStatus exportProcessStatus);

    Mono<ExportProcess> findTopByExportProcessStatusOrderByExecutionSequenceAsc(ExportProcessStatus exportProcessStatus);

    Mono<Boolean> existsExportProcessByExportProcessStatusIn(List<ExportProcessStatus> exportProcessStatuses);
}
