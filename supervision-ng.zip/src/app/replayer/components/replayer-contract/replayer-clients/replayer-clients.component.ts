import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { MatSnackBar } from '@angular/material/snack-bar';
import { ReplayerService } from '../../../service/replay.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ReplayReport } from '../../../models/replay-report.model';
import { ClientsService } from '../../../../clients/service/clients.service';
import { ClientsTable } from '../../../../clients/models/clients-table.model';
import { atLeastOne, atLeastOneChecked } from '../../../../consts/consts';
import { takeUntil } from 'rxjs';
import { ClientPage } from '../../../../clients/models/client.page';

@Component({
    selector: 'app-replayer-clients',
    templateUrl: './replayer-clients.component.html',
    styleUrls: ['./replayer-clients.component.scss'],
    standalone: false
})
export class ReplayerClientsComponent implements OnInit, OnDestroy {

  popupFormMass: UntypedFormGroup;
  popupFormAll: UntypedFormGroup;
  @ViewChild(DatatableComponent) clients: DatatableComponent;
  listClients: any[];
  listClientsToReplay: any[];
  filteredClients: any[];
  action: any;
  date: any;
  replayReport: any;
  clientsFilled: any;
  clientsFilledInput: any;
  clientsFilledInputList: any[];
  clientsFilledFormatted: string;
  clientPage: ClientPage = new ClientPage();
  searchText = '';
  loadedIndex = 0;

  constructor(private replayerService: ReplayerService, private datePipe: DatePipe, private formBuilder: UntypedFormBuilder, private snackBar: MatSnackBar, private clientsService: ClientsService) {
  }

  ngOnInit(): void {
    this.getClients(false, 0, 5, "custAccNumber", "desc", "");
    this.initFormMass();
    this.subscribeFormMass();
    this.initFormAll();
    this.subscribeFormAll();
  }

  ngOnDestroy(): void {
    this.replayerService.ngUnsubscribe$.next();
    this.replayerService.ngUnsubscribe$.complete();
  }

  getClients(errors: boolean, page: number, itemPerPage: number, sort: string, order: string, filter: string): void {
    this.clientsService.getAllClients(errors, page, itemPerPage, sort, order, filter).subscribe({
      next: (response: any) => {
        this.listClients = response.content.map((data: any) => {
          return <ClientsTable>{
            custAccNumber: data.custAccNumber,
            name: data.name,
            brand: data.brand
          };
        })
        this.clientPage = {
          currentPage: response.pageable.pageNumber,
          itemsOnPage: response.pageable.pageSize,
          currentOffset: response.pageable.offset,
          totalPages: response.totalPages,
          totalItems: response.totalElements
      }
      },
      complete: () => { },
    });
  }

  tabClick(tab: any) {
    if(tab.index == 0 && this.loadedIndex != 0) {
      this.getClients(false, 0, 5, "custAccNumber", "desc", "");
      this.loadedIndex = 0;
    }
    this.replayReport = null;
    
  }

  onSelect(event: any) {
    this.listClientsToReplay = event.selected;
    this.showClientsFromTable()
  }

  showClientsFromTable() {
    this.clientsFilled = this.listClientsToReplay.map(value => value.custAccNumber);
    this.formatListClients();
  }

  formatListClients() {
    this.clientsFilledFormatted = this.clientsFilled.toString().split(",").join("\n");
  }

  initFormMass() {
    this.popupFormMass = this.formBuilder.group({
      checkCreateMass: new UntypedFormControl(false),
      checkUpdateMass: new UntypedFormControl(true),
      dateReplayMass: new UntypedFormControl(''),
      dateDisabledMass: new UntypedFormControl(),
      refcomReplay: new UntypedFormControl(''),
    }, {
      validator: [atLeastOne(Validators.required,
        ['dateReplayMass', 'dateDisabledMass']),
      atLeastOneChecked(['checkCreateMass', 'checkUpdateMass'])],
    });
  }

  initFormAll() {
    this.popupFormAll = this.formBuilder.group({
      checkCreateAll: new UntypedFormControl(false),
      checkUpdateAll: new UntypedFormControl(true),
      dateReplayAll: new UntypedFormControl(''),
      dateDisabledAll: new UntypedFormControl(),
      refcomReplayAll: new UntypedFormControl(''),
    }, {
      validator: [atLeastOne(Validators.required,
        ['dateReplayAll', 'dateDisabledAll']),
      atLeastOneChecked(['checkCreateAll', 'checkUpdateAll'])],
    });
  }


  replayClients() {
    this.replayReport = null;
    this.clientsFilledInputList = this.clientsFilledFormatted.split("\n");
    var refcomReplay = this.popupFormMass.get('refcomReplay')?.value ? 'true' : 'false';
    this.replayerService.replayClientsMass(this.action, this.clientsFilledInputList, refcomReplay, this.date)
      .subscribe({
        next: (response: any) => {
          if(response.waitingResponse==true){
            this.replayReport = {
              nbSuccess: response.nbSuccess,
              nbErrors: response.nbErrors,
              nbTotal: response.nbTotal,
              mapErrors: response.mapErrors,
              listSuccess: response.listSuccess
            };
          } else {
            this.snackBar.open(response.shortMessage, 'Fermer', { duration: 8000 });

          }          
        },
        complete: () => {
          this.clients.recalculate();
          this.clientsFilledFormatted = "";
          this.clientsFilled = [];
          this.clients.selected = [];
        },
      });
  }

  replayClientsAll() {
    this.replayReport = null;
    var refcomReplay = this.popupFormAll.get('refcomReplayAll')?.value ? 'true' : 'false';
    this.replayerService.replayClientsAll(this.action, refcomReplay, this.date)
      .subscribe({
        next: (response: any) => {
          this.snackBar.open(response.result, 'Fermer', { duration: 8000 });
        },
        complete: () => {
        },
      });
  }

  subscribeFormMass() {
    this.popupFormMass.get('dateDisabledMass')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe({
      next: (disableBoolean) => {
        if (disableBoolean) {
          this.popupFormMass.controls['dateReplayMass'].setValue(null, { emitEvent: false });
          this.popupFormMass.get('dateReplayMass')?.disable();
        } else {
          this.popupFormMass.get('dateReplayMass')?.enable();
          this.popupFormMass.controls['dateDisabledMass'].setValue(null, { emitEvent: false });
        }
      }
    });
    this.popupFormMass.get('checkCreateMass')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormMass.controls['checkUpdateMass'].setValue(null, { emitEvent: false });
      }
    });

    this.popupFormMass.get('checkUpdateMass')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormMass.controls['checkCreateMass'].setValue(null, { emitEvent: false });
      }
    });
  }

  subscribeFormAll() {
    this.popupFormAll.get('dateDisabledAll')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe({
      next: (disableBoolean) => {
        if (disableBoolean) {
          this.popupFormAll.controls['dateReplayAll'].setValue(null, { emitEvent: false });
          this.popupFormAll.get('dateReplayAll')?.disable();
        } else {
          this.popupFormAll.get('dateReplayAll')?.enable();
          this.popupFormAll.controls['dateDisabledAll'].setValue(null, { emitEvent: false });
        }
      }
    });
    this.popupFormAll.get('checkCreateAll')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormAll.controls['checkUpdateAll'].setValue(null, { emitEvent: false });
      }
    });

    this.popupFormAll.get('checkUpdateAll')?.valueChanges.pipe(takeUntil(this.replayerService.ngUnsubscribe$)).subscribe((checked) => {
      if (checked) {
        this.popupFormAll.controls['checkCreateAll'].setValue(null, { emitEvent: false });
      }
    });
  }

  submitFormMass(): void {
    this.date = this.formatDateCall(this.popupFormMass.get('dateReplayMass')?.value);
    this.action = this.popupFormMass.get('checkCreateMass')?.value == true ? "create" : "update";
    this.replayClients();
    this.popupFormMass.get('dateReplayMass')?.enable();
    this.popupFormMass.controls['dateDisabledMass'].setValue(null, { emitEvent: false });
    this.popupFormMass.controls['checkCreateMass'].setValue(null, { emitEvent: false });
    this.popupFormMass.controls['checkUpdateMass'].setValue(true);
    this.popupFormMass.controls['dateReplayMass'].setValue(null);
    this.popupFormMass.controls['refcomReplay'].setValue(null);
  }

  submitFormAll(): void {
    this.date = this.formatDateCall(this.popupFormAll.get('dateReplayAll')?.value);
    this.action = this.popupFormAll.get('checkCreateAll')?.value == true ? "create" : "update";
    this.replayClientsAll();
    this.popupFormAll.get('dateReplayAll')?.enable();
    this.popupFormAll.controls['dateDisabledAll'].setValue(null, { emitEvent: false });
    this.popupFormAll.controls['checkCreateAll'].setValue(null, { emitEvent: false });
    this.popupFormAll.controls['checkUpdateAll'].setValue(true);
    this.popupFormAll.controls['dateReplayAll'].setValue(null);
    this.popupFormAll.controls['refcomReplayAll'].setValue(null);
  }

  updateFilter(event: KeyboardEvent) {
    if (!event.target) {
        return null;
    }
    const val = (event.target as HTMLInputElement).value;        
    if (event.key === 'Enter') {
        this.getClients(false,0, 5, "custAccNumber", "desc", val);
    }
}


  formatDateCall(date: Date | string) {
    return this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm:ss', 'fr');
  }


  onPageChange(event: any) {
    this.getClients(false,event.offset, 5, this.clients.sorts[0].prop, this.clients.sorts[0].dir, this.searchText);  
}

  onSort(event: any) {
      this.getClients(false,this.clientPage.currentPage!, 5, event.sorts[0].prop, event.sorts[0].dir, this.searchText);
      this.clients.offset = this.clientPage.currentPage!;
  }
  

}
