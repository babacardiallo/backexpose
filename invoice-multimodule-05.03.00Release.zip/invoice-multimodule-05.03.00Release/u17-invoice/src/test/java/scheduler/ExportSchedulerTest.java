package scheduler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.json.JsonMapper;
import fr.laposte.blg.blinks.lib.common.entities.ExportHistoryEntity;
import fr.laposte.blg.blinks.lib.common.entities.ExportProcess;
import fr.laposte.blg.blinks.lib.common.entities.SchedulerParamsEntity;
import fr.laposte.blg.blinks.lib.common.repositories.ExportProcessRepository;
import fr.laposte.blg.blinks.lib.common.repositories.InvoiceRepository;
import fr.laposte.blg.blinks.u17.scheduler.ExportScheduler;
import fr.laposte.blg.blinks.u17.service.DocaposteService;
import fr.laposte.blg.blinks.u17.service.CoeurfinanceService;
import fr.laposte.blg.blinks.u17.service.InfocaInvoiceExportService;
import fr.laposte.blg.blinks.u17.util.SchedulerUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.TaskScheduler;
import reactor.core.publisher.Mono;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExportSchedulerTest {

    @InjectMocks private ExportScheduler exportScheduler;
    @Mock private DocaposteService docaposteService;
    @Mock private CoeurfinanceService coeurfinanceService;
    @Mock private InfocaInvoiceExportService infocaInvoiceExportService;
    @Mock private ExportProcessRepository exportProcessRepository;
    @Mock private InvoiceRepository invoiceRepository;
    @Mock private TaskScheduler taskScheduler;
    @Mock private SchedulerUtils schedulerUtils;

    @BeforeEach
    void setUpDirectories() throws IOException {
        SchedulerParamsEntity schedulerParams = createSchedulerParamsEntity(1L, "export_scheduler");
        exportScheduler = new ExportScheduler(docaposteService, coeurfinanceService, infocaInvoiceExportService, exportProcessRepository, invoiceRepository, schedulerParams, schedulerUtils, taskScheduler);
    }


    private SchedulerParamsEntity createSchedulerParamsEntity(Long id, String schedulerName) {
        SchedulerParamsEntity params = new SchedulerParamsEntity();
        params.setId(id);
        params.setSchedulerName(schedulerName);
        params.setCronExpression("0 * * * * *");
        params.setWaitingDelay(1);
        params.setCustomParams("");
        params.setIsEnabled(true);
        return params;
    }
    @Test
    void testSaveProcess() throws JsonProcessingException {
        String order = "{\"infoca\": 10, \"coeurfinance\": 11, \"docaposte\": 12}";
        JsonNode jsonNode = new JsonMapper().readTree(order);
        ExportHistoryEntity exportHistoryEntity = new ExportHistoryEntity();
        exportHistoryEntity.setIdExport(10L);
        when(this.invoiceRepository.getMinIdForProcess())
                .thenReturn(Mono.just(1L));
        when(this.invoiceRepository.getMaxIdForProcess())
                .thenReturn(Mono.just(2L));
        when(this.invoiceRepository.getMaxId())
                .thenReturn(Mono.just(1L));
        doAnswer(invocation -> Mono.just(invocation.getArgument(0)))
                .when(exportProcessRepository).save(any(ExportProcess.class));
        when(this.exportProcessRepository.deleteSuccessProcess())
                .thenReturn(Mono.just(1));
        when(this.schedulerUtils.mapStringToJson(anyString())).thenReturn(jsonNode);
        exportScheduler.run();
        ArgumentCaptor<ExportProcess> captor = ArgumentCaptor.forClass(ExportProcess.class);
        verify(exportProcessRepository, atLeastOnce()).save(captor.capture());
        ExportProcess savedEntity = captor.getValue();
        Assertions.assertNull(savedEntity.getErrorCode());
        Assertions.assertNull(savedEntity.getErrorMessage());
    }




}
